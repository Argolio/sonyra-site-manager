<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Status {

	public static function get_product_name(): string {
		return 'Пульт сайта';
	}

	public static function get_platform_name(): string {
		return 'SONYRA Site Platform';
	}

	public static function get_publisher(): string {
		return 'SONYRA STUDIO';
	}

	public static function get_licensor(): string {
		return 'ИП Катаев С.А. / IPKTFSA';
	}

	public static function get_technical_name(): string {
		return 'sonyra-site-manager';
	}

	public static function get_version(): string {
		return SONYRA_SITE_MANAGER_VERSION;
	}

	public static function get_release_channel(): string {
		return 'manual_zip';
	}

	public static function get_build_type(): string {
		return 'foundation';
	}

	public static function get_release_metadata(): array {
		return array(
			'product_name'    => self::get_product_name(),
			'platform_name'   => self::get_platform_name(),
			'publisher'       => self::get_publisher(),
			'licensor'        => self::get_licensor(),
			'technical_name'  => self::get_technical_name(),
			'version'         => self::get_version(),
			'release_channel' => self::get_release_channel(),
			'build_type'      => self::get_build_type(),
			'text_domain'     => 'sonyra-site-manager',
			'main_file'       => 'sonyra-site-manager.php',
			'copyright'       => '© 2026 SONYRA STUDIO',
		);
	}

	public static function get_runtime_status(): array {
		$owner_user_id                       = 0;
		$capabilities_count                  = 0;
		$audit_log_ready                     = class_exists( 'Sonyra_Site_Manager_Audit_Log' );
		$audit_events_count                  = 0;
		$db_version                          = (string) get_option( 'sonyra_site_manager_db_version', '' );
		$db_required_version                 = defined( 'SONYRA_SITE_MANAGER_DB_VERSION' ) ? SONYRA_SITE_MANAGER_DB_VERSION : '';
		$database_ready                      = false;
		$database_missing_tables             = array();
		$database_health_ready               = false;
		$database_health_checked             = false;
		$database_tables_total               = 0;
		$database_tables_existing            = 0;
		$database_tables_missing_count       = 0;
		$database_db_version_matches         = false;

		if ( class_exists( 'Sonyra_Site_Manager_Permissions' ) ) {
			$owner_user_id      = Sonyra_Site_Manager_Permissions::get_owner_user_id();
			$capabilities_count = count( Sonyra_Site_Manager_Permissions::get_capabilities() );
		}

		if ( $audit_log_ready ) {
			$audit_events_count = Sonyra_Site_Manager_Audit_Log::count_events();
		}

		if ( class_exists( 'Sonyra_Site_Manager_Database' ) ) {
			$database_status         = Sonyra_Site_Manager_Database::tables_exist();
			$database_ready          = (bool) $database_status['is_ready'];
			$database_missing_tables = $database_status['missing'];
		}

		if ( class_exists( 'Sonyra_Site_Manager_Database_Health' ) ) {
			$database_health_checked       = true;
			$database_version_status       = Sonyra_Site_Manager_Database_Health::check_db_version();
			$database_table_status         = Sonyra_Site_Manager_Database_Health::check_tables();
			$database_db_version_matches   = (bool) $database_version_status['matches'];
			$database_tables_total         = (int) $database_table_status['total_required'];
			$database_tables_existing      = (int) $database_table_status['total_existing'];
			$database_tables_missing_count = count( $database_table_status['missing'] );
			$database_health_ready         = $database_db_version_matches && (bool) $database_table_status['is_ready'];
		}

		return array(
			'product_name'                  => self::get_product_name(),
			'version'                       => self::get_version(),
			'db_version'                    => $db_version,
			'db_required_version'           => $db_required_version,
			'database_ready'                => $database_ready,
			'database_missing_tables'       => $database_missing_tables,
			'database_health_ready'         => $database_health_ready,
			'database_health_checked'       => $database_health_checked,
			'database_tables_total'         => $database_tables_total,
			'database_tables_existing'      => $database_tables_existing,
			'database_tables_missing_count' => $database_tables_missing_count,
			'database_db_version_matches'   => $database_db_version_matches,
			'installed_version'             => (string) get_option( 'sonyra_site_manager_version', '' ),
			'last_known_version'            => (string) get_option( 'sonyra_site_manager_last_known_version', '' ),
			'owner_user_id'                 => $owner_user_id,
			'release_channel'               => self::get_release_channel(),
			'build_type'                    => self::get_build_type(),
			'php_version'                   => PHP_VERSION,
			'wp_version'                    => get_bloginfo( 'version' ),
			'capabilities_count'            => $capabilities_count,
			'audit_log_ready'               => $audit_log_ready,
			'audit_events_count'            => $audit_events_count,
			'is_foundation_ready'           => '' !== self::get_version() && class_exists( 'Sonyra_Site_Manager_Permissions' ) && $capabilities_count > 0,
		);
	}
}
