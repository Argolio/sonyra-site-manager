# SONYRA Help Library Standard

## 1. Назначение

- Help Library / База знаний ПУЛЬТА САЙТА хранит help entries для question/help icons;
- все question/help icons должны ссылаться на help entries;
- help entries централизуются в registry и не размазываются по JS/PHP/CSS.

## 2. Entry shape

- `key`
- `title`
- `body`
- `category`
- `section`
- `source`
- `module_key`
- `editable`
- `i18n_title_key`
- `i18n_body_key`

## 3. Tooltip/popover behavior

- hover, focus и click/tap открывают help popover;
- `Escape` закрывает popover;
- click outside закрывает popover;
- auto-placement обязателен;
- popover должен clamp-иться внутри viewport;
- mobile behavior остаётся viewport-safe и не уходит за экран.

## 4. I18N

- видимый русский текст идёт только через `includes/i18n/ru.php`;
- hardcoded help text в JS/PHP/CSS запрещён;
- каждый help entry использует `i18n_title_key` и `i18n_body_key`;
- missing help entry не должен ломать existing UI.

## 5. Future editor

- `База знаний ПУЛЬТА САЙТА` показывается внутри `Настройки`;
- редактирование будет доступно только owner/admin;
- используется текущий manager auth/capability layer;
- отдельный login/password не используется;
- редактор не реализуется в `0.1.71`.

## 6. Module integration

- будущие modules могут регистрировать help entries через filter;
- если module отключён, его entries исчезают из registry;
- уже существующий UI должен безопасно fallback-нуться, если entry недоступен.
