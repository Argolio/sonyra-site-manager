<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Login_Renderer {

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	private static function versioned_asset_url( string $url, string $path, string $query_arg = 'ver' ): string {
		if ( ! file_exists( $path ) ) {
			return '';
		}

		$asset_mtime = filemtime( $path );
		$asset_version = SONYRA_SITE_MANAGER_VERSION;

		if ( is_int( $asset_mtime ) ) {
			$asset_version .= '-' . $asset_mtime;
		}

		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( $query_arg, $asset_version, $url );
		}

		return $url . '?' . rawurlencode( $query_arg ) . '=' . rawurlencode( $asset_version );
	}

	private static function get_request_code_config(): array {
		$rest_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/request-code' ) : '';
		$verify_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/verify-code' ) : '';
		$nonce = function_exists( 'wp_create_nonce' ) ? wp_create_nonce( 'wp_rest' ) : '';

		return array(
			'restUrl'   => $rest_url,
			'verifyUrl' => $verify_url,
			'nonce'     => $nonce,
			'messages'  => array(
				'loading'        => self::text( 'login.request_loading' ),
				'success'        => self::text( 'login.request_success' ),
				'error'          => self::text( 'login.request_error' ),
				'empty'          => self::text( 'login.request_empty' ),
				'verifyLoading'  => self::text( 'login.verify_loading' ),
				'verifySuccess'  => self::text( 'login.verify_success' ),
				'verifyError'    => self::text( 'login.verify_error' ),
				'verifyEmpty'    => self::text( 'login.verify_empty' ),
				'verifyInvalid'  => self::text( 'login.verify_invalid' ),
				'verifyNotReady' => self::text( 'login.verify_not_ready' ),
			),
		);
	}

	private static function render_request_code_config(): void {
		$config = self::get_request_code_config();
		$json_options = 0;

		if ( defined( 'JSON_HEX_TAG' ) ) {
			$json_options = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
		}

		$encoded = function_exists( 'wp_json_encode' ) ? wp_json_encode( $config, $json_options ) : json_encode( $config, $json_options );

		if ( ! is_string( $encoded ) ) {
			$encoded = '{}';
		}
		?>
		<script type="application/json" id="sonyra-login-request-code-config"><?php echo $encoded; ?></script>
		<?php
	}

	private static function render_request_code_script(): void {
		?>
		<script>
			(function () {
				'use strict';

				function setStatus(statusElement, message) {
					if (!statusElement) {
						return;
					}

					statusElement.textContent = message || '';
				}

				function getConfig() {
					var configElement = document.getElementById('sonyra-login-request-code-config');

					if (!configElement) {
						return {};
					}

					try {
						return JSON.parse(configElement.textContent || '{}');
					} catch (error) {
						return {};
					}
				}

				document.addEventListener('DOMContentLoaded', function () {
					var form = document.querySelector('[data-sonyra-login-request-form]');
					var identifierInput = document.querySelector('[data-sonyra-login-identifier]');
					var submitButton = document.querySelector('[data-sonyra-login-request-button]');
					var statusElement = document.querySelector('[data-sonyra-login-status]');
					var verifyPanel = document.querySelector('[data-sonyra-login-verify-panel]');
					var verifyForm = document.querySelector('[data-sonyra-login-verify-form]');
					var codeInput = document.querySelector('[data-sonyra-login-code-input]');
					var verifyButton = document.querySelector('[data-sonyra-login-verify-button]');
					var config = getConfig();
					var messages = config.messages || {};
					var buttonText = submitButton ? submitButton.textContent : '';
					var verifyButtonText = verifyButton ? verifyButton.textContent : '';
					var requestChallengeUuid = '';

					if (!form || !identifierInput || !submitButton || !statusElement || !config.restUrl) {
						return;
					}

					form.addEventListener('submit', function (event) {
						event.preventDefault();
						requestChallengeUuid = '';

						if (verifyPanel) {
							verifyPanel.hidden = true;
						}

						if (codeInput) {
							codeInput.value = '';
						}

						var identifier = (identifierInput.value || '').trim();

						if (!identifier) {
							setStatus(statusElement, messages.empty || '');
							identifierInput.focus();
							return;
						}

						submitButton.disabled = true;
						submitButton.textContent = messages.loading || buttonText;
						setStatus(statusElement, messages.loading || '');

						fetch(config.restUrl, {
							method: 'POST',
							credentials: 'same-origin',
							headers: {
								'Content-Type': 'application/json',
								'X-WP-Nonce': config.nonce || ''
							},
							body: JSON.stringify({
								email: identifier,
								identifier: identifier
							})
						}).then(function (response) {
							if (!response.ok) {
								throw new Error('request_failed');
							}

							return response.json();
						}).then(function (data) {
							if (!data || data.success === false) {
								throw new Error('request_failed');
							}

							requestChallengeUuid = data.challenge_uuid ? String(data.challenge_uuid) : '';

							if (!requestChallengeUuid) {
								setStatus(statusElement, messages.verifyNotReady || '');
								return;
							}

							setStatus(statusElement, messages.success || '');

							if (verifyPanel) {
								verifyPanel.hidden = false;
							}

							if (codeInput) {
								codeInput.focus();
							}
						}).catch(function () {
							setStatus(statusElement, messages.error || '');
						}).finally(function () {
							submitButton.disabled = false;
							submitButton.textContent = buttonText;
						});
					});

					if (codeInput) {
						codeInput.addEventListener('input', function () {
							codeInput.value = (codeInput.value || '').replace(/\D+/g, '').slice(0, 6);
						});
					}

					if (verifyForm && codeInput && verifyButton && config.verifyUrl) {
						verifyForm.addEventListener('submit', function (event) {
							event.preventDefault();

							var code = (codeInput.value || '').replace(/\D+/g, '').slice(0, 6);
							codeInput.value = code;

							if (!code) {
								setStatus(statusElement, messages.verifyEmpty || '');
								codeInput.focus();
								return;
							}

							if (!/^\d{6}$/.test(code)) {
								setStatus(statusElement, messages.verifyInvalid || '');
								codeInput.focus();
								return;
							}

							if (!requestChallengeUuid) {
								setStatus(statusElement, messages.verifyNotReady || '');
								return;
							}

							verifyButton.disabled = true;
							verifyButton.textContent = messages.verifyLoading || verifyButtonText;
							setStatus(statusElement, messages.verifyLoading || '');

							fetch(config.verifyUrl, {
								method: 'POST',
								credentials: 'same-origin',
								headers: {
									'Content-Type': 'application/json',
									'X-WP-Nonce': config.nonce || ''
								},
								body: JSON.stringify({
									challenge_uuid: requestChallengeUuid,
									code: code
								})
							}).then(function (response) {
								if (!response.ok) {
									throw new Error('verify_failed');
								}

								return response.json();
							}).then(function (data) {
								if (!data || data.authenticated !== true) {
									throw new Error('verify_failed');
								}

								setStatus(statusElement, messages.verifySuccess || '');
							}).catch(function () {
								setStatus(statusElement, messages.verifyError || '');
							}).finally(function () {
								verifyButton.disabled = false;
								verifyButton.textContent = verifyButtonText;
							});
						});
					}
				});
			}());
		</script>
		<?php
	}

	public static function get_preview_state(): string {
		$state = 'identifier';

		if ( isset( $_GET['sonyra_login_preview'] ) ) {
			$state = sanitize_key( wp_unslash( $_GET['sonyra_login_preview'] ) );
		}

		$allowed_states = array( 'identifier', 'code', 'success', 'error' );

		if ( ! in_array( $state, $allowed_states, true ) ) {
			return 'identifier';
		}

		return $state;
	}

	public static function render_placeholder(): void {
		self::render_login_shell();
	}

	public static function render_login_shell(): void {
		$state    = self::get_preview_state();
		$title    = self::text( 'login.title_identifier' );
		$css_url  = plugins_url( 'assets/css/sonyra-login.css', SONYRA_SITE_MANAGER_FILE );
		$logo_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-logo.png';
		$logo_url  = plugins_url( 'assets/images/brand/pult-site-logo.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_ico_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon.ico';
		$favicon_ico_url  = plugins_url( 'assets/images/brand/pult-site-favicon.ico', SONYRA_SITE_MANAGER_FILE );
		$favicon_32_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-32.png';
		$favicon_32_url  = plugins_url( 'assets/images/brand/pult-site-favicon-32.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_192_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-192.png';
		$favicon_192_url  = plugins_url( 'assets/images/brand/pult-site-favicon-192.png', SONYRA_SITE_MANAGER_FILE );
		$apple_touch_icon_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-apple-touch-icon-180.png';
		$apple_touch_icon_url  = plugins_url( 'assets/images/brand/pult-site-apple-touch-icon-180.png', SONYRA_SITE_MANAGER_FILE );
		$year     = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );
		$logo_url_with_ver = self::versioned_asset_url( $logo_url, $logo_path );
		$favicon_ico_url_with_ver = self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' );
		$favicon_32_url_with_ver = self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' );
		$favicon_192_url_with_ver = self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' );
		$apple_touch_icon_url_with_ver = self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' );
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?></title>
	<!-- SONYRA Site Manager favicon build: 0.1.28 -->
	<?php if ( '' !== $favicon_ico_url_with_ver ) : ?>
	<link rel="icon" href="<?php echo esc_url( $favicon_ico_url_with_ver ); ?>" sizes="any">
	<link rel="shortcut icon" href="<?php echo esc_url( $favicon_ico_url_with_ver ); ?>" type="image/x-icon">
	<?php endif; ?>
	<?php if ( '' !== $favicon_32_url_with_ver ) : ?>
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( $favicon_32_url_with_ver ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $favicon_192_url_with_ver ) : ?>
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( $favicon_192_url_with_ver ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $apple_touch_icon_url_with_ver ) : ?>
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( $apple_touch_icon_url_with_ver ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( SONYRA_SITE_MANAGER_VERSION ); ?>">
	<?php self::render_request_code_config(); ?>
</head>
<body class="sonyra-login-page">
	<div id="sonyra-login-root">
		<div class="sonyra-login-shell">
			<div class="sonyra-login-brand" aria-label="<?php echo esc_attr( self::text( 'login.product_name' ) ); ?>">
				<?php if ( '' !== $logo_url_with_ver ) : ?>
					<img src="<?php echo esc_url( $logo_url_with_ver ); ?>" alt="" class="sonyra-login-brand-icon" aria-hidden="true" decoding="async">
				<?php endif; ?>
				<div class="sonyra-login-brand-copy">
					<div class="sonyra-login-brand-title"><?php echo esc_html( self::text( 'login.product_name' ) ); ?></div>
					<div class="sonyra-login-brand-meta"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></div>
				</div>
			</div>

			<main class="sonyra-login-card">
				<?php if ( 'code' === $state ) : ?>
					<?php self::render_code_state(); ?>
				<?php elseif ( 'success' === $state ) : ?>
					<?php self::render_success_state(); ?>
				<?php elseif ( 'error' === $state ) : ?>
					<?php self::render_error_state(); ?>
				<?php else : ?>
					<?php self::render_identifier_state(); ?>
				<?php endif; ?>
			</main>

			<footer class="sonyra-login-footer">
				<span class="sonyra-login-footer-item"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></span>
				<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
				<span class="sonyra-login-footer-item"><?php echo esc_html( '© ' . $year . ' ' . self::text( 'login.footer_rights_holder' ) ); ?></span>
				<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
				<span class="sonyra-login-footer-item sonyra-login-footer-version"><?php echo esc_html( self::text( 'login.version_label' ) . ' ' . SONYRA_SITE_MANAGER_VERSION ); ?></span>
			</footer>
		</div>
	</div>
	<?php self::render_request_code_script(); ?>
</body>
</html>
		<?php
	}

	private static function render_identifier_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-identifier" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_identifier' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_identifier' ) ); ?></p>
			</div>

			<form class="sonyra-login-form" aria-describedby="sonyra-login-status" data-sonyra-login-request-form>
				<div class="sonyra-login-field">
					<label class="sonyra-login-label" for="sonyra-login-identifier"><?php echo esc_html( self::text( 'login.identifier_label' ) ); ?></label>
					<input class="sonyra-login-input" id="sonyra-login-identifier" type="text" name="sonyra_login_identifier" autocomplete="username" inputmode="email" placeholder="<?php echo esc_attr( self::text( 'login.identifier_placeholder' ) ); ?>" data-sonyra-login-identifier>
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="submit" data-sonyra-login-request-button><?php echo esc_html( self::text( 'login.request_button' ) ); ?></button>
			</form>

			<div id="sonyra-login-status" class="sonyra-login-status" aria-live="polite" data-sonyra-login-status>
				<span><?php echo esc_html( self::text( 'login.neutral_status_line_1' ) ); ?></span>
				<span><?php echo esc_html( self::text( 'login.neutral_status_line_2' ) ); ?></span>
			</div>

			<div class="sonyra-login-verify-panel" data-sonyra-login-verify-panel hidden>
				<div class="sonyra-login-verify-copy">
					<div class="sonyra-login-verify-title"><?php echo esc_html( self::text( 'login.verify_panel_title' ) ); ?></div>
					<div class="sonyra-login-verify-hint"><?php echo esc_html( self::text( 'login.verify_panel_hint' ) ); ?></div>
				</div>

				<form class="sonyra-login-verify-form" data-sonyra-login-verify-form>
					<div class="sonyra-login-field">
						<label class="sonyra-login-label" for="sonyra-login-verify-code"><?php echo esc_html( self::text( 'login.code_label' ) ); ?></label>
						<input class="sonyra-login-input sonyra-login-code-input" id="sonyra-login-verify-code" type="text" name="sonyra_login_verify_code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" data-sonyra-login-code-input>
					</div>

					<button class="sonyra-login-button sonyra-login-button-primary" type="submit" data-sonyra-login-verify-button><?php echo esc_html( self::text( 'login.verify_code_button' ) ); ?></button>
				</form>
			</div>
		</section>
		<?php
	}

	private static function render_code_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-code" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_code' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_code' ) ); ?></p>
			</div>

			<form class="sonyra-login-form">
				<div class="sonyra-login-field">
					<label class="sonyra-login-label" for="sonyra-login-code"><?php echo esc_html( self::text( 'login.code_label' ) ); ?></label>
					<input class="sonyra-login-input sonyra-login-input-code" id="sonyra-login-code" type="text" name="sonyra_login_code" maxlength="6" inputmode="numeric" autocomplete="one-time-code" placeholder="<?php echo esc_attr( self::text( 'login.code_placeholder' ) ); ?>">
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.verify_button' ) ); ?></button>

				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.resend' ) ); ?></button>
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.change_identifier' ) ); ?></button>
				</div>
			</form>
		</section>
		<?php
	}

	private static function render_success_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-success" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_success' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_success' ) ); ?></p>
			</div>
		</section>
		<?php
	}

	private static function render_error_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-error" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_error' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_error' ) ); ?></p>
			</div>

			<div class="sonyra-login-form">
				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.retry_button' ) ); ?></button>
				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.change_identifier' ) ); ?></button>
				</div>
			</div>
		</section>
		<?php
	}
}
