<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_REST_Auth_Controller {

	const REST_NAMESPACE = 'sonyra-site-manager/v1';

	private static $blocked_response_keys = array(
		'session_token',
		'session_token_hash',
		'token',
		'raw_token',
		'code',
		'code_hash',
		'email',
		'email_hash',
		'raw_email',
		'otp',
		'secret',
		'nonce',
		'cookie',
		'authorization',
		'debug',
		'attempts',
		'locked_until',
		'internal_reason',
	);

	public static function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/auth/request-code',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'request_code' ),
				'permission_callback' => array( __CLASS__, 'permission_public' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/auth/verify-code',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'verify_code' ),
				'permission_callback' => array( __CLASS__, 'permission_public' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/auth/logout',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'logout' ),
				'permission_callback' => array( __CLASS__, 'permission_logout' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/auth/session',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'session' ),
				'permission_callback' => array( __CLASS__, 'permission_public' ),
			)
		);
	}

	public static function permission_public(): bool {
		return true;
	}

	public static function permission_logout(): bool {
		// Logout на этом этапе idempotent; CSRF/nonce для UI-flow будет подключён отдельным этапом, метод не раскрывает детали токена или сессии.
		return true;
	}

	public static function request_code( WP_REST_Request $request ) {
		$email = self::sanitize_email_input( $request->get_param( 'email' ) );
		$request_result = array();
		$context = array(
			'source' => 'rest_auth_request_code',
			'route'  => 'auth/request-code',
		);

		if ( class_exists( 'Sonyra_Site_Manager_OTP_Request' ) ) {
			$request_result = Sonyra_Site_Manager_OTP_Request::request_login_code( $email, $context );
			self::log_event( 'auth.rest_request_code', array( 'route' => 'auth/request-code', 'result' => 'neutral_response', 'reason_code' => '', 'access_granted' => false ), 'info' );
		} else {
			self::log_event( 'auth.rest_error', array( 'route' => 'auth/request-code', 'result' => 'service_unavailable', 'reason_code' => 'otp_request_unavailable', 'access_granted' => false ), 'warning' );
		}

		$response_data = array(
			'success'   => true,
			'message'   => 'Если доступ разрешён, код будет отправлен на указанную почту.',
			'next_step' => 'Введите код из письма.',
		);

		if ( isset( $request_result['challenge_uuid'] ) && '' !== (string) $request_result['challenge_uuid'] ) {
			$response_data['challenge_uuid'] = (string) $request_result['challenge_uuid'];
		}

		return self::build_response( $response_data );
	}

	public static function verify_code( WP_REST_Request $request ) {
		$challenge_uuid = self::sanitize_challenge_uuid( $request->get_param( 'challenge_uuid' ) );
		$code = self::sanitize_code_input( $request->get_param( 'code' ) );
		$context = array(
			'source' => 'rest_auth_verify_code',
			'route'  => 'auth/verify-code',
		);

		if ( '' === $challenge_uuid || 6 !== strlen( $code ) ) {
			unset( $code );
			self::log_event( 'auth.rest_verify_code', array( 'route' => 'auth/verify-code', 'result' => 'failed', 'authenticated' => false, 'access_granted' => false, 'reason_code' => 'invalid_input' ), 'warning' );

			return self::build_verify_failure_response();
		}

		if ( ! class_exists( 'Sonyra_Site_Manager_Auth_Login' ) || ! class_exists( 'Sonyra_Site_Manager_Auth_Cookie' ) ) {
			unset( $code );
			self::log_event( 'auth.rest_error', array( 'route' => 'auth/verify-code', 'result' => 'service_unavailable', 'authenticated' => false, 'access_granted' => false, 'reason_code' => 'auth_service_unavailable' ), 'warning' );

			return self::build_verify_failure_response();
		}

		$login_result = Sonyra_Site_Manager_Auth_Login::complete_login_with_otp( $challenge_uuid, $code, $context );
		unset( $code );

		$verified = ! empty( $login_result['verified'] );
		$session_created = ! empty( $login_result['session_created'] );
		$session_token = isset( $login_result['session_token'] ) ? (string) $login_result['session_token'] : '';
		$expires_at = isset( $login_result['expires_at'] ) ? (string) $login_result['expires_at'] : '';

		unset( $login_result['session_token'] );

		if ( $verified && $session_created && '' !== $session_token ) {
			$cookie_set = Sonyra_Site_Manager_Auth_Cookie::set_auth_cookie( $session_token, $expires_at );
			unset( $session_token );

			if ( $cookie_set ) {
				self::log_event( 'auth.rest_verify_code', array( 'route' => 'auth/verify-code', 'result' => 'authenticated', 'authenticated' => true, 'access_granted' => false, 'reason_code' => '' ), 'info' );

				return self::build_response(
					array(
						'success'        => true,
						'authenticated'  => true,
						'access_granted' => false,
						'message'        => 'Вход подтверждён.',
						'next_step'      => 'Переход к Пульту сайта будет доступен после проверки доступа.',
					)
				);
			}
		}

		unset( $session_token );
		self::log_event( 'auth.rest_verify_code', array( 'route' => 'auth/verify-code', 'result' => 'failed', 'authenticated' => false, 'access_granted' => false, 'reason_code' => 'verify_failed' ), 'warning' );

		return self::build_verify_failure_response();
	}

	public static function logout( WP_REST_Request $request ) {
		unset( $request );

		if ( class_exists( 'Sonyra_Site_Manager_Auth_Cookie' ) ) {
			Sonyra_Site_Manager_Auth_Cookie::revoke_cookie_session();
		}

		self::log_event( 'auth.rest_logout', array( 'route' => 'auth/logout', 'result' => 'completed', 'authenticated' => false, 'access_granted' => false, 'reason_code' => '' ), 'info' );

		return self::build_response(
			array(
				'success' => true,
				'message' => 'Вы вышли из Пульта сайта.',
			)
		);
	}

	public static function session( WP_REST_Request $request ) {
		unset( $request );

		if ( ! class_exists( 'Sonyra_Site_Manager_Auth_Cookie' ) ) {
			self::log_event( 'auth.rest_session_checked', array( 'route' => 'auth/session', 'result' => 'unauthenticated', 'authenticated' => false, 'access_granted' => false, 'reason_code' => 'cookie_service_unavailable' ), 'info' );

			return self::build_session_unauthenticated_response();
		}

		$cookie_result = Sonyra_Site_Manager_Auth_Cookie::validate_cookie();

		if ( empty( $cookie_result['valid'] ) ) {
			self::log_event( 'auth.rest_session_checked', array( 'route' => 'auth/session', 'result' => 'unauthenticated', 'authenticated' => false, 'access_granted' => false, 'reason_code' => 'session_invalid' ), 'info' );

			return self::build_session_unauthenticated_response();
		}

		$role_key = '';

		if ( class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			$context = Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();
			$decision = Sonyra_Site_Manager_Auth_Access_Guard::can_access_manager( $context );
			$role_key = isset( $decision['role_key'] ) ? sanitize_key( (string) $decision['role_key'] ) : '';
		}

		self::log_event( 'auth.rest_session_checked', array( 'route' => 'auth/session', 'result' => 'authenticated', 'authenticated' => true, 'access_granted' => false, 'reason_code' => '' ), 'info' );

		return self::build_response(
			array(
				'success'        => true,
				'authenticated'  => true,
				'access_granted' => false,
				'message'        => 'Вход выполнен.',
				'role'           => $role_key,
			)
		);
	}

	public static function sanitize_email_input( $value ): string {
		$value = trim( strtolower( (string) $value ) );

		if ( function_exists( 'sanitize_email' ) ) {
			$value = sanitize_email( $value );
		}

		return (string) $value;
	}

	public static function sanitize_code_input( $value ): string {
		$value = preg_replace( '/\\D+/', '', (string) $value );

		return substr( (string) $value, 0, 6 );
	}

	public static function sanitize_challenge_uuid( $value ): string {
		$value = trim( (string) $value );

		if ( function_exists( 'sanitize_text_field' ) ) {
			$value = sanitize_text_field( $value );
		}

		return substr( (string) $value, 0, 100 );
	}

	public static function build_response( array $data = array(), int $status = 200 ) {
		$safe_data = self::remove_blocked_response_keys( $data );
		$response = function_exists( 'rest_ensure_response' ) ? rest_ensure_response( $safe_data ) : $safe_data;

		if ( is_object( $response ) && method_exists( $response, 'set_status' ) ) {
			$response->set_status( $status );
		}

		return $response;
	}

	public static function get_rest_auth_status(): array {
		return array(
			'controller_ready'      => true,
			'namespace'             => self::REST_NAMESPACE,
			'request_code_route'    => '/auth/request-code',
			'verify_code_route'     => '/auth/verify-code',
			'logout_route'          => '/auth/logout',
			'session_route'         => '/auth/session',
			'creates_ui'            => false,
			'grants_manager_access' => false,
			'creates_manager_route' => false,
		);
	}

	private static function build_verify_failure_response() {
		return self::build_response(
			array(
				'success'        => true,
				'authenticated'  => false,
				'access_granted' => false,
				'message'        => 'Вход не подтверждён. Проверьте код и попробуйте ещё раз.',
			)
		);
	}

	private static function build_session_unauthenticated_response() {
		return self::build_response(
			array(
				'success'        => true,
				'authenticated'  => false,
				'access_granted' => false,
				'message'        => 'Вход не выполнен.',
			)
		);
	}

	private static function remove_blocked_response_keys( array $data ): array {
		$safe_data = array();

		foreach ( $data as $key => $value ) {
			$key_string = strtolower( (string) $key );

			if ( in_array( $key_string, self::$blocked_response_keys, true ) ) {
				continue;
			}

			$safe_data[ $key ] = is_array( $value ) ? self::remove_blocked_response_keys( $value ) : $value;
		}

		return $safe_data;
	}

	private static function log_event( string $event_type, array $context, string $severity ): void {
		if ( ! class_exists( 'Sonyra_Site_Manager_Audit_Log' ) ) {
			return;
		}

		$allowed_events = array(
			'auth.rest_request_code',
			'auth.rest_verify_code',
			'auth.rest_logout',
			'auth.rest_session_checked',
			'auth.rest_denied',
			'auth.rest_error',
		);

		if ( ! in_array( $event_type, $allowed_events, true ) ) {
			$event_type = 'auth.rest_error';
		}

		Sonyra_Site_Manager_Audit_Log::log_event( $event_type, self::get_safe_audit_context( $context ), $severity );
	}

	private static function get_safe_audit_context( array $context ): array {
		$allowed = array();
		$allowed_keys = array(
			'route',
			'result',
			'authenticated',
			'access_granted',
			'reason_code',
		);

		foreach ( $allowed_keys as $key ) {
			if ( array_key_exists( $key, $context ) ) {
				$allowed[ $key ] = $context[ $key ];
			}
		}

		$allowed['access_granted'] = false;

		return $allowed;
	}
}
