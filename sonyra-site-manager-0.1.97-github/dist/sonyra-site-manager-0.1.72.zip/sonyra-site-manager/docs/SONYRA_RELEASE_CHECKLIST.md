# SONYRA Release Checklist

## Pre-release checklist

- [ ] Этап release явно разрешён.
- [ ] Все файлы этапа определены.
- [ ] Нет незавершённых STOP-условий.
- [ ] Все обязательные проверки выполнены.
- [ ] Финальный отчёт подготовлен.
- [ ] Видимое название плагина: Пульт сайта.
- [ ] Издатель: SONYRA STUDIO.
- [ ] Правообладатель/лицензиар/продавец в документах: ИП Катаев С.А. / IPKTFSA.
- [ ] Stable plugin slug: `sonyra-site-manager`.
- [ ] Корень архива внутри zip: `sonyra-site-manager/`.
- [ ] Главный файл внутри zip: `sonyra-site-manager/sonyra-site-manager.php`.
- [ ] Версионный корень вида `sonyra-site-manager-X.X.X/` запрещён.
- [ ] Техническое имя архива: sonyra-site-manager-X.X.X.zip.
- [ ] Предыдущие архивы сохранены.
- [ ] Deploy не выполнялся.

## Version consistency

- [ ] plugin header проверен.
- [ ] SONYRA_SITE_MANAGER_VERSION проверен.
- [ ] asset version проверен.
- [ ] REST bootstrap проверен.
- [ ] manager footer/about проверен.
- [ ] diagnostics проверен.
- [ ] version log проверен.
- [ ] release checklist проверен.
- [ ] mismatch отсутствует.
- [ ] При mismatch релиз остановлен.

## File structure

- [ ] Созданы только разрешённые файлы.
- [ ] Не создан лишний scaffold.
- [ ] Не добавлены лишние директории.
- [ ] Нет случайных временных файлов.
- [ ] UTF-8 без BOM подтверждён.

## No old NDD code

- [ ] Старый NDD-код не использован.
- [ ] Навигатор добрых дел не использован как источник архитектуры.
- [ ] ndd-site-manager не использован как источник архитектуры.
- [ ] manager-app.js не использован как основа.
- [ ] manager-v2 не использован как основа.

## No forbidden working names

- [ ] Используются только SONYRA, SONYRA Site Platform, SONYRA Site Manager, SONYRA STUDIO.
- [ ] Запрещённые варианты написания не используются как рабочие названия.
- [ ] Техническое имя sonyra-site-manager используется последовательно.
- [ ] Главный файл sonyra-site-manager.php указан последовательно.

## UI and i18n audit

- [ ] Видимый пользовательский интерфейс только на русском языке.
- [ ] Английские видимые UI-слова отсутствуют.
- [ ] Английские fallback-строки отсутствуют.
- [ ] `includes/i18n/ru.php` содержит активный `ru_RU` dictionary.
- [ ] `currentLocale` и `fallbackLocale` присутствуют в JS payload там, где payload используется.
- [ ] Новые i18n key names не содержат кириллицу.
- [ ] Help Library использует `i18n_title_key` и `i18n_body_key`.
- [ ] Page Elements Library использует `label_key` и `description_key`.
- [ ] Fake language switcher отсутствует.
- [ ] UI остаётся русским.
- [ ] Русские UI-строки не написаны напрямую в PHP.
- [ ] Русские UI-строки не написаны напрямую в JS.
- [ ] Русские UI-строки не написаны напрямую в HTML templates.

## Security audit

- [ ] Manager закрыт от гостей.
- [ ] Manager закрыт от пользователей без прав.
- [ ] Capability checks проверены.
- [ ] Nonce/session checks проверены.
- [ ] sanitize input проверен.
- [ ] validate input проверен.
- [ ] escape output проверен.
- [ ] audit log проверен.
- [ ] denied access events проверены.

## REST audit

- [ ] Все REST endpoints имеют permissions callbacks.
- [ ] Private endpoints закрыты.
- [ ] Public endpoints имеют явный контракт.
- [ ] Guest access разрешён только там, где это публичный контракт.
- [ ] Ошибки REST не раскрывают секреты.
- [ ] Видимые REST-сообщения на русском языке.

## Route audit

- [ ] Manager routes проверены.
- [ ] Public routes проверены.
- [ ] Embed routes проверены.
- [ ] iframe routes проверены.
- [ ] Internal diagnostics routes проверены.
- [ ] WordPress Pages не используются как основа публичных страниц.

## DB migration audit for future

- [ ] Миграции имеют версию.
- [ ] Миграции обратимы или безопасно повторяемы.
- [ ] Ошибки миграций фиксируются.
- [ ] Release останавливается при неуспешной миграции.

## Database pre-release checks for future

- [ ] Migration plan присутствует.
- [ ] Backup/rollback note присутствует.
- [ ] db version изменён намеренно.
- [ ] Migration idempotent.
- [ ] Destructive migration отсутствует.
- [ ] Version log обновлён.
- [ ] Audit event записан.

## Manager UI audit for future

- [ ] Manager shell проверен.
- [ ] Section-specific changes остаются внутри section boundary.
- [ ] Manager shell не загрязнён section business logic.
- [ ] No global CSS leaks from section styles.
- [ ] No unscoped JS leaks from section runtime.
- [ ] Section service methods задокументированы.
- [ ] No new plugin root or slug.
- [ ] No duplicate section header/hero.
- [ ] Actions размещены в существующем page header.
- [ ] Section badges размещены в header meta/chips row только на основе реальных section data.
- [ ] Item badges размещены рядом с элементом, который они описывают.
- [ ] Alerts/errors/success используют Notice Center, inline alert или field-level validation, а не decorative badges.
- [ ] No fake badges/metrics/progress/status.
- [ ] SVG icon alignment следует header standard: icon tile выровнен по kicker + title.
- [ ] Header remains compact and does not become a hero.
- [ ] Рабочие UI-цепочки доказаны.
- [ ] DOM/root selector проверен.
- [ ] loading state проверен.
- [ ] success render проверен.
- [ ] error render проверен.
- [ ] Recovery/copy debug проверен, если нужен.

## Pages table release checks

- [ ] Главный экран `Страницы` использует только колонки `Страница / В меню / Обновлена / Действия`.
- [ ] Колонки `Статус / Главная / Порядок` отсутствуют.
- [ ] Статус, `Главная` и `В меню` показаны compact badges внутри колонки `Страница`.
- [ ] Колонка `В меню` показывает `header/footer` icon + `№` позиции либо только `—`.
- [ ] Toolbar содержит поиск с icon `search` и placeholder `Найти страницу…`.
- [ ] Filters соответствуют `Все / Опубликованы / Черновики / Скрытые / В меню`.
- [ ] Sorting соответствует `Обновлены недавно / Сначала новые / А–Я / Я–А / По меню`.
- [ ] Dropdown `⋯` использует фиксированный порядок действий.
- [ ] Pages actions dropdown opens.
- [ ] `Предпросмотр`, `История изменений`, `Дублировать` активны и кликабельны.
- [ ] `SEO-настройки` остаётся disabled и не кликается.
- [ ] `Удалить` открывает destructive confirmation modal и не удаляет сразу.
- [ ] Toolbar separate from table.
- [ ] Updated header/body aligned.
- [ ] updated_at changes after save.
- [ ] visible updated date uses Intl, not toISOString slice.
- [ ] Toolbar filter icon present.
- [ ] Toolbar sort icon present and word `Сортировка` is not visible.
- [ ] Filter/sort groups have spacing.
- [ ] Accepted icons parameters/sections/open unchanged.
- [ ] Changed icons only for preview/copy link/make home/SEO/history/duplicate.
- [ ] Dynamic action shows `Скрыть` for published and `Опубликовать` for not published.
- [ ] No raw SVG.
- [ ] Dropdown lower row accessible.
- [ ] Dropdown internal scroll works.
- [ ] Publish label visible.
- [ ] No fake empty flash on reload.
- [ ] No dashboard-to-pages jump on reload.
- [ ] Success notice has icon.
- [ ] Notice icon color matches notice text via `currentColor`.
- [ ] Success notice auto-dismisses and has close button.
- [ ] Search focus remains stable while typing in `Найти страницу…`.
- [ ] Header badges under description are visible.
- [ ] Duplicate action creates a new draft page with unique slug.
- [ ] Home slug is preserved when home page changes.
- [ ] History modal opens and shows events or empty state.
- [ ] Modal header/body/footer are visually separated.
- [ ] Modal body scrolls inside modal and modal does not touch viewport bounds.
- [ ] Preview route `/sonyra-preview/{slug}/` works and is protected.
- [ ] Preview route returns `noindex,nofollow`.
- [ ] Open action uses real public route.
- [ ] Время `Обновлена` форматируется через browser/device timezone и JS `Intl`.

## Public renderer audit for future

- [ ] Собственная модель страниц проверена.
- [ ] Публичный рендер проверен.
- [ ] Output escaping проверен.
- [ ] Видимый пользовательский интерфейс только на русском языке.

## Section library release checks

- [ ] В left column есть heading `Секции`.
- [ ] Рядом с `Секции` есть help tooltip.
- [ ] Рядом с `Блоки секции` есть help tooltip.
- [ ] Tooltip texts подробные и читаемые.
- [ ] `Акцентная секция` не использует icon `app-window`.
- [ ] Delete section modal включает section name.
- [ ] Delete section modal показывает red warning icon.
- [ ] Delete section modal предупреждает про blocks внутри section.
- [ ] Delete section modal визуально воспринимается как dangerous action.
- [ ] Help popover не уходит за viewport.
- [ ] Help texts приходят из Help Library entries.
- [ ] Hardcoded tooltip text в JS/PHP/CSS отсутствует.
- [ ] Drag handle визуально отличается от смысловой icon tile.
- [ ] В `Настройки` есть reserved card `База знаний ПУЛЬТА САЙТА`.
- [ ] Все core sections selectable через modal `Добавить секцию`.
- [ ] Modal `Добавить секцию` показывает только рабочие core sections.
- [ ] Settings action секции открывает modal `Параметры секции`.
- [ ] Delete action секции открывает destructive modal `Удалить секцию?`.
- [ ] Modal `Добавить секцию` закрывается сразу после выбора одной section.
- [ ] Double-click по section card не создаёт дубли.
- [ ] Desktop workspace секций использует пропорцию около `40/60`.
- [ ] Текст section card не ломается вертикально.
- [ ] В left panel всегда видна кнопка `Добавить секцию`.
- [ ] `sonyra_site_manager_section_definitions` существует.
- [ ] Unknown type сохраняется и не удаляется молча.
- [ ] Unavailable module instance не ломает editor.
- [ ] Unavailable module instance не ломает public/preview output.
- [ ] No raw SVG inside section library UI.

## Embed/iframe audit for future

- [ ] Shortcode export используется только как export/embed-слой.
- [ ] iframe используется только как export/embed-слой.
- [ ] Embed token foundation проверен.
- [ ] iframe security foundation проверен.
- [ ] allowed domains foundation проверен.

## Классический ручной релиз

Перед сборкой:

- [ ] Проверки этапа пройдены.
- [ ] Нет STOP-срабатываний.
- [ ] Нет изменений вне разрешённых файлов.
- [ ] Версия синхронизирована.

Сборка:

- [ ] Архив создаётся только в ./dist/.
- [ ] Имя архива соответствует sonyra-site-manager-X.X.X.zip.
- [ ] Предыдущие архивы не удалены.
- [ ] Deploy не выполнялся.

После сборки:

- [ ] Наличие архива проверено.
- [ ] Размер архива проверен.
- [ ] Список файлов внутри архива проверен.
- [ ] Лишние системные файлы отсутствуют.
- [ ] .DS_Store отсутствует.
- [ ] node_modules отсутствует.
- [ ] Временные файлы отсутствуют.
- [ ] Старый NDD-код отсутствует.

Ручная проверка пользователем:

- [ ] Пользователь устанавливает zip через WordPress.
- [ ] Пользователь активирует плагин.
- [ ] Пользователь проверяет сайт.
- [ ] Пользователь проверяет экран плагина.
- [ ] При ошибке пользователь откатывается на предыдущий zip.

## Archive/package checklist for future

- [ ] Архив создаётся только на release-этапе.
- [ ] Архив не содержит временные файлы.
- [ ] Архив не содержит dev-only артефакты.
- [ ] Архив не содержит секреты.
- [ ] Архив соответствует version consistency.

## Private updater release checks

- [ ] Update endpoint проверен только на явно разрешённом updater-этапе.
- [ ] Manifest JSON валиден.
- [ ] Package URL принадлежит разрешённому домену.
- [ ] Package checksum / sha256 совпадает.
- [ ] Signature проверяется, когда signed manifest включён.
- [ ] License status проверяется, когда license/update integration включена.
- [ ] Fallback to manual zip через ./dist/ сохраняется.
- [ ] Update UI не создаётся отдельным пунктом меню WordPress.

## Extension architecture release checks

- [ ] Manifest расширения содержит compatibility metadata.
- [ ] Manifest расширения содержит license/update contract fields.
- [ ] Package URL принадлежит разрешённому repository domain.
- [ ] Checksum/signature validation предусмотрены для будущего install/update runtime.
- [ ] Расширение не ломает семь базовых разделов.
- [ ] Расширение не добавляет основные пункты меню без отдельного архитектурного решения.
- [ ] Расширение не подменяет sidebar, page header или дизайн-систему базы.
- [ ] Клиентский сайт не отправляет контент или персональные данные в центральную систему.
- [ ] Формулировки подключения к системе сопровождения не создают неверную семантику управления сайтом поставщиком.
- [ ] Zip не содержит `node_modules`, temp files, OS junk, hidden service dirs или full upstream dumps.

## Auth release checks for future

- [ ] No plain OTP storage.
- [ ] No user enumeration.
- [ ] Rate limits проверены.
- [ ] Lockout проверен.
- [ ] Session hash проверен.
- [ ] Audit events без секретов проверены.
- [ ] Russian visible UI проверен.
- [ ] wp-login не является main product UX.

## Auth cookie release checks for future

- [ ] Auth cookie содержит HttpOnly.
- [ ] Auth cookie содержит Secure on HTTPS.
- [ ] Auth cookie содержит SameSite.
- [ ] Auth token не хранится в localStorage/sessionStorage.
- [ ] Auth token не пишется в logs/audit/status.
- [ ] Logout clears cookie.
- [ ] Session revoke works.
- [ ] Access guard checked separately.

## REST auth release checks for future

- [ ] REST auth namespace correct: `sonyra-site-manager/v1`.
- [ ] `request-code` neutral response.
- [ ] `verify-code` no token in JSON.
- [ ] HttpOnly cookie set.
- [ ] `logout` clears cookie.
- [ ] `session` safe response.
- [ ] No English visible messages.
- [ ] No manager access from REST auth alone.

## Login screen release checks for future

- [ ] Login route not `wp-login`.
- [ ] Login UI Russian only.
- [ ] No password field in first release login.
- [ ] Identifier field says “Электронная почта или логин”.
- [ ] After request-code screen switches to code entry.
- [ ] No token in frontend.
- [ ] No localStorage/sessionStorage auth token.
- [ ] No email/login enumeration.
- [ ] Visual QA completed.
- [ ] Mobile QA completed.
- [ ] `/manager` protected separately.

## Final release report format

Финальный release-отчёт должен содержать:

- статус release;
- версию;
- список файлов и артефактов;
- результаты version consistency;
- результаты security audit;
- результаты REST audit;
- результаты route audit;
- результаты UI/i18n audit;
- результаты package checklist;
- STOP-условия и срабатывания;
- подтверждение, что старый NDD-код, manager-app.js и manager-v2 не использованы.

## Managed Site Agent release checks

Будущие release checks для PLATFORM/AGENT-этапов:

- [ ] No central owner UI inside managed site plugin.
- [ ] Managed site API signed.
- [ ] Unsigned commands rejected.
- [ ] Replay commands rejected.
- [ ] Unknown commands rejected.
- [ ] No arbitrary remote code execution.
- [ ] No arbitrary SQL execution.
- [ ] Telemetry excludes customer sales and personal data.
- [ ] Secrets masked.
- [ ] Command audit exists.
- [ ] Billing/access restriction safe.
- [ ] Manual restore safe.
- [ ] License/access status changes audited.
- [ ] Central Owner Control Plugin is separate.

## Pages sections workspace release checks

- [ ] В режиме `Секции` не показываются параметры страницы.
- [ ] Workspace имеет two-column layout: sections left, blocks right.
- [ ] Section card text не ломается вертикально.
- [ ] Block card text не ломается вертикально.
- [ ] Delete section confirmation работает через destructive modal.
- [ ] Delete block confirmation работает через destructive modal.
- [ ] Drag handles reorder sections и сохраняют порядок.
- [ ] Drag handles reorder blocks и сохраняют порядок.
- [ ] Sidebar collapsed reload проходит без flicker.
