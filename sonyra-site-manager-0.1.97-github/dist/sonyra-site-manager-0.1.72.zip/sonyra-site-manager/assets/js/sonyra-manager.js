(function () {
	'use strict';

	var STORAGE_KEY = 'sonyra_manager_sidebar_state';
	var MOBILE_QUERY = '(max-width: 780px)';
	var shell = document.querySelector('[data-manager-shell]');

	if (!shell) {
		return;
	}

	var toggleButton = shell.querySelector('[data-manager-sidebar-toggle]');
	var logoButton = shell.querySelector('[data-manager-logo-toggle]');
	var sidebar = shell.querySelector('.sonyra-manager-sidebar');
	var backdrop = shell.querySelector('[data-manager-backdrop]');
	var routeButtons = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-route]'));
	var views = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-view]'));
	var pageKicker = shell.querySelector('[data-manager-kicker]');
	var topbarTitle = shell.querySelector('[data-manager-title]');
	var pageDescription = shell.querySelector('[data-manager-description]');
	var pageHeaderIcon = shell.querySelector('[data-manager-header-icon]');
	var pageBadges = shell.querySelector('[data-manager-badges]');
	var headerActionGroups = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-header-actions]'));
	var activeRoute = 'dashboard';
	var logoutButton = shell.querySelector('[data-manager-logout]');
	var logoutError = shell.querySelector('[data-manager-logout-error]');
	var noticeCenter = shell.querySelector('[data-manager-notice-center]');
	var supportModal = shell.querySelector('[data-manager-notice-support-modal]');
	var mediaQuery = window.matchMedia ? window.matchMedia(MOBILE_QUERY) : null;
	var sidebarMotionTimer = 0;
	var noticeTimers = {};

	function isMobile() {
		return mediaQuery ? mediaQuery.matches : window.innerWidth <= 780;
	}

	function getStoredState() {
		try {
			var value = window.localStorage.getItem(STORAGE_KEY);
			return value === 'collapsed' || value === 'expanded' ? value : '';
		} catch (error) {
			return '';
		}
	}

	function storeState(state) {
		try {
			window.localStorage.setItem(STORAGE_KEY, state);
		} catch (error) {}
	}

	function clearSidebarMotionTimer() {
		if (sidebarMotionTimer) {
			window.clearTimeout(sidebarMotionTimer);
			sidebarMotionTimer = 0;
		}
	}

	function finishSidebarMotion() {
		clearSidebarMotionTimer();
		shell.removeAttribute('data-sidebar-motion');
	}

	function beginSidebarMotion() {
		clearSidebarMotionTimer();
		shell.setAttribute('data-sidebar-motion', 'active');
		sidebarMotionTimer = window.setTimeout(finishSidebarMotion, 340);
	}

	function setSidebarState(state, shouldStore, shouldAnimate) {
		var nextState = state === 'collapsed' ? 'collapsed' : 'expanded';
		var currentState = shell.getAttribute('data-sidebar-state') || '';
		var shouldRunMotion = shouldAnimate === true && currentState && currentState !== nextState;
		var expanded = nextState === 'expanded';

		if (shouldRunMotion) {
			beginSidebarMotion();
		}

		document.documentElement.classList.toggle('sonyra-sidebar-collapsed', nextState === 'collapsed');
		shell.setAttribute('data-sidebar-state', nextState);
		shell.classList.toggle('sonyra-manager-mobile-open', expanded && isMobile());

		if (toggleButton) {
			toggleButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			toggleButton.setAttribute('aria-label', expanded ? (toggleButton.dataset.labelExpanded || '') : (toggleButton.dataset.labelCollapsed || ''));
		}

		if (logoButton) {
			logoButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			logoButton.setAttribute('aria-label', expanded ? (logoButton.dataset.labelExpanded || '') : (logoButton.dataset.labelCollapsed || ''));
		}

		if (backdrop) {
			backdrop.hidden = !(expanded && isMobile());
		}

		if (shouldStore) {
			storeState(nextState);
		}
	}

	function handleSidebarTransitionEnd(event) {
		if (!shell.hasAttribute('data-sidebar-motion')) {
			return;
		}

		if (
			(event.target === shell && event.propertyName === 'grid-template-columns') ||
			(event.target === sidebar && event.propertyName === 'width')
		) {
			finishSidebarMotion();
		}
	}

	function getRouteFromHash() {
		var hash = window.location.hash || '';
		var route = hash.replace(/^#\/?/, '').replace(/^\//, '');
		return route || 'dashboard';
	}

	function normalizeRoute(route) {
		var found = views.some(function (view) {
			return view.getAttribute('data-manager-view') === route;
		});

		return found ? route : 'dashboard';
	}

	function findTemplate(selector, route) {
		return shell.querySelector(selector + '="' + route + '"]');
	}

	function clearNode(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function updateHeaderIcon(route) {
		var iconTemplate = findTemplate('[data-manager-icon-template', route);

		if (pageHeaderIcon && iconTemplate && iconTemplate.firstElementChild) {
			clearNode(pageHeaderIcon);
			pageHeaderIcon.appendChild(iconTemplate.firstElementChild.cloneNode(true));
		}
	}

	function updateHeaderBadges(route) {
		var badgeTemplate = findTemplate('[data-manager-badge-template', route);

		if (pageBadges && badgeTemplate && badgeTemplate.firstElementChild) {
			pageBadges.parentNode.replaceChild(badgeTemplate.firstElementChild.cloneNode(true), pageBadges);
			pageBadges = shell.querySelector('[data-manager-badges]');
		}
	}

	function updateHeaderActions(route) {
		headerActionGroups.forEach(function (group) {
			group.hidden = group.getAttribute('data-manager-header-actions') !== route;
		});
	}

	function setRoute(route, shouldUpdateHash) {
		var nextRoute = normalizeRoute(route);
		var activeButton = null;
		activeRoute = nextRoute;

		views.forEach(function (view) {
			view.hidden = view.getAttribute('data-manager-view') !== nextRoute;
		});

		routeButtons.forEach(function (button) {
			var isActive = button.getAttribute('data-manager-route') === nextRoute;
			button.classList.toggle('sonyra-manager-nav-item-active', isActive);

			if (isActive) {
				button.setAttribute('aria-current', 'page');
				activeButton = button;
			} else {
				button.removeAttribute('aria-current');
			}
		});

		if (activeButton) {
			if (pageKicker) {
				pageKicker.textContent = activeButton.dataset.kicker || '';
			}

			if (topbarTitle) {
				topbarTitle.textContent = activeButton.dataset.title || activeButton.textContent || '';
			}

			if (pageDescription) {
				pageDescription.textContent = activeButton.dataset.description || '';
			}

			updateHeaderIcon(nextRoute);
			updateHeaderBadges(nextRoute);
			updateHeaderActions(nextRoute);
		}

		if (shouldUpdateHash && window.location.hash !== '#/' + nextRoute) {
			window.location.hash = '#/' + nextRoute;
		}

		if (isMobile()) {
			setSidebarState('collapsed', false, true);
		}

		if (SonyraPagesSection && typeof SonyraPagesSection.handleRouteChange === 'function') {
			SonyraPagesSection.handleRouteChange(nextRoute);
		}

		shell.removeAttribute('data-manager-booting');
	}

	function showLogoutError() {
		if (noticeCenter) {
			noticeCenter.hidden = false;
		}

		if (logoutError) {
			logoutError.hidden = false;
		}
	}

	function closeSupportModal() {
		if (supportModal) {
			supportModal.hidden = true;
		}
	}

	function openSupportModal() {
		if (supportModal) {
			supportModal.hidden = false;
			var closeButton = supportModal.querySelector('[data-manager-notice-modal-close]');

			if (closeButton) {
				closeButton.focus();
			}
		}
	}

	function clearNoticeTimer(targetId) {
		if (!targetId || !noticeTimers[targetId]) {
			return;
		}

		window.clearTimeout(noticeTimers[targetId]);
		delete noticeTimers[targetId];
	}

	function getNoticeAutoDismissDelay(type) {
		if (type === 'success') {
			return 4000;
		}

		if (type === 'info') {
			return 6000;
		}

		return 0;
	}

	function dismissNotice(targetId) {
		if (!targetId) {
			return;
		}

		clearNoticeTimer(targetId);
		var notice = shell.querySelector('[data-manager-notice-id="' + targetId + '"]');

		if (notice) {
			notice.classList.add('is-dismissing');
			window.setTimeout(function () {
				notice.hidden = true;
				notice.classList.remove('is-dismissing');

				if (noticeCenter && !noticeCenter.querySelector('.sonyra-manager-notice-card:not([hidden])')) {
					noticeCenter.hidden = true;
				}
			}, 180);
			return;
		}

		if (noticeCenter && !noticeCenter.querySelector('.sonyra-manager-notice-card:not([hidden])')) {
			noticeCenter.hidden = true;
		}
	}

	function scheduleNoticeAutoDismiss(notice) {
		if (!notice) {
			return;
		}

		var targetId = notice.getAttribute('data-manager-notice-id') || '';
		var delay = getNoticeAutoDismissDelay(notice.getAttribute('data-manager-notice-type') || '');

		clearNoticeTimer(targetId);

		if (!targetId || delay <= 0) {
			return;
		}

		noticeTimers[targetId] = window.setTimeout(function () {
			dismissNotice(targetId);
		}, delay);
	}

	function initRenderedNotices() {
		if (!noticeCenter) {
			return;
		}

		Array.prototype.slice.call(noticeCenter.querySelectorAll('[data-manager-notice-id]')).forEach(function (notice) {
			scheduleNoticeAutoDismiss(notice);
		});
	}

	function handleNoticeAction(event) {
		var actionButton = event.target.closest('[data-manager-notice-action], [data-manager-notice-modal-close]');

		if (!actionButton || !shell.contains(actionButton) && (!supportModal || !supportModal.contains(actionButton))) {
			return;
		}

		if (actionButton.disabled) {
			return;
		}

		if (actionButton.hasAttribute('data-manager-notice-modal-close')) {
			event.preventDefault();
			closeSupportModal();
			return;
		}

		var action = actionButton.getAttribute('data-manager-notice-action') || '';

		if (action === 'reload') {
			event.preventDefault();
			window.location.reload();
			return;
		}

		if (action === 'dismiss') {
			event.preventDefault();
			dismissNotice(actionButton.getAttribute('data-manager-notice-target') || '');
			return;
		}

		if (action === 'open_modal') {
			event.preventDefault();
			openSupportModal();
		}
	}

	function redirectToLogin() {
		var loginUrl = shell.getAttribute('data-login-url') || '/manager/login';
		window.location.assign(loginUrl);
	}

	function runLogout() {
		var logoutUrl = shell.getAttribute('data-logout-url') || '';

		if (!logoutUrl || logoutUrl.indexOf('://') === -1 && logoutUrl.charAt(0) !== '/') {
			showLogoutError();
			return;
		}

		if (logoutButton) {
			logoutButton.disabled = true;
		}

		fetch(logoutUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': shell.getAttribute('data-nonce') || ''
			},
			body: '{}'
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('logout_failed');
			}

			return response.json().catch(function () {
				return {};
			});
		}).then(function () {
			redirectToLogin();
		}).catch(function () {
			showLogoutError();

			if (logoutButton) {
				logoutButton.disabled = false;
			}
		});
	}

	var SonyraPagesSection;
	var pagesRoot = shell.querySelector('[data-manager-pages-root]');
	var pagesState = {
		items: [],
		pagesStatus: 'loading',
		activeId: '',
		activeSectionId: '',
		saving: false,
		loaded: false,
		mode: 'table',
		searchQuery: '',
		statusFilter: 'all',
		sort: 'recent',
		openDropdownId: '',
		openAddMenu: '',
		pageModalOpen: false,
		sectionLibraryModalOpen: false,
		sectionModalOpen: false,
		blockModalOpen: false,
		historyModalOpen: false,
		deleteModalOpen: false,
		modalDraft: null,
		sectionDraft: null,
		blockDraft: null,
		historyTargetId: '',
		deleteTargetType: '',
		deleteTargetId: '',
		deleteTargetParentId: '',
		openHelpTooltip: '',
		openHelpTooltipPinned: false,
		openHelpTooltipTrigger: '',
		addingSection: false,
		pendingSectionType: '',
		dragSectionId: '',
		dragBlockId: '',
		lastTrigger: null,
		pendingPageId: '',
		pendingAction: ''
	};
	var pagesI18n = {};
	var currentLocale = 'ru_RU';
	var fallbackLocale = 'ru_RU';
	var helpEntries = {};
	var sectionDefinitions = [];
	var pagesMain = shell.querySelector('.sonyra-manager-main');
	var browserTimeZone = '';

	function initPagesI18n() {
		var node = document.getElementById('sonyra-manager-pages-i18n');

		if (!node) {
			return;
		}

		try {
			var payload = JSON.parse(node.textContent || '{}') || {};
			if (payload && typeof payload === 'object' && payload.dictionary) {
				currentLocale = String(payload.currentLocale || 'ru_RU');
				fallbackLocale = String(payload.fallbackLocale || currentLocale || 'ru_RU');
				pagesI18n = payload.dictionary && typeof payload.dictionary === 'object' ? payload.dictionary : {};
			} else {
				pagesI18n = payload && typeof payload === 'object' ? payload : {};
			}
		} catch (error) {
			pagesI18n = {};
			currentLocale = 'ru_RU';
			fallbackLocale = 'ru_RU';
		}
	}

	function t(key) {
		return pagesI18n[key] || '';
	}

	function initSectionDefinitions() {
		var node = document.getElementById('sonyra-manager-pages-sections-library');

		if (!node) {
			return;
		}

		try {
			sectionDefinitions = (JSON.parse(node.textContent || '[]') || []).map(normalizeSectionDefinition).filter(function (definition) {
				return Boolean(definition.type);
			});
		} catch (error) {
			sectionDefinitions = [];
		}
	}

	function initHelpEntries() {
		var node = document.getElementById('sonyra-manager-help-entries');

		if (!node) {
			return;
		}

		try {
			(JSON.parse(node.textContent || '[]') || []).forEach(function (entry) {
				if (entry && entry.key) {
					helpEntries[String(entry.key)] = entry;
				}
			});
		} catch (error) {
			helpEntries = {};
		}
	}

	function getHelpEntry(key) {
		return helpEntries[String(key || '')] || null;
	}

	function normalizeSectionDefinition(definition) {
		var normalized = definition && typeof definition === 'object' ? definition : {};

		if (!normalized.type || !normalized.label || !normalized.description || !normalized.icon_key || !normalized.category) {
			return {};
		}

		return {
			type: normalized.type || '',
			label: normalized.label || '',
			description: normalized.description || '',
			label_key: normalized.label_key || '',
			description_key: normalized.description_key || '',
			icon_key: normalized.icon_key || 'circle-dot',
			category: normalized.category || 'content',
			provider: normalized.provider || 'core',
			module_key: normalized.module_key || '',
			status: normalized.status || 'implemented',
			default_section: normalized.default_section && typeof normalized.default_section === 'object' ? normalized.default_section : {},
			default_blocks: Array.isArray(normalized.default_blocks) ? normalized.default_blocks : [],
			fields: Array.isArray(normalized.fields) ? normalized.fields : [],
			default_block_name_key: normalized.default_block_name_key || ''
		};
	}

	function getSectionDefinitions() {
		return sectionDefinitions.slice();
	}

	function getSectionDefinition(type) {
		return getSectionDefinitions().find(function (definition) {
			return definition.type === type;
		}) || null;
	}

	function getSectionCategoryLabel(category) {
		return t('manager.page_elements.categories.' + String(category || 'content')) || t('manager.pages.library.category.' + String(category || 'content')) || '';
	}

	function initPagesLocale() {
		try {
			browserTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
		} catch (error) {
			browserTimeZone = '';
		}
	}

	function createId(prefix) {
		return (prefix || 'id') + '-' + String(Date.now()) + '-' + String(Math.floor(Math.random() * 100000));
	}

	function normalizePage(page) {
		var normalized = page && typeof page === 'object' ? page : {};

		return {
			id: normalized.id || createId('page'),
			title: normalized.title || '',
			slug: normalized.slug || '',
			status: normalized.status || 'draft',
			is_home: normalized.is_home === true,
			show_in_menu: normalized.show_in_menu === true,
			menu_title: normalized.menu_title || '',
			menu_order: Number(normalized.menu_order || 10),
			seo_title: normalized.seo_title || '',
			seo_description: normalized.seo_description || '',
			sections: ensureUniqueTitles(Array.isArray(normalized.sections) ? normalized.sections.map(normalizeSection) : [], function (section) {
				return section.name || getDefaultSectionTitle(section.type);
			}),
			history: Array.isArray(normalized.history) ? normalized.history.map(normalizeHistoryEvent) : [],
			created_at: normalized.created_at || '',
			updated_at: normalized.updated_at || '',
			public_url: normalized.public_url || '',
			preview_url: normalized.preview_url || '',
			can_open: normalized.can_open === true
		};
	}

	function normalizeHistoryEvent(event) {
		var normalized = event && typeof event === 'object' ? event : {};

		return {
			at: normalized.at || new Date().toISOString(),
			action: normalized.action || '',
			label: normalized.label || '',
			details: normalized.details || ''
		};
	}

	function normalizeSection(section) {
		var normalized = section && typeof section === 'object' ? section : {};
		var definition = getSectionDefinition(normalized.type || '');
		var type = normalized.type || 'text';
		var blocks = Array.isArray(normalized.blocks) ? normalized.blocks.map(function (block) {
			return normalizeBlock(block, type);
		}) : [];
		var defaultSection = definition && definition.default_section && typeof definition.default_section === 'object' ? definition.default_section : {};

		if (!blocks.length && hasLegacySectionContent(normalized)) {
			blocks.push(normalizeBlock({
				type: getDefaultBlockType(type),
				heading: normalized.title || '',
				kicker: normalized.kicker || '',
				text: normalized.text || '',
				description: normalized.text || '',
				button_label: normalized.button_label || '',
				button_url: normalized.button_url || '',
				email: normalized.email || '',
				phone: normalized.phone || '',
				address: normalized.address || ''
			}, type));
		}

		if (!blocks.length && Array.isArray(defaultSection.blocks) && defaultSection.blocks.length) {
			blocks = defaultSection.blocks.map(function (block) {
				return normalizeBlock(block, type);
			});
		}

		return {
			id: normalized.id || createId('section'),
			type: type,
			name: normalized.name || '',
			blocks: ensureUniqueTitles(blocks, function (block) {
				return block.name || getDefaultBlockTitle(block.type);
			}),
			provider: normalized.provider || (defaultSection.provider || 'core'),
			module_key: normalized.module_key || defaultSection.module_key || '',
			unavailable: normalized.unavailable === true || !definition
		};
	}

	function normalizeBlock(block, fallbackType) {
		var normalized = block && typeof block === 'object' ? block : {};
		var originalType = normalized.type || getDefaultBlockType(fallbackType);
		var type = ['hero', 'text', 'contacts'].indexOf(originalType) >= 0 ? originalType : originalType;

		return {
			id: normalized.id || createId('block'),
			type: type,
			name: normalized.name || '',
			kicker: normalized.kicker || '',
			heading: normalized.heading || normalized.title || '',
			text: normalized.text || '',
			description: normalized.description || (type === 'contacts' ? (normalized.text || '') : ''),
			button_label: normalized.button_label || '',
			button_url: normalized.button_url || '',
			email: normalized.email || '',
			phone: normalized.phone || '',
			address: normalized.address || '',
			unavailable: normalized.unavailable === true || ['hero', 'text', 'contacts'].indexOf(type) < 0
		};
	}

	function hasLegacySectionContent(section) {
		return ['kicker', 'title', 'text', 'button_label', 'button_url', 'email', 'phone', 'address'].some(function (key) {
			return Boolean(section && section[key]);
		});
	}

	function ensureUniqueTitles(items, getBaseTitle) {
		var used = [];

		return items.map(function (item) {
			var nextItem = item;
			var currentTitle = item.name || '';
			var baseTitle = typeof getBaseTitle === 'function' ? getBaseTitle(item) : currentTitle;
			nextItem.name = buildUniqueTitle(currentTitle || baseTitle, used);
			used.push(nextItem.name);
			return nextItem;
		});
	}

	function buildUniqueTitle(baseTitle, usedTitles) {
		var base = String(baseTitle || '').trim();
		var suffix = 1;
		var candidate = base;

		if (!base) {
			return '';
		}

		while (usedTitles.indexOf(candidate) >= 0) {
			candidate = base + ' ' + String(suffix);
			suffix += 1;
		}

		return candidate;
	}

	function getTypeConfig(type) {
		var baseConfig = {
			hero: {
				sectionTitle: t('manager.pages.section_types.hero'),
				blockTitleKey: 'manager.pages.block_types.hero',
				sectionLabel: t('manager.pages.sections.hero'),
				blockLabelKey: 'manager.pages.block_types.hero',
				sectionIcon: 'sparkles',
				blockIcon: 'app-window'
			},
			text: {
				sectionTitle: t('manager.pages.section_types.text'),
				blockTitleKey: 'manager.pages.block_types.text',
				sectionLabel: t('manager.pages.sections.text'),
				blockLabelKey: 'manager.pages.sections.block_text',
				sectionIcon: 'file-text',
				blockIcon: 'align-left'
			},
			contacts: {
				sectionTitle: t('manager.pages.section_types.contacts'),
				blockTitleKey: 'manager.pages.block_types.contacts',
				sectionLabel: t('manager.pages.sections.contacts'),
				blockLabelKey: 'manager.pages.sections.block_contacts',
				sectionIcon: 'address-book',
				blockIcon: 'mail'
			}
		}[type || 'text'] || {
			sectionTitle: t('manager.pages.sections.module_unavailable'),
			blockTitleKey: 'manager.pages.block_types.text',
			sectionLabel: t('manager.pages.sections.module_unavailable'),
			blockLabelKey: 'manager.pages.sections.block_text',
			sectionIcon: 'file-text',
			blockIcon: 'align-left'
		};
		var sectionDefinition = getSectionDefinition(type);

		if (sectionDefinition) {
			baseConfig.sectionTitle = sectionDefinition.label;
			baseConfig.sectionLabel = sectionDefinition.label;
			baseConfig.sectionIcon = sectionDefinition.icon_key;
			baseConfig.sectionDescription = sectionDefinition.description;
		}

		return baseConfig;
	}

	function getDefaultSectionTitle(type) {
		return getTypeConfig(type).sectionTitle || '';
	}

	function getDefaultBlockTitle(type) {
		return t(getTypeConfig(type).blockTitleKey);
	}

	function getSectionTypeLabel(type) {
		return getTypeConfig(type).sectionLabel || '';
	}

	function getBlockTypeLabel(type) {
		return t(getTypeConfig(type).blockLabelKey);
	}

	function replacePlaceholder(template, value) {
		return String(template || '').replace('%s', String(value || ''));
	}

	function getDeleteTargetName(type, targetId, parentId) {
		var page;
		var section;
		var block;

		if (type === 'section') {
			section = getSectionById(getActivePage(), targetId);
			return section ? (section.name || getSectionTypeLabel(section.type)) : '';
		}

		if (type === 'block') {
			section = getSectionById(getActivePage(), parentId);

			if (!section) {
				return '';
			}

			block = (section.blocks || []).find(function (item) {
				return item.id === targetId;
			}) || null;

			return block ? (block.name || getBlockTypeLabel(block.type)) : '';
		}

		page = findPage(targetId);
		return page ? (page.title || page.slug || '') : '';
	}

	function getDefaultBlockType(sectionType) {
		var definition = getSectionDefinition(sectionType);
		var defaults = definition && definition.default_blocks && definition.default_blocks[0] ? definition.default_blocks[0] : null;

		if (defaults && ['hero', 'text', 'contacts'].indexOf(defaults.type) >= 0) {
			return defaults.type;
		}

		return ['hero', 'text', 'contacts'].indexOf(sectionType) >= 0 ? sectionType : 'text';
	}

	function findPage(id) {
		return pagesState.items.find(function (item) {
			return item.id === id;
		}) || null;
	}

	function getActivePage() {
		return findPage(pagesState.activeId);
	}

	function getActiveSection(page) {
		var currentPage = page || getActivePage();

		if (!currentPage) {
			return null;
		}

		if (!pagesState.activeSectionId && currentPage.sections[0]) {
			pagesState.activeSectionId = currentPage.sections[0].id;
		}

		return currentPage.sections.find(function (section) {
			return section.id === pagesState.activeSectionId;
		}) || currentPage.sections[0] || null;
	}

	function getSectionById(page, sectionId) {
		var currentPage = page || getActivePage();

		if (!currentPage) {
			return null;
		}

		return currentPage.sections.find(function (section) {
			return section.id === sectionId;
		}) || null;
	}

	function isPagesTableMobile() {
		return window.innerWidth <= 767;
	}

	function clonePagesIcon(key) {
		var template = pagesRoot ? pagesRoot.querySelector('[data-pages-icon-template="' + key + '"]') : null;

		if (!template || !template.firstElementChild) {
			return document.createTextNode('');
		}

		return template.firstElementChild.cloneNode(true);
	}

	function setPagesMessage(type, message) {
		var messageNode = pagesRoot ? pagesRoot.querySelector('[data-pages-message]') : null;
		var iconKey = 'info-circle';
		var icon;
		var text;
		var closeButton;

		if (!messageNode) {
			return;
		}

		if (!message) {
			clearNoticeTimer('pages-message');
			messageNode.hidden = true;
			messageNode.textContent = '';
			messageNode.removeAttribute('data-pages-message-type');
			messageNode.removeAttribute('data-manager-notice-type');
			messageNode.classList.remove('is-dismissing');
			return;
		}

		if (type === 'success') {
			iconKey = 'circle-check';
		} else if (type === 'warning') {
			iconKey = 'alert-triangle';
		} else if (type === 'error') {
			iconKey = 'alert-circle';
		} else if (type === 'loading') {
			iconKey = 'progress';
		}

		clearNode(messageNode);
		messageNode.hidden = false;
		messageNode.setAttribute('data-pages-message-type', type || 'info');
		messageNode.setAttribute('data-manager-notice-type', type || 'info');

		icon = createTextNode('span', 'sonyra-manager-notice__icon');
		icon.appendChild(clonePagesIcon(iconKey));
		text = createTextNode('span', 'sonyra-manager-notice__text', message);
		messageNode.appendChild(icon);
		messageNode.appendChild(text);

		if (type !== 'loading') {
			closeButton = document.createElement('button');
			closeButton.type = 'button';
			closeButton.className = 'sonyra-manager-notice__close';
			closeButton.setAttribute('data-pages-message-close', 'true');
			closeButton.setAttribute('aria-label', t('manager.notice_close_label'));
			closeButton.appendChild(clonePagesIcon('x'));
			messageNode.appendChild(closeButton);
		}

		clearNoticeTimer('pages-message');

		if (type === 'success' || type === 'info') {
			noticeTimers['pages-message'] = window.setTimeout(function () {
				messageNode.classList.add('is-dismissing');
				window.setTimeout(function () {
					setPagesMessage('', '');
				}, 180);
			}, type === 'success' ? 4000 : 6000);
		}
	}

	function getPagesUrl(page) {
		if (!page) {
			return '';
		}

		if (page.public_url) {
			return page.public_url;
		}

		var siteUrl = shell.getAttribute('data-site-url') || '/';

		if (page.is_home) {
			return siteUrl;
		}

		return siteUrl.replace(/\/?$/, '/') + (page.slug || '').replace(/^\/|\/$/g, '') + '/';
	}

	function getPagePreviewUrl(page) {
		if (!page) {
			return '';
		}

		if (page.preview_url) {
			return page.preview_url;
		}

		var siteUrl = shell.getAttribute('data-site-url') || '/';
		var normalizedBase = siteUrl.replace(/\/?$/, '/');
		var slug = (page.slug || '').replace(/^\/|\/$/g, '');

		if (slug) {
			return normalizedBase + 'sonyra-preview/' + slug + '/';
		}

		return normalizedBase + 'sonyra-preview/id/' + (page.id || '') + '/';
	}

	function formatCountLabel(key, count) {
		return t(key).replace('%d', String(count));
	}

	function getPagesSummary() {
		return pagesState.items.reduce(function (summary, page) {
			summary.total += 1;
			if (page.status === 'published') {
				summary.published += 1;
			} else if (page.status === 'hidden') {
				summary.hidden += 1;
			} else {
				summary.draft += 1;
			}

			if (page.is_home) {
				summary.hasHome = true;
			}

			return summary;
		}, {
			total: 0,
			published: 0,
			draft: 0,
			hidden: 0,
			hasHome: false
		});
	}

	function createHeaderMetaChip(label, tone) {
		return createTextNode('span', 'sonyra-manager-page-badge sonyra-manager-page-header__meta-chip sonyra-manager-page-badge-' + (tone || 'neutral'), label);
	}

	function getHistoryEventLabel(action) {
		var key = 'manager.pages.history.event.' + action;
		var value = t(key);
		return value || '';
	}

	function addPageHistoryEvent(page, action, details) {
		if (!page) {
			return page;
		}

		page.history = Array.isArray(page.history) ? page.history.slice() : [];
		page.history.unshift({
			at: new Date().toISOString(),
			action: action,
			label: getHistoryEventLabel(action),
			details: details || ''
		});
		page.history = page.history.slice(0, 50);
		return page;
	}

	function clearPendingPageAction() {
		pagesState.pendingPageId = '';
		pagesState.pendingAction = '';
	}

	function setPendingPageAction(pageId, action, messageKey) {
		pagesState.pendingPageId = pageId || '';
		pagesState.pendingAction = action || '';
		if (messageKey) {
			setPagesMessage('loading', t(messageKey));
		}
		renderPagesGridContentOnly();
	}

	function isPendingPageAction(pageId, action) {
		return pagesState.saving && pagesState.pendingPageId === pageId && (!action || pagesState.pendingAction === action);
	}

	function buildDuplicateSlug(baseSlug) {
		var normalizedBase = String(baseSlug || 'home').replace(/^\/|\/$/g, '') || 'home';
		var candidate = normalizedBase + '-copy';
		var suffix = 2;
		var used = {};

		pagesState.items.forEach(function (page) {
			if (page.slug) {
				used[page.slug] = true;
			}
		});

		while (used[candidate]) {
			candidate = normalizedBase + '-copy-' + String(suffix);
			suffix += 1;
		}

		return candidate;
	}

	function renderPagesToolbar() {
		var openSite = shell.querySelector('[data-pages-open-site]');
		var firstOpenable = pagesState.items.find(function (page) {
			return page.can_open && page.is_home;
		}) || pagesState.items.find(function (page) {
			return page.can_open;
		});

		if (openSite) {
			openSite.disabled = !firstOpenable;
			openSite.title = firstOpenable ? '' : t('manager.pages.open_site_disabled');
		}
	}

	function renderPagesHeaderBadges() {
		if (!pageBadges) {
			return;
		}

		clearNode(pageBadges);
		pageBadges.classList.add('sonyra-manager-page-header__meta');

		var summary = getPagesSummary();
		pageBadges.appendChild(createHeaderMetaChip(formatCountLabel('manager.pages.badges.total', summary.total), 'neutral'));
		pageBadges.appendChild(createHeaderMetaChip(formatCountLabel('manager.pages.badges.published_total', summary.published), 'ready'));
		pageBadges.appendChild(createHeaderMetaChip(formatCountLabel('manager.pages.badges.draft_total', summary.draft), 'warning'));
		pageBadges.appendChild(createHeaderMetaChip(formatCountLabel('manager.pages.badges.hidden_total', summary.hidden), 'danger'));

		if (summary.hasHome) {
			pageBadges.appendChild(createHeaderMetaChip(t('manager.pages.badges.home_ready'), 'neutral'));
		}

		pageBadges.hidden = false;
	}

	function renderPagesEditor() {
		if (!pagesRoot) {
			return;
		}

		var workspaceRoot = pagesRoot.querySelector('[data-pages-workspace]');
		var workspace = pagesRoot.querySelector('[data-pages-sections-mode]');
		var helpRoot = pagesRoot.querySelector('[data-pages-help-popover-root]');
		var page = getActivePage();

		if (!workspaceRoot || !workspace) {
			return;
		}

		workspace.hidden = pagesState.mode !== 'sections';
		clearNode(workspaceRoot);
		if (helpRoot) {
			clearNode(helpRoot);
		}

		if (!page || pagesState.mode !== 'sections') {
			pagesState.openHelpTooltip = '';
			pagesState.openHelpTooltipPinned = false;
			pagesState.openHelpTooltipTrigger = '';
			return;
		}

		var activeSection = getActiveSection(page);

		if (activeSection) {
			pagesState.activeSectionId = activeSection.id;
		}

		workspaceRoot.appendChild(buildSectionsWorkspace(page, activeSection));
		renderHelpPopover();
	}

	function renderHelpPopover() {
		var popoverRoot = pagesRoot ? pagesRoot.querySelector('[data-pages-help-popover-root]') : null;
		var trigger;
		var triggerRect;
		var popover;
		var entry;
		var preferredWidth = 360;
		var gap = 10;
		var viewportPadding = 14;
		var viewportWidth = window.innerWidth || 0;
		var viewportHeight = window.innerHeight || 0;
		var left = 0;
		var top = 0;
		var placement = 'right';
		var clampedWidth;
		var popoverHeight;

		if (!popoverRoot) {
			return;
		}

		clearNode(popoverRoot);

		if (!pagesState.openHelpTooltip || pagesState.mode !== 'sections') {
			return;
		}

		entry = getHelpEntry(pagesState.openHelpTooltip);
		trigger = pagesRoot.querySelector('[data-sonyra-help-trigger="' + pagesState.openHelpTooltipTrigger + '"]');

		if (!entry || !trigger) {
			return;
		}

		popover = createTextNode('article', 'sonyra-help-popover');
		popover.setAttribute('data-pages-help-popover', pagesState.openHelpTooltip);
		popover.setAttribute('role', 'tooltip');
		popover.appendChild(createTextNode('strong', 'sonyra-help-popover__title', entry.title || ''));
		popover.appendChild(createTextNode('p', 'sonyra-help-popover__body', entry.body || ''));
		popoverRoot.appendChild(popover);

		triggerRect = trigger.getBoundingClientRect();
		clampedWidth = Math.min(preferredWidth, Math.max(220, viewportWidth - (viewportPadding * 2)));
		popover.style.maxWidth = String(clampedWidth) + 'px';

		if (triggerRect.right + gap + clampedWidth <= viewportWidth - viewportPadding) {
			left = triggerRect.right + gap;
			placement = 'right';
		} else if (triggerRect.left - gap - clampedWidth >= viewportPadding) {
			left = triggerRect.left - gap - clampedWidth;
			placement = 'left';
		} else {
			left = Math.max(viewportPadding, Math.min(triggerRect.left, viewportWidth - clampedWidth - viewportPadding));
			placement = 'bottom';
		}

		popoverHeight = Math.ceil(popover.getBoundingClientRect().height || popover.offsetHeight || 0);

		if (placement === 'right' || placement === 'left') {
			if (triggerRect.top < viewportHeight * 0.45 && triggerRect.bottom + gap + popoverHeight <= viewportHeight - viewportPadding) {
				top = triggerRect.bottom + gap;
			} else if (triggerRect.top - gap - popoverHeight >= viewportPadding) {
				top = triggerRect.top - popoverHeight - gap;
			} else {
				top = Math.max(viewportPadding, Math.min(triggerRect.top, viewportHeight - popoverHeight - viewportPadding));
			}
		} else {
			if (triggerRect.bottom + gap + popoverHeight <= viewportHeight - viewportPadding) {
				top = triggerRect.bottom + gap;
				placement = 'bottom';
			} else {
				top = triggerRect.top - popoverHeight - gap;
				placement = 'top';
			}

			top = Math.max(viewportPadding, Math.min(top, viewportHeight - popoverHeight - viewportPadding));
		}

		left = Math.max(viewportPadding, Math.min(left, viewportWidth - clampedWidth - viewportPadding));

		popover.style.left = String(left) + 'px';
		popover.style.top = String(top) + 'px';
		popover.setAttribute('data-popover-placement', placement);
	}

	function buildSectionsWorkspace(page, activeSection) {
		var workspace = createTextNode('div', 'sonyra-pages-sections-workspace');
		var context = createTextNode('div', 'sonyra-pages-sections-context sonyra-manager-pages-table-card');
		var contextCopy = createTextNode('div', 'sonyra-pages-sections-context-copy');
		var contextLabel = createTextNode('span', 'sonyra-pages-sections-context-label', t('manager.pages.sections.current_page'));
		var contextTitle = createTextNode('strong', 'sonyra-pages-sections-context-title', page.title || '/');
		var backButton = createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.back_to_table'), 'arrow-left');
		var grid = createTextNode('div', 'sonyra-pages-sections-grid');

		backButton.setAttribute('data-pages-back-to-table', 'true');
		contextCopy.appendChild(contextLabel);
		contextCopy.appendChild(contextTitle);
		context.appendChild(contextCopy);
		context.appendChild(backButton);
		workspace.appendChild(context);
		grid.appendChild(buildSectionsListPanel(page, activeSection));
		grid.appendChild(buildBlocksPanel(page, activeSection));
		workspace.appendChild(grid);

		return workspace;
	}

	function buildSectionsListPanel(page, activeSection) {
		var panel = createTextNode('aside', 'sonyra-pages-sections-list-panel sonyra-manager-pages-table-card');
		var head = createPanelHead(t('manager.pages.sections.panel_title'), t('manager.pages.sections.description'), 'pages.sections.panel', 'manager.help.aria.pages.sections.panel');
		var addButton = createButton('sonyra-manager-pages-primary', t('manager.pages.actions.add_section'));
		var list = createTextNode('div', 'sonyra-pages-sections-list');

		addButton.setAttribute('data-pages-open-section-library', 'true');
		head.appendChild(addButton);
		panel.appendChild(head);

		if (!page.sections.length) {
			panel.appendChild(createWorkspaceEmptyState(
				t('manager.pages.sections.empty_title'),
				t('manager.pages.sections.empty_description'),
				t('manager.pages.actions.add_section'),
				'section'
			));
			return panel;
		}

		page.sections.forEach(function (section) {
			list.appendChild(createSectionCard(section, activeSection && activeSection.id === section.id));
		});
		panel.appendChild(list);

		return panel;
	}

	function buildBlocksPanel(page, activeSection) {
		var panel = createTextNode('section', 'sonyra-pages-blocks-panel sonyra-manager-pages-table-card');
		var head = createPanelHead(t('manager.pages.sections.blocks_title'), '', 'pages.sections.blocks', 'manager.help.aria.pages.sections.blocks');
		var addButton = createButton('sonyra-manager-pages-primary', t('manager.pages.actions.add_block'));
		var list = createTextNode('div', 'sonyra-pages-blocks-list');

		addButton.setAttribute('data-pages-add-menu-trigger', 'block');
		addButton.disabled = !activeSection;
		head.appendChild(buildAddMenuWrap(addButton, 'block'));
		panel.appendChild(head);

		if (!activeSection) {
			panel.appendChild(createWorkspaceHintState(t('manager.pages.sections.choose_section')));
			return panel;
		}

		if (!activeSection.blocks.length) {
			panel.appendChild(createWorkspaceEmptyState(
				t('manager.pages.sections.empty_blocks_title'),
				t('manager.pages.sections.empty_blocks_description'),
				t('manager.pages.actions.add_block'),
				'block'
			));
			return panel;
		}

		activeSection.blocks.forEach(function (block) {
			list.appendChild(createBlockCard(activeSection, block));
		});
		panel.appendChild(list);

		return panel;
	}

	function createPanelHead(titleText, descriptionText, helpKey, ariaLabelKey) {
		var head = createTextNode('div', 'sonyra-pages-workspace-head sonyra-pages-panel-head');
		var copy = createTextNode('div', 'sonyra-pages-workspace-head-copy');
		var titleWrap = createTextNode('div', 'sonyra-pages-panel-title-wrap');
		titleWrap.appendChild(createTextNode('h3', 'sonyra-pages-workspace-head-title', titleText));
		if (helpKey) {
			titleWrap.appendChild(createHelpTooltip(helpKey, ariaLabelKey));
		}
		copy.appendChild(titleWrap);
		if (descriptionText) {
			copy.appendChild(createTextNode('p', 'sonyra-pages-workspace-head-description', descriptionText));
		}
		head.appendChild(copy);
		return head;
	}

	function createHelpTooltip(helpKey, ariaLabelKey) {
		var wrap = createTextNode('div', 'sonyra-help-tooltip-wrap');
		var trigger = createButton('sonyra-help-tooltip-trigger', '', 'help-circle');
		var triggerId = 'help-trigger-' + String(helpKey || '').replace(/[^a-z0-9_-]/gi, '-');
		var isOpen = pagesState.openHelpTooltip === helpKey;

		trigger.id = triggerId;
		trigger.setAttribute('aria-label', t(ariaLabelKey || 'manager.pages.actions.help_tooltip'));
		trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		trigger.setAttribute('data-pages-help-tooltip-trigger', helpKey);
		trigger.setAttribute('data-sonyra-help-key', helpKey);
		trigger.setAttribute('data-sonyra-help-trigger', triggerId);

		wrap.appendChild(trigger);
		return wrap;
	}

	function buildAddMenuWrap(button, target) {
		var wrap = createTextNode('div', 'sonyra-pages-workspace-menu-wrap');
		var menu = createTextNode('div', 'sonyra-pages-action-menu sonyra-pages-inline-action-menu');
		var configList = target === 'section' ? ['hero', 'text', 'contacts'] : ['hero', 'text', 'contacts'];
		var isOpen = pagesState.openAddMenu === target;

		wrap.appendChild(button);
		menu.hidden = !isOpen;
		menu.setAttribute('data-pages-add-menu', target);

		configList.forEach(function (type) {
			var option = createTextNode('button', 'sonyra-pages-action-item');
			var icon = createTextNode('span', 'sonyra-manager-pages-dropdown-icon');
			var labelKey = target === 'section' ? getTypeConfig(type).sectionLabelKey : getTypeConfig(type).blockLabelKey;
			option.type = 'button';
			option.setAttribute('data-pages-add-' + target, type);
			icon.appendChild(clonePagesIcon(target === 'section' ? getTypeConfig(type).sectionIcon : getTypeConfig(type).blockIcon));
			option.appendChild(icon);
			option.appendChild(createTextNode('span', '', t(labelKey)));
			menu.appendChild(option);
		});

		wrap.appendChild(menu);

		return wrap;
	}

	function createWorkspaceEmptyState(title, description, buttonLabel, target) {
		var empty = createTextNode('div', 'sonyra-manager-pages-empty-state sonyra-pages-workspace-empty-state');
		var button = createButton('sonyra-manager-pages-primary', buttonLabel);

		if (target === 'section') {
			button.setAttribute('data-pages-open-section-library', 'true');
		} else {
			button.setAttribute('data-pages-add-menu-trigger', target);
		}
		empty.appendChild(createTextNode('strong', '', title));
		empty.appendChild(createTextNode('p', '', description));
		empty.appendChild(button);
		return empty;
	}

	function createWorkspaceHintState(title) {
		var empty = createTextNode('div', 'sonyra-manager-pages-empty-state sonyra-pages-workspace-empty-state');
		empty.appendChild(createTextNode('strong', '', title));
		return empty;
	}

	function createSectionCard(section, isActive) {
		var card = createTextNode('article', 'sonyra-section-card');
		var handle = createDragHandle('section', section.id);
		var icon = createCardIcon(getTypeConfig(section.type).sectionIcon);
		var text = createCardText(section.name || getDefaultSectionTitle(section.type), section.unavailable ? t('manager.pages.sections.module_unavailable') : getSectionTypeLabel(section.type));
		var actions = createCardActions('section', section.id);

		card.setAttribute('data-pages-section-card', section.id);
		card.setAttribute('data-pages-section-select', section.id);
		card.dataset.sectionId = section.id;
		card.classList.toggle('is-active', isActive === true);
		card.appendChild(handle);
		card.appendChild(icon);
		card.appendChild(text);
		card.appendChild(actions);
		return card;
	}

	function createBlockCard(section, block) {
		var card = createTextNode('article', 'sonyra-block-card');
		var handle = createDragHandle('block', block.id, section.id);
		var icon = createCardIcon(getTypeConfig(block.type).blockIcon);
		var text = createCardText(block.name || getDefaultBlockTitle(block.type), getBlockTypeLabel(block.type));
		var actions = createCardActions('block', block.id, section.id);

		card.setAttribute('data-pages-block-card', block.id);
		card.dataset.blockId = block.id;
		card.dataset.sectionId = section.id;
		card.appendChild(handle);
		card.appendChild(icon);
		card.appendChild(text);
		card.appendChild(actions);
		return card;
	}

	function createDragHandle(kind, itemId, sectionId) {
		var handle = createTextNode('button', 'sonyra-pages-drag-handle sonyra-drag-handle');
		handle.type = 'button';
		handle.draggable = true;
		handle.setAttribute('aria-label', kind === 'section' ? t('manager.pages.actions.drag_section') : t('manager.pages.sections.blocks_title'));
		handle.setAttribute('data-pages-drag-handle', kind);
		handle.setAttribute('data-pages-drag-id', itemId);
		if (sectionId) {
			handle.setAttribute('data-pages-drag-section-id', sectionId);
		}
		handle.appendChild(clonePagesIcon('dots-grip'));
		return handle;
	}

	function createCardIcon(iconKey) {
		var icon = createTextNode('span', 'sonyra-pages-card-icon');
		icon.appendChild(clonePagesIcon(iconKey));
		return icon;
	}

	function createCardText(titleText, typeText) {
		var text = createTextNode('div', 'sonyra-pages-card-copy sonyra-section-card__content');
		text.appendChild(createTextNode('div', 'sonyra-pages-card-title sonyra-section-card__title', titleText));
		text.appendChild(createTextNode('div', 'sonyra-pages-card-type sonyra-section-card__type', typeText));
		return text;
	}

	function createCardActions(kind, itemId, sectionId) {
		var actions = createTextNode('div', 'sonyra-pages-card-actions sonyra-section-card__actions');
		var settingsButton = createButton('sonyra-pages-card-action', '', 'settings');
		var deleteButton = createButton('sonyra-pages-card-action sonyra-pages-card-action-danger', '', 'trash');

		settingsButton.setAttribute('data-pages-' + kind + '-settings', itemId);
		deleteButton.setAttribute('data-pages-' + kind + '-delete', itemId);
		settingsButton.setAttribute('aria-label', kind === 'section' ? t('manager.pages.sections.section_modal_title') : t('manager.pages.sections.block_modal_title'));
		deleteButton.setAttribute('aria-label', kind === 'section' ? t('manager.pages.sections.delete_section_title') : t('manager.pages.sections.delete_block_title'));
		if (sectionId) {
			settingsButton.setAttribute('data-pages-section-id', sectionId);
			deleteButton.setAttribute('data-pages-section-id', sectionId);
		}
		actions.appendChild(settingsButton);
		actions.appendChild(deleteButton);
		return actions;
	}

	function createTextNode(tag, className, text) {
		var node = document.createElement(tag);

		if (className) {
			node.className = className;
		}

		if (text !== undefined) {
			node.textContent = text;
		}

		return node;
	}

	function createButton(className, text, iconKey) {
		var button = document.createElement('button');
		button.type = 'button';
		button.className = className;

		if (iconKey) {
			var iconWrap = createTextNode('span', 'sonyra-manager-pages-button-icon-wrap');
			iconWrap.appendChild(clonePagesIcon(iconKey));
			button.appendChild(iconWrap);
		}

		if (text) {
			button.appendChild(document.createTextNode(text));
		}

		return button;
	}

	function formatPageUpdatedAt(value) {
		if (!value) {
			return {
				dateText: '—',
				timeText: ''
			};
		}

		var date = new Date(value);

		if (Number.isNaN(date.getTime())) {
			return {
				dateText: '—',
				timeText: ''
			};
		}

		return {
			dateText: new Intl.DateTimeFormat('ru-RU', {
				day: '2-digit',
				month: '2-digit',
				year: 'numeric'
			}).format(date),
			timeText: new Intl.DateTimeFormat('ru-RU', {
				hour: '2-digit',
				minute: '2-digit'
			}).format(date)
		};
	}

	function filterPagesForTable() {
		var query = String(pagesState.searchQuery || '').trim().toLowerCase();

		return pagesState.items.filter(function (page) {
			var matchesFilter = true;

			if (pagesState.statusFilter === 'published') {
				matchesFilter = page.status === 'published';
			} else if (pagesState.statusFilter === 'draft') {
				matchesFilter = page.status === 'draft';
			} else if (pagesState.statusFilter === 'hidden') {
				matchesFilter = page.status === 'hidden';
			} else if (pagesState.statusFilter === 'menu') {
				matchesFilter = page.show_in_menu === true;
			}

			if (!matchesFilter) {
				return false;
			}

			if (!query) {
				return true;
			}

			var haystack = [
				page.title || '',
				page.slug || '',
				page.menu_title || ''
			].join(' ').toLowerCase();

			return haystack.indexOf(query) !== -1;
		});
	}

	function sortPagesForTable(items) {
		return items.slice().sort(function (left, right) {
			if (pagesState.sort === 'created') {
				return new Date(right.created_at || 0).getTime() - new Date(left.created_at || 0).getTime();
			}

			if (pagesState.sort === 'az') {
				return String(left.title || '').localeCompare(String(right.title || ''), 'ru');
			}

			if (pagesState.sort === 'za') {
				return String(right.title || '').localeCompare(String(left.title || ''), 'ru');
			}

			if (pagesState.sort === 'menu') {
				if (left.show_in_menu !== right.show_in_menu) {
					return left.show_in_menu ? -1 : 1;
				}

				if (Number(left.menu_order || 0) !== Number(right.menu_order || 0)) {
					return Number(left.menu_order || 0) - Number(right.menu_order || 0);
				}

				return String(left.title || '').localeCompare(String(right.title || ''), 'ru');
			}

			return new Date(right.updated_at || right.created_at || 0).getTime() - new Date(left.updated_at || left.created_at || 0).getTime();
		});
	}

	function getPreparedPagesForTable() {
		return sortPagesForTable(filterPagesForTable());
	}

	function createPageBadge(text, tone) {
		return createTextNode('span', 'sonyra-manager-pages-page-badge sonyra-manager-pages-page-badge-' + tone, text);
	}

	function renderMenuCell(page) {
		var cell = createTextNode('div', 'sonyra-manager-pages-menu-cell');

		if (!page.show_in_menu) {
			cell.appendChild(createTextNode('span', 'sonyra-manager-pages-menu-empty', t('manager.pages.table.not_in_menu')));
			return cell;
		}

		var icon = createTextNode('span', 'sonyra-manager-pages-menu-icon');
		icon.appendChild(clonePagesIcon('menu-header'));
		cell.appendChild(icon);
		cell.appendChild(createTextNode('span', 'sonyra-manager-pages-menu-text', '№' + String(page.menu_order || 0)));
		return cell;
	}

	function renderUpdatedCell(page) {
		var formatted = formatPageUpdatedAt(page.updated_at || page.created_at || '');
		var cell = createTextNode('div', 'sonyra-pages-updated sonyra-pages-table-cell sonyra-pages-table-cell--updated');

		cell.appendChild(createTextNode('span', 'sonyra-pages-updated-date', formatted.dateText));

		if (formatted.timeText) {
			cell.appendChild(createTextNode('span', 'sonyra-pages-updated-time', formatted.timeText));
		}

		return cell;
	}

	function createDropdownItem(definition, page) {
		var item = createTextNode('button', 'sonyra-pages-action-item');
		var isDisabled = definition.future === true || definition.disabled(page) === true || isPendingPageAction(page.id);

		item.type = 'button';
		item.setAttribute('data-sonyra-page-action', definition.action);
		item.setAttribute('data-sonyra-page-id', page.id);
		item.appendChild(createTextNode('span', 'sonyra-manager-pages-dropdown-icon'));
		item.firstChild.appendChild(clonePagesIcon(definition.icon));
		item.appendChild(createTextNode('span', '', definition.label));

		if (definition.danger) {
			item.classList.add('is-danger');
		}

		if (isDisabled) {
			item.classList.add('is-disabled');
			item.setAttribute('aria-disabled', 'true');
			item.setAttribute('tabindex', '-1');
			item.disabled = true;
		}

		return item;
	}

	function getPagePublishAction(page) {
		if (page.status === 'published') {
			return {
				action: 'hide',
				label: t('manager.pages.actions.hide'),
				icon: 'eye-off',
				disabled: function () { return false; }
			};
		}

		return {
			action: 'publish',
			label: t('manager.pages.actions.publish'),
			icon: 'eye',
			disabled: function () { return false; }
		};
	}

	function getDropdownItems(page) {
		var publishAction = getPagePublishAction(page);

		return [
			{ action: 'settings', label: t('manager.pages.actions.parameters'), icon: 'settings', disabled: function () { return false; } },
			{ action: 'sections', label: t('manager.pages.actions.sections'), icon: 'section', disabled: function () { return false; } },
			{ action: 'open', label: t('manager.pages.actions.open'), icon: 'external-link', disabled: function (current) { return !current.can_open; } },
			{ action: 'preview', label: t('manager.pages.actions.preview'), icon: 'browser-preview', disabled: function () { return false; } },
			{ action: 'copy', label: t('manager.pages.actions.copy_link'), icon: 'link', disabled: function () { return false; } },
			{ action: 'make-home', label: t('manager.pages.actions.make_home'), icon: 'home', disabled: function (current) { return current.is_home === true; } },
			publishAction,
			{ action: 'seo', label: t('manager.pages.actions.seo'), icon: 'world-search', future: true, disabled: function () { return true; } },
			{ action: 'history', label: t('manager.pages.actions.history'), icon: 'history', disabled: function () { return false; } },
			{ action: 'duplicate', label: t('manager.pages.actions.duplicate'), icon: 'copy', disabled: function () { return false; } },
			{ action: 'delete', label: t('manager.pages.actions.delete'), icon: 'trash', disabled: function () { return false; }, danger: true }
		];
	}

	function renderActionsCell(page) {
		var wrapper = createTextNode('div', 'sonyra-pages-action-cell sonyra-pages-table-cell sonyra-pages-table-cell--actions');
		var trigger = createButton('sonyra-pages-action-trigger', t('manager.pages.table.actions'));
		var dropdown = createTextNode('div', 'sonyra-pages-action-menu');
		var isOpen = pagesState.openDropdownId === page.id;
		var isPending = isPendingPageAction(page.id);

		trigger.setAttribute('aria-label', t('manager.pages.actions.page_actions'));
		trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		trigger.setAttribute('data-sonyra-page-actions-trigger', page.id);
		trigger.disabled = isPending;

		if (isPending) {
			trigger.classList.add('is-pending');
			clearNode(trigger);
			trigger.appendChild(createTextNode('span', 'sonyra-manager-pages-dropdown-icon'));
			trigger.firstChild.appendChild(clonePagesIcon('progress'));
		}

		wrapper.appendChild(trigger);

		dropdown.setAttribute('data-sonyra-page-actions-menu', page.id);
		dropdown.hidden = !isOpen;
		getDropdownItems(page).forEach(function (definition, index) {
			if (index === 10) {
				dropdown.appendChild(createTextNode('div', 'sonyra-manager-pages-dropdown-divider'));
			}

			dropdown.appendChild(createDropdownItem(definition, page));
		});
		wrapper.appendChild(dropdown);

		return wrapper;
	}

	function renderPageCell(page) {
		var cell = createTextNode('div', 'sonyra-manager-pages-page-cell');
		var slugText = page.is_home ? '/' : '/' + page.slug + '/';
		var title = createTextNode('div', 'page-title', page.title || page.menu_title || slugText);
		var url = createTextNode('div', 'page-url', page.is_home ? '/' : '/' + page.slug + '/');
		var badges = createTextNode('div', 'page-badges');

		badges.appendChild(createPageBadge(t('manager.pages.status.' + page.status), page.status));

		if (page.is_home) {
			badges.appendChild(createPageBadge(t('manager.pages.badges.home_selected'), 'home'));
		}

		if (page.show_in_menu) {
			badges.appendChild(createPageBadge(t('manager.pages.status.menu_yes'), 'menu'));
		}

		cell.appendChild(title);
		cell.appendChild(url);
		cell.appendChild(badges);
		return cell;
	}

	function buildPagesGridContent() {
		var pages = getPreparedPagesForTable();
		var card = createTextNode('div', 'sonyra-manager-pages-table-card sonyra-pages-table-card');
		var listWrap;

		card.setAttribute('data-pages-grid-card', 'true');

		if (pagesState.pagesStatus === 'loading') {
			card.appendChild(renderPagesLoadingState());
			return card;
		}

		if (pagesState.pagesStatus === 'error') {
			card.appendChild(renderPagesErrorState());
			return card;
		}

		if (pagesState.pagesStatus === 'loaded' && !pagesState.items.length) {
			card.appendChild(renderEmptyState('empty'));
			return card;
		}

		if (!pages.length) {
			card.appendChild(renderEmptyState('filtered'));
			return card;
		}

		if (isPagesTableMobile()) {
			listWrap = createTextNode('div', 'sonyra-manager-pages-cards');
			pages.forEach(function (page) {
				var pageCard = createTextNode('article', 'sonyra-manager-pages-card');
				var menuRow = createTextNode('div', 'sonyra-manager-pages-card-row');
				var updatedRow = createTextNode('div', 'sonyra-manager-pages-card-row');
				var actionsRow = createTextNode('div', 'sonyra-manager-pages-card-actions');
				menuRow.appendChild(createTextNode('span', 'sonyra-manager-pages-card-label', t('manager.pages.table.column_menu')));
				menuRow.appendChild(renderMenuCell(page));
				updatedRow.appendChild(createTextNode('span', 'sonyra-manager-pages-card-label', t('manager.pages.table.column_updated')));
				updatedRow.appendChild(renderUpdatedCell(page));
				actionsRow.appendChild(renderActionsCell(page));
				pageCard.appendChild(renderPageCell(page));
				pageCard.appendChild(menuRow);
				pageCard.appendChild(updatedRow);
				pageCard.appendChild(actionsRow);
				if (isPendingPageAction(page.id)) {
					pageCard.classList.add('is-pending');
				}
				listWrap.appendChild(pageCard);
			});
		} else {
			listWrap = createTextNode('div', 'sonyra-pages-table');
			var header = createTextNode('div', 'sonyra-pages-table-head');
			header.appendChild(createTextNode('div', 'sonyra-pages-table-heading sonyra-pages-table-heading--page', t('manager.pages.table.column_page')));
			header.appendChild(createTextNode('div', 'sonyra-pages-table-heading sonyra-pages-table-heading--menu', t('manager.pages.table.column_menu')));
			header.appendChild(createTextNode('div', 'sonyra-pages-table-heading sonyra-pages-table-heading--updated', t('manager.pages.table.column_updated')));
			header.appendChild(createTextNode('div', 'sonyra-pages-table-heading sonyra-pages-table-heading--actions', t('manager.pages.table.column_actions')));
			listWrap.appendChild(header);
			var body = createTextNode('div', 'sonyra-pages-table-body');
			pages.forEach(function (page) {
				var row = createTextNode('div', 'sonyra-pages-table-row');
				var pageCell = renderPageCell(page);
				var menuCell = renderMenuCell(page);

				pageCell.classList.add('sonyra-pages-table-cell', 'sonyra-pages-table-cell--page');
				menuCell.classList.add('sonyra-pages-table-cell', 'sonyra-pages-table-cell--menu');
				row.appendChild(pageCell);
				row.appendChild(menuCell);
				row.appendChild(renderUpdatedCell(page));
				row.appendChild(renderActionsCell(page));
				if (isPendingPageAction(page.id)) {
					row.classList.add('is-pending');
				}
				body.appendChild(row);
			});
			listWrap.appendChild(body);
		}

		card.appendChild(listWrap);
		return card;
	}

	function renderPagesGridContentOnly() {
		var screen = pagesRoot ? pagesRoot.querySelector('[data-pages-table-screen]') : null;

		if (!screen || pagesState.mode === 'sections') {
			return;
		}

		var nextCard = buildPagesGridContent();
		var currentCard = screen.querySelector('[data-pages-grid-card]');

		if (!currentCard) {
			renderPagesGrid();
			return;
		}

		currentCard.parentNode.replaceChild(nextCard, currentCard);
	}

	function renderPagesGrid() {
		var screen = pagesRoot.querySelector('[data-pages-table-screen]');
		var list = createTextNode('div', 'sonyra-pages-list');
		var toolbar = createTextNode('div', 'sonyra-pages-toolbar-panel');
		var searchWrap = createTextNode('label', 'sonyra-pages-search');
		var searchIcon = createTextNode('span', 'sonyra-pages-search-icon');
		var searchInput = document.createElement('input');
		var filtersWrap = createTextNode('div', 'sonyra-pages-toolbar-controls');
		var filterWrap = createTextNode('div', 'sonyra-pages-filter-wrap');
		var filterIcon = createTextNode('span', 'sonyra-pages-toolbar-static-icon');
		var filters = createTextNode('div', 'sonyra-pages-filter-group');
		var sortWrap = createTextNode('label', 'sonyra-pages-sort sonyra-pages-sort-control');
		var sortLabel = createTextNode('span', 'sonyra-pages-toolbar-static-icon');
		var sortSelect = document.createElement('select');

		if (!screen) {
			return;
		}

		clearNode(screen);
		screen.hidden = pagesState.mode === 'sections';

		if (pagesState.mode === 'sections') {
			return;
		}

		searchIcon.appendChild(clonePagesIcon('search'));
		searchWrap.appendChild(searchIcon);
		searchInput.type = 'search';
		searchInput.className = 'sonyra-pages-search-input';
		searchInput.value = pagesState.searchQuery;
		searchInput.placeholder = t('manager.pages.table.search_prompt');
		searchInput.setAttribute('data-pages-search', 'true');
		searchWrap.appendChild(searchInput);
		toolbar.appendChild(searchWrap);
		filterIcon.setAttribute('aria-hidden', 'true');
		filterIcon.appendChild(clonePagesIcon('filter'));

		[
			{ value: 'all', label: t('manager.pages.table.filter_all') },
			{ value: 'published', label: t('manager.pages.table.filter_published') },
			{ value: 'draft', label: t('manager.pages.table.filter_draft') },
			{ value: 'hidden', label: t('manager.pages.table.filter_hidden') },
			{ value: 'menu', label: t('manager.pages.table.filter_menu') }
		].forEach(function (filter) {
			var chip = createButton('sonyra-pages-filter-chip', filter.label);
			chip.setAttribute('data-pages-filter', filter.value);
			chip.setAttribute('aria-pressed', pagesState.statusFilter === filter.value ? 'true' : 'false');
			chip.classList.toggle('is-active', pagesState.statusFilter === filter.value);
			filters.appendChild(chip);
		});

		filterWrap.appendChild(filterIcon);
		filterWrap.appendChild(filters);
		sortLabel.setAttribute('aria-hidden', 'true');
		sortLabel.appendChild(clonePagesIcon('arrows-sort'));
		sortWrap.appendChild(sortLabel);
		sortSelect.className = 'sonyra-pages-sort-select';
		sortSelect.setAttribute('data-pages-sort', 'true');
		[
			{ value: 'recent', label: t('manager.pages.table.sort_recent') },
			{ value: 'created', label: t('manager.pages.table.sort_created') },
			{ value: 'az', label: t('manager.pages.table.sort_az') },
			{ value: 'za', label: t('manager.pages.table.sort_za') },
			{ value: 'menu', label: t('manager.pages.table.sort_menu') }
		].forEach(function (optionDef) {
			var option = document.createElement('option');
			option.value = optionDef.value;
			option.textContent = optionDef.label;
			sortSelect.appendChild(option);
		});
		sortSelect.value = pagesState.sort;
		sortWrap.appendChild(sortSelect);
		filtersWrap.appendChild(filterWrap);
		filtersWrap.appendChild(sortWrap);
		toolbar.appendChild(filtersWrap);
		list.appendChild(toolbar);

		list.appendChild(buildPagesGridContent());
		screen.appendChild(list);
	}

	function renderEmptyState(type) {
		var empty = createTextNode('div', 'sonyra-manager-pages-empty-state');
		var title;
		var description;
		var button;

		if (type === 'filtered') {
			title = t('manager.pages.empty_reset_title');
			description = t('manager.pages.empty_reset_description');
			button = createButton('sonyra-manager-pages-secondary', t('manager.pages.empty_reset_action'));
			button.setAttribute('data-pages-reset-filters', 'true');
		} else {
			title = t('manager.pages.empty_title');
			description = t('manager.pages.empty_description');
			button = createButton('sonyra-manager-pages-primary', t('manager.pages.actions.create'));
			button.setAttribute('data-pages-create', 'true');
		}

		empty.appendChild(createTextNode('strong', '', title));
		empty.appendChild(createTextNode('p', '', description));
		empty.appendChild(button);
		return empty;
	}

	function renderPagesLoadingState() {
		var loading = createTextNode('div', 'sonyra-manager-pages-empty-state sonyra-manager-pages-loading-state');
		var icon = createTextNode('span', 'sonyra-manager-notice__icon');

		icon.appendChild(clonePagesIcon('progress'));
		loading.appendChild(icon);
		loading.appendChild(createTextNode('strong', '', t('manager.pages.loading')));
		return loading;
	}

	function renderPagesErrorState() {
		var error = createTextNode('div', 'sonyra-manager-pages-empty-state');
		error.appendChild(createTextNode('strong', '', t('manager.pages.errors.load_failed')));
		return error;
	}

	function renderPagesTableScreen() {
		renderPagesToolbar();
		renderPagesHeaderBadges();
		renderPagesGrid();
		renderPagesEditor();
		renderPageModal();
	}

	function renderPages() {
		renderPagesTableScreen();
	}

	function fetchPagesCollection() {
		var pagesUrl = shell.getAttribute('data-pages-url') || '';

		if (!pagesRoot || !pagesUrl) {
			return Promise.reject(new Error('pages_unavailable'));
		}

		return fetch(pagesUrl, {
			method: 'GET',
			credentials: 'same-origin',
			headers: {
				'X-Sonyra-Pages-Nonce': shell.getAttribute('data-pages-nonce') || ''
			}
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('load_failed');
			}

			return response.json();
		});
	}

	function loadPages() {
		pagesState.pagesStatus = 'loading';
		renderPages();

		fetchPagesCollection().then(function (data) {
			pagesState.items = Array.isArray(data.items) ? data.items.map(normalizePage) : [];
			pagesState.activeId = pagesState.items[0] ? pagesState.items[0].id : '';
			pagesState.loaded = true;
			pagesState.pagesStatus = 'loaded';
			renderPages();
		}).catch(function () {
			pagesState.loaded = true;
			pagesState.pagesStatus = 'error';
			setPagesMessage('error', t('manager.pages.errors.load_failed'));
			renderPages();
		});
	}

	function createPage() {
		pagesState.modalDraft = normalizePage({
			id: createId('page'),
			title: '',
			slug: '',
			status: 'draft',
			menu_order: (pagesState.items.length + 1) * 10,
			sections: []
		});
		pagesState.pageModalOpen = true;
		pagesState.historyModalOpen = false;
		pagesState.lastTrigger = document.activeElement;
		renderPageModal();
	}

	function renderPageModal() {
		if (!pagesRoot) {
			return;
		}

		var modalRoot = pagesRoot.querySelector('[data-pages-modal-root]');

		if (!modalRoot) {
			return;
		}

		clearNode(modalRoot);

		if (!pagesState.pageModalOpen && !pagesState.sectionLibraryModalOpen && !pagesState.sectionModalOpen && !pagesState.blockModalOpen && !pagesState.deleteModalOpen && !pagesState.historyModalOpen) {
			document.body.classList.remove('sonyra-manager-modal-open');
			return;
		}

		document.body.classList.add('sonyra-manager-modal-open');

		var overlay = createTextNode('div', 'sonyra-manager-pages-modal-overlay sonyra-manager-modal-overlay');
		var panel = createTextNode('div', 'sonyra-manager-pages-modal sonyra-manager-modal');
		var header = createTextNode('header', 'sonyra-manager-pages-modal-header sonyra-manager-modal__header');
		var icon = createTextNode('div', 'sonyra-manager-pages-modal-icon');
		var copy = createTextNode('div', 'sonyra-manager-pages-modal-copy');
		var title = createTextNode('h3', 'sonyra-manager-pages-modal-title');
		var description = createTextNode('p', 'sonyra-manager-pages-modal-description');
		var closeButton = createButton('sonyra-manager-pages-modal-close', '', 'x');
		var body = createTextNode('div', 'sonyra-manager-pages-modal-body sonyra-manager-modal__body');
		var footer = createTextNode('footer', 'sonyra-manager-pages-modal-footer sonyra-manager-modal__footer');

		overlay.setAttribute('data-pages-modal-overlay', 'true');
		panel.setAttribute('role', 'dialog');
		panel.setAttribute('aria-modal', 'true');
		panel.setAttribute('aria-labelledby', 'sonyra-pages-modal-title');
		closeButton.setAttribute('aria-label', t('manager.pages.modal.close'));
		closeButton.setAttribute('data-pages-close-modal', 'true');

		if (pagesState.deleteModalOpen) {
			var deleteTargetName = getDeleteTargetName(pagesState.deleteTargetType, pagesState.deleteTargetId, pagesState.deleteTargetParentId);
			icon.appendChild(clonePagesIcon('alert-triangle'));
			panel.classList.add('sonyra-manager-pages-modal-danger', 'sonyra-manager-modal--destructive');
			title.id = 'sonyra-pages-modal-title';
			title.textContent = pagesState.deleteTargetType === 'section' ? replacePlaceholder(t('manager.pages.sections.delete_section_title_named'), deleteTargetName) : (pagesState.deleteTargetType === 'block' ? t('manager.pages.sections.delete_block_title') : t('manager.pages.modal.delete_page_title'));
			description.textContent = t('manager.pages.modal.delete_line_one');
			copy.appendChild(title);
			copy.appendChild(description);
			body.appendChild(createTextNode('p', 'sonyra-manager-pages-modal-danger-text', pagesState.deleteTargetType === 'section' ? replacePlaceholder(t('manager.pages.sections.delete_section_line_two_named'), deleteTargetName) : (pagesState.deleteTargetType === 'block' ? t('manager.pages.sections.delete_block_line_two') : t('manager.pages.modal.delete_page_line_two'))));
			if (pagesState.deleteTargetType === 'section') {
				body.appendChild(createTextNode('p', 'sonyra-manager-modal__danger-note', t('manager.pages.sections.delete_section_blocks_warning')));
			}
			footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel')));
			footer.lastChild.setAttribute('data-pages-close-modal', 'true');
			footer.appendChild(createButton('sonyra-manager-pages-primary sonyra-manager-pages-primary-danger', t('manager.pages.actions.delete')));
			footer.lastChild.setAttribute('data-pages-confirm-delete', pagesState.deleteTargetId);
		} else if (pagesState.historyModalOpen) {
			var historyPage = findPage(pagesState.historyTargetId);
			var historyItems = historyPage && Array.isArray(historyPage.history) ? historyPage.history : [];

			icon.appendChild(clonePagesIcon('history'));
			title.id = 'sonyra-pages-modal-title';
			title.textContent = t('manager.pages.history.title');
			description.textContent = t('manager.pages.history.description');
			copy.appendChild(title);
			copy.appendChild(description);

			if (!historyItems.length) {
				body.appendChild(createTextNode('strong', '', t('manager.pages.history.empty_title')));
				body.appendChild(createTextNode('p', 'sonyra-manager-pages-modal-description', t('manager.pages.history.empty_description')));
			} else {
				var historyList = createTextNode('div', 'sonyra-manager-pages-history-list');
				historyItems.forEach(function (eventItem) {
					var formatted = formatPageUpdatedAt(eventItem.at || '');
					var row = createTextNode('article', 'sonyra-manager-pages-history-item');
					row.appendChild(createTextNode('strong', 'sonyra-manager-pages-history-item-title', eventItem.label || ''));
					row.appendChild(createTextNode('time', 'sonyra-manager-pages-history-item-time', formatted.dateText + (formatted.timeText ? ' · ' + formatted.timeText : '')));
					if (eventItem.details) {
						row.appendChild(createTextNode('p', 'sonyra-manager-pages-history-item-details', eventItem.details));
					}
					historyList.appendChild(row);
				});
				body.appendChild(historyList);
			}

				footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.modal.close')));
				footer.lastChild.setAttribute('data-pages-close-modal', 'true');
		} else if (pagesState.sectionLibraryModalOpen) {
			icon.appendChild(clonePagesIcon('section'));
			title.id = 'sonyra-pages-modal-title';
			title.textContent = t('manager.pages.sections.add_modal_title');
			description.textContent = t('manager.pages.sections.add_modal_description');
			copy.appendChild(title);
			copy.appendChild(description);
			body.appendChild(buildSectionLibraryModalBody());
			footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel')));
			footer.lastChild.setAttribute('data-pages-close-modal', 'true');
		} else if (pagesState.sectionModalOpen && pagesState.sectionDraft) {
			icon.appendChild(clonePagesIcon('settings'));
			title.id = 'sonyra-pages-modal-title';
			title.textContent = t('manager.pages.sections.section_modal_title');
			description.textContent = t('manager.pages.sections.section_modal_description');
			copy.appendChild(title);
			copy.appendChild(description);
			body.appendChild(createNamedModalField('section', 'name', t('manager.pages.sections.section_name'), pagesState.sectionDraft.name || '', 'text'));
			body.appendChild(createReadonlyModalField(t('manager.pages.sections.section_type'), getSectionTypeLabel(pagesState.sectionDraft.type), t('manager.pages.sections.type_readonly')));
			footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel')));
			footer.lastChild.setAttribute('data-pages-close-modal', 'true');
			footer.appendChild(createButton('sonyra-manager-pages-primary', pagesState.saving ? t('manager.pages.actions.saving') : t('manager.pages.actions.save')));
			footer.lastChild.setAttribute('data-pages-save-section-modal', 'true');
			footer.lastChild.disabled = pagesState.saving;
		} else if (pagesState.blockModalOpen && pagesState.blockDraft) {
			icon.appendChild(clonePagesIcon('settings'));
			title.id = 'sonyra-pages-modal-title';
			title.textContent = t('manager.pages.sections.block_modal_title');
			description.textContent = t('manager.pages.sections.block_modal_description');
			copy.appendChild(title);
			copy.appendChild(description);
			body.appendChild(createNamedModalField('block', 'name', t('manager.pages.sections.block_name'), pagesState.blockDraft.name || '', 'text'));
			if (pagesState.blockDraft.type === 'hero') {
				body.appendChild(createNamedModalField('block', 'kicker', t('manager.pages.sections.kicker'), pagesState.blockDraft.kicker || '', 'text'));
				body.appendChild(createNamedModalField('block', 'heading', t('manager.pages.sections.title'), pagesState.blockDraft.heading || '', 'text'));
				body.appendChild(createNamedModalField('block', 'text', t('manager.pages.sections.text_field'), pagesState.blockDraft.text || '', 'textarea'));
				body.appendChild(createNamedModalField('block', 'button_label', t('manager.pages.sections.button_label'), pagesState.blockDraft.button_label || '', 'text'));
				body.appendChild(createNamedModalField('block', 'button_url', t('manager.pages.sections.button_url'), pagesState.blockDraft.button_url || '', 'url'));
			} else if (pagesState.blockDraft.type === 'contacts') {
				body.appendChild(createNamedModalField('block', 'heading', t('manager.pages.sections.title'), pagesState.blockDraft.heading || '', 'text'));
				body.appendChild(createNamedModalField('block', 'description', t('manager.pages.sections.description_field'), pagesState.blockDraft.description || '', 'textarea'));
				body.appendChild(createNamedModalField('block', 'email', t('manager.pages.sections.email'), pagesState.blockDraft.email || '', 'email'));
				body.appendChild(createNamedModalField('block', 'phone', t('manager.pages.sections.phone'), pagesState.blockDraft.phone || '', 'text'));
				body.appendChild(createNamedModalField('block', 'address', t('manager.pages.sections.address'), pagesState.blockDraft.address || '', 'text'));
			} else {
				body.appendChild(createNamedModalField('block', 'heading', t('manager.pages.sections.title'), pagesState.blockDraft.heading || '', 'text'));
				body.appendChild(createNamedModalField('block', 'text', t('manager.pages.sections.text_field'), pagesState.blockDraft.text || '', 'textarea'));
			}
			footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel')));
			footer.lastChild.setAttribute('data-pages-close-modal', 'true');
			footer.appendChild(createButton('sonyra-manager-pages-primary', pagesState.saving ? t('manager.pages.actions.saving') : t('manager.pages.actions.save')));
			footer.lastChild.setAttribute('data-pages-save-block-modal', 'true');
			footer.lastChild.disabled = pagesState.saving;
		} else if (pagesState.modalDraft) {
			icon.appendChild(clonePagesIcon('settings'));
			title.id = 'sonyra-pages-modal-title';
			title.textContent = t('manager.pages.modal.page_title');
			description.textContent = t('manager.pages.modal.page_description');
			copy.appendChild(title);
			copy.appendChild(description);
			body.appendChild(createPageModalField('title', t('manager.pages.fields.title'), pagesState.modalDraft.title, 'text'));
			body.appendChild(createPageModalField('slug', t('manager.pages.fields.slug'), pagesState.modalDraft.slug, 'text'));
			body.appendChild(createPageModalField('status', t('manager.pages.fields.status'), pagesState.modalDraft.status, 'select'));
			body.appendChild(createPageModalField('menu_order', t('manager.pages.fields.menu_order'), String(pagesState.modalDraft.menu_order || 0), 'number'));
			body.appendChild(createPageSwitch('is_home', t('manager.pages.fields.is_home'), pagesState.modalDraft.is_home));
			body.appendChild(createPageSwitch('show_in_menu', t('manager.pages.fields.show_in_menu'), pagesState.modalDraft.show_in_menu, pagesState.modalDraft.status !== 'published'));
			body.appendChild(createPageModalField('menu_title', t('manager.pages.fields.menu_title'), pagesState.modalDraft.menu_title, 'text'));
			body.appendChild(createPageModalField('seo_title', t('manager.pages.fields.seo_title'), pagesState.modalDraft.seo_title, 'text'));
			body.appendChild(createPageModalField('seo_description', t('manager.pages.fields.seo_description'), pagesState.modalDraft.seo_description, 'textarea'));
			footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel')));
			footer.lastChild.setAttribute('data-pages-close-modal', 'true');
			footer.appendChild(createButton('sonyra-manager-pages-primary', pagesState.saving ? t('manager.pages.actions.saving') : t('manager.pages.actions.save')));
			footer.lastChild.setAttribute('data-pages-save-modal', 'true');
			footer.lastChild.disabled = pagesState.saving;
		}

		header.appendChild(icon);
		header.appendChild(copy);
		header.appendChild(closeButton);
		panel.appendChild(header);
		panel.appendChild(body);
		panel.appendChild(footer);
		overlay.appendChild(panel);
		modalRoot.appendChild(overlay);
	}

	function buildSectionLibraryModalBody() {
		var grid = createTextNode('div', 'sonyra-pages-section-library-grid');

		getSectionDefinitions().forEach(function (definition) {
			grid.appendChild(createSectionLibraryCard(definition));
		});

		return grid;
	}

	function createSectionLibraryCard(definition) {
		var card = createTextNode('button', 'sonyra-pages-section-library-card');
		var icon = createTextNode('span', 'sonyra-pages-section-library-icon');
		var copy = createTextNode('span', 'sonyra-pages-section-library-copy');
		var category = getSectionCategoryLabel(definition.category);
		var isPending = pagesState.addingSection && pagesState.pendingSectionType === definition.type;

		card.type = 'button';
		card.setAttribute('data-pages-library-section', definition.type);
		card.disabled = pagesState.addingSection || pagesState.saving;
		card.setAttribute('aria-disabled', card.disabled ? 'true' : 'false');
		card.classList.toggle('is-pending', isPending);
		icon.appendChild(clonePagesIcon(definition.icon_key));
		copy.appendChild(createTextNode('strong', 'sonyra-pages-section-library-title', definition.label));
		copy.appendChild(createTextNode('span', 'sonyra-pages-section-library-description', definition.description));

		if (category) {
			copy.appendChild(createTextNode('span', 'sonyra-pages-section-library-category', category));
		}

		card.appendChild(icon);
		card.appendChild(copy);
		return card;
	}

	function createNamedModalField(scope, key, labelText, value, type) {
		var field = createTextNode('label', 'sonyra-manager-pages-field');
		var title = createTextNode('span', '', labelText);
		var control = type === 'textarea' ? document.createElement('textarea') : document.createElement('input');
		if (type === 'textarea') {
			control.rows = 4;
		} else {
			control.type = type || 'text';
		}
		control.value = value || '';
		control.setAttribute('data-pages-' + scope + '-modal-field', key);
		field.appendChild(title);
		field.appendChild(control);
		return field;
	}

	function createReadonlyModalField(labelText, valueText, hintText) {
		var field = createTextNode('div', 'sonyra-manager-pages-field sonyra-pages-modal-readonly-field');
		field.appendChild(createTextNode('span', '', labelText));
		field.appendChild(createTextNode('div', 'sonyra-pages-modal-readonly-value', valueText));
		if (hintText) {
			field.appendChild(createTextNode('p', 'sonyra-manager-pages-modal-description', hintText));
		}
		return field;
	}

	function createPageModalField(key, labelText, value, type) {
		var field = createTextNode('label', 'sonyra-manager-pages-field');
		var title = createTextNode('span', '', labelText);
		var control;

		if (type === 'textarea') {
			control = document.createElement('textarea');
			control.rows = 3;
		} else if (type === 'select') {
			control = document.createElement('select');
			[
				{ value: 'draft', label: t('manager.pages.status.draft') },
				{ value: 'published', label: t('manager.pages.status.published') },
				{ value: 'hidden', label: t('manager.pages.status.hidden') }
			].forEach(function (optionData) {
				var option = document.createElement('option');
				option.value = optionData.value;
				option.textContent = optionData.label;
				control.appendChild(option);
			});
		} else {
			control = document.createElement('input');
			control.type = type;
		}

		control.value = value || '';
		control.setAttribute('data-pages-modal-field', key);
		field.appendChild(title);
		field.appendChild(control);
		return field;
	}

	function createPageSwitch(key, labelText, active, disabled) {
		var button = createButton('sonyra-manager-pages-switch', labelText);
		button.setAttribute('data-pages-modal-switch', key);
		button.setAttribute('aria-pressed', active ? 'true' : 'false');
		button.classList.toggle('sonyra-manager-pages-switch-active', active === true);
		button.disabled = disabled === true;
		button.insertBefore(createTextNode('span', 'sonyra-manager-pages-switch-control'), button.firstChild);
		return button;
	}

	function updateModalDraftField(key, value) {
		if (!pagesState.modalDraft) {
			return;
		}

		if (key === 'menu_order') {
			pagesState.modalDraft[key] = Math.max(0, Math.min(999, Number(value || 0)));
		} else {
			pagesState.modalDraft[key] = value;
		}

		if (key === 'status' && value !== 'published') {
			pagesState.modalDraft.show_in_menu = false;
		}

		if (key === 'status') {
			renderPageModal();
		}
	}

	function updateSectionDraftField(key, value) {
		if (!pagesState.sectionDraft) {
			return;
		}

		pagesState.sectionDraft[key] = value;
	}

	function updateBlockDraftField(key, value) {
		if (!pagesState.blockDraft) {
			return;
		}

		pagesState.blockDraft[key] = value;
	}

	function toggleModalDraftSwitch(key) {
		if (!pagesState.modalDraft) {
			return;
		}

		if (key === 'show_in_menu' && pagesState.modalDraft.status !== 'published') {
			return;
		}

		pagesState.modalDraft[key] = !pagesState.modalDraft[key];
		renderPageModal();
	}

	function closePageOverlay() {
		pagesState.pageModalOpen = false;
		pagesState.sectionLibraryModalOpen = false;
		pagesState.sectionModalOpen = false;
		pagesState.blockModalOpen = false;
		pagesState.historyModalOpen = false;
		pagesState.deleteModalOpen = false;
		pagesState.modalDraft = null;
		pagesState.sectionDraft = null;
		pagesState.blockDraft = null;
		pagesState.historyTargetId = '';
		pagesState.deleteTargetType = '';
		pagesState.deleteTargetId = '';
		pagesState.deleteTargetParentId = '';
		pagesState.addingSection = false;
		pagesState.pendingSectionType = '';
		renderPageModal();

		if (pagesState.lastTrigger && typeof pagesState.lastTrigger.focus === 'function') {
			pagesState.lastTrigger.focus();
		}
	}

	function openSectionLibrary(trigger) {
		pagesState.sectionLibraryModalOpen = true;
		pagesState.pageModalOpen = false;
		pagesState.sectionModalOpen = false;
		pagesState.blockModalOpen = false;
		pagesState.historyModalOpen = false;
		pagesState.deleteModalOpen = false;
		pagesState.lastTrigger = trigger || document.activeElement;
		renderPageModal();
	}

	function savePagesCollection(items, onSuccess, onError) {
		var pagesUrl = shell.getAttribute('data-pages-url') || '';
		var previousItems = pagesState.items.slice();

		if (!pagesRoot || !pagesUrl || pagesState.saving) {
			return;
		}

		pagesState.saving = true;
		pagesState.items = items.map(normalizePage);
		renderPageModal();
		renderPagesGridContentOnly();
		renderPagesHeaderBadges();

		fetch(pagesUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-Sonyra-Pages-Nonce': shell.getAttribute('data-pages-nonce') || ''
			},
			body: JSON.stringify({ items: items })
		}).then(function (response) {
			return response.json().catch(function () {
				return {};
			}).then(function (data) {
				if (!response.ok) {
					throw new Error(data.message || t('manager.pages.errors.save_failed'));
				}

				return data;
			});
			}).then(function (data) {
				pagesState.items = Array.isArray(data.items) ? data.items.map(normalizePage) : pagesState.items;

				if (typeof onSuccess === 'function') {
					onSuccess(data);
				}

				renderPages();
			}).catch(function (error) {
				pagesState.items = previousItems.map(normalizePage);
				if (typeof onError === 'function') {
					onError(error);
				}
				setPagesMessage('error', error.message || t('manager.pages.errors.save_failed'));
				renderPages();
			}).finally(function () {
				pagesState.saving = false;
				clearPendingPageAction();
				renderPageModal();
				renderPagesGridContentOnly();
			});
	}

	function savePageModal() {
		if (!pagesState.modalDraft) {
			return;
		}

		var items = pagesState.items.map(normalizePage);
		var index = items.findIndex(function (page) {
			return page.id === pagesState.modalDraft.id;
		});
		var currentPage = index >= 0 ? items[index] : null;
		var nextPage = normalizePage({
			id: pagesState.modalDraft.id,
			title: pagesState.modalDraft.title,
			slug: pagesState.modalDraft.slug,
			status: pagesState.modalDraft.status,
			is_home: pagesState.modalDraft.is_home,
			show_in_menu: pagesState.modalDraft.show_in_menu,
			menu_title: pagesState.modalDraft.menu_title,
			menu_order: pagesState.modalDraft.menu_order,
			seo_title: pagesState.modalDraft.seo_title,
			seo_description: pagesState.modalDraft.seo_description,
			sections: index >= 0 ? items[index].sections : [],
			history: currentPage && Array.isArray(currentPage.history) ? currentPage.history : []
		});
		var successMessageKey = index >= 0 ? 'manager.pages.success.saved' : 'manager.pages.success.created';

		if (nextPage.is_home) {
			items = items.map(function (page) {
				page.is_home = false;
				return page;
			});
		}

		if (index >= 0 && currentPage && currentPage.slug !== nextPage.slug) {
			addPageHistoryEvent(nextPage, 'slug_changed');
		}

		addPageHistoryEvent(nextPage, index >= 0 ? 'updated' : 'created');

		if (index >= 0) {
			items[index] = nextPage;
		} else {
			items.push(nextPage);
		}

		setPagesMessage('loading', t(index >= 0 ? 'manager.pages.pending.saving' : 'manager.pages.pending.creating'));
		savePagesCollection(items, function () {
			pagesState.activeId = nextPage.id;
			setPagesMessage('success', t(successMessageKey));
			closePageOverlay();
		});
	}

	function deletePage(pageId) {
		var items = pagesState.items.filter(function (page) {
			return page.id !== pageId;
		});

		savePagesCollection(items, function () {
			if (pagesState.activeId === pageId) {
				pagesState.activeId = items[0] ? items[0].id : '';
			}

			closePageOverlay();
		});
	}

	function copyPageUrl(pageId) {
		var page = findPage(pageId);

		if (!page) {
			return;
		}

		if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
			setPagesMessage('error', t('manager.pages.table.link_copy_error'));
			return;
		}

		navigator.clipboard.writeText(getPagesUrl(page)).then(function () {
			setPagesMessage('success', t('manager.pages.table.link_copied'));
		}).catch(function () {
			setPagesMessage('error', t('manager.pages.table.link_copy_error'));
		});
	}

	function makePageHome(pageId) {
		var items = pagesState.items.map(normalizePage).map(function (page) {
			page.is_home = page.id === pageId;
			return page;
		});

		items.forEach(function (page) {
			if (page.id === pageId) {
				addPageHistoryEvent(page, 'home');
			}
		});

		setPendingPageAction(pageId, 'make-home', 'manager.pages.pending.home');
		savePagesCollection(items, function () {
			pagesState.openDropdownId = '';
			setPagesMessage('success', t('manager.pages.success.home_updated'));
		});
	}

	function hidePage(pageId) {
		var items = pagesState.items.map(normalizePage).map(function (page) {
			if (page.id === pageId) {
				page.status = 'hidden';
				page.show_in_menu = false;
				addPageHistoryEvent(page, 'hidden');
			}

			return page;
		});

		setPendingPageAction(pageId, 'hide', 'manager.pages.pending.hiding');
		savePagesCollection(items, function () {
			pagesState.openDropdownId = '';
			setPagesMessage('success', t('manager.pages.success.hidden'));
		});
	}

	function publishPage(pageId) {
		var items = pagesState.items.map(normalizePage).map(function (page) {
			if (page.id === pageId) {
				page.status = 'published';
				addPageHistoryEvent(page, 'published');
			}

			return page;
		});

		setPendingPageAction(pageId, 'publish', 'manager.pages.pending.publishing');
		savePagesCollection(items, function () {
			pagesState.openDropdownId = '';
			setPagesMessage('success', t('manager.pages.success.published'));
		});
	}

	function duplicatePage(pageId) {
		var source = findPage(pageId);

		if (!source) {
			return;
		}

		var duplicatedPage = normalizePage({
			id: createId('page'),
			title: (source.title || '') + ' ' + t('manager.pages.duplicate.suffix'),
			slug: buildDuplicateSlug(source.slug || 'home'),
			status: 'draft',
			is_home: false,
			show_in_menu: false,
			menu_title: source.menu_title || '',
			menu_order: Number(source.menu_order || 0) + 10,
			seo_title: source.seo_title || '',
			seo_description: source.seo_description || '',
			sections: Array.isArray(source.sections) ? source.sections.map(normalizeSection) : [],
			history: [],
			created_at: new Date().toISOString(),
			updated_at: new Date().toISOString()
		});

		addPageHistoryEvent(duplicatedPage, 'duplicated');
		setPendingPageAction(pageId, 'duplicate', 'manager.pages.pending.duplicating');
		savePagesCollection(pagesState.items.map(normalizePage).concat([duplicatedPage]), function () {
			pagesState.activeId = duplicatedPage.id;
			pagesState.openDropdownId = '';
			setPagesMessage('success', t('manager.pages.success.duplicated'));
		});
	}

	function openPageActionsDropdown(pageId, trigger) {
		if (!pageId) {
			return;
		}

		pagesState.openDropdownId = pageId;
		pagesState.lastTrigger = trigger || document.activeElement;
		renderPages();
		window.requestAnimationFrame(function () {
			applyPageActionsDropdownPlacement(pageId);
		});
	}

	function togglePageActionsDropdown(pageId, trigger) {
		if (pagesState.openDropdownId === pageId) {
			closePageActionsDropdown();
			return;
		}

		openPageActionsDropdown(pageId, trigger);
	}

	function closePageActionsDropdown() {
		if (!pagesState.openDropdownId) {
			return;
		}

		pagesState.openDropdownId = '';
		renderPages();
	}

	function applyPageActionsDropdownPlacement(pageId) {
		var dropdown = pagesRoot ? pagesRoot.querySelector('[data-sonyra-page-actions-menu="' + pageId + '"]') : null;
		var trigger = pagesRoot ? pagesRoot.querySelector('[data-sonyra-page-actions-trigger="' + pageId + '"]') : null;
		var triggerRect;
		var viewportHeight;
		var minimumGap = 12;
		var preferredHeight;
		var spaceBelow;
		var spaceAbove;
		var placement = 'down';
		var maxHeight;

		if (!dropdown || !trigger || dropdown.hidden) {
			return;
		}

		dropdown.classList.remove('is-open-up', 'is-open-down');
		dropdown.style.maxHeight = '';

		triggerRect = trigger.getBoundingClientRect();
		viewportHeight = window.innerHeight;
		preferredHeight = Math.ceil(dropdown.scrollHeight || dropdown.getBoundingClientRect().height || 0);
		spaceBelow = viewportHeight - triggerRect.bottom - minimumGap;
		spaceAbove = triggerRect.top - minimumGap;

		if (spaceBelow >= preferredHeight) {
			placement = 'down';
			maxHeight = Math.min(preferredHeight, spaceBelow);
		} else if (spaceAbove >= preferredHeight) {
			placement = 'up';
			maxHeight = Math.min(preferredHeight, spaceAbove);
		} else if (spaceAbove > spaceBelow) {
			placement = 'up';
			maxHeight = Math.max(180, spaceAbove);
		} else {
			placement = 'down';
			maxHeight = Math.max(180, spaceBelow);
		}

		dropdown.classList.add(placement === 'up' ? 'is-open-up' : 'is-open-down');
		dropdown.style.maxHeight = String(Math.max(180, Math.floor(maxHeight))) + 'px';
		dropdown.style.overflowY = 'auto';
	}

	function updateActivePageField(key, value) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		if (key === 'menu_order') {
			page[key] = Math.max(0, Math.min(999, Number(value || 0)));
		} else {
			page[key] = value;
		}

		if (key === 'status' && page.status !== 'published') {
			page.show_in_menu = false;
		}

		if (key === 'status') {
			renderPages();
		}
	}

	function toggleActivePageSetting(key) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		if (key === 'show_in_menu' && page.status !== 'published') {
			return;
		}

		page[key] = !page[key];

		if (key === 'is_home' && page.is_home) {
			pagesState.items.forEach(function (item) {
				if (item.id !== page.id) {
					item.is_home = false;
				}
			});
		}

		renderPages();
	}

	function addSection(type) {
		var page = getActivePage();
		var definition = getSectionDefinition(type);
		var nextType = definition ? definition.type : 'text';
		var defaults = definition && definition.default_section ? definition.default_section : { type: nextType, name: getDefaultSectionTitle(nextType), blocks: [] };
		var nextSectionId = createId('section');
		var items;

		if (!page) {
			return;
		}

		if (pagesState.addingSection || pagesState.saving) {
			return;
		}

		items = pagesState.items.map(normalizePage).map(function (currentPage) {
			var usedTitles;
			if (currentPage.id !== pagesState.activeId) {
				return currentPage;
			}

			usedTitles = currentPage.sections.map(function (section) {
				return section.name || '';
			});
			currentPage.sections.push(normalizeSection({
				id: nextSectionId,
				type: nextType,
				name: buildUniqueTitle(defaults.name || getDefaultSectionTitle(nextType), usedTitles),
				blocks: Array.isArray(defaults.blocks) ? defaults.blocks : [],
				provider: defaults.provider || (definition ? definition.provider : 'core'),
				module_key: defaults.module_key || (definition ? definition.module_key : '')
			}));
			addPageHistoryEvent(currentPage, 'updated');
			return currentPage;
		});

		pagesState.addingSection = true;
		pagesState.pendingSectionType = nextType;
		pagesState.activeSectionId = nextSectionId;
		pagesState.openAddMenu = '';
		renderPageModal();
		setPagesMessage('loading', t('manager.pages.pending.saving'));
		savePagesCollection(items, function () {
			pagesState.addingSection = false;
			pagesState.pendingSectionType = '';
			setPagesMessage('success', t('manager.pages.success.section_added'));
			closePageOverlay();
		}, function () {
			pagesState.addingSection = false;
			pagesState.pendingSectionType = '';
			renderPageModal();
		});
	}

	function addBlock(type) {
		var page = getActivePage();
		var section = getActiveSection(page);
		var nextType = ['hero', 'text', 'contacts'].indexOf(type) >= 0 ? type : (section ? section.type : 'text');
		var nextBlockId = createId('block');
		var items;

		if (!page || !section) {
			return;
		}

		items = pagesState.items.map(normalizePage).map(function (currentPage) {
			if (currentPage.id !== pagesState.activeId) {
				return currentPage;
			}

			currentPage.sections = currentPage.sections.map(function (currentSection) {
				var usedTitles;
				if (currentSection.id !== section.id) {
					return currentSection;
				}

				usedTitles = currentSection.blocks.map(function (block) {
					return block.name || '';
				});
				currentSection.blocks.push(normalizeBlock({
					id: nextBlockId,
					type: nextType,
					name: buildUniqueTitle(getDefaultBlockTitle(nextType), usedTitles)
				}, nextType));
				return currentSection;
			});
			addPageHistoryEvent(currentPage, 'updated');
			return currentPage;
		});

		pagesState.openAddMenu = '';
		setPagesMessage('loading', t('manager.pages.pending.saving'));
		savePagesCollection(items, function () {
			setPagesMessage('success', t('manager.pages.success.saved'));
		});
	}

	function openSectionSettings(sectionId, trigger) {
		var section = getSectionById(getActivePage(), sectionId);

		if (!section) {
			return;
		}

		pagesState.sectionDraft = normalizeSection(section);
		pagesState.sectionModalOpen = true;
		pagesState.blockModalOpen = false;
		pagesState.pageModalOpen = false;
		pagesState.lastTrigger = trigger || document.activeElement;
		renderPageModal();
	}

	function openBlockSettings(sectionId, blockId, trigger) {
		var section = getSectionById(getActivePage(), sectionId);
		var block;

		if (!section) {
			return;
		}

		block = section.blocks.find(function (item) {
			return item.id === blockId;
		}) || null;

		if (!block) {
			return;
		}

		pagesState.blockDraft = normalizeBlock(block, section.type);
		pagesState.blockDraft.sectionId = sectionId;
		pagesState.blockModalOpen = true;
		pagesState.sectionModalOpen = false;
		pagesState.pageModalOpen = false;
		pagesState.lastTrigger = trigger || document.activeElement;
		renderPageModal();
	}

	function saveSectionModal() {
		var items;

		if (!pagesState.sectionDraft) {
			return;
		}

		items = pagesState.items.map(normalizePage).map(function (page) {
			if (page.id !== pagesState.activeId) {
				return page;
			}

			page.sections = ensureUniqueTitles(page.sections.map(function (section) {
				if (section.id === pagesState.sectionDraft.id) {
					section.name = pagesState.sectionDraft.name || getDefaultSectionTitle(section.type);
				}

				return section;
			}), function (section) {
				return section.name || getDefaultSectionTitle(section.type);
			});
			addPageHistoryEvent(page, 'updated');
			return page;
		});

		setPagesMessage('loading', t('manager.pages.pending.saving'));
		savePagesCollection(items, function () {
			setPagesMessage('success', t('manager.pages.success.saved'));
			closePageOverlay();
		});
	}

	function saveBlockModal() {
		var items;

		if (!pagesState.blockDraft || !pagesState.blockDraft.sectionId) {
			return;
		}

		items = pagesState.items.map(normalizePage).map(function (page) {
			if (page.id !== pagesState.activeId) {
				return page;
			}

			page.sections = page.sections.map(function (section) {
				if (section.id !== pagesState.blockDraft.sectionId) {
					return section;
				}

				section.blocks = ensureUniqueTitles(section.blocks.map(function (block) {
					if (block.id === pagesState.blockDraft.id) {
						block.name = pagesState.blockDraft.name || getDefaultBlockTitle(block.type);
						block.kicker = pagesState.blockDraft.kicker || '';
						block.heading = pagesState.blockDraft.heading || '';
						block.text = pagesState.blockDraft.text || '';
						block.description = pagesState.blockDraft.description || '';
						block.button_label = pagesState.blockDraft.button_label || '';
						block.button_url = pagesState.blockDraft.button_url || '';
						block.email = pagesState.blockDraft.email || '';
						block.phone = pagesState.blockDraft.phone || '';
						block.address = pagesState.blockDraft.address || '';
					}

					return block;
				}), function (block) {
					return block.name || getDefaultBlockTitle(block.type);
				});
				return section;
			});
			addPageHistoryEvent(page, 'updated');
			return page;
		});

		setPagesMessage('loading', t('manager.pages.pending.saving'));
		savePagesCollection(items, function () {
			setPagesMessage('success', t('manager.pages.success.saved'));
			closePageOverlay();
		});
	}

	function openDeleteModal(type, targetId, parentId, trigger) {
		pagesState.deleteTargetType = type;
		pagesState.deleteTargetId = targetId;
		pagesState.deleteTargetParentId = parentId || '';
		pagesState.deleteModalOpen = true;
		pagesState.pageModalOpen = false;
		pagesState.sectionModalOpen = false;
		pagesState.blockModalOpen = false;
		pagesState.lastTrigger = trigger || document.activeElement;
		renderPageModal();
	}

	function deleteSection(sectionId) {
		var items = pagesState.items.map(normalizePage).map(function (page) {
			if (page.id !== pagesState.activeId) {
				return page;
			}

			page.sections = page.sections.filter(function (section) {
				return section.id !== sectionId;
			});
			addPageHistoryEvent(page, 'updated');
			return page;
		});

		setPagesMessage('loading', t('manager.pages.pending.saving'));
		savePagesCollection(items, function () {
			var activePage = getActivePage();
			var nextSection = activePage && activePage.sections[0] ? activePage.sections[0] : null;
			pagesState.activeSectionId = nextSection ? nextSection.id : '';
			setPagesMessage('success', t('manager.pages.success.saved'));
			closePageOverlay();
		});
	}

	function deleteBlock(sectionId, blockId) {
		var items = pagesState.items.map(normalizePage).map(function (page) {
			if (page.id !== pagesState.activeId) {
				return page;
			}

			page.sections = page.sections.map(function (section) {
				if (section.id === sectionId) {
					section.blocks = section.blocks.filter(function (block) {
						return block.id !== blockId;
					});
				}

				return section;
			});
			addPageHistoryEvent(page, 'updated');
			return page;
		});

		setPagesMessage('loading', t('manager.pages.pending.saving'));
		savePagesCollection(items, function () {
			setPagesMessage('success', t('manager.pages.success.saved'));
			closePageOverlay();
		});
	}

	function reorderSections(sourceId, targetId) {
		reorderItems(function (page) {
			var nextSections = page.sections.slice();
			var fromIndex = nextSections.findIndex(function (section) { return section.id === sourceId; });
			var toIndex = nextSections.findIndex(function (section) { return section.id === targetId; });
			var moved;

			if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) {
				return null;
			}

			moved = nextSections.splice(fromIndex, 1)[0];
			nextSections.splice(toIndex, 0, moved);
			page.sections = nextSections;
			return page;
		});
	}

	function reorderBlocks(sectionId, sourceId, targetId) {
		reorderItems(function (page) {
			var updated = false;

			page.sections = page.sections.map(function (section) {
				var nextBlocks;
				var fromIndex;
				var toIndex;
				var moved;

				if (section.id !== sectionId) {
					return section;
				}

				nextBlocks = section.blocks.slice();
				fromIndex = nextBlocks.findIndex(function (block) { return block.id === sourceId; });
				toIndex = nextBlocks.findIndex(function (block) { return block.id === targetId; });

				if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) {
					return section;
				}

				moved = nextBlocks.splice(fromIndex, 1)[0];
				nextBlocks.splice(toIndex, 0, moved);
				section.blocks = nextBlocks;
				updated = true;
				return section;
			});

			return updated ? page : null;
		});
	}

	function reorderItems(mutator) {
		var items = pagesState.items.map(normalizePage);
		var changed = false;
		var nextItems = items.map(function (page) {
			var nextPage = mutator(page);

			if (nextPage) {
				addPageHistoryEvent(nextPage, 'updated');
				changed = true;
				return nextPage;
			}

			return page;
		});

		if (!changed) {
			return;
		}

		pagesState.openAddMenu = '';
		savePagesCollection(nextItems, function () {
			setPagesMessage('success', t('manager.pages.success.saved'));
		});
	}

	function savePages() {
		var pagesUrl = shell.getAttribute('data-pages-url') || '';
		var saveButton = pagesRoot ? pagesRoot.querySelector('[data-pages-save]') : null;
		var activePage = getActivePage();

		if (!pagesRoot || !pagesUrl || pagesState.saving) {
			return;
		}

		if (activePage) {
			addPageHistoryEvent(activePage, 'updated');
		}

		pagesState.saving = true;
		setPagesMessage('loading', t('manager.pages.pending.saving'));

		if (saveButton) {
			saveButton.disabled = true;
			saveButton.querySelector('span:last-child').textContent = t('manager.pages.actions.saving');
		}

		fetch(pagesUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-Sonyra-Pages-Nonce': shell.getAttribute('data-pages-nonce') || ''
			},
			body: JSON.stringify({ items: pagesState.items })
		}).then(function (response) {
			return response.json().catch(function () {
				return {};
			}).then(function (data) {
				if (!response.ok) {
					throw new Error(data.message || t('manager.pages.errors.save_failed'));
				}

				return data;
			});
		}).then(function (data) {
			pagesState.items = Array.isArray(data.items) ? data.items.map(normalizePage) : pagesState.items;
			setPagesMessage('success', data.message || t('manager.pages.success.saved'));
			renderPages();
		}).catch(function (error) {
			setPagesMessage('error', error.message || t('manager.pages.errors.save_failed'));
			renderPages();
		}).finally(function () {
			pagesState.saving = false;

			if (saveButton) {
				saveButton.disabled = false;
				saveButton.querySelector('span:last-child').textContent = t('manager.pages.actions.save');
			}
		});
	}

	function openPage(page) {
		if (!page || !page.can_open) {
			setPagesMessage('error', t('manager.pages.errors.page_not_openable'));
			return;
		}

		window.open(getPagesUrl(page), '_blank', 'noopener');
	}

	function openPreviewPage(page) {
		if (!page) {
			return;
		}

		window.open(getPagePreviewUrl(page), '_blank', 'noopener');
	}

	function handlePagesClick(event) {
		var pagesAction = event.target.closest('[data-pages-create], [data-pages-open-site]');

		if (!pagesRoot || (!pagesRoot.contains(event.target) && !pagesAction)) {
			closePageActionsDropdown();
			return;
		}

		var createButton = event.target.closest('[data-pages-create]');
		var backButton = event.target.closest('[data-pages-back-to-table]');
		var resetFiltersButton = event.target.closest('[data-pages-reset-filters]');
		var filterChip = event.target.closest('[data-pages-filter]');
		var dropdownToggle = event.target.closest('[data-sonyra-page-actions-trigger]');
		var dropdownAction = event.target.closest('[data-sonyra-page-action]');
		var dropdownMenu = event.target.closest('[data-sonyra-page-actions-menu]');
		var pagesMessageClose = event.target.closest('[data-pages-message-close]');
		var closeModalButton = event.target.closest('[data-pages-close-modal]');
		var confirmDeleteButton = event.target.closest('[data-pages-confirm-delete]');
		var saveButton = event.target.closest('[data-pages-save]');
		var saveModalButton = event.target.closest('[data-pages-save-modal]');
		var editButton = event.target.closest('[data-pages-edit]');
		var openButton = event.target.closest('[data-pages-open]');
		var openCurrent = event.target.closest('[data-pages-open-current]');
		var openSite = event.target.closest('[data-pages-open-site]');
		var openSectionLibraryButton = event.target.closest('[data-pages-open-section-library]');
		var switchButton = event.target.closest('[data-pages-switch]');
		var modalSwitchButton = event.target.closest('[data-pages-modal-switch]');
		var addMenuTrigger = event.target.closest('[data-pages-add-menu-trigger]');
		var addSectionButton = event.target.closest('[data-pages-add-section]');
		var addBlockButton = event.target.closest('[data-pages-add-block]');
		var sectionLibraryCard = event.target.closest('[data-pages-library-section]');
		var sectionSelectButton = event.target.closest('[data-pages-section-select]');
		var sectionSettingsButton = event.target.closest('[data-pages-section-settings]');
		var sectionDeleteButton = event.target.closest('[data-pages-section-delete]');
		var blockSettingsButton = event.target.closest('[data-pages-block-settings]');
		var blockDeleteButton = event.target.closest('[data-pages-block-delete]');
		var saveSectionModalButton = event.target.closest('[data-pages-save-section-modal]');
		var saveBlockModalButton = event.target.closest('[data-pages-save-block-modal]');

		if (pagesMessageClose) {
			event.preventDefault();
			setPagesMessage('', '');
			return;
		}

		if (dropdownToggle) {
			event.preventDefault();
			event.stopPropagation();
			togglePageActionsDropdown(dropdownToggle.getAttribute('data-sonyra-page-actions-trigger') || '', dropdownToggle);
			return;
		}

		if (dropdownAction) {
			event.preventDefault();
			event.stopPropagation();

			if (dropdownAction.disabled || dropdownAction.classList.contains('is-disabled') || dropdownAction.getAttribute('aria-disabled') === 'true') {
				return;
			}

			handleDropdownAction(dropdownAction);
			return;
		}

		if (!dropdownMenu) {
			closePageActionsDropdown();
		}

		if (createButton) {
			event.preventDefault();
			createPage();
			} else if (backButton) {
				event.preventDefault();
				pagesState.mode = 'table';
				pagesState.openAddMenu = '';
				renderPages();
		} else if (resetFiltersButton) {
			event.preventDefault();
			pagesState.searchQuery = '';
			pagesState.statusFilter = 'all';
			pagesState.sort = 'recent';
			renderPages();
		} else if (filterChip) {
			event.preventDefault();
			pagesState.statusFilter = filterChip.getAttribute('data-pages-filter') || 'all';
			renderPages();
		} else if (closeModalButton) {
			event.preventDefault();
			closePageOverlay();
		} else if (confirmDeleteButton) {
			event.preventDefault();
			if (pagesState.deleteTargetType === 'section') {
				deleteSection(confirmDeleteButton.getAttribute('data-pages-confirm-delete') || '');
			} else if (pagesState.deleteTargetType === 'block') {
				deleteBlock(pagesState.deleteTargetParentId, confirmDeleteButton.getAttribute('data-pages-confirm-delete') || '');
			} else {
				deletePage(confirmDeleteButton.getAttribute('data-pages-confirm-delete') || '');
			}
		} else if (saveModalButton) {
			event.preventDefault();
			savePageModal();
		} else if (saveButton) {
			event.preventDefault();
			savePages();
		} else if (editButton) {
			event.preventDefault();
			pagesState.activeId = editButton.getAttribute('data-pages-edit') || '';
			renderPages();
		} else if (openButton) {
			event.preventDefault();
			openPage(findPage(openButton.getAttribute('data-pages-open') || ''));
		} else if (openCurrent) {
			event.preventDefault();
			openPage(getActivePage());
		} else if (openSite) {
			event.preventDefault();
			openPage(pagesState.items.find(function (page) {
				return page.can_open && page.is_home;
			}) || pagesState.items.find(function (page) {
				return page.can_open;
			}));
		} else if (openSectionLibraryButton) {
			event.preventDefault();
			openSectionLibrary(openSectionLibraryButton);
		} else if (switchButton) {
			event.preventDefault();
			toggleActivePageSetting(switchButton.getAttribute('data-pages-switch') || '');
		} else if (modalSwitchButton) {
			event.preventDefault();
			toggleModalDraftSwitch(modalSwitchButton.getAttribute('data-pages-modal-switch') || '');
		} else if (addMenuTrigger) {
			event.preventDefault();
			pagesState.openAddMenu = pagesState.openAddMenu === (addMenuTrigger.getAttribute('data-pages-add-menu-trigger') || '') ? '' : (addMenuTrigger.getAttribute('data-pages-add-menu-trigger') || '');
			renderPagesEditor();
		} else if (sectionLibraryCard) {
			event.preventDefault();
			if (sectionLibraryCard.disabled || sectionLibraryCard.getAttribute('aria-disabled') === 'true') {
				return;
			}
			addSection(sectionLibraryCard.getAttribute('data-pages-library-section') || 'text');
		} else if (addSectionButton) {
			event.preventDefault();
			addSection(addSectionButton.getAttribute('data-pages-add-section') || 'text');
		} else if (addBlockButton) {
			event.preventDefault();
			addBlock(addBlockButton.getAttribute('data-pages-add-block') || 'text');
		} else if (sectionSettingsButton) {
			event.preventDefault();
			openSectionSettings(sectionSettingsButton.getAttribute('data-pages-section-settings') || '', sectionSettingsButton);
		} else if (sectionDeleteButton) {
			event.preventDefault();
			openDeleteModal('section', sectionDeleteButton.getAttribute('data-pages-section-delete') || '', '', sectionDeleteButton);
		} else if (event.target.closest('[data-pages-help-tooltip-trigger]')) {
			var helpTrigger = event.target.closest('[data-pages-help-tooltip-trigger]');
			event.preventDefault();
			if (pagesState.openHelpTooltip === (helpTrigger.getAttribute('data-pages-help-tooltip-trigger') || '') && pagesState.openHelpTooltipPinned) {
				closeHelpTooltip();
			} else {
				openHelpTooltip(
					helpTrigger.getAttribute('data-pages-help-tooltip-trigger') || '',
					helpTrigger.getAttribute('data-sonyra-help-trigger') || '',
					true
				);
			}
		} else if (sectionSelectButton) {
			if (event.target.closest('[data-pages-drag-handle], .sonyra-pages-card-actions')) {
				return;
			}
			event.preventDefault();
			pagesState.activeSectionId = sectionSelectButton.getAttribute('data-pages-section-select') || '';
			renderPagesEditor();
		} else if (blockSettingsButton) {
			event.preventDefault();
			openBlockSettings(blockSettingsButton.getAttribute('data-pages-section-id') || '', blockSettingsButton.getAttribute('data-pages-block-settings') || '', blockSettingsButton);
		} else if (blockDeleteButton) {
			event.preventDefault();
			openDeleteModal('block', blockDeleteButton.getAttribute('data-pages-block-delete') || '', blockDeleteButton.getAttribute('data-pages-section-id') || '', blockDeleteButton);
		} else if (saveSectionModalButton) {
			event.preventDefault();
			saveSectionModal();
		} else if (saveBlockModalButton) {
			event.preventDefault();
			saveBlockModal();
		}
	}

	function handleDropdownAction(button) {
		if (button.classList.contains('is-disabled') || button.disabled || button.getAttribute('aria-disabled') === 'true') {
			return;
		}

		var action = button.getAttribute('data-sonyra-page-action') || '';
		var pageId = button.getAttribute('data-sonyra-page-id') || '';
		var page = findPage(pageId);

		if (!page) {
			return;
		}

		if (action === 'settings') {
			pagesState.openDropdownId = '';
			pagesState.modalDraft = normalizePage(page);
			pagesState.pageModalOpen = true;
			pagesState.lastTrigger = button;
			renderPages();
			return;
		}

			if (action === 'sections') {
				pagesState.openDropdownId = '';
				pagesState.activeId = pageId;
				pagesState.activeSectionId = page.sections[0] ? page.sections[0].id : '';
				pagesState.mode = 'sections';
				renderPages();
				return;
		}

		if (action === 'open') {
			closePageActionsDropdown();
			openPage(page);
			return;
		}

		if (action === 'preview') {
			closePageActionsDropdown();
			openPreviewPage(page);
			return;
		}

		if (action === 'copy') {
			closePageActionsDropdown();
			copyPageUrl(pageId);
			renderPages();
			return;
		}

		if (action === 'make-home') {
			closePageActionsDropdown();
			makePageHome(pageId);
			return;
		}

		if (action === 'history') {
			pagesState.openDropdownId = '';
			pagesState.historyTargetId = pageId;
			pagesState.historyModalOpen = true;
			pagesState.lastTrigger = button;
			renderPageModal();
			renderPagesGridContentOnly();
			return;
		}

		if (action === 'duplicate') {
			closePageActionsDropdown();
			duplicatePage(pageId);
			return;
		}

		if (action === 'hide') {
			closePageActionsDropdown();
			hidePage(pageId);
			return;
		}

		if (action === 'publish') {
			closePageActionsDropdown();
			publishPage(pageId);
			return;
		}

			if (action === 'delete') {
				pagesState.openDropdownId = '';
				pagesState.deleteTargetType = 'page';
				pagesState.deleteTargetId = pageId;
				pagesState.deleteTargetParentId = '';
				pagesState.deleteModalOpen = true;
				pagesState.lastTrigger = button;
				renderPages();
		}
	}

	function handlePagesInput(event) {
		if (!pagesRoot || !pagesRoot.contains(event.target)) {
			return;
		}

		var searchField = event.target.closest('[data-pages-search]');
		var modalField = event.target.closest('[data-pages-modal-field]');
		var sectionModalField = event.target.closest('[data-pages-section-modal-field]');
		var blockModalField = event.target.closest('[data-pages-block-modal-field]');

		if (searchField) {
			pagesState.searchQuery = searchField.value || '';
			renderPagesGridContentOnly();
		} else if (modalField) {
			updateModalDraftField(modalField.getAttribute('data-pages-modal-field') || '', modalField.value);
		} else if (sectionModalField) {
			updateSectionDraftField(sectionModalField.getAttribute('data-pages-section-modal-field') || '', sectionModalField.value);
		} else if (blockModalField) {
			updateBlockDraftField(blockModalField.getAttribute('data-pages-block-modal-field') || '', blockModalField.value);
		}
	}

	function handlePagesChange(event) {
		var filterChip = event.target.closest('[data-pages-filter]');
		var sortControl = event.target.closest('[data-pages-sort]');

		if (filterChip) {
			pagesState.statusFilter = filterChip.getAttribute('data-pages-filter') || 'all';
			renderPages();
		} else if (sortControl) {
			pagesState.sort = sortControl.value || 'recent';
			renderPages();
		}
	}

	function handlePagesDragStart(event) {
		var handle = event.target.closest('[data-pages-drag-handle]');

		if (!handle) {
			return;
		}

		if (handle.getAttribute('data-pages-drag-handle') === 'section') {
			pagesState.dragSectionId = handle.getAttribute('data-pages-drag-id') || '';
			pagesState.dragBlockId = '';
		} else {
			pagesState.dragBlockId = handle.getAttribute('data-pages-drag-id') || '';
			pagesState.dragSectionId = handle.getAttribute('data-pages-drag-section-id') || '';
		}

		if (event.dataTransfer) {
			event.dataTransfer.effectAllowed = 'move';
			event.dataTransfer.setData('text/plain', handle.getAttribute('data-pages-drag-id') || '');
		}
	}

	function handlePagesDragOver(event) {
		var sectionCard = event.target.closest('[data-pages-section-card]');
		var blockCard = event.target.closest('[data-pages-block-card]');

		if ((pagesState.dragSectionId && sectionCard) || (pagesState.dragBlockId && blockCard)) {
			event.preventDefault();
		}
	}

	function handlePagesDrop(event) {
		var sectionCard = event.target.closest('[data-pages-section-card]');
		var blockCard = event.target.closest('[data-pages-block-card]');
		var targetId;
		var targetSectionId;

		if (pagesState.dragSectionId && sectionCard) {
			event.preventDefault();
			targetId = sectionCard.getAttribute('data-pages-section-card') || '';
			if (targetId && targetId !== pagesState.dragSectionId) {
				reorderSections(pagesState.dragSectionId, targetId);
			}
		}

		if (pagesState.dragBlockId && blockCard) {
			event.preventDefault();
			targetId = blockCard.getAttribute('data-pages-block-card') || '';
			targetSectionId = blockCard.dataset.sectionId || '';
			if (targetId && targetSectionId && targetId !== pagesState.dragBlockId) {
				reorderBlocks(targetSectionId, pagesState.dragBlockId, targetId);
			}
		}

		pagesState.dragSectionId = '';
		pagesState.dragBlockId = '';
	}

	function handlePagesDragEnd() {
		pagesState.dragSectionId = '';
		pagesState.dragBlockId = '';
	}

	function openHelpTooltip(tooltipId, triggerId, pinned) {
		if (!tooltipId) {
			return;
		}

		pagesState.openHelpTooltip = tooltipId;
		pagesState.openHelpTooltipPinned = pinned === true;
		pagesState.openHelpTooltipTrigger = triggerId || '';
		renderPagesEditor();
	}

	function closeHelpTooltip() {
		if (!pagesState.openHelpTooltip) {
			return;
		}

		pagesState.openHelpTooltip = '';
		pagesState.openHelpTooltipPinned = false;
		pagesState.openHelpTooltipTrigger = '';
		renderPagesEditor();
	}

	SonyraPagesSection = {
		init: function () {
			initPagesI18n();
			initHelpEntries();
			initSectionDefinitions();
			initPagesLocale();

			if (!pagesRoot) {
				return;
			}

				shell.addEventListener('click', handlePagesClick);
				pagesRoot.addEventListener('input', handlePagesInput);
				pagesRoot.addEventListener('change', handlePagesChange);
				pagesRoot.addEventListener('dragstart', handlePagesDragStart);
				pagesRoot.addEventListener('dragover', handlePagesDragOver);
				pagesRoot.addEventListener('drop', handlePagesDrop);
				pagesRoot.addEventListener('dragend', handlePagesDragEnd);
				pagesRoot.addEventListener('click', function (event) {
					var overlay = event.target.closest('[data-pages-modal-overlay]');

				if (overlay && event.target === overlay) {
					closePageOverlay();
				}
			});
			pagesRoot.addEventListener('wheel', function (event) {
				if (event.target.closest('[data-sonyra-page-actions-menu]')) {
					event.stopPropagation();
				}
			}, { passive: true });
			pagesRoot.addEventListener('touchmove', function (event) {
				if (event.target.closest('[data-sonyra-page-actions-menu]')) {
					event.stopPropagation();
				}
			}, { passive: true });
			document.addEventListener('click', function (event) {
				if (event.target.closest('[data-sonyra-page-actions-trigger]') || event.target.closest('[data-sonyra-page-actions-menu]')) {
					return;
				}

				if (!pagesRoot.contains(event.target) && !event.target.closest('[data-pages-open-site]')) {
					closePageActionsDropdown();
					if (pagesState.openAddMenu) {
						pagesState.openAddMenu = '';
						if (pagesState.mode === 'sections') {
							renderPagesEditor();
						}
					}
					return;
				}

				if (pagesRoot.contains(event.target)) {
					closePageActionsDropdown();
				}

				if (!event.target.closest('[data-pages-add-menu-trigger]') && !event.target.closest('[data-pages-add-menu]')) {
					pagesState.openAddMenu = '';
					if (pagesState.mode === 'sections') {
						renderPagesEditor();
					}
				}

				if (!event.target.closest('[data-pages-help-tooltip-trigger]') && !event.target.closest('[data-pages-help-popover]')) {
					closeHelpTooltip();
				}
			});
			pagesRoot.addEventListener('mouseover', function (event) {
				var trigger = event.target.closest('[data-pages-help-tooltip-trigger]');

				if (!trigger) {
					return;
				}

				var tooltipId = trigger.getAttribute('data-pages-help-tooltip-trigger') || '';

				if (pagesState.openHelpTooltip === tooltipId && !pagesState.openHelpTooltipPinned) {
					return;
				}

				openHelpTooltip(tooltipId, trigger.getAttribute('data-sonyra-help-trigger') || '', false);
			});
			pagesRoot.addEventListener('mouseout', function (event) {
				var tooltipWrap = event.target.closest('.sonyra-help-tooltip-wrap');
				var relatedPopover = event.relatedTarget && event.relatedTarget.closest ? event.relatedTarget.closest('[data-pages-help-popover]') : null;

				if (!tooltipWrap || tooltipWrap.contains(event.relatedTarget) || relatedPopover) {
					return;
				}

				if (!pagesState.openHelpTooltipPinned) {
					closeHelpTooltip();
				}
			});
			pagesRoot.addEventListener('focusin', function (event) {
				var trigger = event.target.closest('[data-pages-help-tooltip-trigger]');

				if (!trigger) {
					return;
				}

				var tooltipId = trigger.getAttribute('data-pages-help-tooltip-trigger') || '';

				if (pagesState.openHelpTooltip === tooltipId && pagesState.openHelpTooltipPinned) {
					return;
				}

				openHelpTooltip(tooltipId, trigger.getAttribute('data-sonyra-help-trigger') || '', true);
			});
			pagesRoot.addEventListener('focusout', function (event) {
				var tooltipWrap = event.target.closest('.sonyra-help-tooltip-wrap');
				var relatedPopover = event.relatedTarget && event.relatedTarget.closest ? event.relatedTarget.closest('[data-pages-help-popover]') : null;

				if (!tooltipWrap || tooltipWrap.contains(event.relatedTarget) || relatedPopover) {
					return;
				}

				if (!pagesState.openHelpTooltipPinned) {
					closeHelpTooltip();
				}
			});
			pagesRoot.addEventListener('mouseout', function (event) {
				var popover = event.target.closest('[data-pages-help-popover]');

				if (!popover || popover.contains(event.relatedTarget)) {
					return;
				}

				if (!pagesState.openHelpTooltipPinned) {
					closeHelpTooltip();
				}
			});
					document.addEventListener('keydown', function (event) {
						if (event.key === 'Escape') {
							if (pagesState.openHelpTooltip) {
								closeHelpTooltip();
								return;
							}
							if (pagesState.deleteModalOpen || pagesState.pageModalOpen || pagesState.sectionLibraryModalOpen || pagesState.sectionModalOpen || pagesState.blockModalOpen || pagesState.historyModalOpen) {
								closePageOverlay();
								return;
							}

						pagesState.openAddMenu = '';
						closePageActionsDropdown();
					}
				});
			window.addEventListener('resize', function () {
				closePageActionsDropdown();
				if (pagesState.openHelpTooltip) {
					renderHelpPopover();
				}
			});

			if (pagesMain) {
				pagesMain.addEventListener('scroll', function () {
					closePageActionsDropdown();
					if (pagesState.openHelpTooltip) {
						renderHelpPopover();
					}
				});
			}
		},
			handleRouteChange: function (route) {
				if (route === 'pages' && pagesRoot && !pagesState.loaded) {
					loadPages();
				} else if (route === 'pages' && pagesRoot) {
					renderPagesToolbar();
					renderPagesHeaderBadges();
				}
			},
		load: loadPages,
		render: renderPages
	};

	SonyraPagesSection.init();

	routeButtons.forEach(function (button) {
		button.addEventListener('click', function () {
			setRoute(button.getAttribute('data-manager-route') || 'dashboard', true);
		});
	});

	if (toggleButton) {
		toggleButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true, true);
		});
	}

	if (logoButton) {
		logoButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true, true);
		});
	}

	if (backdrop) {
		backdrop.addEventListener('click', function () {
			setSidebarState('collapsed', false, true);
		});
	}

	if (logoutButton) {
		logoutButton.addEventListener('click', runLogout);
	}

	document.addEventListener('click', handleNoticeAction);
	initRenderedNotices();

	if (supportModal) {
		supportModal.addEventListener('click', function (event) {
			if (event.target === supportModal) {
				closeSupportModal();
			}
		});
	}

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && supportModal && !supportModal.hidden) {
			closeSupportModal();
			return;
		}

		if (event.key === 'Escape' && isMobile() && shell.getAttribute('data-sidebar-state') === 'expanded') {
			setSidebarState('collapsed', false, true);
		}
	});

	window.addEventListener('hashchange', function () {
		setRoute(getRouteFromHash(), false);
	});

	if (mediaQuery && mediaQuery.addEventListener) {
		mediaQuery.addEventListener('change', function () {
			setSidebarState(isMobile() ? 'collapsed' : (getStoredState() || 'expanded'), false);
		});
	}

	shell.addEventListener('transitionend', handleSidebarTransitionEnd);

	if (sidebar) {
		sidebar.addEventListener('transitionend', handleSidebarTransitionEnd);
	}

	setSidebarState(getStoredState() || (isMobile() ? 'collapsed' : 'expanded'), false);
	setRoute(getRouteFromHash(), false);
}());
