# SONYRA Release Checklist

## Pre-release checklist

- [ ] Этап release явно разрешён.
- [ ] Все файлы этапа определены.
- [ ] Нет незавершённых STOP-условий.
- [ ] Все обязательные проверки выполнены.
- [ ] Финальный отчёт подготовлен.
- [ ] Видимое название плагина: Пульт сайта.
- [ ] Издатель: SONYRA STUDIO.
- [ ] Правообладатель/лицензиар/продавец в документах: ИП Катаев С.А. / IPKTFSA.
- [ ] Stable plugin slug: `sonyra-site-manager`.
- [ ] Корень архива внутри zip: `sonyra-site-manager/`.
- [ ] Главный файл внутри zip: `sonyra-site-manager/sonyra-site-manager.php`.
- [ ] Версионный корень вида `sonyra-site-manager-X.X.X/` запрещён.
- [ ] Техническое имя архива: sonyra-site-manager-X.X.X.zip.
- [ ] Предыдущие архивы сохранены.
- [ ] Deploy не выполнялся.

## Version consistency

- [ ] plugin header проверен.
- [ ] SONYRA_SITE_MANAGER_VERSION проверен.
- [ ] asset version проверен.
- [ ] REST bootstrap проверен.
- [ ] manager footer/about проверен.
- [ ] diagnostics проверен.
- [ ] version log проверен.
- [ ] release checklist проверен.
- [ ] mismatch отсутствует.
- [ ] При mismatch релиз остановлен.

## File structure

- [ ] Созданы только разрешённые файлы.
- [ ] Не создан лишний scaffold.
- [ ] Не добавлены лишние директории.
- [ ] Нет случайных временных файлов.
- [ ] UTF-8 без BOM подтверждён.

## No old NDD code

- [ ] Старый NDD-код не использован.
- [ ] Навигатор добрых дел не использован как источник архитектуры.
- [ ] ndd-site-manager не использован как источник архитектуры.
- [ ] manager-app.js не использован как основа.
- [ ] manager-v2 не использован как основа.

## No forbidden working names

- [ ] Используются только SONYRA, SONYRA Site Platform, SONYRA Site Manager, SONYRA STUDIO.
- [ ] Запрещённые варианты написания не используются как рабочие названия.
- [ ] Техническое имя sonyra-site-manager используется последовательно.
- [ ] Главный файл sonyra-site-manager.php указан последовательно.

## UI and i18n audit

- [ ] Видимый пользовательский интерфейс только на русском языке.
- [ ] Английские видимые UI-слова отсутствуют.
- [ ] Английские fallback-строки отсутствуют.
- [ ] assets/i18n/i18n-ru.js содержит пользовательские UI-строки.
- [ ] t('key') используется для вывода пользовательских UI-строк.
- [ ] Русские UI-строки не написаны напрямую в PHP.
- [ ] Русские UI-строки не написаны напрямую в JS.
- [ ] Русские UI-строки не написаны напрямую в HTML templates.

## Security audit

- [ ] Manager закрыт от гостей.
- [ ] Manager закрыт от пользователей без прав.
- [ ] Capability checks проверены.
- [ ] Nonce/session checks проверены.
- [ ] sanitize input проверен.
- [ ] validate input проверен.
- [ ] escape output проверен.
- [ ] audit log проверен.
- [ ] denied access events проверены.

## REST audit

- [ ] Все REST endpoints имеют permissions callbacks.
- [ ] Private endpoints закрыты.
- [ ] Public endpoints имеют явный контракт.
- [ ] Guest access разрешён только там, где это публичный контракт.
- [ ] Ошибки REST не раскрывают секреты.
- [ ] Видимые REST-сообщения на русском языке.

## Route audit

- [ ] Manager routes проверены.
- [ ] Public routes проверены.
- [ ] Embed routes проверены.
- [ ] iframe routes проверены.
- [ ] Internal diagnostics routes проверены.
- [ ] WordPress Pages не используются как основа публичных страниц.

## DB migration audit for future

- [ ] Миграции имеют версию.
- [ ] Миграции обратимы или безопасно повторяемы.
- [ ] Ошибки миграций фиксируются.
- [ ] Release останавливается при неуспешной миграции.

## Database pre-release checks for future

- [ ] Migration plan присутствует.
- [ ] Backup/rollback note присутствует.
- [ ] db version изменён намеренно.
- [ ] Migration idempotent.
- [ ] Destructive migration отсутствует.
- [ ] Version log обновлён.
- [ ] Audit event записан.

## Manager UI audit for future

- [ ] Manager shell проверен.
- [ ] Рабочие UI-цепочки доказаны.
- [ ] DOM/root selector проверен.
- [ ] loading state проверен.
- [ ] success render проверен.
- [ ] error render проверен.
- [ ] Recovery/copy debug проверен, если нужен.

## Public renderer audit for future

- [ ] Собственная модель страниц проверена.
- [ ] Публичный рендер проверен.
- [ ] Output escaping проверен.
- [ ] Видимый пользовательский интерфейс только на русском языке.

## Embed/iframe audit for future

- [ ] Shortcode export используется только как export/embed-слой.
- [ ] iframe используется только как export/embed-слой.
- [ ] Embed token foundation проверен.
- [ ] iframe security foundation проверен.
- [ ] allowed domains foundation проверен.

## Классический ручной релиз

Перед сборкой:

- [ ] Проверки этапа пройдены.
- [ ] Нет STOP-срабатываний.
- [ ] Нет изменений вне разрешённых файлов.
- [ ] Версия синхронизирована.

Сборка:

- [ ] Архив создаётся только в ./dist/.
- [ ] Имя архива соответствует sonyra-site-manager-X.X.X.zip.
- [ ] Предыдущие архивы не удалены.
- [ ] Deploy не выполнялся.

После сборки:

- [ ] Наличие архива проверено.
- [ ] Размер архива проверен.
- [ ] Список файлов внутри архива проверен.
- [ ] Лишние системные файлы отсутствуют.
- [ ] .DS_Store отсутствует.
- [ ] node_modules отсутствует.
- [ ] Временные файлы отсутствуют.
- [ ] Старый NDD-код отсутствует.

Ручная проверка пользователем:

- [ ] Пользователь устанавливает zip через WordPress.
- [ ] Пользователь активирует плагин.
- [ ] Пользователь проверяет сайт.
- [ ] Пользователь проверяет экран плагина.
- [ ] При ошибке пользователь откатывается на предыдущий zip.

## Archive/package checklist for future

- [ ] Архив создаётся только на release-этапе.
- [ ] Архив не содержит временные файлы.
- [ ] Архив не содержит dev-only артефакты.
- [ ] Архив не содержит секреты.
- [ ] Архив соответствует version consistency.

## Private updater release checks

- [ ] Update endpoint проверен только на явно разрешённом updater-этапе.
- [ ] Manifest JSON валиден.
- [ ] Package URL принадлежит разрешённому домену.
- [ ] Package checksum / sha256 совпадает.
- [ ] Signature проверяется, когда signed manifest включён.
- [ ] License status проверяется, когда license/update integration включена.
- [ ] Fallback to manual zip через ./dist/ сохраняется.
- [ ] Update UI не создаётся отдельным пунктом меню WordPress.

## Extension architecture release checks

- [ ] Manifest расширения содержит compatibility metadata.
- [ ] Manifest расширения содержит license/update contract fields.
- [ ] Package URL принадлежит разрешённому repository domain.
- [ ] Checksum/signature validation предусмотрены для будущего install/update runtime.
- [ ] Расширение не ломает семь базовых разделов.
- [ ] Расширение не добавляет основные пункты меню без отдельного архитектурного решения.
- [ ] Расширение не подменяет sidebar, page header или дизайн-систему базы.
- [ ] Клиентский сайт не отправляет контент или персональные данные в центральную систему.
- [ ] Формулировки подключения к системе сопровождения не создают неверную семантику управления сайтом поставщиком.
- [ ] Zip не содержит `node_modules`, temp files, OS junk, hidden service dirs или full upstream dumps.

## Auth release checks for future

- [ ] No plain OTP storage.
- [ ] No user enumeration.
- [ ] Rate limits проверены.
- [ ] Lockout проверен.
- [ ] Session hash проверен.
- [ ] Audit events без секретов проверены.
- [ ] Russian visible UI проверен.
- [ ] wp-login не является main product UX.

## Auth cookie release checks for future

- [ ] Auth cookie содержит HttpOnly.
- [ ] Auth cookie содержит Secure on HTTPS.
- [ ] Auth cookie содержит SameSite.
- [ ] Auth token не хранится в localStorage/sessionStorage.
- [ ] Auth token не пишется в logs/audit/status.
- [ ] Logout clears cookie.
- [ ] Session revoke works.
- [ ] Access guard checked separately.

## REST auth release checks for future

- [ ] REST auth namespace correct: `sonyra-site-manager/v1`.
- [ ] `request-code` neutral response.
- [ ] `verify-code` no token in JSON.
- [ ] HttpOnly cookie set.
- [ ] `logout` clears cookie.
- [ ] `session` safe response.
- [ ] No English visible messages.
- [ ] No manager access from REST auth alone.

## Login screen release checks for future

- [ ] Login route not `wp-login`.
- [ ] Login UI Russian only.
- [ ] No password field in first release login.
- [ ] Identifier field says “Электронная почта или логин”.
- [ ] After request-code screen switches to code entry.
- [ ] No token in frontend.
- [ ] No localStorage/sessionStorage auth token.
- [ ] No email/login enumeration.
- [ ] Visual QA completed.
- [ ] Mobile QA completed.
- [ ] `/manager` protected separately.

## Final release report format

Финальный release-отчёт должен содержать:

- статус release;
- версию;
- список файлов и артефактов;
- результаты version consistency;
- результаты security audit;
- результаты REST audit;
- результаты route audit;
- результаты UI/i18n audit;
- результаты package checklist;
- STOP-условия и срабатывания;
- подтверждение, что старый NDD-код, manager-app.js и manager-v2 не использованы.

## Managed Site Agent release checks

Будущие release checks для PLATFORM/AGENT-этапов:

- [ ] No central owner UI inside managed site plugin.
- [ ] Managed site API signed.
- [ ] Unsigned commands rejected.
- [ ] Replay commands rejected.
- [ ] Unknown commands rejected.
- [ ] No arbitrary remote code execution.
- [ ] No arbitrary SQL execution.
- [ ] Telemetry excludes customer sales and personal data.
- [ ] Secrets masked.
- [ ] Command audit exists.
- [ ] Billing/access restriction safe.
- [ ] Manual restore safe.
- [ ] License/access status changes audited.
- [ ] Central Owner Control Plugin is separate.
