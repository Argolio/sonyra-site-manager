(function () {
	'use strict';

	var STORAGE_KEY = 'sonyra_manager_sidebar_state';
	var MOBILE_QUERY = '(max-width: 780px)';
	var shell = document.querySelector('[data-manager-shell]');

	if (!shell) {
		return;
	}

	var toggleButton = shell.querySelector('[data-manager-sidebar-toggle]');
	var logoButton = shell.querySelector('[data-manager-logo-toggle]');
	var sidebar = shell.querySelector('.sonyra-manager-sidebar');
	var backdrop = shell.querySelector('[data-manager-backdrop]');
	var routeButtons = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-route]'));
	var views = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-view]'));
	var pageKicker = shell.querySelector('[data-manager-kicker]');
	var topbarTitle = shell.querySelector('[data-manager-title]');
	var pageDescription = shell.querySelector('[data-manager-description]');
	var pageHeaderIcon = shell.querySelector('[data-manager-header-icon]');
	var pageBadges = shell.querySelector('[data-manager-badges]');
	var headerActionGroups = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-header-actions]'));
	var activeRoute = 'dashboard';
	var logoutButton = shell.querySelector('[data-manager-logout]');
	var logoutError = shell.querySelector('[data-manager-logout-error]');
	var noticeCenter = shell.querySelector('[data-manager-notice-center]');
	var supportModal = shell.querySelector('[data-manager-notice-support-modal]');
	var mediaQuery = window.matchMedia ? window.matchMedia(MOBILE_QUERY) : null;
	var sidebarMotionTimer = 0;

	function isMobile() {
		return mediaQuery ? mediaQuery.matches : window.innerWidth <= 780;
	}

	function getStoredState() {
		try {
			var value = window.localStorage.getItem(STORAGE_KEY);
			return value === 'collapsed' || value === 'expanded' ? value : '';
		} catch (error) {
			return '';
		}
	}

	function storeState(state) {
		try {
			window.localStorage.setItem(STORAGE_KEY, state);
		} catch (error) {}
	}

	function clearSidebarMotionTimer() {
		if (sidebarMotionTimer) {
			window.clearTimeout(sidebarMotionTimer);
			sidebarMotionTimer = 0;
		}
	}

	function finishSidebarMotion() {
		clearSidebarMotionTimer();
		shell.removeAttribute('data-sidebar-motion');
	}

	function beginSidebarMotion() {
		clearSidebarMotionTimer();
		shell.setAttribute('data-sidebar-motion', 'active');
		sidebarMotionTimer = window.setTimeout(finishSidebarMotion, 340);
	}

	function setSidebarState(state, shouldStore, shouldAnimate) {
		var nextState = state === 'collapsed' ? 'collapsed' : 'expanded';
		var currentState = shell.getAttribute('data-sidebar-state') || '';
		var shouldRunMotion = shouldAnimate === true && currentState && currentState !== nextState;
		var expanded = nextState === 'expanded';

		if (shouldRunMotion) {
			beginSidebarMotion();
		}

		shell.setAttribute('data-sidebar-state', nextState);
		shell.classList.toggle('sonyra-manager-mobile-open', expanded && isMobile());

		if (toggleButton) {
			toggleButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			toggleButton.setAttribute('aria-label', expanded ? (toggleButton.dataset.labelExpanded || '') : (toggleButton.dataset.labelCollapsed || ''));
		}

		if (logoButton) {
			logoButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			logoButton.setAttribute('aria-label', expanded ? (logoButton.dataset.labelExpanded || '') : (logoButton.dataset.labelCollapsed || ''));
		}

		if (backdrop) {
			backdrop.hidden = !(expanded && isMobile());
		}

		if (shouldStore) {
			storeState(nextState);
		}
	}

	function handleSidebarTransitionEnd(event) {
		if (!shell.hasAttribute('data-sidebar-motion')) {
			return;
		}

		if (
			(event.target === shell && event.propertyName === 'grid-template-columns') ||
			(event.target === sidebar && event.propertyName === 'width')
		) {
			finishSidebarMotion();
		}
	}

	function getRouteFromHash() {
		var hash = window.location.hash || '';
		var route = hash.replace(/^#\/?/, '').replace(/^\//, '');
		return route || 'dashboard';
	}

	function normalizeRoute(route) {
		var found = views.some(function (view) {
			return view.getAttribute('data-manager-view') === route;
		});

		return found ? route : 'dashboard';
	}

	function findTemplate(selector, route) {
		return shell.querySelector(selector + '="' + route + '"]');
	}

	function clearNode(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function updateHeaderIcon(route) {
		var iconTemplate = findTemplate('[data-manager-icon-template', route);

		if (pageHeaderIcon && iconTemplate && iconTemplate.firstElementChild) {
			clearNode(pageHeaderIcon);
			pageHeaderIcon.appendChild(iconTemplate.firstElementChild.cloneNode(true));
		}
	}

	function updateHeaderBadges(route) {
		var badgeTemplate = findTemplate('[data-manager-badge-template', route);

		if (pageBadges && badgeTemplate && badgeTemplate.firstElementChild) {
			pageBadges.parentNode.replaceChild(badgeTemplate.firstElementChild.cloneNode(true), pageBadges);
			pageBadges = shell.querySelector('[data-manager-badges]');
		}
	}

	function updateHeaderActions(route) {
		headerActionGroups.forEach(function (group) {
			group.hidden = group.getAttribute('data-manager-header-actions') !== route;
		});
	}

	function setRoute(route, shouldUpdateHash) {
		var nextRoute = normalizeRoute(route);
		var activeButton = null;
		activeRoute = nextRoute;

		views.forEach(function (view) {
			view.hidden = view.getAttribute('data-manager-view') !== nextRoute;
		});

		routeButtons.forEach(function (button) {
			var isActive = button.getAttribute('data-manager-route') === nextRoute;
			button.classList.toggle('sonyra-manager-nav-item-active', isActive);

			if (isActive) {
				button.setAttribute('aria-current', 'page');
				activeButton = button;
			} else {
				button.removeAttribute('aria-current');
			}
		});

		if (activeButton) {
			if (pageKicker) {
				pageKicker.textContent = activeButton.dataset.kicker || '';
			}

			if (topbarTitle) {
				topbarTitle.textContent = activeButton.dataset.title || activeButton.textContent || '';
			}

			if (pageDescription) {
				pageDescription.textContent = activeButton.dataset.description || '';
			}

			updateHeaderIcon(nextRoute);
			updateHeaderBadges(nextRoute);
			updateHeaderActions(nextRoute);
		}

		if (shouldUpdateHash && window.location.hash !== '#/' + nextRoute) {
			window.location.hash = '#/' + nextRoute;
		}

		if (isMobile()) {
			setSidebarState('collapsed', false, true);
		}

		if (nextRoute === 'pages' && pagesRoot && !pagesState.loaded) {
			loadPages();
		} else if (nextRoute === 'pages' && pagesRoot) {
			renderPagesToolbar();
		}
	}

	function showLogoutError() {
		if (noticeCenter) {
			noticeCenter.hidden = false;
		}

		if (logoutError) {
			logoutError.hidden = false;
		}
	}

	function closeSupportModal() {
		if (supportModal) {
			supportModal.hidden = true;
		}
	}

	function openSupportModal() {
		if (supportModal) {
			supportModal.hidden = false;
			var closeButton = supportModal.querySelector('[data-manager-notice-modal-close]');

			if (closeButton) {
				closeButton.focus();
			}
		}
	}

	function dismissNotice(targetId) {
		if (!targetId) {
			return;
		}

		var notice = shell.querySelector('[data-manager-notice-id="' + targetId + '"]');

		if (notice) {
			notice.hidden = true;
		}

		if (noticeCenter && !noticeCenter.querySelector('.sonyra-manager-notice-card:not([hidden])')) {
			noticeCenter.hidden = true;
		}
	}

	function handleNoticeAction(event) {
		var actionButton = event.target.closest('[data-manager-notice-action], [data-manager-notice-modal-close]');

		if (!actionButton || !shell.contains(actionButton) && (!supportModal || !supportModal.contains(actionButton))) {
			return;
		}

		if (actionButton.disabled) {
			return;
		}

		if (actionButton.hasAttribute('data-manager-notice-modal-close')) {
			event.preventDefault();
			closeSupportModal();
			return;
		}

		var action = actionButton.getAttribute('data-manager-notice-action') || '';

		if (action === 'reload') {
			event.preventDefault();
			window.location.reload();
			return;
		}

		if (action === 'dismiss') {
			event.preventDefault();
			dismissNotice(actionButton.getAttribute('data-manager-notice-target') || '');
			return;
		}

		if (action === 'open_modal') {
			event.preventDefault();
			openSupportModal();
		}
	}

	function redirectToLogin() {
		var loginUrl = shell.getAttribute('data-login-url') || '/manager/login';
		window.location.assign(loginUrl);
	}

	function runLogout() {
		var logoutUrl = shell.getAttribute('data-logout-url') || '';

		if (!logoutUrl || logoutUrl.indexOf('://') === -1 && logoutUrl.charAt(0) !== '/') {
			showLogoutError();
			return;
		}

		if (logoutButton) {
			logoutButton.disabled = true;
		}

		fetch(logoutUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': shell.getAttribute('data-nonce') || ''
			},
			body: '{}'
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('logout_failed');
			}

			return response.json().catch(function () {
				return {};
			});
		}).then(function () {
			redirectToLogin();
		}).catch(function () {
			showLogoutError();

			if (logoutButton) {
				logoutButton.disabled = false;
			}
		});
	}

	var pagesRoot = shell.querySelector('[data-manager-pages-root]');
	var pagesState = {
		items: [],
		activeId: '',
		saving: false,
		loaded: false
	};
	var pagesI18n = {};

	function initPagesI18n() {
		var node = document.getElementById('sonyra-manager-pages-i18n');

		if (!node) {
			return;
		}

		try {
			pagesI18n = JSON.parse(node.textContent || '{}') || {};
		} catch (error) {
			pagesI18n = {};
		}
	}

	function t(key) {
		return pagesI18n[key] || '';
	}

	function createId(prefix) {
		return (prefix || 'id') + '-' + String(Date.now()) + '-' + String(Math.floor(Math.random() * 100000));
	}

	function normalizePage(page) {
		var normalized = page && typeof page === 'object' ? page : {};

		return {
			id: normalized.id || createId('page'),
			title: normalized.title || '',
			slug: normalized.slug || '',
			status: normalized.status || 'draft',
			is_home: normalized.is_home === true,
			show_in_menu: normalized.show_in_menu === true,
			menu_title: normalized.menu_title || '',
			menu_order: Number(normalized.menu_order || 10),
			seo_title: normalized.seo_title || '',
			seo_description: normalized.seo_description || '',
			sections: Array.isArray(normalized.sections) ? normalized.sections.map(normalizeSection) : [],
			created_at: normalized.created_at || '',
			updated_at: normalized.updated_at || '',
			public_url: normalized.public_url || '',
			can_open: normalized.can_open === true
		};
	}

	function normalizeSection(section) {
		var normalized = section && typeof section === 'object' ? section : {};
		var type = ['hero', 'text', 'contacts'].indexOf(normalized.type) >= 0 ? normalized.type : 'text';

		return {
			id: normalized.id || createId('section'),
			type: type,
			kicker: normalized.kicker || '',
			title: normalized.title || '',
			text: normalized.text || '',
			button_label: normalized.button_label || '',
			button_url: normalized.button_url || '',
			email: normalized.email || '',
			phone: normalized.phone || '',
			address: normalized.address || ''
		};
	}

	function findPage(id) {
		return pagesState.items.find(function (item) {
			return item.id === id;
		}) || null;
	}

	function getActivePage() {
		return findPage(pagesState.activeId);
	}

	function clonePagesIcon(key) {
		var template = pagesRoot ? pagesRoot.querySelector('[data-pages-icon-template="' + key + '"]') : null;

		if (!template || !template.firstElementChild) {
			return document.createTextNode('');
		}

		return template.firstElementChild.cloneNode(true);
	}

	function setPagesMessage(type, message) {
		var messageNode = pagesRoot ? pagesRoot.querySelector('[data-pages-message]') : null;

		if (!messageNode) {
			return;
		}

		if (!message) {
			messageNode.hidden = true;
			messageNode.textContent = '';
			messageNode.removeAttribute('data-pages-message-type');
			return;
		}

		messageNode.hidden = false;
		messageNode.textContent = message;
		messageNode.setAttribute('data-pages-message-type', type || 'info');
	}

	function getPagesUrl(page) {
		if (!page) {
			return '';
		}

		if (page.public_url) {
			return page.public_url;
		}

		var siteUrl = shell.getAttribute('data-site-url') || '/';

		if (page.is_home) {
			return siteUrl;
		}

		return siteUrl.replace(/\/?$/, '/') + (page.slug || '').replace(/^\/|\/$/g, '') + '/';
	}

	function renderPagesList() {
		if (!pagesRoot) {
			return;
		}

		var list = pagesRoot.querySelector('[data-pages-list]');

		if (!list) {
			return;
		}

		clearNode(list);

		if (!pagesState.loaded) {
			var loading = document.createElement('p');
			loading.className = 'sonyra-manager-pages-empty';
			loading.textContent = t('manager.pages.loading');
			list.appendChild(loading);
			return;
		}

		if (!pagesState.items.length) {
			var empty = document.createElement('article');
			empty.className = 'sonyra-manager-pages-empty';
			var emptyTitle = document.createElement('strong');
			var emptyText = document.createElement('span');
			emptyTitle.textContent = t('manager.pages.empty_title');
			emptyText.textContent = t('manager.pages.empty_description');
			empty.appendChild(emptyTitle);
			empty.appendChild(emptyText);
			list.appendChild(empty);
			return;
		}

		pagesState.items.forEach(function (page) {
			var item = document.createElement('article');
			item.className = 'sonyra-manager-pages-list-item';
			item.classList.toggle('sonyra-manager-pages-list-item-active', page.id === pagesState.activeId);

			var icon = document.createElement('div');
			icon.className = 'sonyra-manager-pages-list-icon';
			icon.appendChild(clonePagesIcon(page.status === 'published' ? 'circle-check' : (page.status === 'hidden' ? 'eye' : 'progress')));

			var copy = document.createElement('div');
			copy.className = 'sonyra-manager-pages-list-copy';
			var title = document.createElement('strong');
			var meta = document.createElement('span');
			var url = document.createElement('small');
			title.textContent = page.title || t('manager.pages.editor.title');
			meta.textContent = t('manager.pages.status.' + page.status) + ' · ' + (page.show_in_menu && page.status === 'published' ? t('manager.pages.status.menu_yes') : t('manager.pages.status.menu_no'));
			url.textContent = page.is_home ? '/' : '/' + page.slug + '/';
			copy.appendChild(title);
			copy.appendChild(meta);
			copy.appendChild(url);

			var actions = document.createElement('div');
			actions.className = 'sonyra-manager-pages-list-actions';
			var edit = document.createElement('button');
			edit.type = 'button';
			edit.dataset.pagesEdit = page.id;
			edit.appendChild(clonePagesIcon('edit'));
			edit.appendChild(document.createTextNode(t('manager.pages.actions.edit')));
			actions.appendChild(edit);

			var open = document.createElement('button');
			open.type = 'button';
			open.dataset.pagesOpen = page.id;
			open.disabled = !page.can_open;
			open.appendChild(clonePagesIcon('external-link'));
			open.appendChild(document.createTextNode(t('manager.pages.actions.open')));
			actions.appendChild(open);

			item.appendChild(icon);
			item.appendChild(copy);
			item.appendChild(actions);
			list.appendChild(item);
		});
	}

	function renderPagesToolbar() {
		if (!pagesRoot) {
			return;
		}

		var openSite = shell.querySelector('[data-pages-open-site]');
		var firstOpenable = pagesState.items.find(function (page) {
			return page.can_open && page.is_home;
		}) || pagesState.items.find(function (page) {
			return page.can_open;
		});

		if (openSite) {
			openSite.disabled = !firstOpenable;
			openSite.title = firstOpenable ? '' : t('manager.pages.open_site_disabled');
		}

		renderPagesHeaderBadges();
	}

	function appendPagesHeaderBadge(label, tone) {
		if (!pageBadges || !label) {
			return;
		}

		var badge = document.createElement('span');
		var text = document.createElement('span');
		badge.className = 'sonyra-manager-page-badge sonyra-manager-page-badge-' + (tone || 'neutral');
		text.textContent = label;
		badge.appendChild(text);
		pageBadges.appendChild(badge);
	}

	function renderPagesHeaderBadges() {
		if (!pageBadges || activeRoute !== 'pages') {
			return;
		}

		var published = pagesState.items.filter(function (page) {
			return page.status === 'published';
		}).length;
		var drafts = pagesState.items.filter(function (page) {
			return page.status === 'draft';
		}).length;
		var hidden = pagesState.items.filter(function (page) {
			return page.status === 'hidden';
		}).length;
		var hasHome = pagesState.items.some(function (page) {
			return page.is_home === true;
		});

		clearNode(pageBadges);
		appendPagesHeaderBadge(published > 0 ? t('manager.pages.badges.published') + ': ' + published : '', 'ready');
		appendPagesHeaderBadge(drafts > 0 ? t('manager.pages.badges.drafts') + ': ' + drafts : '', 'neutral');
		appendPagesHeaderBadge(hidden > 0 ? t('manager.pages.badges.hidden') + ': ' + hidden : '', 'neutral');
		appendPagesHeaderBadge(hasHome ? t('manager.pages.badges.home_selected') : '', 'ready');
		pageBadges.hidden = !pageBadges.children.length;
	}

	function renderPagesEditor() {
		if (!pagesRoot) {
			return;
		}

		var editor = pagesRoot.querySelector('[data-pages-editor]');
		var page = getActivePage();

		if (!editor) {
			return;
		}

		editor.hidden = !page;

		if (!page) {
			return;
		}

		Array.prototype.slice.call(editor.querySelectorAll('[data-pages-field]')).forEach(function (field) {
			var key = field.getAttribute('data-pages-field') || '';
			field.value = page[key] !== undefined ? page[key] : '';
			field.disabled = key === 'slug' && page.is_home;
		});

		Array.prototype.slice.call(editor.querySelectorAll('[data-pages-switch]')).forEach(function (button) {
			var key = button.getAttribute('data-pages-switch') || '';
			var active = page[key] === true;
			button.setAttribute('aria-pressed', active ? 'true' : 'false');
			button.classList.toggle('sonyra-manager-pages-switch-active', active);
			button.disabled = key === 'show_in_menu' && page.status !== 'published';
		});

		var openCurrent = editor.querySelector('[data-pages-open-current]');

		if (openCurrent) {
			openCurrent.disabled = !page.can_open;
		}

		renderPageSections(page);
	}

	function renderPageSections(page) {
		var container = pagesRoot ? pagesRoot.querySelector('[data-pages-sections]') : null;

		if (!container) {
			return;
		}

		clearNode(container);

		page.sections.forEach(function (section, index) {
			var card = document.createElement('article');
			card.className = 'sonyra-manager-pages-section-card';
			card.dataset.sectionId = section.id;

			var head = document.createElement('div');
			head.className = 'sonyra-manager-pages-section-card-head';
			var title = document.createElement('strong');
			title.appendChild(clonePagesIcon('section'));
			title.appendChild(document.createTextNode(t('manager.pages.sections.' + section.type)));
			var controls = document.createElement('div');
			controls.className = 'sonyra-manager-pages-section-controls';
			[
				['arrow-up', 'manager.pages.actions.move_up', 'up', index === 0],
				['arrow-down', 'manager.pages.actions.move_down', 'down', index === page.sections.length - 1],
				['trash', 'manager.pages.actions.remove_section', 'remove', false]
			].forEach(function (control) {
				var button = document.createElement('button');
				button.type = 'button';
				button.dataset.sectionAction = control[2];
				button.dataset.sectionId = section.id;
				button.disabled = control[3];
				button.appendChild(clonePagesIcon(control[0]));
				button.setAttribute('aria-label', t(control[1]));
				controls.appendChild(button);
			});
			head.appendChild(title);
			head.appendChild(controls);
			card.appendChild(head);

			card.appendChild(createSectionTypeField(section));
			card.appendChild(createSectionField(section, 'kicker', 'manager.pages.sections.kicker', 'input'));
			card.appendChild(createSectionField(section, 'title', 'manager.pages.sections.title', 'input'));
			card.appendChild(createSectionField(section, 'text', 'manager.pages.sections.text_field', 'textarea'));

			if (section.type === 'hero') {
				card.appendChild(createSectionField(section, 'button_label', 'manager.pages.sections.button_label', 'input'));
				card.appendChild(createSectionField(section, 'button_url', 'manager.pages.sections.button_url', 'input'));
			}

			if (section.type === 'contacts') {
				card.appendChild(createSectionField(section, 'email', 'manager.pages.sections.email', 'input'));
				card.appendChild(createSectionField(section, 'phone', 'manager.pages.sections.phone', 'input'));
				card.appendChild(createSectionField(section, 'address', 'manager.pages.sections.address', 'input'));
			}

			container.appendChild(card);
		});
	}

	function createSectionTypeField(section) {
		var label = document.createElement('label');
		var span = document.createElement('span');
		var select = document.createElement('select');
		label.className = 'sonyra-manager-pages-field';
		span.textContent = t('manager.pages.sections.type');
		select.dataset.sectionField = 'type';
		select.dataset.sectionId = section.id;
		['hero', 'text', 'contacts'].forEach(function (type) {
			var option = document.createElement('option');
			option.value = type;
			option.textContent = t('manager.pages.sections.' + type);
			select.appendChild(option);
		});
		select.value = section.type;
		label.appendChild(span);
		label.appendChild(select);
		return label;
	}

	function createSectionField(section, key, labelKey, controlType) {
		var label = document.createElement('label');
		var span = document.createElement('span');
		var control = controlType === 'textarea' ? document.createElement('textarea') : document.createElement('input');
		label.className = 'sonyra-manager-pages-field';
		span.textContent = t(labelKey);
		control.dataset.sectionField = key;
		control.dataset.sectionId = section.id;

		if (controlType === 'textarea') {
			control.rows = 3;
		} else {
			control.type = key === 'email' ? 'email' : (key === 'button_url' ? 'url' : 'text');
		}

		control.value = section[key] || '';
		label.appendChild(span);
		label.appendChild(control);
		return label;
	}

	function renderPages() {
		renderPagesToolbar();
		renderPagesList();
		renderPagesEditor();
	}

	function loadPages() {
		var pagesUrl = shell.getAttribute('data-pages-url') || '';

		if (!pagesRoot || !pagesUrl) {
			return;
		}

		renderPages();

		fetch(pagesUrl, {
			method: 'GET',
			credentials: 'same-origin',
			headers: {
				'X-Sonyra-Pages-Nonce': shell.getAttribute('data-pages-nonce') || ''
			}
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('load_failed');
			}

			return response.json();
		}).then(function (data) {
			pagesState.items = Array.isArray(data.items) ? data.items.map(normalizePage) : [];
			pagesState.activeId = pagesState.items[0] ? pagesState.items[0].id : '';
			pagesState.loaded = true;
			renderPages();
		}).catch(function () {
			pagesState.loaded = true;
			setPagesMessage('error', t('manager.pages.errors.load_failed'));
			renderPages();
		});
	}

	function createPage() {
		var page = normalizePage({
			id: createId('page'),
			title: t('manager.pages.editor.new_title'),
			slug: 'new-page',
			status: 'draft',
			menu_order: (pagesState.items.length + 1) * 10,
			sections: [
				{ id: createId('section'), type: 'hero', title: t('manager.pages.editor.new_title'), text: '' }
			]
		});

		pagesState.items.push(page);
		pagesState.activeId = page.id;
		setPagesMessage('', '');
		renderPages();
	}

	function updateActivePageField(key, value) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		if (key === 'menu_order') {
			page[key] = Math.max(0, Math.min(999, Number(value || 0)));
		} else {
			page[key] = value;
		}

		if (key === 'status' && page.status !== 'published') {
			page.show_in_menu = false;
		}

		if (key === 'status') {
			renderPages();
		}
	}

	function toggleActivePageSetting(key) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		if (key === 'show_in_menu' && page.status !== 'published') {
			return;
		}

		page[key] = !page[key];

		if (key === 'is_home' && page.is_home) {
			pagesState.items.forEach(function (item) {
				if (item.id !== page.id) {
					item.is_home = false;
				}
			});
			page.slug = 'home';
		}

		renderPages();
	}

	function addSection(type) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		page.sections.push(normalizeSection({ id: createId('section'), type: type || 'text' }));
		renderPagesEditor();
	}

	function updateSection(sectionId, key, value) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		page.sections = page.sections.map(function (section) {
			if (section.id === sectionId) {
				section[key] = value;

				if (key === 'type') {
					section.type = ['hero', 'text', 'contacts'].indexOf(value) >= 0 ? value : 'text';
				}
			}

			return section;
		});

		if (key === 'type') {
			renderPagesEditor();
		}
	}

	function moveSection(sectionId, direction) {
		var page = getActivePage();

		if (!page) {
			return;
		}

		var index = page.sections.findIndex(function (section) {
			return section.id === sectionId;
		});
		var nextIndex = direction === 'up' ? index - 1 : index + 1;

		if (index < 0 || nextIndex < 0 || nextIndex >= page.sections.length) {
			return;
		}

		var moved = page.sections.splice(index, 1)[0];
		page.sections.splice(nextIndex, 0, moved);
		renderPagesEditor();
	}

	function removeSection(sectionId) {
		var page = getActivePage();

		if (!page || !window.confirm(t('manager.pages.errors.confirm_remove_section'))) {
			return;
		}

		page.sections = page.sections.filter(function (section) {
			return section.id !== sectionId;
		});
		renderPagesEditor();
	}

	function savePages() {
		var pagesUrl = shell.getAttribute('data-pages-url') || '';
		var saveButton = pagesRoot ? pagesRoot.querySelector('[data-pages-save]') : null;

		if (!pagesRoot || !pagesUrl || pagesState.saving) {
			return;
		}

		pagesState.saving = true;
		setPagesMessage('', '');

		if (saveButton) {
			saveButton.disabled = true;
			saveButton.querySelector('span:last-child').textContent = t('manager.pages.actions.saving');
		}

		fetch(pagesUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-Sonyra-Pages-Nonce': shell.getAttribute('data-pages-nonce') || ''
			},
			body: JSON.stringify({ items: pagesState.items })
		}).then(function (response) {
			return response.json().catch(function () {
				return {};
			}).then(function (data) {
				if (!response.ok) {
					throw new Error(data.message || t('manager.pages.errors.save_failed'));
				}

				return data;
			});
		}).then(function (data) {
			pagesState.items = Array.isArray(data.items) ? data.items.map(normalizePage) : pagesState.items;
			setPagesMessage('success', data.message || t('manager.pages.success.saved'));
			renderPages();
		}).catch(function (error) {
			setPagesMessage('error', error.message || t('manager.pages.errors.save_failed'));
			renderPages();
		}).finally(function () {
			pagesState.saving = false;

			if (saveButton) {
				saveButton.disabled = false;
				saveButton.querySelector('span:last-child').textContent = t('manager.pages.actions.save');
			}
		});
	}

	function openPage(page) {
		if (!page || !page.can_open) {
			setPagesMessage('error', t('manager.pages.errors.page_not_openable'));
			return;
		}

		window.open(getPagesUrl(page), '_blank', 'noopener');
	}

	function handlePagesClick(event) {
		var pagesAction = event.target.closest('[data-pages-create], [data-pages-open-site]');

		if (!pagesRoot || (!pagesRoot.contains(event.target) && !pagesAction)) {
			return;
		}

		var createButton = event.target.closest('[data-pages-create]');
		var saveButton = event.target.closest('[data-pages-save]');
		var editButton = event.target.closest('[data-pages-edit]');
		var openButton = event.target.closest('[data-pages-open]');
		var openCurrent = event.target.closest('[data-pages-open-current]');
		var openSite = event.target.closest('[data-pages-open-site]');
		var switchButton = event.target.closest('[data-pages-switch]');
		var addSectionButton = event.target.closest('[data-pages-add-section]');
		var sectionActionButton = event.target.closest('[data-section-action]');

		if (createButton) {
			event.preventDefault();
			createPage();
		} else if (saveButton) {
			event.preventDefault();
			savePages();
		} else if (editButton) {
			event.preventDefault();
			pagesState.activeId = editButton.getAttribute('data-pages-edit') || '';
			renderPages();
		} else if (openButton) {
			event.preventDefault();
			openPage(findPage(openButton.getAttribute('data-pages-open') || ''));
		} else if (openCurrent) {
			event.preventDefault();
			openPage(getActivePage());
		} else if (openSite) {
			event.preventDefault();
			openPage(pagesState.items.find(function (page) {
				return page.can_open && page.is_home;
			}) || pagesState.items.find(function (page) {
				return page.can_open;
			}));
		} else if (switchButton) {
			event.preventDefault();
			toggleActivePageSetting(switchButton.getAttribute('data-pages-switch') || '');
		} else if (addSectionButton) {
			event.preventDefault();
			addSection(addSectionButton.getAttribute('data-pages-add-section') || 'text');
		} else if (sectionActionButton) {
			event.preventDefault();
			var sectionId = sectionActionButton.getAttribute('data-section-id') || '';
			var action = sectionActionButton.getAttribute('data-section-action') || '';

			if (action === 'up' || action === 'down') {
				moveSection(sectionId, action);
			} else if (action === 'remove') {
				removeSection(sectionId);
			}
		}
	}

	function handlePagesInput(event) {
		if (!pagesRoot || !pagesRoot.contains(event.target)) {
			return;
		}

		var pageField = event.target.closest('[data-pages-field]');
		var sectionField = event.target.closest('[data-section-field]');

		if (pageField) {
			updateActivePageField(pageField.getAttribute('data-pages-field') || '', pageField.value);
		} else if (sectionField) {
			updateSection(sectionField.getAttribute('data-section-id') || '', sectionField.getAttribute('data-section-field') || '', sectionField.value);
		}
	}

	initPagesI18n();

	if (pagesRoot) {
		shell.addEventListener('click', handlePagesClick);
		pagesRoot.addEventListener('input', handlePagesInput);
		pagesRoot.addEventListener('change', handlePagesInput);
	}

	routeButtons.forEach(function (button) {
		button.addEventListener('click', function () {
			setRoute(button.getAttribute('data-manager-route') || 'dashboard', true);
		});
	});

	if (toggleButton) {
		toggleButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true, true);
		});
	}

	if (logoButton) {
		logoButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true, true);
		});
	}

	if (backdrop) {
		backdrop.addEventListener('click', function () {
			setSidebarState('collapsed', false, true);
		});
	}

	if (logoutButton) {
		logoutButton.addEventListener('click', runLogout);
	}

	document.addEventListener('click', handleNoticeAction);

	if (supportModal) {
		supportModal.addEventListener('click', function (event) {
			if (event.target === supportModal) {
				closeSupportModal();
			}
		});
	}

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && supportModal && !supportModal.hidden) {
			closeSupportModal();
			return;
		}

		if (event.key === 'Escape' && isMobile() && shell.getAttribute('data-sidebar-state') === 'expanded') {
			setSidebarState('collapsed', false, true);
		}
	});

	window.addEventListener('hashchange', function () {
		setRoute(getRouteFromHash(), false);
	});

	if (mediaQuery && mediaQuery.addEventListener) {
		mediaQuery.addEventListener('change', function () {
			setSidebarState(isMobile() ? 'collapsed' : (getStoredState() || 'expanded'), false);
		});
	}

	shell.addEventListener('transitionend', handleSidebarTransitionEnd);

	if (sidebar) {
		sidebar.addEventListener('transitionend', handleSidebarTransitionEnd);
	}

	setSidebarState(getStoredState() || (isMobile() ? 'collapsed' : 'expanded'), false);
	setRoute(getRouteFromHash(), false);
}());
