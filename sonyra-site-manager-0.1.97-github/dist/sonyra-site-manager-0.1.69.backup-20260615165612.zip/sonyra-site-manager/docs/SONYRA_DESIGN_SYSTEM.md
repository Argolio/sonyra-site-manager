# SONYRA Design System

## Назначение

Этот документ фиксирует контракт будущей дизайн-системы SONYRA Site Manager.

Интерфейс должен выглядеть как готовый premium SaaS-продукт, а не как техническая админка.

## Общие правила SONYRA

Во всех будущих design-этапах используются только канонические написания:

- SONYRA
- SONYRA Site Platform
- SONYRA Site Manager
- SONYRA STUDIO

Неканонические варианты названия SONYRA нельзя использовать как рабочие названия.

Весь видимый пользовательский интерфейс будущего продукта должен быть только на русском языке.

Английские пользовательские UI-строки и англицизмы запрещены.

Исключения допустимы только для технически неизбежных терминов: API, REST, HTML, iframe, URL, JSON, CSS, JS, PHP, WordPress, shortcode, nonce, slug.

Пользовательские строки будущего интерфейса должны идти через i18n.

Будущий основной i18n-файл:

- assets/i18n/i18n-ru.js

Будущий helper:

- t('key')

Никаких “красивых, но мёртвых” кнопок. Каждый интерактивный элемент должен иметь рабочую цепочку:

DOM/root selector -> selector элемента -> handler -> loading state -> request/action -> success/error render -> UI update.

Deploy по умолчанию запрещён. Будущие zip-релизы собираются только в ./dist/. Предыдущие zip-релизы нельзя удалять.

## Design foundation

Дизайн строится через:

- tokens;
- components;
- layout;
- states.

Случайные цвета в отдельных экранах запрещены.

Случайные размеры, тени, радиусы и отступы запрещены.

Будущие файлы design foundation:

- assets/design/sonyra-tokens.css
- assets/design/sonyra-components.css
- assets/design/sonyra-layout.css
- assets/design/sonyra-states.css
- assets/design/sonyra-manager.css

## Component states

Все компоненты должны иметь состояния:

- обычное;
- наведение;
- фокус;
- загрузка;
- успех;
- ошибка;
- отключено;
- пустое состояние.

## Обязательные компоненты

Design system должен описывать и поддерживать:

- кнопки;
- карточки;
- панели;
- поля ввода;
- переключатели;
- бейджи;
- модальные окна;
- выезжающие панели;
- уведомления;
- боковое меню;
- верхняя панель;
- пустые состояния;
- состояния загрузки;
- состояния ошибки;
- состояния успеха;
- прогресс;
- карточки дашборда;
- карточки модулей;
- панель кода вставки;
- управление логотипом;
- управление градиентами.

Видимые названия компонентов в пользовательском UI должны быть по-русски. Технические имена классов и файлов могут быть на английском.

## Layout contract

Layout должен обеспечивать:

- предсказуемую manager-навигацию;
- читаемые рабочие области;
- responsive-поведение для desktop, tablet и mobile;
- отсутствие визуального хаоса при пустых, загрузочных и ошибочных состояниях;
- совместимость с будущими module screens.

## Visual acceptance rule

Любой UI/design-этап не принят, если Codex не дал визуальный отчёт:

- DOM-структура;
- CSS-слои;
- responsive-поведение;
- состояния элементов;
- i18n-источник видимых строк;
- отсутствие английских UI-слов;
- рабочая цепочка controls.

## Login shell design pattern

Login shell должен использовать premium SaaS pattern:

- centered auth card;
- brand area;
- clean SaaS background;
- identifier input “Электронная почта или логин”;
- code input state;
- primary action button;
- secondary text actions;
- accessible inputs;
- status messages;
- mobile responsive pattern;
- no raw technical styling;
- no global selectors;
- no password field on first release.

## Manager page header standard

Начиная с версии `0.1.64`, protected `/manager` использует единый premium SaaS page header:

- section metadata является единым источником для nav label, page title, kicker, description, `icon_key`, actions и осмысленных badge/chips;
- page header состоит из icon tile, text stack, optional meta/chips row и optional actions-zone;
- page header kicker не повторяет brand name “ПУЛЬТ САЙТА”;
- page title компактнее hero/display-заголовков и не делит CSS selector с hero/placeholder card titles;
- description берётся из i18n section metadata и не дублируется в JS;
- icon tile использует только `Sonyra_Site_Manager_Icon_Renderer` и `icon_key` из SONYRA Icon Library;
- background `/manager` следует approved login background pattern;
- visible UI strings остаются только через i18n.

### Page header exists rule

Во всех разделах ПУЛЬТА САЙТА уже есть общий page header. Рабочая зона раздела должна начинаться сразу после этого header.

Запрещено:

- создавать второй header внутри рабочей области раздела;
- создавать второй hero-блок ради заголовка, статусов или кнопок;
- дублировать название раздела внутри контента крупным заголовком;
- делать повторные заголовочные прослойки вроде “Публичный сайт / Страницы”;
- переносить заголовок раздела из общего page header в рабочую область.

Разрешено:

- менять существующий page header;
- менять надзаголовок, основной заголовок и описание;
- менять `icon_key`;
- добавлять actions справа, если это реальные действия раздела.

### Header typography and SVG alignment

Общий header для всех разделов использует компактный premium SaaS pattern:

- SVG icon tile слева;
- текстовая группа справа от иконки;
- надзаголовок маленький, фиолетовый, разряженный, uppercase;
- основной заголовок примерно в 3 раза крупнее надзаголовка;
- основной заголовок не должен быть чрезмерно жирным, огромным или с раздутым `line-height`;
- описание идёт ниже заголовка спокойным размером;
- header остаётся компактным, без hero-space.

SVG alignment contract:

- SVG/icon tile выравнивается по зоне “надзаголовок + основной заголовок”;
- верх icon tile примерно на уровне верхней границы надзаголовка;
- низ icon tile примерно на уровне нижней границы основного заголовка;
- описание не влияет на вертикальное положение SVG;
- запрещено центрировать SVG по полной высоте header вместе с описанием.

### Page Header Typography Fixed Scale

Все page headers ПУЛЬТА САЙТА используют фиксированную числовую шкалу. Подбирать значения визуально запрещено.

Desktop, `1024px+`:

- container: `padding: 22px 24px`, `border-radius: 24px`, `min-height: auto`;
- icon tile: `56px` × `56px`, `border-radius: 18px`, `flex: 0 0 56px`;
- icon SVG: `24px` × `24px`;
- icon-to-text gap: `16px`;
- text-to-actions gap: `20px`;
- eyebrow: `13px` / `16px`, `font-weight: 700`, `letter-spacing: 0.16em`, `text-transform: uppercase`, `margin-bottom: 6px`;
- title: `34px` / `37px`, `font-weight: 680`, `letter-spacing: -0.035em`, `max-width: 760px`, `text-transform: none`;
- title hard limits: max `36px`, max `font-weight 700`;
- description: `16px` / `24px`, `font-weight: 500`, `margin-top: 10px`, `max-width: 860px`;
- actions: `display: flex`, `align-items: center`, `justify-content: flex-end`, `gap: 10px`, `flex-wrap: nowrap`;
- badges/chips: `12px`, `height: 28px`, `line-height: 28px`, `font-weight: 650`, `padding: 0 10px`, `border-radius: 999px`.

Tablet, `768px–1023px`:

- container: `padding: 20px`;
- icon tile: `52px` × `52px`;
- icon SVG: `22px` × `22px`;
- eyebrow: `12px` / `15px`;
- title: `30px` / `34px`, `font-weight: 660`, `max-width: 680px`;
- description: `15px` / `23px`.

Mobile, `<768px`:

- container: `padding: 18px`;
- icon tile: `48px` × `48px`;
- icon SVG: `21px` × `21px`;
- eyebrow: `11px` / `14px`, `letter-spacing: 0.14em`;
- title: `26px` / `30px`, `font-weight: 650`, `letter-spacing: -0.03em`;
- description: `14px` / `21px`, `margin-top: 8px`;
- actions: `margin-top: 14px`, `flex-wrap: wrap`.

Запрещено:

- no title 40px+;
- no title font-weight 800/900;
- no uppercase main title;
- no duplicate header/hero;
- no icon centering by full header height;
- no fake badges.

Release audit anchors: Page Header Typography Fixed Scale, `34px`, `37px`, font-weight 680, no title 40px, no uppercase main title, icon tile 56, badges 12px, height 28px.

### Header actions rule

Actions — это реальные быстрые действия раздела.

Примеры:

- Открыть сайт;
- Создать страницу;
- Сохранить;
- Добавить;
- Проверить;
- Обновить;
- Экспортировать.

Размещение:

- desktop: справа в существующем page header, в одну строку;
- mobile: аккуратный перенос или стек без поломки header.

Запрещено:

- добавлять fake actions;
- делать кнопку, если действие не реализовано;
- делать кнопку “Сохранить”, если save-flow не работает;
- делать кнопку “Открыть”, если нечего реально открыть;
- создавать второй header ради кнопок.

### Badge placement standard

Бейджи не являются actions. Бейджи нельзя бездумно размещать справа рядом с кнопками и нельзя использовать как декоративные fake-status.

#### Глобальные бейджи состояния раздела

Используются только если основаны на реальных данных всего раздела.

Примеры для “Страниц”:

- 3 опубликованы;
- 1 черновик;
- Главная выбрана;
- Есть скрытые страницы.

Где размещать:

- компактная meta/chips-строка внутри существующего page header;
- под описанием или рядом с описанием;
- не справа вместо actions;
- не отдельным hero-блоком;
- не декоративной плашкой.

#### Бейджи конкретного элемента

Если бейдж относится к конкретной странице, модулю, пользователю, документу или записи, он должен быть рядом с этим элементом.

Примеры для строки страницы:

- Опубликована;
- Черновик;
- Скрыта;
- Главная;
- В меню.

Где размещать:

- в строке списка;
- в карточке элемента;
- в редакторе рядом с названием элемента;
- рядом с соответствующим полем.

Не размещать такие бейджи в общем page header, если они не относятся ко всему разделу.

#### Предупреждения, ошибки, успех

Это не бейджи.

Использовать:

- Notice Center;
- inline alert;
- field-level validation.

Примеры:

- slug занят;
- страница не опубликована;
- сохранить не удалось;
- главная страница не выбрана.

Запрещено превращать ошибки/предупреждения в маленькие декоративные бейджи в header.

#### Статусы контролов

Если статус относится к конкретному контролу, он должен быть рядом с этим контролом.

Примеры:

- email подтверждён;
- ключ подключён;
- синхронизация включена;
- модуль требует настройки.

Не выносить такие статусы в header без причины.

### Fake badge prohibition

Запрещено:

- fake metrics;
- fake progress;
- fake status;
- бейджи “для красоты”;
- бейджи без реальных данных;
- бейджи, которые дублируют заголовок;
- бейджи, которые обещают будущую функцию;
- “готово”, “активно”, “фундамент”, “будущий этап”, если за этим нет реальной рабочей логики.

### Examples

Правильно:

```text
СТРАНИЦЫ
СОЗДАНИЕ, НАСТРОЙКА И ПУБЛИКАЦИЯ
Создавайте страницы, настраивайте адреса, собирайте секции и управляйте пунктами меню

[3 опубликованы] [1 черновик] [Главная выбрана]

Справа:
[Открыть сайт] [Создать страницу]
```

Неправильно:

- второй блок “Публичный сайт / Страницы”;
- повторный крупный заголовок “Страницы”;
- бейджи справа вместо кнопок;
- fake badge “Будущий этап”;
- fake badge “Основа”;
- бейдж “Меню готово”, если меню не реализовано;
- кнопка “Открыть сайт”, если сайт не открывается.

## Manager sidebar standard freeze

Начиная с версии `0.1.63`, sidebar invariant rail считается принятым стандартом.

Правила для будущих изменений:

- новые page sections добавляются через section metadata, а не ручным дублированием nav/view/header массивов;
- `icon_key` для nav и page header выбирается только из SONYRA Icon Library;
- nav item height, icon slot, SVG size, font-weight и gap не меняются без отдельного visual audit;
- collapsed и expanded nav grid model не должны различаться по геометрии icon slot;
- icon slot и SVG не должны иметь state-dependent geometry;
- “Выйти” остаётся последним action item, слегка отделённым, без pin-to-bottom;
- sidebar остаётся fixed/sticky rail, а main content сохраняет независимый scroll;
- hardcoded SVG в sidebar запрещены;
- `transition: all` для nav/icon/sidebar geometry запрещён.

## Extension UI standard

Будущие расширения обязаны использовать дизайн-систему базы.

Правила:

- расширения не приносят хаотичные стили;
- расширения используют cards, buttons, badges, toggles, page header и layout tokens базового manager UI;
- UI витрины расширений в “Модули” должен использовать те же компоненты;
- новые основные пункты меню не добавляются без отдельного архитектурного решения;
- extension UI должен соблюдать i18n, русский интерфейс, accessibility и security rules;
- расширение не может подменять sidebar, page header или global shell.

## STOP-условия

Немедленно остановиться, если design-этап требует случайных CSS-решений вне design system, английских видимых UI-строк, обхода i18n, обхода security rules или создания декоративных controls без рабочей цепочки.
