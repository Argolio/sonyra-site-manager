<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Manager_Renderer {

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	private static function versioned_asset_url( string $url, string $path, string $query_arg = 'ver' ): string {
		if ( ! file_exists( $path ) ) {
			return '';
		}

		$asset_mtime = filemtime( $path );
		$asset_version = SONYRA_SITE_MANAGER_VERSION;

		if ( is_int( $asset_mtime ) ) {
			$asset_version .= '-' . $asset_mtime;
		}

		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( $query_arg, $asset_version, $url );
		}

		return $url . '?' . rawurlencode( $query_arg ) . '=' . rawurlencode( $asset_version );
	}

	private static function render_icon( string $name, string $class_name = 'sonyra-manager-icon' ): void {
		if ( class_exists( 'Sonyra_Site_Manager_Icon_Renderer' ) ) {
			Sonyra_Site_Manager_Icon_Renderer::display(
				$name,
				array(
					'class'       => 'sonyra-icon ' . $class_name,
					'aria_hidden' => true,
				)
			);
		}
	}

	private static function get_sections(): array {
		return array(
			'dashboard' => array(
				'route'       => 'dashboard',
				'nav_label'   => 'manager.nav_dashboard',
				'title'       => 'manager.section_dashboard_title',
				'kicker'      => 'manager.section_dashboard_kicker',
				'description' => 'manager.section_dashboard_description',
				'icon_key'    => 'layout-dashboard',
				'badges'      => array(
					array(
						'label'    => 'manager.badge_work_mode',
						'icon_key' => 'circle-check',
						'tone'     => 'ready',
					),
				),
				'enabled'     => true,
			),
			'setup'     => array(
				'route'       => 'setup',
				'nav_label'   => 'manager.nav_site',
				'title'       => 'manager.section_setup_title',
				'kicker'      => 'manager.section_setup_kicker',
				'description' => 'manager.section_setup_description',
				'icon_key'    => 'app-window',
				'badges'      => array(),
				'enabled'     => true,
			),
			'pages'     => array(
				'route'       => 'pages',
				'nav_label'   => 'manager.nav_pages',
				'title'       => 'manager.section_pages_title',
				'kicker'      => 'manager.section_pages_kicker',
				'description' => 'manager.section_pages_description',
				'icon_key'    => 'file-text',
				'badges'      => array(),
				'enabled'     => true,
			),
			'design'    => array(
				'route'       => 'design',
				'nav_label'   => 'manager.nav_design',
				'title'       => 'manager.section_design_title',
				'kicker'      => 'manager.section_design_kicker',
				'description' => 'manager.section_design_description',
				'icon_key'    => 'brush',
				'badges'      => array(),
				'enabled'     => true,
			),
			'modules'   => array(
				'route'       => 'modules',
				'nav_label'   => 'manager.nav_modules',
				'title'       => 'manager.section_modules_title',
				'kicker'      => 'manager.section_modules_kicker',
				'description' => 'manager.section_modules_description',
				'icon_key'    => 'components',
				'badges'      => array(),
				'enabled'     => true,
			),
			'security'  => array(
				'route'       => 'security',
				'nav_label'   => 'manager.nav_security',
				'title'       => 'manager.section_security_title',
				'kicker'      => 'manager.section_security_kicker',
				'description' => 'manager.section_security_description',
				'icon_key'    => 'shield-check',
				'badges'      => array(),
				'enabled'     => true,
			),
			'settings'  => array(
				'route'       => 'settings',
				'nav_label'   => 'manager.nav_settings',
				'title'       => 'manager.section_settings_title',
				'kicker'      => 'manager.section_settings_kicker',
				'description' => 'manager.section_settings_description',
				'icon_key'    => 'settings',
				'badges'      => array(),
				'enabled'     => true,
			),
		);
	}

	private static function get_nav_items(): array {
		return array_values( self::get_sections() );
	}

	private static function get_views(): array {
		return self::get_sections();
	}

	private static function render_page_badges( array $badges, string $attr_name = '' ): void {
		$badges = array_slice( $badges, 0, 4 );
		$hidden = empty( $badges ) ? ' hidden' : '';
		?>
		<div class="sonyra-manager-page-badges"<?php echo '' !== $attr_name ? ' ' . esc_attr( $attr_name ) : ''; ?><?php echo $hidden; ?>>
			<?php foreach ( $badges as $badge ) : ?>
				<?php
				$badge_icon = isset( $badge['icon_key'] ) ? (string) $badge['icon_key'] : 'info-circle';
				$badge_tone = isset( $badge['tone'] ) ? (string) $badge['tone'] : 'neutral';
				?>
				<span class="sonyra-manager-page-badge sonyra-manager-page-badge-<?php echo esc_attr( $badge_tone ); ?>">
					<?php self::render_icon( $badge_icon, 'sonyra-manager-icon sonyra-manager-page-badge-icon' ); ?>
					<span><?php echo esc_html( self::text( (string) $badge['label'] ) ); ?></span>
				</span>
			<?php endforeach; ?>
		</div>
		<?php
	}

	private static function render_page_header( array $section ): void {
		?>
		<header class="sonyra-manager-topbar sonyra-manager-page-header">
			<div class="sonyra-manager-page-header-icon" data-manager-header-icon>
				<?php self::render_icon( (string) $section['icon_key'], 'sonyra-manager-icon sonyra-manager-page-header-svg' ); ?>
			</div>
			<div class="sonyra-manager-page-header-copy">
				<p class="sonyra-manager-page-kicker" data-manager-kicker><?php echo esc_html( self::text( (string) $section['kicker'] ) ); ?></p>
				<h1 class="sonyra-manager-page-title" data-manager-title><?php echo esc_html( self::text( (string) $section['title'] ) ); ?></h1>
				<p class="sonyra-manager-page-description" data-manager-description><?php echo esc_html( self::text( (string) $section['description'] ) ); ?></p>
			</div>
			<?php self::render_page_badges( isset( $section['badges'] ) ? (array) $section['badges'] : array(), 'data-manager-badges' ); ?>
		</header>
		<?php
	}

	private static function render_page_header_templates( array $sections ): void {
		?>
		<div class="sonyra-manager-header-templates" hidden>
			<?php foreach ( $sections as $section ) : ?>
				<span data-manager-icon-template="<?php echo esc_attr( $section['route'] ); ?>"><?php self::render_icon( (string) $section['icon_key'], 'sonyra-manager-icon sonyra-manager-page-header-svg' ); ?></span>
				<span data-manager-badge-template="<?php echo esc_attr( $section['route'] ); ?>"><?php self::render_page_badges( isset( $section['badges'] ) ? (array) $section['badges'] : array(), 'data-manager-badges' ); ?></span>
			<?php endforeach; ?>
		</div>
		<?php
	}

	private static function get_dashboard_state(): array {
		$state = array(
			'mode'       => 'setup',
			'completion' => false,
		);

		if ( function_exists( 'apply_filters' ) ) {
			$filtered_state = apply_filters(
				'sonyra_site_manager_dashboard_mode',
				$state,
				array(
					'route' => 'dashboard',
				)
			);

			if ( is_array( $filtered_state ) ) {
				$state = array_merge( $state, $filtered_state );
			}
		}

		$state['mode'] = 'working' === (string) $state['mode'] ? 'working' : 'setup';
		$state['completion'] = true === $state['completion'];

		if ( function_exists( 'apply_filters' ) ) {
			$state['completion'] = true === apply_filters(
				'sonyra_site_manager_dashboard_completion',
				$state['completion'],
				array(
					'mode' => $state['mode'],
				)
			);
		}

		return $state;
	}

	private static function get_dashboard_setup_steps(): array {
		$steps = array(
			array( 'key' => 'site', 'title' => 'manager.dashboard_step_site_title', 'description' => 'manager.dashboard_step_site_description', 'section_route' => 'setup', 'icon_key' => 'app-window', 'status' => 'needs_setup', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'setup' ),
			array( 'key' => 'pages', 'title' => 'manager.dashboard_step_pages_title', 'description' => 'manager.dashboard_step_pages_description', 'section_route' => 'pages', 'icon_key' => 'file-text', 'status' => 'needs_setup', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'pages' ),
			array( 'key' => 'design', 'title' => 'manager.dashboard_step_design_title', 'description' => 'manager.dashboard_step_design_description', 'section_route' => 'design', 'icon_key' => 'brush', 'status' => 'needs_setup', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'design' ),
			array( 'key' => 'documents', 'title' => 'manager.dashboard_step_documents_title', 'description' => 'manager.dashboard_step_documents_description', 'section_route' => 'setup', 'icon_key' => 'file-check', 'status' => 'needs_setup', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'setup' ),
			array( 'key' => 'cookie', 'title' => 'manager.dashboard_step_cookie_title', 'description' => 'manager.dashboard_step_cookie_description', 'section_route' => 'setup', 'icon_key' => 'cookie', 'status' => 'needs_setup', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'setup' ),
			array( 'key' => 'form', 'title' => 'manager.dashboard_step_form_title', 'description' => 'manager.dashboard_step_form_description', 'section_route' => 'pages', 'icon_key' => 'forms', 'status' => 'not_checked', 'required' => false, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'pages' ),
			array( 'key' => 'security', 'title' => 'manager.dashboard_step_security_title', 'description' => 'manager.dashboard_step_security_description', 'section_route' => 'security', 'icon_key' => 'shield-check', 'status' => 'not_checked', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'security' ),
			array( 'key' => 'publication', 'title' => 'manager.dashboard_step_publication_title', 'description' => 'manager.dashboard_step_publication_description', 'section_route' => 'setup', 'icon_key' => 'world-www', 'status' => 'not_checked', 'required' => true, 'action_label' => 'manager.dashboard_action_open_section', 'action_route' => 'setup' ),
		);

		return self::filter_dashboard_items( 'sonyra_site_manager_dashboard_setup_steps', $steps );
	}

	private static function get_dashboard_status_cards(): array {
		$cards = array(
			array( 'key' => 'site', 'title' => 'manager.dashboard_card_site_title', 'description' => 'manager.dashboard_card_site_description', 'icon_key' => 'app-window', 'status' => 'needs_setup' ),
			array( 'key' => 'documents_cookie', 'title' => 'manager.dashboard_card_documents_cookie_title', 'description' => 'manager.dashboard_card_documents_cookie_description', 'icon_key' => 'file-check', 'status' => 'needs_setup' ),
			array( 'key' => 'forms', 'title' => 'manager.dashboard_card_forms_title', 'description' => 'manager.dashboard_card_forms_description', 'icon_key' => 'forms', 'status' => 'not_checked' ),
			array( 'key' => 'security', 'title' => 'manager.dashboard_card_security_title', 'description' => 'manager.dashboard_card_security_description', 'icon_key' => 'shield-check', 'status' => 'not_checked' ),
			array( 'key' => 'modules', 'title' => 'manager.dashboard_card_modules_title', 'description' => 'manager.dashboard_card_modules_description', 'icon_key' => 'components', 'status' => 'optional' ),
			array( 'key' => 'updates_connection', 'title' => 'manager.dashboard_card_updates_title', 'description' => 'manager.dashboard_card_updates_description', 'icon_key' => 'cloud-check', 'status' => 'not_checked' ),
		);

		return self::filter_dashboard_items( 'sonyra_site_manager_dashboard_status_cards', $cards );
	}

	private static function get_dashboard_activity_items(): array {
		$items = array();

		return self::filter_dashboard_items( 'sonyra_site_manager_dashboard_activity', $items );
	}

	private static function get_dashboard_extension_slots(): array {
		return array(
			'alerts'  => self::filter_dashboard_items( 'sonyra_site_manager_dashboard_alerts', array() ),
			'metrics' => self::filter_dashboard_items( 'sonyra_site_manager_dashboard_metrics', array() ),
		);
	}

	private static function filter_dashboard_items( string $filter_name, array $items ): array {
		if ( function_exists( 'apply_filters' ) ) {
			$filtered_items = apply_filters(
				$filter_name,
				$items,
				array(
					'route' => 'dashboard',
				)
			);

			if ( is_array( $filtered_items ) ) {
				$items = $filtered_items;
			}
		}

		return array_values( array_filter( $items, 'is_array' ) );
	}

	private static function get_dashboard_status_label_key( string $status ): string {
		$status_map = array(
			'not_checked' => 'manager.dashboard_status_not_checked',
			'needs_setup' => 'manager.dashboard_status_needs_setup',
			'ready'       => 'manager.dashboard_status_ready',
			'optional'    => 'manager.dashboard_status_optional',
		);

		return isset( $status_map[ $status ] ) ? $status_map[ $status ] : $status_map['not_checked'];
	}

	private static function render_dashboard_view(): void {
		$state = self::get_dashboard_state();
		$setup_steps = self::get_dashboard_setup_steps();
		$status_cards = self::get_dashboard_status_cards();
		$activity_items = self::get_dashboard_activity_items();
		$extension_slots = self::get_dashboard_extension_slots();
		?>
		<section class="sonyra-manager-view sonyra-manager-view-dashboard" data-manager-view="dashboard">
			<div class="sonyra-manager-dashboard-foundation">
				<?php self::render_dashboard_setup_panel( $setup_steps, $state ); ?>
				<?php self::render_dashboard_working_panel( $status_cards, $activity_items, $extension_slots ); ?>
			</div>
			<?php self::render_dashboard_completion_modal( $state ); ?>
		</section>
		<?php
	}

	private static function render_dashboard_setup_panel( array $steps, array $state ): void {
		$required_steps = array_filter(
			$steps,
			static function ( array $step ): bool {
				return ! empty( $step['required'] );
			}
		);
		?>
		<section class="sonyra-manager-dashboard-panel sonyra-manager-dashboard-setup-panel" data-dashboard-mode="<?php echo esc_attr( (string) $state['mode'] ); ?>">
			<div class="sonyra-manager-dashboard-panel-head">
				<div>
					<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( 'manager.dashboard_setup_kicker' ) ); ?></p>
					<h2><?php echo esc_html( self::text( 'manager.dashboard_setup_title' ) ); ?></h2>
					<p><?php echo esc_html( self::text( 'manager.dashboard_setup_description' ) ); ?></p>
				</div>
				<span class="sonyra-manager-dashboard-status-badge sonyra-manager-dashboard-status-badge-needs_setup"><?php echo esc_html( self::text( 'manager.dashboard_setup_not_complete' ) ); ?></span>
			</div>
			<div class="sonyra-manager-dashboard-summary-grid">
				<div class="sonyra-manager-dashboard-summary-card">
					<span><?php echo esc_html( self::text( 'manager.dashboard_required_steps_label' ) ); ?></span>
					<strong><?php echo esc_html( count( $required_steps ) ); ?></strong>
					<small><?php echo esc_html( self::text( 'manager.dashboard_no_auto_ready' ) ); ?></small>
				</div>
				<div class="sonyra-manager-dashboard-summary-card">
					<span><?php echo esc_html( self::text( 'manager.dashboard_next_step_label' ) ); ?></span>
					<strong><?php echo esc_html( self::text( 'manager.dashboard_next_step_value' ) ); ?></strong>
					<small><?php echo esc_html( self::text( 'manager.dashboard_next_step_hint' ) ); ?></small>
				</div>
			</div>
			<div class="sonyra-manager-dashboard-steps">
				<?php foreach ( $steps as $step ) : ?>
					<?php self::render_dashboard_setup_step( $step ); ?>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
	}

	private static function render_dashboard_working_panel( array $cards, array $activity_items, array $extension_slots ): void {
		?>
		<section class="sonyra-manager-dashboard-panel sonyra-manager-dashboard-working-panel">
			<div class="sonyra-manager-dashboard-panel-head">
				<div>
					<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( 'manager.dashboard_working_kicker' ) ); ?></p>
					<h2><?php echo esc_html( self::text( 'manager.dashboard_working_title' ) ); ?></h2>
					<p><?php echo esc_html( self::text( 'manager.dashboard_working_description' ) ); ?></p>
				</div>
				<span class="sonyra-manager-dashboard-status-badge sonyra-manager-dashboard-status-badge-not_checked"><?php echo esc_html( self::text( 'manager.dashboard_data_pending_label' ) ); ?></span>
			</div>
			<div class="sonyra-manager-dashboard-card-grid">
				<?php foreach ( $cards as $card ) : ?>
					<?php self::render_dashboard_card( $card ); ?>
				<?php endforeach; ?>
			</div>
			<div class="sonyra-manager-dashboard-secondary-grid">
				<div class="sonyra-manager-dashboard-placeholder-card">
					<?php self::render_icon( 'alert-circle', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
					<h3><?php echo esc_html( self::text( 'manager.dashboard_activity_title' ) ); ?></h3>
					<p><?php echo esc_html( empty( $activity_items ) ? self::text( 'manager.dashboard_activity_empty' ) : self::text( 'manager.dashboard_extension_data_ready' ) ); ?></p>
				</div>
				<div class="sonyra-manager-dashboard-placeholder-card" <?php echo empty( $extension_slots['alerts'] ) && empty( $extension_slots['metrics'] ) ? 'hidden' : ''; ?>>
					<?php self::render_icon( 'components', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
					<h3><?php echo esc_html( self::text( 'manager.dashboard_extension_slots_title' ) ); ?></h3>
					<p><?php echo esc_html( self::text( 'manager.dashboard_extension_slots_description' ) ); ?></p>
				</div>
			</div>
		</section>
		<?php
	}

	private static function render_dashboard_card( array $card ): void {
		if ( empty( $card['title'] ) || empty( $card['description'] ) ) {
			return;
		}

		$icon_key = isset( $card['icon_key'] ) ? (string) $card['icon_key'] : 'info-circle';
		$status = isset( $card['status'] ) ? (string) $card['status'] : 'not_checked';
		?>
		<article class="sonyra-manager-dashboard-card">
			<div class="sonyra-manager-dashboard-card-icon"><?php self::render_icon( $icon_key, 'sonyra-manager-icon sonyra-manager-card-icon' ); ?></div>
			<div>
				<h3><?php echo esc_html( self::text( (string) $card['title'] ) ); ?></h3>
				<p><?php echo esc_html( self::text( (string) $card['description'] ) ); ?></p>
				<span class="sonyra-manager-dashboard-status-badge sonyra-manager-dashboard-status-badge-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( self::text( self::get_dashboard_status_label_key( $status ) ) ); ?></span>
			</div>
		</article>
		<?php
	}

	private static function render_dashboard_setup_step( array $step ): void {
		if ( empty( $step['title'] ) || empty( $step['description'] ) || empty( $step['icon_key'] ) ) {
			return;
		}

		$status = isset( $step['status'] ) ? (string) $step['status'] : 'not_checked';
		$action_route = isset( $step['action_route'] ) ? (string) $step['action_route'] : 'dashboard';
		$action_label = isset( $step['action_label'] ) ? (string) $step['action_label'] : 'manager.dashboard_action_open_section';
		?>
		<article class="sonyra-manager-dashboard-step">
			<div class="sonyra-manager-dashboard-step-icon"><?php self::render_icon( (string) $step['icon_key'], 'sonyra-manager-icon sonyra-manager-card-icon' ); ?></div>
			<div class="sonyra-manager-dashboard-step-copy">
				<strong><?php echo esc_html( self::text( (string) $step['title'] ) ); ?></strong>
				<p><?php echo esc_html( self::text( (string) $step['description'] ) ); ?></p>
			</div>
			<div class="sonyra-manager-dashboard-step-actions">
				<span class="sonyra-manager-dashboard-status-badge sonyra-manager-dashboard-status-badge-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( self::text( self::get_dashboard_status_label_key( $status ) ) ); ?></span>
				<button type="button" class="sonyra-manager-dashboard-link" data-manager-route="<?php echo esc_attr( $action_route ); ?>"><?php echo esc_html( self::text( $action_label ) ); ?></button>
			</div>
		</article>
		<?php
	}

	private static function render_dashboard_completion_modal( array $state ): void {
		$hidden = ' hidden';
		?>
		<div class="sonyra-manager-dashboard-completion-modal" data-manager-dashboard-completion-modal<?php echo $hidden; ?>>
			<div class="sonyra-manager-dashboard-completion-card" role="dialog" aria-modal="true" aria-labelledby="sonyra-manager-dashboard-completion-title">
				<?php self::render_icon( 'circle-check', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
				<h2 id="sonyra-manager-dashboard-completion-title"><?php echo esc_html( self::text( 'manager.dashboard_completion_title' ) ); ?></h2>
				<p><?php echo esc_html( self::text( 'manager.dashboard_completion_description' ) ); ?></p>
				<button type="button" class="sonyra-manager-dashboard-link"><?php echo esc_html( self::text( 'manager.dashboard_completion_button' ) ); ?></button>
			</div>
		</div>
		<?php
	}

	public static function render_shell(): void {
		$css_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/css/sonyra-manager.css';
		$css_url = plugins_url( 'assets/css/sonyra-manager.css', SONYRA_SITE_MANAGER_FILE );
		$js_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/js/sonyra-manager.js';
		$js_url = plugins_url( 'assets/js/sonyra-manager.js', SONYRA_SITE_MANAGER_FILE );
		$logo_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-logo.png';
		$logo_url = plugins_url( 'assets/images/brand/pult-site-logo.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_ico_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon.ico';
		$favicon_ico_url = plugins_url( 'assets/images/brand/pult-site-favicon.ico', SONYRA_SITE_MANAGER_FILE );
		$favicon_32_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-32.png';
		$favicon_32_url = plugins_url( 'assets/images/brand/pult-site-favicon-32.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_192_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-192.png';
		$favicon_192_url = plugins_url( 'assets/images/brand/pult-site-favicon-192.png', SONYRA_SITE_MANAGER_FILE );
		$apple_touch_icon_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-apple-touch-icon-180.png';
		$apple_touch_icon_url = plugins_url( 'assets/images/brand/pult-site-apple-touch-icon-180.png', SONYRA_SITE_MANAGER_FILE );
		$logout_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/logout' ) : '';
		$login_url = function_exists( 'home_url' ) ? home_url( '/manager/login' ) : '/manager/login';
		$nonce = function_exists( 'wp_create_nonce' ) ? wp_create_nonce( 'wp_rest' ) : '';
		$year = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );
		$sections = self::get_sections();
		$views = self::get_views();
		$active_section = $sections['dashboard'];
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
		<title><?php echo esc_html( self::text( (string) $active_section['title'] ) ); ?></title>
	<?php if ( '' !== self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" href="<?php echo esc_url( self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ); ?>" sizes="any">
	<link rel="shortcut icon" href="<?php echo esc_url( self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ); ?>" type="image/x-icon">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' ) ) : ?>
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( self::versioned_asset_url( $css_url, $css_path ) ); ?>">
</head>
<body class="sonyra-manager-page">
	<div class="sonyra-manager-shell" data-sidebar-state="expanded" data-manager-shell data-logout-url="<?php echo esc_url( $logout_url ); ?>" data-login-url="<?php echo esc_url( $login_url ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>">
		<div class="sonyra-manager-backdrop" data-manager-backdrop hidden></div>

			<main class="sonyra-manager-main">
				<?php self::render_page_header( $active_section ); ?>
				<?php self::render_page_header_templates( $sections ); ?>

			<div class="sonyra-manager-notice" data-manager-logout-error hidden>
				<?php self::render_icon( 'alert-circle', 'sonyra-manager-icon sonyra-manager-notice-icon' ); ?>
				<span><?php echo esc_html( self::text( 'manager.logout_error' ) ); ?></span>
				<small><?php echo esc_html( self::text( 'manager.logout_error_hint' ) ); ?></small>
			</div>

				<?php self::render_dashboard_view(); ?>

			<?php foreach ( $views as $route => $view ) : ?>
				<?php if ( 'dashboard' === $route ) : ?>
					<?php continue; ?>
				<?php endif; ?>
					<section class="sonyra-manager-view sonyra-manager-view-placeholder" data-manager-view="<?php echo esc_attr( $route ); ?>" hidden>
						<div class="sonyra-manager-placeholder-card">
							<div class="sonyra-manager-hero-icon"><?php self::render_icon( (string) $view['icon_key'], 'sonyra-manager-icon sonyra-manager-hero-svg' ); ?></div>
							<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( (string) $view['kicker'] ) ); ?></p>
							<h2><?php echo esc_html( self::text( (string) $view['title'] ) ); ?></h2>
							<p><?php echo esc_html( self::text( (string) $view['description'] ) ); ?></p>
						</div>
					</section>
				<?php endforeach; ?>

				<footer class="sonyra-login-footer">
					<span class="sonyra-login-footer-item"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></span>
					<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
					<span class="sonyra-login-footer-item"><?php echo esc_html( '© ' . $year . ' ' . self::text( 'login.footer_rights_holder' ) ); ?></span>
					<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
					<span class="sonyra-login-footer-item sonyra-login-footer-version"><?php echo esc_html( self::text( 'login.version_label' ) . ' ' . SONYRA_SITE_MANAGER_VERSION ); ?></span>
				</footer>
		</main>

		<aside class="sonyra-manager-sidebar" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_label' ) ); ?>">
			<div class="sonyra-manager-brand-row">
				<div class="sonyra-manager-brand">
					<button type="button" class="sonyra-manager-logo-tile" data-manager-logo-toggle aria-expanded="true" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-expanded="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-collapsed="<?php echo esc_attr( self::text( 'manager.sidebar_expand' ) ); ?>" data-tooltip="<?php echo esc_attr( self::text( 'manager.sidebar_expand_hint' ) ); ?>">
						<?php if ( '' !== self::versioned_asset_url( $logo_url, $logo_path ) ) : ?>
							<img src="<?php echo esc_url( self::versioned_asset_url( $logo_url, $logo_path ) ); ?>" alt="" aria-hidden="true" decoding="async">
						<?php endif; ?>
					</button>
					<span class="sonyra-manager-brand-copy">
						<strong><?php echo esc_html( self::text( 'manager.brand_name' ) ); ?></strong>
						<small><?php echo esc_html( self::text( 'manager.publisher' ) ); ?></small>
					</span>
				</div>
				<button type="button" class="sonyra-manager-sidebar-toggle" data-manager-sidebar-toggle aria-expanded="true" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-expanded="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-collapsed="<?php echo esc_attr( self::text( 'manager.sidebar_expand' ) ); ?>">
					<span class="sonyra-manager-toggle-icon"><?php self::render_icon( 'layout-sidebar-left-collapse' ); ?></span>
				</button>
			</div>

			<nav class="sonyra-manager-nav">
					<ul>
						<?php foreach ( self::get_nav_items() as $item ) : ?>
							<li>
								<button type="button" class="sonyra-manager-nav-item" data-manager-route="<?php echo esc_attr( $item['route'] ); ?>" data-kicker="<?php echo esc_attr( self::text( (string) $item['kicker'] ) ); ?>" data-title="<?php echo esc_attr( self::text( (string) $item['title'] ) ); ?>" data-description="<?php echo esc_attr( self::text( (string) $item['description'] ) ); ?>" data-tooltip="<?php echo esc_attr( self::text( (string) $item['nav_label'] ) ); ?>" <?php echo 'dashboard' === $item['route'] ? 'aria-current="page"' : ''; ?>>
									<span class="sonyra-manager-nav-icon-slot"><?php self::render_icon( (string) $item['icon_key'], 'sonyra-manager-icon sonyra-manager-nav-icon' ); ?></span>
									<span class="sonyra-manager-nav-label"><?php echo esc_html( self::text( (string) $item['nav_label'] ) ); ?></span>
								</button>
							</li>
						<?php endforeach; ?>
						<li class="sonyra-manager-nav-logout-row">
							<button type="button" class="sonyra-manager-nav-item sonyra-manager-logout" data-manager-logout data-tooltip="<?php echo esc_attr( self::text( 'manager.nav_logout' ) ); ?>">
								<span class="sonyra-manager-nav-icon-slot"><?php self::render_icon( 'logout', 'sonyra-manager-icon sonyra-manager-nav-icon' ); ?></span>
								<span class="sonyra-manager-nav-label"><?php echo esc_html( self::text( 'manager.nav_logout' ) ); ?></span>
							</button>
						</li>
					</ul>
				</nav>
			</aside>
	</div>
	<script src="<?php echo esc_url( self::versioned_asset_url( $js_url, $js_path ) ); ?>" defer></script>
</body>
</html>
		<?php
	}

	private static function render_metric( string $label_key ): void {
		?>
		<div class="sonyra-manager-metric">
			<span><?php echo esc_html( self::text( $label_key ) ); ?></span>
			<strong><?php echo esc_html( self::text( 'manager.metric_empty' ) ); ?></strong>
			<small><?php echo esc_html( self::text( 'manager.metric_pending' ) ); ?></small>
		</div>
		<?php
	}

	private static function render_step( string $icon, string $title_key, string $hint_key, string $status_key, string $state ): void {
		?>
		<div class="sonyra-manager-step sonyra-manager-step-<?php echo esc_attr( $state ); ?>">
			<span class="sonyra-manager-step-icon"><?php self::render_icon( $icon ); ?></span>
			<span>
				<strong><?php echo esc_html( self::text( $title_key ) ); ?></strong>
				<small><?php echo esc_html( self::text( $hint_key ) ); ?></small>
			</span>
			<em><?php echo esc_html( self::text( $status_key ) ); ?></em>
		</div>
		<?php
	}
}
