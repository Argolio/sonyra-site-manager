# SONYRA Color Controller Contract

## 1. Purpose

Color Controller is the system design layer of SONYRA Site Manager. It stores colors, gradients, patterns and the reusable site library that will later connect to sections, blocks, widgets, popups, header, footer and global text colors.

Visible UX for this system must follow `docs/SONYRA_MANAGER_SECTION_UX_STANDARD.md`.

## 2. Store

- option name: `sonyra_site_manager_color_controller`
- autoload: `false`
- current store version: `0.1.0`
- DB migration is not used in release `0.1.76`

Root shape:

- `version`
- `colors[]`
- `gradients[]`
- `patterns[]`
- `presets[]`
- `library_meta`

## 3. Colors

- each color stores `value_hex` and `value_rgb`
- HEX is normalized to uppercase `#RRGGBB`
- RGB is stored as a numeric array `[r, g, b]`
- roles use technical keys such as `brand.primary` and `text.secondary`
- invalid colors are rejected and not saved

## 4. Gradients

- only `linear` gradients are allowed in `0.1.76`
- each gradient stores `angle` and `stops[]`
- stops are limited to `2–5`
- each stop stores valid `color_hex`
- each stop position is limited to `0–100`
- raw CSS input is not accepted

## 5. Patterns

- patterns use an allowlist of `pattern_type`
- arbitrary CSS patterns are not accepted
- pattern colors are stored as normalized HEX values
- settings are limited to safe scalar values

Allowed pattern types:

- `soft_glow`
- `soft_blobs`
- `diagonal_wave`
- `accent_orbit`
- `deep_background`
- `color_splash`
- `subtle_grid`
- `radial_aura`

## 6. Library

- the library stores saved colors, gradients and patterns
- the manager UI shows the default core library immediately after first load
- future releases may add user-created presets and richer reuse workflows

## 7. Tokens

- future integrations should reference design tokens instead of raw display values when possible
- token references should still keep safe fallback values for stable rendering

## 8. Integration Roadmap

Future connection points:

- sections
- blocks
- widgets
- popups
- header
- footer
- global text colors
- public CSS variables

## 9. Security

- no raw CSS injection
- no arbitrary CSS persistence
- no `url()`, `var()`, `expression()` or `javascript:` user input
- no public style application in release `0.1.76`
- validators normalize or reject unsafe input before saving

## 10. Current Release `0.1.76`

Release `0.1.76` includes:

- Color Controller architecture
- dedicated store and option
- `Дизайн` landing section with a real tool card for `Цветовая библиотека`
- dedicated internal tool screen in `Дизайн`
- default core library
- validation methods for colors, gradients and patterns

Release `0.1.76` does not include:

- full color CRUD
- gradient builder UI
- pattern builder UI
- picker integration into sections, blocks, widgets or popups
- public style application

## 11. UX Positioning Standard

- `Дизайн` should evolve as a section landing, not as a permanent full-screen Color Controller surface;
- the internal tool screen should use the tool context card pattern from `SONYRA_MANAGER_SECTION_UX_STANDARD.md`;
- the visible product name of the tool should be `Цветовая библиотека`;
- the technical name `Color Controller` may remain in architecture, option keys, REST layer and internal code;
- the internal screen keeps only `Цвета`, `Градиенты` and `Паттерны` tabs;
- the internal screen does not render a duplicate hero/header inside the body;
- counters belong to the tool card and the compact tabs/meta panel, not to the big `Дизайн` page header;
- future Color Library UI work must align with the `Страницы`-derived section UX standard before adding CRUD.
- the Color Library tool context card must reuse the `Страницы` context/panel standard one-to-one;
- the visible label `ЦВЕТОВАЯ БИБЛИОТЕКА` remains a muted service label, not a violet accent;
- the help icon must reuse the shared help trigger component and Help Library behavior;
- the back action `Вернуться в раздел Дизайн` must use the shared arrow-back button pattern;
- the tabs/meta row must use the same padded toolbar logic as `Страницы`.
- the Color Library toolbar counters must use meta-chip style, not dot-separated loose text;
- the back action must remain vertically centered inside the context card;
- footer spacing is a global manager shell responsibility, not a Color Library-only hack;
- future product decision may still split card layouts: colors may become a compact grid later, while gradients and patterns may keep large preview cards;
- release `0.1.76` hotfix does not change card sizes and does not introduce CRUD.
