(function () {
	'use strict';

	var payloadNode = document.getElementById('sonyra-manager-color-controller-payload');
	var helpNode = document.getElementById('sonyra-manager-help-entries');
	var root = document.querySelector('[data-color-controller-root]');
	var app = root ? root.querySelector('[data-color-controller-app]') : null;
	var state = {
		currentLocale: 'ru_RU',
		fallbackLocale: 'ru_RU',
		dictionary: {},
		data: {
			version: '0.1.0',
			colors: [],
			gradients: [],
			patterns: [],
			presets: [],
			library_meta: {
				updated_at: '',
				created_by: 'core'
			}
		},
		summary: {
			colors: 0,
			gradients: 0,
			patterns: 0,
			presets: 0
		},
		apiUrl: '',
		nonce: '',
		helpKey: 'design.colors.controller',
		activeTab: 'colors',
		activeView: 'landing',
		helpEntries: {},
		hasLoadedRemote: false
	};

	function parseJsonNode(node) {
		if (!node) {
			return {};
		}

		try {
			return JSON.parse(node.textContent || '{}');
		} catch (error) {
			return {};
		}
	}

	function createTextNode(tag, className, text) {
		var node = document.createElement(tag);

		if (className) {
			node.className = className;
		}

		if (text !== undefined) {
			node.textContent = text;
		}

		return node;
	}

	function clearNode(node) {
		while (node && node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function t(key) {
		return state.dictionary && state.dictionary[key] ? state.dictionary[key] : '';
	}

	function formatRgb(rgb) {
		if (!Array.isArray(rgb) || rgb.length !== 3) {
			return '—';
		}

		return rgb.join(', ');
	}

	function formatUpdatedAt(value) {
		if (!value) {
			return '—';
		}

		var date = new Date(value);

		if (Number.isNaN(date.getTime())) {
			return '—';
		}

		return new Intl.DateTimeFormat('ru-RU', {
			day: '2-digit',
			month: '2-digit',
			year: 'numeric',
			hour: '2-digit',
			minute: '2-digit'
		}).format(date);
	}

	function getPatternColorsCount(pattern) {
		return pattern && pattern.colors ? Object.keys(pattern.colors).length : 0;
	}

	function getGradientStopsCount(gradient) {
		return gradient && Array.isArray(gradient.stops) ? gradient.stops.length : 0;
	}

	function buildGradientBackground(gradient) {
		if (!gradient || !Array.isArray(gradient.stops) || !gradient.stops.length) {
			return 'linear-gradient(135deg, #E2E8F0 0%, #CBD5E1 100%)';
		}

		return 'linear-gradient(' + String(gradient.angle || 135) + 'deg, ' + gradient.stops.map(function (stop) {
			return String(stop.color_hex || '#CBD5E1') + ' ' + String(stop.position || 0) + '%';
		}).join(', ') + ')';
	}

	function normalizeEntries(entries) {
		var normalized = {};

		if (!Array.isArray(entries)) {
			return normalized;
		}

		entries.forEach(function (entry) {
			if (!entry || typeof entry !== 'object' || !entry.key) {
				return;
			}

			normalized[String(entry.key)] = entry;
		});

		return normalized;
	}

	function cloneStandardIcon(key) {
		var template = document.querySelector('[data-pages-icon-template="' + key + '"]');

		if (!template || !template.firstElementChild) {
			return document.createTextNode('');
		}

		return template.firstElementChild.cloneNode(true);
	}

	function createStandardButton(className, text, iconKey) {
		var button = document.createElement('button');

		button.type = 'button';
		button.className = className;

		if (iconKey) {
			var iconWrap = createTextNode('span', 'sonyra-manager-pages-button-icon-wrap');
			iconWrap.appendChild(cloneStandardIcon(iconKey));
			button.appendChild(iconWrap);
		}

		if (text) {
			button.appendChild(document.createTextNode(text));
		}

		return button;
	}

	function getPluralWord(count, baseKey) {
		var mod10 = count % 10;
		var mod100 = count % 100;
		var suffix = 'many';

		if (mod10 === 1 && mod100 !== 11) {
			suffix = 'one';
		} else if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
			suffix = 'few';
		}

		return t(baseKey + '_' + suffix);
	}

	function formatCountPhrase(count, baseKey) {
		return String(count) + ' ' + getPluralWord(count, baseKey);
	}

	function buildSummaryParts() {
		return [
			formatCountPhrase(state.summary.colors || 0, 'manager.design.colors.count_color'),
			formatCountPhrase(state.summary.gradients || 0, 'manager.design.colors.count_gradient'),
			formatCountPhrase(state.summary.patterns || 0, 'manager.design.colors.count_pattern')
		];
	}

	function buildInlineSummary() {
		return createTextNode('div', 'sonyra-color-controller__inline-summary', buildSummaryParts().join(' · '));
	}

	function buildToolbarSummary() {
		var group = createTextNode('div', 'sonyra-manager-meta-chip-group sonyra-color-controller__toolbar-summary');

		buildSummaryParts().forEach(function (part) {
			group.appendChild(createTextNode('span', 'sonyra-manager-meta-chip sonyra-color-controller__toolbar-chip', part));
		});

		return group;
	}

	function buildHelpButton() {
		var wrap = createTextNode('div', 'sonyra-help-tooltip-wrap sonyra-color-controller__help-wrap');
		var button = createStandardButton('sonyra-help-tooltip-trigger', '', 'help-circle');
		var popover = createTextNode('div', 'sonyra-help-popover sonyra-color-controller__help-popover');
		var entry = state.helpEntries[state.helpKey] || null;
		var triggerId = 'color-help-trigger-' + String(state.helpKey || '').replace(/[^a-z0-9_-]/gi, '-');

		button.id = triggerId;
		button.setAttribute('aria-label', t('manager.pages.actions.help_tooltip'));
		button.setAttribute('aria-expanded', 'false');
		button.setAttribute('data-color-help-toggle', state.helpKey);
		button.setAttribute('data-sonyra-help-key', state.helpKey);
		button.setAttribute('data-sonyra-help-trigger', triggerId);

		if (entry) {
			popover.appendChild(createTextNode('strong', 'sonyra-help-popover__title sonyra-color-controller__help-title', entry.title || ''));
			popover.appendChild(createTextNode('p', 'sonyra-help-popover__body sonyra-color-controller__help-body', entry.body || ''));
		}

		popover.hidden = true;
		popover.setAttribute('data-color-help-popover', state.helpKey);
		wrap.appendChild(button);
		wrap.appendChild(popover);

		return wrap;
	}

	function buildLandingCard() {
		var card = createTextNode('article', 'sonyra-color-controller__tool-card');
		var head = createTextNode('div', 'sonyra-color-controller__tool-card-head');
		var icon = createTextNode('span', 'sonyra-color-controller__tool-card-icon');
		var copy = createTextNode('div', 'sonyra-color-controller__tool-card-copy');
		var footer = createTextNode('div', 'sonyra-color-controller__tool-card-footer');
		var button = document.createElement('button');

		icon.setAttribute('aria-hidden', 'true');
		copy.appendChild(createTextNode('strong', 'sonyra-color-controller__tool-card-title', t('manager.design.tools.color_library.title')));
		copy.appendChild(createTextNode('p', 'sonyra-color-controller__tool-card-description', t('manager.design.tools.color_library.description')));
		head.appendChild(icon);
		head.appendChild(copy);

		button.type = 'button';
		button.className = 'sonyra-color-controller__tool-card-action';
		button.setAttribute('data-color-open-library', 'true');
		button.textContent = t('manager.design.tools.color_library.action');

		footer.appendChild(buildInlineSummary());
		footer.appendChild(button);
		card.appendChild(head);
		card.appendChild(footer);

		return card;
	}

	function buildLandingView() {
		var section = createTextNode('section', 'sonyra-color-controller__landing');
		section.appendChild(buildLandingCard());
		return section;
	}

	function buildContextCard() {
		var card = createTextNode('section', 'sonyra-pages-sections-context sonyra-pages-layer-context sonyra-manager-pages-table-card sonyra-color-controller__context');
		var copy = createTextNode('div', 'sonyra-pages-sections-context-copy sonyra-pages-layer-context-copy sonyra-color-controller__context-copy');
		var labelRow = createTextNode('div', 'sonyra-pages-panel-title-wrap sonyra-color-controller__context-label-row');
		var actions = createTextNode('div', 'sonyra-pages-layer-context-actions sonyra-color-controller__context-actions');
		var backButton = createStandardButton('sonyra-manager-pages-secondary', t('manager.design.colors.back_to_design'), 'arrow-left');

		labelRow.appendChild(createTextNode('span', 'sonyra-pages-sections-context-label', t('manager.design.colors.context_title')));
		labelRow.appendChild(buildHelpButton());
		copy.appendChild(labelRow);
		copy.appendChild(createTextNode('strong', 'sonyra-pages-sections-context-title sonyra-color-controller__context-title', t('manager.design.colors.context_subtitle')));
		backButton.setAttribute('data-color-back', 'true');

		actions.appendChild(backButton);
		card.appendChild(copy);
		card.appendChild(actions);

		return card;
	}

	function buildTabs() {
		var nav = createTextNode('nav', 'sonyra-pages-filter-group sonyra-color-controller__tabs');
		var tabs = [
			{ key: 'colors', label: t('manager.design.colors.tab_colors') },
			{ key: 'gradients', label: t('manager.design.colors.tab_gradients') },
			{ key: 'patterns', label: t('manager.design.colors.tab_patterns') }
		];

		tabs.forEach(function (tab) {
			var button = document.createElement('button');
			button.type = 'button';
			button.className = 'sonyra-pages-filter-chip sonyra-color-controller__tab' + (state.activeTab === tab.key ? ' is-active' : '');
			button.textContent = tab.label;
			button.setAttribute('data-color-tab', tab.key);
			button.setAttribute('aria-pressed', state.activeTab === tab.key ? 'true' : 'false');
			nav.appendChild(button);
		});

		return nav;
	}

	function buildToolbar() {
		var toolbar = createTextNode('section', 'sonyra-pages-toolbar-panel sonyra-color-controller__toolbar');
		var meta = createTextNode('div', 'sonyra-pages-toolbar-controls sonyra-color-controller__toolbar-meta');

		toolbar.appendChild(buildTabs());
		meta.appendChild(buildToolbarSummary());
		toolbar.appendChild(meta);
		return toolbar;
	}

	function buildEmptyState() {
		var empty = createTextNode('div', 'sonyra-color-controller__empty');
		empty.appendChild(createTextNode('strong', '', t('manager.design.colors.empty_title')));
		empty.appendChild(createTextNode('p', '', t('manager.design.colors.empty_description')));
		return empty;
	}

	function createMetaItem(label, value) {
		var fragment = document.createDocumentFragment();
		fragment.appendChild(createTextNode('dt', '', label));
		fragment.appendChild(createTextNode('dd', '', value));
		return fragment;
	}

	function buildColorCard(color) {
		var card = createTextNode('article', 'sonyra-color-controller__card sonyra-color-controller__card-color');
		var preview = createTextNode('div', 'sonyra-color-controller__preview sonyra-color-controller__preview-color');
		var content = createTextNode('div', 'sonyra-color-controller__card-content');
		var meta = createTextNode('dl', 'sonyra-color-controller__meta');

		preview.style.background = color.value_hex || '#E2E8F0';
		content.appendChild(createTextNode('strong', 'sonyra-color-controller__card-title', color.name || ''));
		content.appendChild(createTextNode('span', 'sonyra-color-controller__card-type', t('manager.design.colors.preview_color')));
		meta.appendChild(createMetaItem(t('manager.design.colors.hex_label'), color.value_hex || '—'));
		meta.appendChild(createMetaItem(t('manager.design.colors.rgb_label'), formatRgb(color.value_rgb)));
		meta.appendChild(createMetaItem(t('manager.design.colors.role_label'), color.role || '—'));
		card.appendChild(preview);
		card.appendChild(content);
		card.appendChild(meta);

		return card;
	}

	function buildGradientCard(gradient) {
		var card = createTextNode('article', 'sonyra-color-controller__card sonyra-color-controller__card-gradient');
		var preview = createTextNode('div', 'sonyra-color-controller__preview sonyra-color-controller__preview-gradient');
		var content = createTextNode('div', 'sonyra-color-controller__card-content');
		var meta = createTextNode('dl', 'sonyra-color-controller__meta');

		preview.style.backgroundImage = buildGradientBackground(gradient);
		content.appendChild(createTextNode('strong', 'sonyra-color-controller__card-title', gradient.name || ''));
		content.appendChild(createTextNode('span', 'sonyra-color-controller__card-type', t('manager.design.colors.preview_gradient')));
		meta.appendChild(createMetaItem(t('manager.design.colors.gradient_angle_label'), String(gradient.angle || 0) + '°'));
		meta.appendChild(createMetaItem(t('manager.design.colors.gradient_stops_label'), String(getGradientStopsCount(gradient))));
		meta.appendChild(createMetaItem(t('manager.design.colors.updated_label'), formatUpdatedAt(gradient.updated_at)));
		card.appendChild(preview);
		card.appendChild(content);
		card.appendChild(meta);

		return card;
	}

	function buildPatternPreview(pattern) {
		var preview = createTextNode('div', 'sonyra-color-controller__preview sonyra-color-controller__preview-pattern');
		var base = createTextNode('div', 'sonyra-color-controller__pattern-base');
		var orbA = createTextNode('span', 'sonyra-color-controller__pattern-orb is-a');
		var orbB = createTextNode('span', 'sonyra-color-controller__pattern-orb is-b');
		var orbC = createTextNode('span', 'sonyra-color-controller__pattern-orb is-c');
		var grid = createTextNode('span', 'sonyra-color-controller__pattern-grid');
		var colors = pattern && pattern.colors ? pattern.colors : {};

		base.style.background = colors.base || '#FFFFFF';
		orbA.style.background = colors.accent_a || '#EDE9FE';
		orbB.style.background = colors.accent_b || '#FCE7F3';
		orbC.style.background = colors.accent_c || '#DBEAFE';

		preview.appendChild(base);
		preview.appendChild(orbA);
		preview.appendChild(orbB);
		preview.appendChild(orbC);
		preview.appendChild(grid);

		return preview;
	}

	function buildPatternCard(pattern) {
		var card = createTextNode('article', 'sonyra-color-controller__card sonyra-color-controller__card-pattern');
		var content = createTextNode('div', 'sonyra-color-controller__card-content');
		var meta = createTextNode('dl', 'sonyra-color-controller__meta');

		card.appendChild(buildPatternPreview(pattern));
		content.appendChild(createTextNode('strong', 'sonyra-color-controller__card-title', pattern.name || ''));
		content.appendChild(createTextNode('span', 'sonyra-color-controller__card-type', t('manager.design.colors.preview_pattern')));
		meta.appendChild(createMetaItem(t('manager.design.colors.pattern_type_label'), pattern.pattern_type || '—'));
		meta.appendChild(createMetaItem(t('manager.design.colors.pattern_colors_label'), String(getPatternColorsCount(pattern))));
		meta.appendChild(createMetaItem(t('manager.design.colors.updated_label'), formatUpdatedAt(pattern.updated_at)));
		card.appendChild(content);
		card.appendChild(meta);

		return card;
	}

	function buildCardsGrid(items, builder) {
		var grid = createTextNode('div', 'sonyra-color-controller__grid');

		if (!items.length) {
			return buildEmptyState();
		}

		items.forEach(function (item) {
			grid.appendChild(builder(item));
		});

		return grid;
	}

	function buildTabContent() {
		var body = createTextNode('section', 'sonyra-manager-pages-table-card sonyra-color-controller__body');

		if (state.activeTab === 'colors') {
			body.appendChild(buildCardsGrid(state.data.colors || [], buildColorCard));
			return body;
		}

		if (state.activeTab === 'gradients') {
			body.appendChild(buildCardsGrid(state.data.gradients || [], buildGradientCard));
			return body;
		}

		body.appendChild(buildCardsGrid(state.data.patterns || [], buildPatternCard));
		return body;
	}

	function buildLibraryView() {
		var section = createTextNode('section', 'sonyra-color-controller__workspace');
		section.appendChild(buildContextCard());
		section.appendChild(buildToolbar());
		section.appendChild(buildTabContent());
		return section;
	}

	function recalculateSummary() {
		state.summary = {
			colors: Array.isArray(state.data.colors) ? state.data.colors.length : 0,
			gradients: Array.isArray(state.data.gradients) ? state.data.gradients.length : 0,
			patterns: Array.isArray(state.data.patterns) ? state.data.patterns.length : 0,
			presets: Array.isArray(state.data.presets) ? state.data.presets.length : 0
		};
	}

	function render(container, nextState) {
		var target = container || app;

		if (nextState && typeof nextState === 'object') {
			if (nextState.data) {
				state.data = nextState.data;
			}

			if (nextState.activeTab) {
				state.activeTab = nextState.activeTab;
			}

			if (nextState.activeView) {
				state.activeView = nextState.activeView;
			}
		}

		if (!target) {
			return;
		}

		recalculateSummary();
		clearNode(target);

		if (state.activeView === 'library') {
			target.appendChild(buildLibraryView());
			return;
		}

		target.appendChild(buildLandingView());
	}

	function getState() {
		return {
			currentLocale: state.currentLocale,
			fallbackLocale: state.fallbackLocale,
			data: state.data,
			summary: state.summary,
			activeTab: state.activeTab,
			activeView: state.activeView
		};
	}

	function applyRemoteData(payload) {
		if (!payload || typeof payload !== 'object') {
			return;
		}

		if (payload.data && typeof payload.data === 'object') {
			state.data = payload.data;
		}

		if (payload.summary && typeof payload.summary === 'object') {
			state.summary = payload.summary;
		}
	}

	function refresh() {
		if (!state.apiUrl || !window.fetch) {
			render(app);
			return Promise.resolve(getState());
		}

		return window.fetch(state.apiUrl, {
			method: 'GET',
			headers: {
				'X-Sonyra-Color-Controller-Nonce': state.nonce || ''
			},
			credentials: 'same-origin'
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('request_failed');
			}

			return response.json();
		}).then(function (payload) {
			applyRemoteData(payload);
			state.hasLoadedRemote = true;
			render(app);
			return getState();
		}).catch(function () {
			render(app);
			return getState();
		});
	}

	function closeHelpPopovers() {
		if (!app) {
			return;
		}

		Array.prototype.slice.call(app.querySelectorAll('[data-color-help-popover]')).forEach(function (popover) {
			popover.hidden = true;
		});
		Array.prototype.slice.call(app.querySelectorAll('[data-color-help-toggle]')).forEach(function (button) {
			button.setAttribute('aria-expanded', 'false');
		});
	}

	function toggleHelp(helpKey) {
		var popover = app ? app.querySelector('[data-color-help-popover="' + helpKey + '"]') : null;

		if (!popover) {
			return;
		}

		popover.hidden = !popover.hidden;
		if (app) {
			var button = app.querySelector('[data-color-help-toggle="' + helpKey + '"]');

			if (button) {
				button.setAttribute('aria-expanded', popover.hidden ? 'false' : 'true');
			}
		}
	}

	function handleClick(event) {
		var tabButton = event.target.closest('[data-color-tab]');
		var helpButton = event.target.closest('[data-color-help-toggle]');
		var openButton = event.target.closest('[data-color-open-library]');
		var backButton = event.target.closest('[data-color-back]');

		if (tabButton) {
			state.activeTab = tabButton.getAttribute('data-color-tab') || 'colors';
			render(app);
			return;
		}

		if (helpButton) {
			toggleHelp(helpButton.getAttribute('data-color-help-toggle') || state.helpKey);
			return;
		}

		if (openButton) {
			state.activeView = 'library';
			render(app);
			return;
		}

		if (backButton) {
			state.activeView = 'landing';
			closeHelpPopovers();
			render(app);
			return;
		}

		closeHelpPopovers();
	}

	function handleKeydown(event) {
		if (event.key === 'Escape') {
			closeHelpPopovers();
		}
	}

	function init(options) {
		var payload = parseJsonNode(payloadNode);

		options = options && typeof options === 'object' ? options : {};
		state.currentLocale = String(payload.currentLocale || 'ru_RU');
		state.fallbackLocale = String(payload.fallbackLocale || state.currentLocale || 'ru_RU');
		state.dictionary = payload.dictionary && typeof payload.dictionary === 'object' ? payload.dictionary : {};
		state.data = payload.data && typeof payload.data === 'object' ? payload.data : state.data;
		state.summary = payload.summary && typeof payload.summary === 'object' ? payload.summary : state.summary;
		state.apiUrl = String(payload.apiUrl || '');
		state.nonce = String(payload.nonce || '');
		state.helpKey = String(payload.helpKey || state.helpKey);
		state.helpEntries = normalizeEntries(parseJsonNode(helpNode));

		if (options.root && options.root.nodeType === 1) {
			root = options.root;
			app = root.querySelector('[data-color-controller-app]') || app;
		}

		if (!app) {
			return;
		}

		if (!app.getAttribute('data-color-controller-bound')) {
			app.addEventListener('click', handleClick);
			app.addEventListener('keydown', handleKeydown);
			app.setAttribute('data-color-controller-bound', 'true');
		}

		render(app);
	}

	function handleRouteChange(route) {
		if (route !== 'design') {
			return;
		}

		state.activeView = 'landing';
		state.activeTab = 'colors';

		if (!app) {
			init();
			return;
		}

		if (!state.hasLoadedRemote) {
			refresh();
			return;
		}

		render(app);
	}

	window.SonyraColorController = {
		init: init,
		render: render,
		getState: getState,
		refresh: refresh,
		handleRouteChange: handleRouteChange
	};
}());
