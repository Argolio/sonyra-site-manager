<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Plugin {

	/**
	 * @var string
	 */
	private $version;

	public function __construct( $version ) {
		$this->version = $version;
	}

	public function run() {
		add_action( 'plugins_loaded', array( 'Sonyra_Site_Manager_Installer', 'maybe_runtime_sync' ), 20 );
	}

	public function get_version() {
		return $this->version;
	}
}
