(function () {
	'use strict';

	var root = document.querySelector('[data-color-controller-root]');
	var app = root ? root.querySelector('[data-color-controller-app]') : null;
	var payloadNode = document.getElementById('sonyra-manager-color-controller-payload');
	var helpEntriesNode = document.getElementById('sonyra-manager-help-entries');

	if (!root || !app || !payloadNode) {
		return;
	}

	var payload = parseJson(payloadNode.textContent || '{}');
	var helpEntries = parseJson(helpEntriesNode ? (helpEntriesNode.textContent || '[]') : '[]');
	var helpMap = {};

	(helpEntries || []).forEach(function (entry) {
		if (entry && entry.key) {
			helpMap[String(entry.key)] = entry;
		}
	});

	var state = {
		routeActive: false,
		view: 'landing',
		activeTab: 'colors',
		data: normalizeData(payload.data || {}),
		summary: normalizeSummary(payload.summary || {}),
		apiUrl: String(payload.apiUrl || ''),
		nonce: String(payload.nonce || ''),
		helpKey: String(payload.helpKey || ''),
		message: null,
		modal: null,
		helpOpen: false
	};

	function getDestructiveModalSubtitleText() {
		return String(payload && payload.messages && payload.messages.destructiveModalSubtitle ? payload.messages.destructiveModalSubtitle : t('manager.design.colors.delete_modal_description'));
	}

	function parseJson(source) {
		try {
			return JSON.parse(source);
		} catch (error) {
			return null;
		}
	}

	function t(key, fallback) {
		var dictionary = payload && payload.dictionary ? payload.dictionary : {};
		return dictionary[key] || fallback || '';
	}

	function getManagerUi() {
		if (!window.SonyraManagerUI) {
			throw new Error('[SonyraManagerUI] Shared manager UI library is not loaded.');
		}

		return window.SonyraManagerUI;
	}

	function normalizeSharedIconKey(iconName) {
		if (iconName === 'arrowLeft') {
			return 'arrow-left';
		}

		if (iconName === 'close') {
			return 'x';
		}

		return iconName;
	}

	function normalizeData(data) {
		return {
			colors: Array.isArray(data.colors) ? data.colors.slice() : [],
			gradients: Array.isArray(data.gradients) ? data.gradients.slice() : [],
			patterns: Array.isArray(data.patterns) ? data.patterns.slice() : [],
			presets: Array.isArray(data.presets) ? data.presets.slice() : [],
			library_meta: data.library_meta && typeof data.library_meta === 'object' ? data.library_meta : {}
		};
	}

	function normalizeSummary(summary) {
		return {
			colors: Number(summary.colors || 0),
			gradients: Number(summary.gradients || 0),
			patterns: Number(summary.patterns || 0),
			presets: Number(summary.presets || 0)
		};
	}

	function createNode(tag, className, text) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (typeof text === 'string') {
			node.textContent = text;
		}
		return node;
	}

	function createButton(className, text, iconName) {
		return getManagerUi().renderButton({
			className: className,
			text: text,
			iconKey: normalizeSharedIconKey(iconName)
		});
	}

	function clearNode(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function getCollectionKey(entityType) {
		if (entityType === 'color') {
			return 'colors';
		}
		if (entityType === 'gradient') {
			return 'gradients';
		}
		return 'patterns';
	}

	function getEntityTitle(entityType) {
		if (entityType === 'color') {
			return t('manager.design.colors.tab_colors');
		}
		if (entityType === 'gradient') {
			return t('manager.design.colors.tab_gradients');
		}
		return t('manager.design.colors.tab_patterns');
	}

	function getEntityCreateKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.create_color';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.create_gradient';
		}
		return 'manager.design.colors.create_pattern';
	}

	function getEntityEditKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.edit_color';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.edit_gradient';
		}
		return 'manager.design.colors.edit_pattern';
	}

	function getEntityDeleteTitleKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.delete_color_title';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.delete_gradient_title';
		}
		return 'manager.design.colors.delete_pattern_title';
	}

	function getEntityDeleteBodyKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.delete_color_body';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.delete_gradient_body';
		}
		return 'manager.design.colors.delete_pattern_body';
	}

	function getEntityCollection() {
		return state.data[state.activeTab] || [];
	}

	function getCurrentEntityType() {
		if (state.activeTab === 'colors') {
			return 'color';
		}
		if (state.activeTab === 'gradients') {
			return 'gradient';
		}
		return 'pattern';
	}

	function applyResponse(response) {
		state.data = normalizeData(response.data || {});
		state.summary = normalizeSummary(response.summary || {});
		state.message = response.message ? { type: 'success', text: String(response.message) } : null;
	}

	function formatCount(value, oneKey, fewKey, manyKey) {
		var count = Math.max(0, Number(value || 0));
		var mod10 = count % 10;
		var mod100 = count % 100;
		var noun = t(manyKey);

		if (mod10 === 1 && mod100 !== 11) {
			noun = t(oneKey);
		} else if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) {
			noun = t(fewKey);
		}

		return String(count) + ' ' + noun;
	}

	function formatRgb(rgb) {
		if (Array.isArray(rgb) && rgb.length >= 3) {
			return rgb.slice(0, 3).join(', ');
		}
		return '—';
	}

	function rgbFromHex(hex) {
		var normalized = normalizeHex(hex);
		if (!normalized) {
			return '';
		}
		return [
			parseInt(normalized.slice(1, 3), 16),
			parseInt(normalized.slice(3, 5), 16),
			parseInt(normalized.slice(5, 7), 16)
		].join(', ');
	}

	function normalizeHex(value) {
		var next = String(value || '').trim().toUpperCase();
		if (next && next.charAt(0) !== '#') {
			next = '#' + next;
		}
		return /^#[0-9A-F]{6}$/.test(next) ? next : '';
	}

	function formatUpdated(value) {
		if (!value) {
			return '—';
		}
		var date = new Date(value);
		if (isNaN(date.getTime())) {
			return '—';
		}
		return date.toLocaleString(payload.currentLocale || 'ru-RU', {
			day: '2-digit',
			month: '2-digit',
			year: 'numeric',
			hour: '2-digit',
			minute: '2-digit'
		});
	}

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	function replaceNamePlaceholder(text, name) {
		return String(text || '').replace(/%s/g, name || '—');
	}

	function getPatternTypeLabel(patternType) {
		var key = 'manager.design.colors.pattern_type_' + String(patternType || '');
		return t(key, String(patternType || ''));
	}

	function buildLandingCard() {
		var card = createNode('article', 'sonyra-color-controller__tool-card sonyra-color-controller__landing');
		var head = createNode('div', 'sonyra-color-controller__tool-card-head');
		var icon = createNode('div', 'sonyra-color-controller__tool-card-icon');
		var copy = createNode('div', 'sonyra-color-controller__tool-card-copy');
		var title = createNode('h2', 'sonyra-color-controller__tool-card-title', t('manager.design.tools.color_library.title'));
		var description = createNode('p', 'sonyra-color-controller__tool-card-description', t('manager.design.tools.color_library.description'));
		var footer = createNode('div', 'sonyra-color-controller__tool-card-footer');
		var chips = buildSummaryChips(true);
		var action = createButton('sonyra-manager-pages-primary', t('manager.design.tools.color_library.action'), 'plus');

		action.setAttribute('data-color-open-library', 'true');
		head.appendChild(icon);
		copy.appendChild(title);
		copy.appendChild(description);
		head.appendChild(copy);
		footer.appendChild(chips);
		footer.appendChild(action);
		card.appendChild(head);
		card.appendChild(footer);

		return card;
	}

	function buildSummaryChips(isLanding) {
		var wrap = createNode('div', 'sonyra-manager-meta-chip-group' + (isLanding ? ' sonyra-color-controller__landing-chips' : ''));
		[
			{
				label: formatCount(state.summary.colors, 'manager.design.colors.count_color_one', 'manager.design.colors.count_color_few', 'manager.design.colors.count_color_many')
			},
			{
				label: formatCount(state.summary.gradients, 'manager.design.colors.count_gradient_one', 'manager.design.colors.count_gradient_few', 'manager.design.colors.count_gradient_many')
			},
			{
				label: formatCount(state.summary.patterns, 'manager.design.colors.count_pattern_one', 'manager.design.colors.count_pattern_few', 'manager.design.colors.count_pattern_many')
			}
		].forEach(function (item) {
			wrap.appendChild(getManagerUi().renderMetaChip({
				className: 'sonyra-manager-meta-chip',
				text: item.label
			}));
		});
		return wrap;
	}

	function buildHelpTooltip() {
		var triggerId = 'help-trigger-' + String(state.helpKey || 'design-colors-controller').replace(/[^a-z0-9_-]/gi, '-');

		return getManagerUi().renderHelpTrigger({
			helpKey: state.helpKey || 'design.colors.controller',
			triggerId: triggerId,
			ariaLabel: t('manager.pages.actions.help_tooltip'),
			expanded: state.helpOpen,
			triggerAttributeName: 'data-color-help-toggle'
		});
	}

	function buildContext() {
		var back = createButton('sonyra-manager-pages-secondary', t('manager.design.colors.back_to_design'), 'arrowLeft');

		back.setAttribute('data-color-back', 'true');
		return getManagerUi().renderContextCard({
			className: 'sonyra-pages-sections-context sonyra-pages-layer-context sonyra-manager-pages-table-card sonyra-color-controller__context',
			copyClassName: 'sonyra-pages-sections-context-copy sonyra-pages-layer-context-copy',
			titleWrapClassName: 'sonyra-pages-panel-title-wrap',
			actionsClassName: 'sonyra-pages-layer-context-actions sonyra-color-controller__context-actions',
			labelNode: createNode('span', 'sonyra-pages-sections-context-label', t('manager.design.colors.context_title')),
			helpNode: buildHelpTooltip(),
			titleNode: createNode('strong', 'sonyra-pages-sections-context-title', t('manager.design.colors.context_subtitle')),
			actions: [back]
		});
	}

	function buildToolbar() {
		var toolbar = createNode('div', 'sonyra-pages-toolbar-panel');
		var filtersWrap = createNode('div', 'sonyra-pages-toolbar-controls');
		var filterGroup = createNode('div', 'sonyra-pages-filter-group sonyra-color-controller__tabs');
		var actions = createNode('div', 'sonyra-color-controller__toolbar-actions');
		var summary = buildSummaryChips(false);
		var createAction = createButton('sonyra-manager-pages-primary', t(getEntityCreateKey(getCurrentEntityType())), 'plus');

		createAction.setAttribute('data-color-create', getCurrentEntityType());
		summary.classList.add('sonyra-color-controller__toolbar-summary');

		[
			{ key: 'colors', label: t('manager.design.colors.tab_colors') },
			{ key: 'gradients', label: t('manager.design.colors.tab_gradients') },
			{ key: 'patterns', label: t('manager.design.colors.tab_patterns') }
		].forEach(function (tab) {
			var chip = createButton('sonyra-pages-filter-chip', tab.label);
			chip.setAttribute('data-color-tab', tab.key);
			chip.setAttribute('aria-pressed', state.activeTab === tab.key ? 'true' : 'false');
			chip.classList.toggle('is-active', state.activeTab === tab.key);
			filterGroup.appendChild(chip);
		});

		filtersWrap.appendChild(filterGroup);
		actions.appendChild(summary);
		actions.appendChild(createAction);
		toolbar.appendChild(filtersWrap);
		toolbar.appendChild(actions);

		return toolbar;
	}

	function buildMessage() {
		if (!state.message || !state.message.text) {
			return null;
		}
		var note = createNode('div', 'sonyra-color-controller__notice sonyra-color-controller__notice-' + state.message.type);
		note.appendChild(createNode('span', 'sonyra-color-controller__notice-text', state.message.text));
		var close = createButton('sonyra-color-controller__notice-close', '', 'close');
		close.setAttribute('aria-label', t('manager.pages.modal.close'));
		close.setAttribute('data-color-dismiss-message', 'true');
		note.appendChild(close);
		return note;
	}

	function createMetaRow(items) {
		var meta = createNode('dl', 'sonyra-color-controller__meta');
		items.forEach(function (item) {
			meta.appendChild(createNode('dt', '', item.label));
			meta.appendChild(createNode('dd', '', item.value));
		});
		return meta;
	}

	function renderColorPreview(item) {
		var preview = createNode('div', 'sonyra-color-controller__preview sonyra-color-controller__preview-color');
		preview.style.background = item.value_hex || '#FFFFFF';
		preview.setAttribute('aria-label', t('manager.design.colors.preview_color'));
		return preview;
	}

	function renderGradientPreview(item) {
		var preview = createNode('div', 'sonyra-color-controller__preview sonyra-color-controller__preview-gradient');
		var stops = Array.isArray(item.stops) ? item.stops : [];
		var angle = Number(item.angle || 135);
		var parts = stops.map(function (stop) {
			return (stop.color_hex || '#FFFFFF') + ' ' + String(Number(stop.position || 0)) + '%';
		});
		preview.style.background = 'linear-gradient(' + angle + 'deg, ' + parts.join(', ') + ')';
		preview.setAttribute('aria-label', t('manager.design.colors.preview_gradient'));
		return preview;
	}

	function renderPatternPreview(item) {
		var preview = createNode('div', 'sonyra-color-controller__preview sonyra-color-controller__preview-pattern');
		var colors = item.colors || {};
		var settings = item.settings || {};
		var intensity = Math.max(0, Math.min(100, Number(settings.intensity || 60)));
		var alpha = Math.max(0.12, Math.min(0.72, intensity / 100));
		var primary = colors.primary || colors.accent_a || '#EDE9FE';
		var background = colors.background || colors.base || '#FFFFFF';
		var orbA = colors.accent_a || primary;
		var orbB = colors.accent_b || primary;
		var orbC = colors.accent_c || primary;

		preview.style.backgroundColor = background;

		if (item.pattern_type === 'dots') {
			preview.style.backgroundImage = 'radial-gradient(' + primary + ' ' + Math.max(1.5, intensity / 14).toFixed(1) + 'px, transparent ' + Math.max(2.5, intensity / 10).toFixed(1) + 'px)';
			preview.style.backgroundSize = Math.max(12, 26 - Math.round(intensity / 8)) + 'px ' + Math.max(12, 26 - Math.round(intensity / 8)) + 'px';
			return preview;
		}

		if (item.pattern_type === 'grid' || item.pattern_type === 'subtle_grid') {
			preview.style.backgroundImage = 'linear-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,0) calc(100% - 1px), ' + hexToRgba(primary, alpha) + ' calc(100% - 1px), ' + hexToRgba(primary, alpha) + ' 100%), linear-gradient(90deg, rgba(255,255,255,0) 0, rgba(255,255,255,0) calc(100% - 1px), ' + hexToRgba(primary, alpha) + ' calc(100% - 1px), ' + hexToRgba(primary, alpha) + ' 100%)';
			preview.style.backgroundSize = Math.max(14, 30 - Math.round(intensity / 5)) + 'px ' + Math.max(14, 30 - Math.round(intensity / 5)) + 'px';
			return preview;
		}

		if (item.pattern_type === 'diagonal_lines' || item.pattern_type === 'diagonal_wave') {
			preview.style.backgroundImage = 'repeating-linear-gradient(135deg, ' + hexToRgba(primary, alpha) + ' 0, ' + hexToRgba(primary, alpha) + ' 2px, transparent 2px, transparent ' + Math.max(8, 22 - Math.round(intensity / 7)) + 'px)';
			return preview;
		}

		preview.appendChild(layer('sonyra-color-controller__pattern-base', background));
		preview.appendChild(orb('sonyra-color-controller__pattern-orb is-a', orbA));
		preview.appendChild(orb('sonyra-color-controller__pattern-orb is-b', orbB));
		preview.appendChild(orb('sonyra-color-controller__pattern-orb is-c', orbC));
		preview.appendChild(layer('sonyra-color-controller__pattern-grid', ''));
		return preview;
	}

	function hexToRgba(hex, alpha) {
		var normalized = normalizeHex(hex);
		if (!normalized) {
			return 'rgba(124,58,237,' + String(alpha || 0.25) + ')';
		}
		return 'rgba('
			+ parseInt(normalized.slice(1, 3), 16) + ','
			+ parseInt(normalized.slice(3, 5), 16) + ','
			+ parseInt(normalized.slice(5, 7), 16) + ','
			+ String(alpha || 0.25) + ')';
	}

	function layer(className, background) {
		var node = createNode('span', className);
		if (background) {
			node.style.background = background;
		}
		return node;
	}

	function orb(className, color) {
		var node = createNode('span', className);
		node.style.background = color;
		return node;
	}

	function buildCardActions(entityType, itemId) {
		var actions = createNode('div', 'sonyra-pages-card-actions');
		var edit = createButton('sonyra-pages-card-action', '', 'settings');
		var remove = createButton('sonyra-pages-card-action sonyra-pages-card-action-danger', '', 'trash');

		edit.setAttribute('aria-label', t('manager.design.colors.edit_action'));
		edit.setAttribute('title', t('manager.design.colors.edit_action'));
		edit.setAttribute('data-color-edit', itemId);
		edit.setAttribute('data-color-entity', entityType);

		remove.setAttribute('aria-label', t('manager.pages.actions.delete'));
		remove.setAttribute('title', t('manager.pages.actions.delete'));
		remove.setAttribute('data-color-delete', itemId);
		remove.setAttribute('data-color-entity', entityType);

		actions.appendChild(edit);
		actions.appendChild(remove);

		return actions;
	}

	function buildColorCard(item) {
		var card = createNode('article', 'sonyra-color-controller__card');
		var titleWrap = createNode('div', 'sonyra-color-controller__card-head');
		var title = createNode('strong', 'sonyra-color-controller__card-title', item.name || '—');
		var type = createNode('span', 'sonyra-color-controller__card-type', t('manager.design.colors.tab_colors'));
		var description = item.description ? createNode('p', 'sonyra-color-controller__card-description', item.description) : null;

		titleWrap.appendChild(title);
		titleWrap.appendChild(type);
		card.appendChild(renderColorPreview(item));
		card.appendChild(titleWrap);
		if (description) {
			card.appendChild(description);
		}
		card.appendChild(createMetaRow([
			{ label: t('manager.design.colors.hex_label'), value: item.value_hex || '—' },
			{ label: t('manager.design.colors.rgb_label'), value: formatRgb(item.value_rgb) },
			{ label: t('manager.design.colors.role_label'), value: item.role || '—' },
			{ label: t('manager.design.colors.updated_label'), value: formatUpdated(item.updated_at) }
		]));
		card.appendChild(buildCardActions('color', item.id));
		return card;
	}

	function buildGradientCard(item) {
		var card = createNode('article', 'sonyra-color-controller__card');
		var titleWrap = createNode('div', 'sonyra-color-controller__card-head');
		var title = createNode('strong', 'sonyra-color-controller__card-title', item.name || '—');
		var type = createNode('span', 'sonyra-color-controller__card-type', t('manager.design.colors.tab_gradients'));
		var description = item.description ? createNode('p', 'sonyra-color-controller__card-description', item.description) : null;
		var stops = Array.isArray(item.stops) ? item.stops : [];

		titleWrap.appendChild(title);
		titleWrap.appendChild(type);
		card.appendChild(renderGradientPreview(item));
		card.appendChild(titleWrap);
		if (description) {
			card.appendChild(description);
		}
		card.appendChild(createMetaRow([
			{ label: t('manager.design.colors.gradient_angle_label'), value: String(Number(item.angle || 0)) + '°' },
			{ label: t('manager.design.colors.gradient_stops_label'), value: String(stops.length) },
			{ label: t('manager.design.colors.role_label'), value: item.role || '—' },
			{ label: t('manager.design.colors.updated_label'), value: formatUpdated(item.updated_at) }
		]));
		card.appendChild(buildCardActions('gradient', item.id));
		return card;
	}

	function buildPatternCard(item) {
		var card = createNode('article', 'sonyra-color-controller__card');
		var titleWrap = createNode('div', 'sonyra-color-controller__card-head');
		var title = createNode('strong', 'sonyra-color-controller__card-title', item.name || '—');
		var type = createNode('span', 'sonyra-color-controller__card-type', t('manager.design.colors.tab_patterns'));
		var description = item.description ? createNode('p', 'sonyra-color-controller__card-description', item.description) : null;
		var colors = item.colors || {};

		titleWrap.appendChild(title);
		titleWrap.appendChild(type);
		card.appendChild(renderPatternPreview(item));
		card.appendChild(titleWrap);
		if (description) {
			card.appendChild(description);
		}
		card.appendChild(createMetaRow([
			{ label: t('manager.design.colors.pattern_type_label'), value: getPatternTypeLabel(item.pattern_type) },
			{ label: t('manager.design.colors.pattern_colors_label'), value: String(Object.keys(colors).length) },
			{ label: t('manager.design.colors.role_label'), value: item.role || '—' },
			{ label: t('manager.design.colors.updated_label'), value: formatUpdated(item.updated_at) }
		]));
		card.appendChild(buildCardActions('pattern', item.id));
		return card;
	}

	function buildGrid() {
		var collection = getEntityCollection();
		var entityType = getCurrentEntityType();

		if (!collection.length) {
			var empty = createNode('div', 'sonyra-color-controller__empty');
			var action = createButton('sonyra-manager-pages-primary', t(getEntityCreateKey(entityType)), 'plus');
			empty.appendChild(createNode('strong', '', t('manager.design.colors.empty_title')));
			empty.appendChild(createNode('p', '', t('manager.design.colors.empty_description')));
			action.setAttribute('data-color-create', entityType);
			empty.appendChild(action);
			return empty;
		}

		var grid = createNode('div', 'sonyra-color-controller__grid');
		collection.forEach(function (item) {
			if (entityType === 'color') {
				grid.appendChild(buildColorCard(item));
			} else if (entityType === 'gradient') {
				grid.appendChild(buildGradientCard(item));
			} else {
				grid.appendChild(buildPatternCard(item));
			}
		});
		return grid;
	}

	function buildWorkspace() {
		var workspace = createNode('div', 'sonyra-color-controller__workspace');
		var message = buildMessage();

		workspace.appendChild(buildContext());
		workspace.appendChild(buildToolbar());
		if (message) {
			workspace.appendChild(message);
		}
		workspace.appendChild(buildGrid());
		return workspace;
	}

	function getItemById(entityType, itemId) {
		var collection = state.data[getCollectionKey(entityType)] || [];
		return collection.find(function (item) {
			return String(item.id || '') === String(itemId || '');
		}) || null;
	}

	function getGradientHex(item, index) {
		var stops = Array.isArray(item && item.stops) ? item.stops : [];
		var stop = stops[index] || stops[stops.length - 1] || null;
		return stop && stop.color_hex ? String(stop.color_hex) : '';
	}

	function getPatternColor(item, key, fallbackKey) {
		var colors = item && item.colors ? item.colors : {};
		return String(colors[key] || colors[fallbackKey] || '');
	}

	function createDraft(entityType, item) {
		if (entityType === 'color') {
			return {
				name: item ? String(item.name || '') : '',
				value_hex: item ? String(item.value_hex || '') : '',
				role: item ? String(item.role || '') : '',
				description: item ? String(item.description || '') : ''
			};
		}
		if (entityType === 'gradient') {
			return {
				name: item ? String(item.name || '') : '',
				first_color_hex: item ? getGradientHex(item, 0) : '',
				second_color_hex: item ? getGradientHex(item, 1) : '',
				angle: item ? String(Number(item.angle || 135)) : '135',
				role: item ? String(item.role || '') : '',
				description: item ? String(item.description || '') : ''
			};
		}
		return {
			name: item ? String(item.name || '') : '',
			pattern_type: item ? String(item.pattern_type || 'dots') : 'dots',
			primary_hex: item ? getPatternColor(item, 'primary', 'accent_a') : '',
			background_hex: item ? getPatternColor(item, 'background', 'base') : '',
			intensity: item ? String(Number(item.settings && item.settings.intensity || 60)) : '60',
			role: item ? String(item.role || '') : '',
			description: item ? String(item.description || '') : ''
		};
	}

	function openFormModal(entityType, itemId) {
		var item = itemId ? getItemById(entityType, itemId) : null;
		state.modal = {
			kind: 'form',
			entityType: entityType,
			itemId: itemId || '',
			mode: item ? 'edit' : 'create',
			draft: createDraft(entityType, item),
			errors: {},
			loading: false
		};
		state.message = null;
		render();
	}

	function openDeleteModal(entityType, itemId, trigger) {
		var item = getItemById(entityType, itemId);
		if (!item) {
			return;
		}

		state.message = null;

		if (typeof window.openManagerDestructiveModal !== 'function') {
			return;
		}

		window.openManagerDestructiveModal({
			entityType: entityType,
			entityName: String(item.name || ''),
			title: replaceNamePlaceholder(t(getEntityDeleteTitleKey(entityType)), String(item.name || '')),
			subtitle: getDestructiveModalSubtitleText(),
			bodyText: replaceNamePlaceholder(t(getEntityDeleteBodyKey(entityType)), String(item.name || '')),
			warningText: '',
			confirmLabel: t('manager.pages.actions.delete'),
			cancelLabel: t('manager.pages.actions.cancel'),
			closeLabel: t('manager.pages.modal.close'),
			loadingLabel: t('manager.pages.modal.deleting'),
			errorFallbackText: t('manager.design.colors.save_failed'),
			trigger: trigger || document.activeElement,
			onConfirm: function () {
				return request('DELETE', buildRequestUrl(entityType, itemId)).then(function (response) {
					applyResponse(response);
					render();
				});
			}
		});
	}

	function closeModal() {
		state.modal = null;
		render();
	}

	function buildField(labelText, control, errorText, helperText, wide) {
		var field = createNode('label', 'sonyra-manager-pages-field' + (wide ? ' sonyra-manager-pages-field-wide' : ''));
		field.appendChild(createNode('span', '', labelText));
		field.appendChild(control);
		if (helperText) {
			field.appendChild(createNode('small', 'sonyra-color-controller__field-helper', helperText));
		}
		if (errorText) {
			field.appendChild(createNode('small', 'sonyra-color-controller__field-error', errorText));
		}
		return field;
	}

	function buildInput(key, type, value, readOnly) {
		var input = document.createElement(type === 'textarea' ? 'textarea' : 'input');
		if (type !== 'textarea') {
			input.type = type;
		}
		input.value = value || '';
		if (readOnly) {
			input.readOnly = true;
		}
		input.setAttribute('data-color-modal-field', key);
		return input;
	}

	function buildSelect(key, value, options) {
		var select = document.createElement('select');
		select.setAttribute('data-color-modal-field', key);
		options.forEach(function (item) {
			var option = document.createElement('option');
			option.value = item.value;
			option.textContent = item.label;
			select.appendChild(option);
		});
		select.value = value || options[0].value;
		return select;
	}

	function buildModalBody() {
		var modal = state.modal;
		var body = createNode('div', 'sonyra-color-controller__modal-fields');
		var draft = modal.draft;
		var errors = modal.errors || {};

		body.appendChild(buildField(
			t('manager.design.colors.field_name'),
			buildInput('name', 'text', draft.name || ''),
			errors.name
		));

		if (modal.entityType === 'color') {
			body.appendChild(buildField(
				t('manager.design.colors.field_hex'),
				buildInput('value_hex', 'text', draft.value_hex || ''),
				errors.value_hex,
				t('manager.design.colors.field_hex_hint')
			));
			body.appendChild(buildField(
				t('manager.design.colors.field_rgb'),
				buildInput('value_rgb', 'text', rgbFromHex(draft.value_hex || ''), true),
				'',
				t('manager.design.colors.field_rgb_hint')
			));
		}

		if (modal.entityType === 'gradient') {
			body.appendChild(buildField(
				t('manager.design.colors.field_first_color'),
				buildInput('first_color_hex', 'text', draft.first_color_hex || ''),
				errors.stops || errors.first_color_hex,
				t('manager.design.colors.field_hex_hint')
			));
			body.appendChild(buildField(
				t('manager.design.colors.field_second_color'),
				buildInput('second_color_hex', 'text', draft.second_color_hex || ''),
				errors.stops || errors.second_color_hex,
				t('manager.design.colors.field_hex_hint')
			));
			body.appendChild(buildField(
				t('manager.design.colors.field_angle'),
				buildInput('angle', 'number', draft.angle || '135', false),
				errors.angle
			));
		}

		if (modal.entityType === 'pattern') {
			body.appendChild(buildField(
				t('manager.design.colors.field_pattern_type'),
				buildSelect('pattern_type', draft.pattern_type || 'dots', [
					{ value: 'dots', label: getPatternTypeLabel('dots') },
					{ value: 'grid', label: getPatternTypeLabel('grid') },
					{ value: 'diagonal_lines', label: getPatternTypeLabel('diagonal_lines') },
					{ value: 'soft_glow', label: getPatternTypeLabel('soft_glow') },
					{ value: 'soft_blobs', label: getPatternTypeLabel('soft_blobs') },
					{ value: 'diagonal_wave', label: getPatternTypeLabel('diagonal_wave') },
					{ value: 'accent_orbit', label: getPatternTypeLabel('accent_orbit') },
					{ value: 'deep_background', label: getPatternTypeLabel('deep_background') },
					{ value: 'color_splash', label: getPatternTypeLabel('color_splash') },
					{ value: 'subtle_grid', label: getPatternTypeLabel('subtle_grid') },
					{ value: 'radial_aura', label: getPatternTypeLabel('radial_aura') }
				]),
				errors.pattern_type
			));
			body.appendChild(buildField(
				t('manager.design.colors.field_primary_color'),
				buildInput('primary_hex', 'text', draft.primary_hex || ''),
				errors.colors || errors.primary_hex,
				t('manager.design.colors.field_hex_hint')
			));
			body.appendChild(buildField(
				t('manager.design.colors.field_background_color'),
				buildInput('background_hex', 'text', draft.background_hex || ''),
				errors.colors || errors.background_hex,
				t('manager.design.colors.field_hex_hint')
			));
			body.appendChild(buildField(
				t('manager.design.colors.field_intensity'),
				buildInput('intensity', 'number', draft.intensity || '60', false),
				errors.intensity
			));
		}

		body.appendChild(buildField(
			t('manager.design.colors.field_role'),
			buildInput('role', 'text', draft.role || ''),
			errors.role,
			t('manager.design.colors.field_role_hint')
		));

		body.appendChild(buildField(
			t('manager.design.colors.field_description'),
			buildInput('description', 'textarea', draft.description || ''),
			errors.description,
			t('manager.design.colors.field_description_hint'),
			true
		));

		return body;
	}

	function renderModal() {
		if (!state.modal) {
			if (!(window.isManagerDestructiveModalOpen && window.isManagerDestructiveModalOpen())) {
				document.body.classList.remove('sonyra-manager-modal-open');
			}
			return null;
		}

		document.body.classList.add('sonyra-manager-modal-open');

		var chrome = getManagerUi().renderStandardModal({
			iconKey: 'settings',
			closeIconKey: 'x',
			titleId: 'sonyra-color-modal-title',
			panelAttributes: {
				role: 'dialog',
				'aria-modal': 'true'
			},
			closeAttributes: {
				'data-color-close-modal': 'true',
				'aria-label': t('manager.pages.modal.close')
			}
		});
		var overlay = chrome.overlay;
		var title = chrome.title;
		var description = chrome.description;
		var body = chrome.body;
		var footer = chrome.footer;

		overlay.setAttribute('data-color-modal-overlay', 'true');

		if (state.modal.kind === 'form') {
			title.textContent = state.modal.mode === 'edit' ? t(getEntityEditKey(state.modal.entityType)) : t(getEntityCreateKey(state.modal.entityType));
			description.textContent = state.modal.mode === 'edit'
				? t('manager.design.colors.modal_edit_description')
				: t('manager.design.colors.modal_create_description');
			body.appendChild(buildModalBody());
			footer.appendChild(createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel')));
			footer.lastChild.setAttribute('data-color-close-modal', 'true');
			footer.appendChild(createButton('sonyra-manager-pages-primary', state.modal.loading ? t('manager.pages.actions.saving') : t('manager.pages.actions.save')));
			footer.lastChild.setAttribute('data-color-save-modal', 'true');
			if (state.modal.loading) {
				footer.lastChild.disabled = true;
			}
		}

		return overlay;
	}

	function render() {
		clearHelpPopoverScope('design');
		clearNode(app);
		app.appendChild(state.view === 'landing' ? buildLandingCard() : buildWorkspace());
		var modal = renderModal();
		if (modal) {
			app.appendChild(modal);
		}
		renderGlobalHelpPopover();
	}

	function getGlobalHelpLayer() {
		return document.querySelector('[data-manager-help-layer]');
	}

	function clearHelpPopoverScope(scope) {
		var layer = getGlobalHelpLayer();
		var selector;

		if (!layer) {
			return;
		}

		selector = scope ? ('[data-sonyra-help-scope="' + scope + '"]') : '[data-sonyra-help-scope]';
		Array.prototype.slice.call(layer.querySelectorAll(selector)).forEach(function (node) {
			if (node && node.parentNode) {
				node.parentNode.removeChild(node);
			}
		});
	}

	function renderGlobalHelpPopover() {
		var layer = getGlobalHelpLayer();
		var trigger;
		var triggerRect;
		var popover;
		var help = helpMap[state.helpKey] || null;
		var preferredWidth = 360;
		var gap = 10;
		var viewportPadding = 14;
		var viewportWidth = window.innerWidth || 0;
		var viewportHeight = window.innerHeight || 0;
		var left = 0;
		var top = 0;
		var placement = 'right';
		var clampedWidth;
		var popoverHeight;

		if (!state.helpOpen || !layer || !help) {
			return;
		}

		trigger = root.querySelector('[data-sonyra-help-key="' + String(state.helpKey || 'design.colors.controller') + '"]');

		if (!trigger) {
			return;
		}

		popover = createNode('article', 'sonyra-help-popover sonyra-color-controller__help-popover');
		popover.setAttribute('data-sonyra-help-scope', 'design');
		popover.setAttribute('data-color-help-popover', 'true');
		popover.setAttribute('role', 'tooltip');
		popover.appendChild(createNode('strong', 'sonyra-help-popover__title sonyra-color-controller__help-title', help.title || ''));
		popover.appendChild(createNode('p', 'sonyra-help-popover__body sonyra-color-controller__help-body', help.body || ''));
		layer.appendChild(popover);

		triggerRect = trigger.getBoundingClientRect();
		clampedWidth = Math.min(preferredWidth, Math.max(220, viewportWidth - (viewportPadding * 2)));
		popover.style.maxWidth = String(clampedWidth) + 'px';

		if (triggerRect.right + gap + clampedWidth <= viewportWidth - viewportPadding) {
			left = triggerRect.right + gap;
			placement = 'right';
		} else if (triggerRect.left - gap - clampedWidth >= viewportPadding) {
			left = triggerRect.left - gap - clampedWidth;
			placement = 'left';
		} else {
			left = Math.max(viewportPadding, Math.min(triggerRect.left, viewportWidth - clampedWidth - viewportPadding));
			placement = 'bottom';
		}

		popoverHeight = Math.ceil(popover.getBoundingClientRect().height || popover.offsetHeight || 0);

		if (placement === 'right' || placement === 'left') {
			if (triggerRect.top < viewportHeight * 0.45 && triggerRect.bottom + gap + popoverHeight <= viewportHeight - viewportPadding) {
				top = triggerRect.bottom + gap;
			} else if (triggerRect.top - gap - popoverHeight >= viewportPadding) {
				top = triggerRect.top - popoverHeight - gap;
			} else {
				top = Math.max(viewportPadding, Math.min(triggerRect.top, viewportHeight - popoverHeight - viewportPadding));
			}
		} else {
			if (triggerRect.bottom + gap + popoverHeight <= viewportHeight - viewportPadding) {
				top = triggerRect.bottom + gap;
				placement = 'bottom';
			} else {
				top = triggerRect.top - popoverHeight - gap;
				placement = 'top';
			}

			top = Math.max(viewportPadding, Math.min(top, viewportHeight - popoverHeight - viewportPadding));
		}

		left = Math.max(viewportPadding, Math.min(left, viewportWidth - clampedWidth - viewportPadding));
		popover.style.left = String(left) + 'px';
		popover.style.top = String(top) + 'px';
		popover.setAttribute('data-popover-placement', placement);
	}

	function updateDraftField(field, value) {
		if (!state.modal || state.modal.kind !== 'form') {
			return;
		}
		state.modal.draft[field] = value;
		if (state.modal.errors && state.modal.errors[field]) {
			delete state.modal.errors[field];
		}
		if (field === 'value_hex' && state.modal.errors && state.modal.errors.value_hex) {
			delete state.modal.errors.value_hex;
		}
	}

	function buildRequestUrl(entityType, itemId) {
		var base = state.apiUrl.replace(/\/$/, '');
		var path = '/' + getCollectionKey(entityType);
		if (itemId) {
			path += '/' + encodeURIComponent(itemId);
		}
		return base + path;
	}

	function request(method, url, body) {
		return fetch(url, {
			method: method,
			headers: {
				'Content-Type': 'application/json',
				'X-Sonyra-Color-Controller-Nonce': state.nonce
			},
			body: body ? JSON.stringify(body) : undefined,
			credentials: 'same-origin'
		}).then(function (response) {
			return response.json().catch(function () {
				return {};
			}).then(function (json) {
				if (!response.ok) {
					var error = new Error(json.message || t('manager.design.colors.save_failed'));
					error.payload = json;
					throw error;
				}
				return json;
			});
		});
	}

	function submitModal() {
		if (!state.modal || state.modal.kind !== 'form' || state.modal.loading) {
			return;
		}

		var modal = state.modal;
		modal.loading = true;
		render();

		request(
			modal.mode === 'edit' ? 'PUT' : 'POST',
			buildRequestUrl(modal.entityType, modal.mode === 'edit' ? modal.itemId : ''),
			{ item: modal.draft }
		).then(function (response) {
			applyResponse(response);
			state.modal = null;
			render();
		}).catch(function (error) {
			var payloadData = error && error.payload && error.payload.data ? error.payload.data : {};
			modal.loading = false;
			modal.errors = payloadData.errors && typeof payloadData.errors === 'object' ? payloadData.errors : {};
			state.message = {
				type: 'error',
				text: error.message || t('manager.design.colors.save_failed')
			};
			render();
		});
	}

	root.addEventListener('click', function (event) {
		var openLibrary = event.target.closest('[data-color-open-library]');
		var back = event.target.closest('[data-color-back]');
		var tab = event.target.closest('[data-color-tab]');
		var create = event.target.closest('[data-color-create]');
		var edit = event.target.closest('[data-color-edit]');
		var remove = event.target.closest('[data-color-delete]');
		var close = event.target.closest('[data-color-close-modal]');
		var save = event.target.closest('[data-color-save-modal]');
		var dismiss = event.target.closest('[data-color-dismiss-message]');
		var helpToggle = event.target.closest('[data-color-help-toggle]');
		var overlay = event.target.closest('[data-color-modal-overlay]');

		if (openLibrary) {
			state.view = 'library';
			state.helpOpen = false;
			render();
			return;
		}

		if (back) {
			state.view = 'landing';
			state.helpOpen = false;
			state.message = null;
			render();
			return;
		}

		if (tab) {
			state.activeTab = tab.getAttribute('data-color-tab') || 'colors';
			state.helpOpen = false;
			state.message = null;
			render();
			return;
		}

		if (create) {
			openFormModal(create.getAttribute('data-color-create') || getCurrentEntityType());
			return;
		}

		if (edit) {
			openFormModal(edit.getAttribute('data-color-entity') || getCurrentEntityType(), edit.getAttribute('data-color-edit') || '');
			return;
		}

		if (remove) {
			openDeleteModal(remove.getAttribute('data-color-entity') || getCurrentEntityType(), remove.getAttribute('data-color-delete') || '', remove);
			return;
		}

		if (close) {
			closeModal();
			return;
		}

		if (save) {
			submitModal();
			return;
		}

		if (dismiss) {
			state.message = null;
			render();
			return;
		}

		if (helpToggle) {
			state.helpOpen = !state.helpOpen;
			render();
			return;
		}

		if (overlay && event.target === overlay) {
			closeModal();
		}
	});

	getManagerUi().bindHelpTooltipLayer(root, {
		triggerSelector: '[data-color-help-toggle]',
		popoverSelector: '[data-color-help-popover]',
		onOpen: function () {
			if (!state.helpOpen) {
				state.helpOpen = true;
				render();
			}
		},
		onClose: function () {
			if (state.helpOpen) {
				state.helpOpen = false;
				render();
			}
		}
	});

	root.addEventListener('input', function (event) {
		var field = event.target.closest('[data-color-modal-field]');
		var rgbField;
		if (!field) {
			return;
		}
		updateDraftField(field.getAttribute('data-color-modal-field') || '', field.value);
		if ((field.getAttribute('data-color-modal-field') || '') === 'value_hex') {
			rgbField = root.querySelector('[data-color-modal-field="value_rgb"]');
			if (rgbField) {
				rgbField.value = rgbFromHex(field.value || '');
			}
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			if (state.modal) {
				closeModal();
			} else if (state.helpOpen) {
				state.helpOpen = false;
				render();
			}
		}
	});

	document.addEventListener('click', function (event) {
		if (!root.contains(event.target) && !event.target.closest('[data-color-help-popover]') && state.helpOpen) {
			state.helpOpen = false;
			render();
		}
	});

	window.addEventListener('resize', function () {
		if (state.helpOpen) {
			render();
		}
	});

	window.SonyraColorController = {
		init: function () {
			render();
		},
		handleRouteChange: function (route) {
			state.routeActive = route === 'design';
			if (!state.routeActive) {
				state.helpOpen = false;
				state.modal = null;
			}
			render();
		}
	};
}());
