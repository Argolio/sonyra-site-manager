<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_REST_Color_Controller {

	const REST_NAMESPACE = 'sonyra-site-manager/v1';

	public static function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/design/colors',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_data' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_design' ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/design/colors/(?P<entity_type>colors|gradients|patterns)',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'create_item' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_design_with_nonce' ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/design/colors/(?P<entity_type>colors|gradients|patterns)/(?P<item_id>[a-z0-9_-]+)',
			array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( __CLASS__, 'update_item' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_design_with_nonce' ),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'delete_item' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_design_with_nonce' ),
				),
			)
		);
	}

	public static function permission_manage_design( WP_REST_Request $request ) {
		unset( $request );

		$context = self::get_auth_context();

		if ( empty( $context['authenticated'] ) || ! class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) || ! Sonyra_Site_Manager_Auth_Access_Guard::can_manage_settings( $context ) ) {
			return new WP_Error( 'sonyra_color_controller_forbidden', self::text( 'manager.design.colors.forbidden' ), array( 'status' => 403 ) );
		}

		return true;
	}

	public static function permission_manage_design_with_nonce( WP_REST_Request $request ) {
		$permission = self::permission_manage_design( $request );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$context = self::get_auth_context();
		$nonce   = (string) $request->get_header( 'x-sonyra-color-controller-nonce' );

		if ( ! class_exists( 'Sonyra_Site_Manager_Color_Controller' ) || ! Sonyra_Site_Manager_Color_Controller::verify_nonce( $nonce, $context ) ) {
			return new WP_Error( 'sonyra_color_controller_invalid_nonce', self::text( 'manager.design.colors.invalid_nonce' ), array( 'status' => 403 ) );
		}

		return true;
	}

	public static function get_data( WP_REST_Request $request ) {
		unset( $request );

		return rest_ensure_response( self::build_response() );
	}

	public static function create_item( WP_REST_Request $request ) {
		$entity_type = self::normalize_entity_type( (string) $request->get_param( 'entity_type' ) );
		$payload     = $request->get_json_params();
		$item_data   = isset( $payload['item'] ) && is_array( $payload['item'] ) ? $payload['item'] : array();
		$saved       = Sonyra_Site_Manager_Color_Controller::create_item( $entity_type, $item_data );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		self::log_event( 'design.colors.' . $entity_type . '.created', $saved['item'] );

		return rest_ensure_response(
			self::build_response(
				self::text( 'manager.design.colors.' . $entity_type . '_created_notice' ),
				$saved['item'],
				$saved['data'],
				$saved['summary']
			)
		);
	}

	public static function update_item( WP_REST_Request $request ) {
		$entity_type = self::normalize_entity_type( (string) $request->get_param( 'entity_type' ) );
		$item_id     = (string) $request->get_param( 'item_id' );
		$payload     = $request->get_json_params();
		$item_data   = isset( $payload['item'] ) && is_array( $payload['item'] ) ? $payload['item'] : array();
		$saved       = Sonyra_Site_Manager_Color_Controller::update_item( $entity_type, $item_id, $item_data );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		self::log_event( 'design.colors.' . $entity_type . '.updated', $saved['item'] );

		return rest_ensure_response(
			self::build_response(
				self::text( 'manager.design.colors.' . $entity_type . '_updated_notice' ),
				$saved['item'],
				$saved['data'],
				$saved['summary']
			)
		);
	}

	public static function delete_item( WP_REST_Request $request ) {
		$entity_type = self::normalize_entity_type( (string) $request->get_param( 'entity_type' ) );
		$item_id     = (string) $request->get_param( 'item_id' );
		$deleted     = Sonyra_Site_Manager_Color_Controller::delete_item( $entity_type, $item_id );

		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}

		self::log_event( 'design.colors.' . $entity_type . '.deleted', $deleted['item'] );

		return rest_ensure_response(
			self::build_response(
				self::text( 'manager.design.colors.' . $entity_type . '_deleted_notice' ),
				$deleted['item'],
				$deleted['data'],
				$deleted['summary']
			)
		);
	}

	private static function build_response( string $message = '', array $item = array(), array $data = array(), array $summary = array() ): array {
		if ( empty( $data ) ) {
			$data = class_exists( 'Sonyra_Site_Manager_Color_Controller' ) ? Sonyra_Site_Manager_Color_Controller::get_data() : array();
		}

		if ( empty( $summary ) ) {
			$summary = class_exists( 'Sonyra_Site_Manager_Color_Controller' ) ? Sonyra_Site_Manager_Color_Controller::get_summary( $data ) : array();
		}

		return array(
			'success' => true,
			'message' => $message,
			'item'    => $item,
			'summary' => $summary,
			'data'    => $data,
		);
	}

	private static function normalize_entity_type( string $entity_type ): string {
		$entity_type = strtolower( trim( $entity_type ) );

		if ( 'colors' === $entity_type ) {
			return 'color';
		}

		if ( 'gradients' === $entity_type ) {
			return 'gradient';
		}

		if ( 'patterns' === $entity_type ) {
			return 'pattern';
		}

		return $entity_type;
	}

	private static function log_event( string $event_key, array $item ): void {
		if ( ! class_exists( 'Sonyra_Site_Manager_Audit_Log' ) ) {
			return;
		}

		Sonyra_Site_Manager_Audit_Log::log_event(
			$event_key,
			array(
				'id'   => isset( $item['id'] ) ? (string) $item['id'] : '',
				'role' => isset( $item['role'] ) ? (string) $item['role'] : '',
				'type' => isset( $item['type'] ) ? (string) $item['type'] : '',
			),
			'info'
		);
	}

	private static function get_auth_context(): array {
		if ( ! class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			return array();
		}

		return Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();
	}

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}
}

if ( function_exists( 'add_action' ) ) {
	add_action( 'rest_api_init', array( 'Sonyra_Site_Manager_REST_Color_Controller', 'register_routes' ) );
}
