# SONYRA Manager Component Inventory

## Назначение

- это официальный каталог разрешённых UI-компонентов ПУЛЬТА САЙТА;
- перед любым UI-патчем Codex обязан прочитать этот документ и `docs/SONYRA_MANAGER_SECTION_UX_STANDARD.md`;
- если нужный компонент не найден в inventory, Codex не имеет права придумывать похожий локальный компонент;
- раздел `Страницы` является master reference для component anatomy, DOM, classes, helpers и placement.

## STANDARD-FIRST / NO IMITATION

- разрешено только переиспользование существующего shared helper, DOM, classes и selectors;
- запрещены `похоже`, `аналогично`, `в том же стиле`, `почти такое же`, локальные копии и альтернативная разметка;
- если shared helper отсутствует, сначала выносится эталонный компонент, потом к нему подключаются target usages;
- любой новый UI-компонент разрешён только после явного user approval и добавления в inventory.

## Mandatory Process

1. Read UX standard.
2. Read component inventory.
3. Identify required components.
4. Map each target component to an inventory item.
5. Reuse the same helper/classes/selectors.
6. Provide Component Reuse Proof.
7. Provide Required Markup Proof.
8. STOP if any target component cannot be mapped.

## 1. Page Header

- **Source reference screen:** `Страницы`
- **Source file/helper:** `includes/class-sonyra-site-manager-manager-renderer.php`
- **Required DOM/classes:** wrapper `.sonyra-manager-page-header`; icon tile; eyebrow; title; description; actions; badges/meta row
- **Required CSS selectors:** `.sonyra-manager-page-header`, `.sonyra-manager-page-header-copy`, `.sonyra-manager-page-header-actions`
- **DOM structure:** page header wrapper → left icon zone + content zone + right actions zone → badges/meta row under text block
- **Placement:** icon tile слева, title/subtitle по центру слева-направо, actions справа, meta под description
- **Spacing:** compact shell header spacing from `Страницы`; no second hero
- **Forbidden local variants:** duplicate hero in body, custom header anatomy, custom action placement
- **Current usages:** global manager sections
- **Future usage rule:** every new section reuses the same header shell contract

## 2. Context Card

- **Source reference screen:** `Страницы → Секции`, `Виджеты страницы`, `Поп-апы страницы`
- **Source file/helper:** `assets/js/sonyra-manager.js`
- **Required DOM/classes:** context wrapper with label row, title/subline block, actions group
- **Required CSS selectors:** `.sonyra-pages-workspace-context`, `.sonyra-pages-workspace-context-copy`, `.sonyra-pages-workspace-context-actions`
- **DOM structure:** wrapper → left content column (label row + title/subline) + right action zone
- **Placement:** context label and help icon above title; actions on the right; no duplicate body title
- **Spacing:** standard card padding; gap between content and actions; margin above toolbar/list by Pages standard
- **Forbidden local variants:** custom tool hero, plain text back action, moved action cluster
- **Current usages:** sections/widgets/popups workspace and design tool context
- **Future usage rule:** all workspace modes reuse this anatomy

## 3. Panel Header

- **Source reference screen:** `Секции`, `Блоки секции`
- **Source file/helper:** `assets/js/sonyra-manager.js`
- **Required DOM/classes:** title row with heading, help icon, optional right action
- **Required CSS selectors:** `.sonyra-pages-panel-header`, `.sonyra-pages-panel-title`, `.sonyra-help-tooltip-wrap`
- **DOM structure:** panel header wrapper → left title/help zone + right action zone
- **Placement:** title left, help icon adjacent, action right
- **Forbidden local variants:** detached help icon, second heading row, random wrapper nesting

## 4. Help Icon / Tooltip

- **Source reference screen:** `Секции`, `Блоки секции`
- **Source file/helper:** `assets/js/sonyra-manager.js`, shared help layer in manager renderer
- **Required DOM/classes:** `.sonyra-help-tooltip-wrap` → `.sonyra-help-tooltip-trigger`; popover in shared help layer
- **Required CSS selectors:** `.sonyra-help-tooltip-trigger`, `.sonyra-help-popover`, `[data-manager-help-layer]`
- **DOM structure:** trigger wrapper only in local component; tooltip body rendered into shared layer
- **Placement:** help icon lives in label/title row; tooltip floats above cards/toolbars
- **Forbidden local variants:** custom help button, inline paragraph instead of tooltip, local tooltip layer
- **Acceptance fields:** shared helper/classes are not enough; visual match required; functional match required; valid help key required; event binding required; global help layer required; hover/focus/click test required; tooltip must appear above panels; no visual-only imitation allowed

## 5. Back Button

- **Source reference screen:** `К списку страниц`
- **Source file/helper:** `assets/js/sonyra-manager.js#createButton`
- **Required DOM/classes:** button `.sonyra-manager-pages-secondary` with left arrow icon
- **Required CSS selectors:** `.sonyra-manager-pages-secondary`
- **DOM structure:** one button → icon span left + text span right
- **Placement:** left side of context card actions
- **Forbidden local variants:** text-only back action, moved icon, custom padding

## 6. Primary Button

- **Source reference screen:** `Страницы`, shared modals
- **Source file/helper:** `assets/js/sonyra-manager.js#createButton`
- **Required DOM/classes:** `.sonyra-manager-pages-primary`
- **Required CSS selectors:** `.sonyra-manager-pages-primary`
- **Placement:** right-side primary action or footer action
- **Forbidden local variants:** custom per-section primary button style

## 7. Secondary Button

- **Source reference screen:** `Страницы`, shared modals
- **Source file/helper:** `assets/js/sonyra-manager.js#createButton`
- **Required DOM/classes:** `.sonyra-manager-pages-secondary`
- **Required CSS selectors:** `.sonyra-manager-pages-secondary`
- **Placement:** secondary/back/cancel action before primary/danger action
- **Forbidden local variants:** custom neutral button markup

## 8. Danger Button

- **Source reference screen:** delete modal in `Страницы`
- **Source file/helper:** `window.openManagerDestructiveModal`
- **Required DOM/classes:** `.sonyra-manager-pages-primary.sonyra-manager-pages-primary-danger`
- **Required CSS selectors:** `.sonyra-manager-pages-primary-danger`
- **Placement:** rightmost footer button in destructive modal
- **Forbidden local variants:** local danger button class, local color delete button style, swapped footer order

## 9. Toolbar / Tabs / Filter Chips

- **Source reference screen:** pages toolbar/filter group
- **Source file/helper:** `assets/js/sonyra-manager.js`
- **Required DOM/classes:** toolbar panel, search/filter/sort row, chips/tabs row
- **Required CSS selectors:** `.sonyra-pages-toolbar-panel`, `.sonyra-pages-filter-chip`
- **Placement:** toolbar below context card; chips stay inside padded toolbar
- **Forbidden local variants:** loose text counters, detached tabs, custom toolbar shell

## 10. Meta Chips / Counters

- **Source reference screen:** pages header badges, design tool counters
- **Source file/helper:** `assets/js/sonyra-manager.js`
- **Required DOM/classes:** compact chip row using existing badge/chip selectors
- **Placement:** under header copy or inside toolbar meta zone
- **Forbidden local variants:** plain text meta line, fake metrics

## 11. Cards

- **Source reference screen:** section/block/widget/popup cards
- **Source file/helper:** `assets/js/sonyra-manager.js`, `assets/js/sonyra-color-controller.js`
- **Required DOM/classes:** card wrapper; drag/action zone; icon tile; content; meta; actions
- **Required CSS selectors:** `.sonyra-pages-card`, `.sonyra-pages-card-actions`
- **Placement:** icon/content center-left, actions right
- **Forbidden local variants:** floating icon tile, action buttons inside title row if reference card does not do this

## 12. SVG Icon Tile

- **Source reference screen:** accepted icon tiles in `Страницы`, destructive modal danger tile
- **Source file/helper:** `clonePagesIcon()`, shared modal helper
- **Required CSS selectors:** `.sonyra-manager-pages-modal-icon`
- **Placement:** icon tile always in left header zone for destructive modal
- **Spacing/sizes:** 56px destructive tile; 28px icon inside; same border/background/radius everywhere
- **Forbidden local variants:** local SVG tile size, local border radius, swapped placement

## 13. Notice / Status Banner

- **Source reference screen:** pages notices and global notice center
- **Source file/helper:** `assets/js/sonyra-manager.js`
- **Required DOM/classes:** notice center, icon, copy, dismiss
- **Placement:** above content list/workspace
- **Forbidden local variants:** decorative badge as notice replacement

## 14. Empty State

- **Source reference screen:** pages empty states
- **Source file/helper:** `assets/js/sonyra-manager.js#createWorkspaceEmptyState`
- **Required DOM/classes:** empty state wrapper + title + description + real action
- **Placement:** inside workspace body
- **Forbidden local variants:** fake CTA, separate pseudo-card component

## 15. Standard Modal

- **Source reference screen:** page settings/add/history modal
- **Source file/helper:** `assets/js/sonyra-manager.js#renderPageModal`
- **Required DOM/classes:** overlay, modal, header, icon tile, copy, close, body, footer
- **Required CSS selectors:** `.sonyra-manager-modal-overlay`, `.sonyra-manager-modal`, `.sonyra-manager-modal__header`, `.sonyra-manager-modal__body`, `.sonyra-manager-modal__footer`
- **Placement:** icon left, copy center-left, close top-right, footer actions right
- **Forbidden local variants:** custom modal shell per section

## 16. Destructive Modal

- **Source reference screen:** delete section/block in `Страницы`
- **Source file/helper:** `assets/js/sonyra-manager.js#openManagerDestructiveModal`
- **Required DOM/classes:** overlay `.sonyra-manager-pages-modal-overlay.sonyra-manager-modal-overlay` → modal `.sonyra-manager-pages-modal.sonyra-manager-modal.sonyra-manager-modal--destructive` → header/body/footer
- **Required CSS selectors:** `.sonyra-manager-pages-modal-icon`, `.sonyra-manager-pages-modal-title`, `.sonyra-manager-pages-modal-danger-text`, `.sonyra-manager-modal__danger-note`, `.sonyra-manager-pages-primary-danger`
- **Required DOM structure:** overlay → modal container → header → icon tile left → title/subtitle column → close button right → body → optional warning slot → footer → cancel button → danger confirm button
- **Placement:** icon tile always left; title/subtitle always middle column; close always top-right; warning slot below body copy; cancel left of danger confirm in footer
- **Spacing/sizes:** header `22px 24px 16px`; body `22px 24px`; footer `16px 24px 22px`; icon-title gap `14px`; footer gap `10px`; icon tile `56px`; destructive icon `28px`
- **Allowed config variables:** `entityType`, `entityName`, `title`, `subtitle`, `bodyText`, `warningText`, `confirmLabel`, `cancelLabel`, `closeLabel`, `loadingLabel`, `onConfirm`
- **Forbidden local variants:** local destructive modal markup, custom danger tile, custom footer order, extra wrappers, moved action zone
- **Current usages:** section delete, block delete, page delete, widget delete, popup delete, color delete, gradient delete, pattern delete
- **Future usage rule:** every delete action must call `openManagerDestructiveModal()` and pass config only
- **Acceptance fields:** shared helper is not enough; typography must match reference; `font-family` token required; title, subtitle, body and buttons must inherit manager font; no browser fallback allowed; behavior must match reference; visual regression check is required after moving modal to a global root

## 17. Footer

- **Source reference screen:** manager shell footer
- **Source file/helper:** manager renderer
- **Required DOM/classes:** footer wrapper + product/version/legal items
- **Placement:** global shell footer below content
- **Forbidden local variants:** local per-section footer spacers or alternate footer blocks

## Required Markup Proof

For every UI patch Codex must provide:

`Component | Reference DOM from “Страницы” | Shared helper/selector | Target DOM | Placement match | Spacing match | Deviations`

For destructive modal the proof is mandatory for:

- section delete
- block delete
- color delete
- gradient delete
- pattern delete
- page delete
- widget delete
- popup delete

If placement or markup differs from the reference component, the patch fails and archive must not be built.
