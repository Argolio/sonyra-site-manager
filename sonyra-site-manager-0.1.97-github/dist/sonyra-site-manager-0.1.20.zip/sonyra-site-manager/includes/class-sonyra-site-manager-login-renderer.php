<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Login_Renderer {

	public static function get_placeholder_title(): string {
		return 'Вход в Пульт сайта';
	}

	public static function get_placeholder_message(): string {
		return 'Экран входа будет подключён следующим этапом.';
	}

	public static function get_placeholder_note(): string {
		return 'Вход будет работать по электронной почте или логину без пароля.';
	}

	public static function render_placeholder(): void {
		$title = self::get_placeholder_title();
		$message = self::get_placeholder_message();
		$note = self::get_placeholder_note();
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?></title>
</head>
<body>
	<main>
		<h1><?php echo esc_html( $title ); ?></h1>
		<p><?php echo esc_html( $message ); ?></p>
		<p><?php echo esc_html( $note ); ?></p>
		<small>SONYRA STUDIO</small>
	</main>
</body>
</html>
		<?php
	}
}
