<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Page_Elements_Library {

	public static function get_core_section_definitions(): array {
		return array(
			self::build_definition( 'hero', 'manager.pages.library.sections.hero.label', 'manager.pages.library.sections.hero.description', 'sparkles', 'content', 'hero', 'manager.pages.defaults.hero.block_name' ),
			self::build_definition( 'text', 'manager.pages.library.sections.text.label', 'manager.pages.library.sections.text.description', 'file-text', 'content', 'text', 'manager.pages.defaults.text.block_name' ),
			self::build_definition( 'media_text', 'manager.pages.library.sections.media_text.label', 'manager.pages.library.sections.media_text.description', 'photo', 'content' ),
			self::build_definition( 'benefits', 'manager.pages.library.sections.benefits.label', 'manager.pages.library.sections.benefits.description', 'layers-selected', 'marketing' ),
			self::build_definition( 'services', 'manager.pages.library.sections.services.label', 'manager.pages.library.sections.services.description', 'components', 'marketing' ),
			self::build_definition( 'cards', 'manager.pages.library.sections.cards.label', 'manager.pages.library.sections.cards.description', 'grid-dots', 'content' ),
			self::build_definition( 'metrics', 'manager.pages.library.sections.metrics.label', 'manager.pages.library.sections.metrics.description', 'chart-bar', 'marketing' ),
			self::build_definition( 'steps', 'manager.pages.library.sections.steps.label', 'manager.pages.library.sections.steps.description', 'list-check', 'content' ),
			self::build_definition( 'pricing', 'manager.pages.library.sections.pricing.label', 'manager.pages.library.sections.pricing.description', 'receipt', 'marketing' ),
			self::build_definition( 'cases', 'manager.pages.library.sections.cases.label', 'manager.pages.library.sections.cases.description', 'briefcase', 'portfolio' ),
			self::build_definition( 'reviews', 'manager.pages.library.sections.reviews.label', 'manager.pages.library.sections.reviews.description', 'message-circle', 'trust' ),
			self::build_definition( 'team', 'manager.pages.library.sections.team.label', 'manager.pages.library.sections.team.description', 'users', 'trust' ),
			self::build_definition( 'partners', 'manager.pages.library.sections.partners.label', 'manager.pages.library.sections.partners.description', 'building', 'trust' ),
			self::build_definition( 'gallery', 'manager.pages.library.sections.gallery.label', 'manager.pages.library.sections.gallery.description', 'photo', 'media' ),
			self::build_definition( 'video', 'manager.pages.library.sections.video.label', 'manager.pages.library.sections.video.description', 'video', 'media' ),
			self::build_definition( 'faq', 'manager.pages.library.sections.faq.label', 'manager.pages.library.sections.faq.description', 'help-circle', 'content' ),
			self::build_definition( 'contacts', 'manager.pages.library.sections.contacts.label', 'manager.pages.library.sections.contacts.description', 'address-book', 'contact', 'contacts', 'manager.pages.defaults.contacts.block_name' ),
			self::build_definition( 'map', 'manager.pages.library.sections.map.label', 'manager.pages.library.sections.map.description', 'map-pin', 'contact' ),
			self::build_definition( 'form', 'manager.pages.library.sections.form.label', 'manager.pages.library.sections.form.description', 'forms', 'contact' ),
			self::build_definition( 'cta', 'manager.pages.library.sections.cta.label', 'manager.pages.library.sections.cta.description', 'target-arrow', 'marketing' ),
			self::build_definition( 'documents_links', 'manager.pages.library.sections.documents_links.label', 'manager.pages.library.sections.documents_links.description', 'file-text', 'content' ),
			self::build_definition( 'divider', 'manager.pages.library.sections.divider.label', 'manager.pages.library.sections.divider.description', 'minus', 'layout' ),
			self::build_definition( 'banner', 'manager.pages.library.sections.banner.label', 'manager.pages.library.sections.banner.description', 'speakerphone', 'marketing' ),
			self::build_definition( 'comparison', 'manager.pages.library.sections.comparison.label', 'manager.pages.library.sections.comparison.description', 'columns', 'content' ),
			self::build_definition( 'schedule', 'manager.pages.library.sections.schedule.label', 'manager.pages.library.sections.schedule.description', 'calendar', 'content' ),
			self::build_definition( 'showcase', 'manager.pages.library.sections.showcase.label', 'manager.pages.library.sections.showcase.description', 'layout-dashboard', 'marketing' ),
			self::build_definition( 'social_links', 'manager.pages.library.sections.social_links.label', 'manager.pages.library.sections.social_links.description', 'world-share', 'contact' ),
			self::build_definition( 'embed', 'manager.pages.library.sections.embed.label', 'manager.pages.library.sections.embed.description', 'code', 'advanced' ),
		);
	}

	public static function get_section_definitions(): array {
		$definitions = self::get_core_section_definitions();

		if ( function_exists( 'apply_filters' ) ) {
			$definitions = apply_filters( 'sonyra_site_manager_section_definitions', $definitions );
		}

		if ( ! is_array( $definitions ) ) {
			$definitions = array();
		}

		$normalized = array();

		foreach ( $definitions as $definition ) {
			if ( ! is_array( $definition ) ) {
				continue;
			}

			$next_definition = self::normalize_section_definition( $definition );

			if ( empty( $next_definition['type'] ) ) {
				continue;
			}

			$normalized[ $next_definition['type'] ] = $next_definition;
		}

		return array_values( $normalized );
	}

	public static function normalize_section_definition( array $definition ): array {
		$type          = isset( $definition['type'] ) ? sanitize_key( (string) $definition['type'] ) : '';
		$label         = isset( $definition['label'] ) ? sanitize_text_field( (string) $definition['label'] ) : '';
		$description   = isset( $definition['description'] ) ? sanitize_textarea_field( (string) $definition['description'] ) : '';
		$icon_key      = isset( $definition['icon_key'] ) ? sanitize_key( (string) $definition['icon_key'] ) : '';
		$category      = isset( $definition['category'] ) ? sanitize_key( (string) $definition['category'] ) : '';
		$provider      = isset( $definition['provider'] ) ? sanitize_key( (string) $definition['provider'] ) : 'core';
		$module_key    = isset( $definition['module_key'] ) ? sanitize_key( (string) $definition['module_key'] ) : '';
		$status        = isset( $definition['status'] ) ? sanitize_key( (string) $definition['status'] ) : 'implemented';
		$default_block = isset( $definition['default_block_type'] ) ? sanitize_key( (string) $definition['default_block_type'] ) : 'text';
		$default_name  = isset( $definition['default_block_name'] ) ? sanitize_text_field( (string) $definition['default_block_name'] ) : $label;
		$fields        = isset( $definition['fields'] ) && is_array( $definition['fields'] ) ? array_values( $definition['fields'] ) : array();

		if ( '' === $type || '' === $label || '' === $description || '' === $icon_key || '' === $category ) {
			return array();
		}

		if ( class_exists( 'Sonyra_Site_Manager_Icon_Registry' ) && ! Sonyra_Site_Manager_Icon_Registry::has( $icon_key ) ) {
			$icon_key = 'circle-dot';
		}

		$default_section = isset( $definition['default_section'] ) && is_array( $definition['default_section'] ) ? $definition['default_section'] : array();
		$default_blocks  = isset( $definition['default_blocks'] ) && is_array( $definition['default_blocks'] ) ? $definition['default_blocks'] : array();

		if ( empty( $default_blocks ) ) {
			$default_blocks = array(
				self::build_default_block(
					$default_block,
					$default_name,
					$label,
					'description',
					$description
				),
			);
		}

		$default_section = array_merge(
			array(
				'id'         => '',
				'type'       => $type,
				'name'       => $label,
				'blocks'     => $default_blocks,
				'provider'   => $provider,
				'module_key' => $module_key,
			),
			$default_section
		);

		return array(
			'type'            => $type,
			'label'           => $label,
			'description'     => $description,
			'icon_key'        => $icon_key,
			'category'        => $category,
			'provider'        => '' !== $provider ? $provider : 'core',
			'module_key'      => $module_key,
			'status'          => '' !== $status ? $status : 'implemented',
			'default_section' => $default_section,
			'default_blocks'  => $default_blocks,
			'fields'          => $fields,
		);
	}

	public static function get_section_definition( $type ): array {
		$type = sanitize_key( (string) $type );

		if ( '' === $type ) {
			return array();
		}

		foreach ( self::get_section_definitions() as $definition ) {
			if ( $type === (string) $definition['type'] ) {
				return $definition;
			}
		}

		return array();
	}

	public static function get_section_type_options(): array {
		$options = array();

		foreach ( self::get_section_definitions() as $definition ) {
			$options[] = array(
				'type'        => (string) $definition['type'],
				'label'       => (string) $definition['label'],
				'description' => (string) $definition['description'],
				'icon_key'    => (string) $definition['icon_key'],
				'category'    => (string) $definition['category'],
				'provider'    => (string) $definition['provider'],
				'module_key'  => (string) $definition['module_key'],
				'status'      => (string) $definition['status'],
			);
		}

		return $options;
	}

	public static function get_section_defaults( $type ): array {
		$definition = self::get_section_definition( $type );

		if ( empty( $definition ) ) {
			return array();
		}

		return isset( $definition['default_section'] ) && is_array( $definition['default_section'] ) ? $definition['default_section'] : array();
	}

	private static function build_definition( string $type, string $label_key, string $description_key, string $icon_key, string $category, string $default_block_type = 'text', string $default_block_name_key = '' ): array {
		$label       = self::text( $label_key );
		$description = self::text( $description_key );
		$block_name  = '' !== $default_block_name_key ? self::text( $default_block_name_key ) : $label;

		if ( 'hero' === $default_block_type ) {
			$default_blocks = array(
				array(
					'id'           => '',
					'type'         => 'hero',
					'name'         => $block_name,
					'heading'      => $label,
					'text'         => self::text( 'manager.pages.defaults.hero.text' ),
					'button_label' => '',
					'button_url'   => '',
				),
			);
		} elseif ( 'contacts' === $default_block_type ) {
			$default_blocks = array(
				array(
					'id'          => '',
					'type'        => 'contacts',
					'name'        => $block_name,
					'heading'     => $label,
					'description' => self::text( 'manager.pages.defaults.contacts.description' ),
					'email'       => '',
					'phone'       => '',
					'address'     => '',
				),
			);
		} else {
			$default_blocks = array(
				self::build_default_block( 'text', $block_name, $label, 'text', $description ),
			);
		}

		return array(
			'type'               => $type,
			'label'              => $label,
			'description'        => $description,
			'icon_key'           => $icon_key,
			'category'           => $category,
			'provider'           => 'core',
			'module_key'         => '',
			'status'             => 'implemented',
			'default_block_type' => $default_block_type,
			'default_block_name' => $block_name,
			'default_section'    => array(
				'id'     => '',
				'type'   => $type,
				'name'   => $label,
				'blocks' => $default_blocks,
			),
			'default_blocks'     => $default_blocks,
			'fields'             => array(),
		);
	}

	private static function build_default_block( string $type, string $name, string $heading, string $text_key, string $text_value ): array {
		return array(
			'id'      => '',
			'type'    => $type,
			'name'    => $name,
			'heading' => $heading,
			'text'    => 'text' === $text_key ? $text_value : '',
		);
	}

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}
}
