# SONYRA Page Elements Library Contract

## 1. Core concept

Page Elements Library объединяет:

- sections;
- blocks;
- widgets;
- popups.

Stage 1 реализует sections registry.

Следующие этапы:

- Stage 2 — blocks;
- Stage 3 — widgets;
- Stage 4 — popups.

## 2. Section definition shape

Section definition использует поля:

- `type`;
- `label`;
- `description`;
- `icon_key`;
- `category`;
- `provider`;
- `module_key`;
- `status`;
- `default_section`;
- `default_blocks`;
- `fields`.

Правила:

- `type` обязателен и хранится как stable key;
- `label` обязателен и идёт только через i18n;
- `description` обязателен и идёт только через i18n;
- `icon_key` обязателен и берётся только из SONYRA Icon Library;
- `category` обязателен;
- `provider` по умолчанию `core`;
- `status` по умолчанию `implemented`;
- `default_section` обязателен;
- `default_blocks` опционален;
- `fields` опционален.

## 3. Filter connector

Базовый connector для секций:

- `sonyra_site_manager_section_definitions`

Core передаёт в filter свои base definitions.

Внешний модуль может добавить свои definitions через этот filter.

После filter definitions должны пройти нормализацию и валидацию.

## 4. External module behavior

Пока модуль включён:

- его definitions появляются в library modal;
- editor может создавать новые instances этого module type.

Если модуль выключен:

- definitions исчезают из modal добавления;
- уже созданные instances не удаляются;
- editor показывает instance как unavailable;
- public renderer не падает;
- save не удаляет instance молча.

## 5. Naming standard

Для visible labels используются только универсальные названия.

Запрещены:

- Первый экран;
- Главный блок;
- Основной блок;
- Ведущий блок.

Разрешённый pattern:

- Акцентная секция;
- Текстовая секция;
- Преимущества;
- Контакты;
- Акцент.

Stored backward-compatible keys вроде `hero` сохраняются и не переименовываются.

## 6. Cross-section integration

- `Страницы` владеют page body sections;
- `Сайт` может использовать menu/page data, но не владеет body sections;
- `Дизайн` позже даёт style defaults;
- `Модули` контролируют подключённые external modules;
- `Безопасность` принимает события и согласия модулей при необходимости;
- `Настройки` владеют только system-level settings;
- `Главное` получает summary, а не editor internals.

## 7. Add section modal contract

- modal `Добавить секцию` работает только как single-select flow;
- выбор section создаёт ровно одну новую section instance;
- после успешного add/save modal закрывается сразу;
- multi-select режим для sections в текущем продукте запрещён;
- повторный click во время add/save блокируется;
- fake success до ответа backend запрещён.

## 8. Section card actions contract

- settings action section card обязан открывать modal `Параметры секции`;
- save в modal секции меняет только section name;
- delete action section card обязан открывать destructive confirmation modal;
- delete section без confirmation modal запрещён.

## 9. Section library icon contract

- `Акцентная секция` для type `hero` использует icon `sparkles`;
- `app-window` не используется для `Акцентная секция`, потому что конфликтует с site/page meaning;
- icon change не меняет type key, label, storage или default blocks.
