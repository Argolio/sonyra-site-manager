(function () {
	'use strict';

	var STORAGE_KEY = 'sonyra_manager_sidebar_state';
	var MOBILE_QUERY = '(max-width: 780px)';
	var shell = document.querySelector('[data-manager-shell]');

	if (!shell) {
		return;
	}

	var toggleButton = shell.querySelector('[data-manager-sidebar-toggle]');
	var logoButton = shell.querySelector('[data-manager-logo-toggle]');
	var backdrop = shell.querySelector('[data-manager-backdrop]');
	var routeButtons = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-route]'));
	var views = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-view]'));
	var topbarTitle = shell.querySelector('[data-manager-title]');
	var topbarSubtitle = shell.querySelector('[data-manager-subtitle]');
	var logoutButton = shell.querySelector('[data-manager-logout]');
	var logoutError = shell.querySelector('[data-manager-logout-error]');
	var mediaQuery = window.matchMedia ? window.matchMedia(MOBILE_QUERY) : null;

	function isMobile() {
		return mediaQuery ? mediaQuery.matches : window.innerWidth <= 780;
	}

	function getStoredState() {
		try {
			var value = window.localStorage.getItem(STORAGE_KEY);
			return value === 'collapsed' || value === 'expanded' ? value : '';
		} catch (error) {
			return '';
		}
	}

	function storeState(state) {
		try {
			window.localStorage.setItem(STORAGE_KEY, state);
		} catch (error) {}
	}

	function setSidebarState(state, shouldStore) {
		var nextState = state === 'collapsed' ? 'collapsed' : 'expanded';
		var expanded = nextState === 'expanded';

		shell.setAttribute('data-sidebar-state', nextState);
		shell.classList.toggle('sonyra-manager-mobile-open', expanded && isMobile());

		if (toggleButton) {
			toggleButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			toggleButton.setAttribute('aria-label', expanded ? (toggleButton.dataset.labelExpanded || '') : (toggleButton.dataset.labelCollapsed || ''));
		}

		if (logoButton) {
			logoButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			logoButton.setAttribute('aria-label', expanded ? (logoButton.dataset.labelExpanded || '') : (logoButton.dataset.labelCollapsed || ''));
		}

		if (backdrop) {
			backdrop.hidden = !(expanded && isMobile());
		}

		if (shouldStore) {
			storeState(nextState);
		}
	}

	function getRouteFromHash() {
		var hash = window.location.hash || '';
		var route = hash.replace(/^#\/?/, '').replace(/^\//, '');
		return route || 'dashboard';
	}

	function normalizeRoute(route) {
		var found = views.some(function (view) {
			return view.getAttribute('data-manager-view') === route;
		});

		return found ? route : 'dashboard';
	}

	function setRoute(route, shouldUpdateHash) {
		var nextRoute = normalizeRoute(route);
		var activeButton = null;

		views.forEach(function (view) {
			view.hidden = view.getAttribute('data-manager-view') !== nextRoute;
		});

		routeButtons.forEach(function (button) {
			var isActive = button.getAttribute('data-manager-route') === nextRoute;
			button.classList.toggle('sonyra-manager-nav-item-active', isActive);

			if (isActive) {
				button.setAttribute('aria-current', 'page');
				activeButton = button;
			} else {
				button.removeAttribute('aria-current');
			}
		});

		if (activeButton) {
			if (topbarTitle) {
				topbarTitle.textContent = activeButton.dataset.title || activeButton.textContent || '';
			}

			if (topbarSubtitle) {
				topbarSubtitle.textContent = activeButton.dataset.subtitle || '';
			}
		}

		if (shouldUpdateHash && window.location.hash !== '#/' + nextRoute) {
			window.location.hash = '#/' + nextRoute;
		}

		if (isMobile()) {
			setSidebarState('collapsed', false);
		}
	}

	function showLogoutError() {
		if (logoutError) {
			logoutError.hidden = false;
		}
	}

	function redirectToLogin() {
		var loginUrl = shell.getAttribute('data-login-url') || '/manager/login';
		window.location.assign(loginUrl);
	}

	function runLogout() {
		var logoutUrl = shell.getAttribute('data-logout-url') || '';

		if (!logoutUrl || logoutUrl.indexOf('://') === -1 && logoutUrl.charAt(0) !== '/') {
			showLogoutError();
			return;
		}

		if (logoutButton) {
			logoutButton.disabled = true;
		}

		fetch(logoutUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': shell.getAttribute('data-nonce') || ''
			},
			body: '{}'
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('logout_failed');
			}

			return response.json().catch(function () {
				return {};
			});
		}).then(function () {
			redirectToLogin();
		}).catch(function () {
			showLogoutError();

			if (logoutButton) {
				logoutButton.disabled = false;
			}
		});
	}

	routeButtons.forEach(function (button) {
		button.addEventListener('click', function () {
			setRoute(button.getAttribute('data-manager-route') || 'dashboard', true);
		});
	});

	if (toggleButton) {
		toggleButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true);
		});
	}

	if (logoButton) {
		logoButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true);
		});
	}

	if (backdrop) {
		backdrop.addEventListener('click', function () {
			setSidebarState('collapsed', false);
		});
	}

	if (logoutButton) {
		logoutButton.addEventListener('click', runLogout);
	}

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && isMobile() && shell.getAttribute('data-sidebar-state') === 'expanded') {
			setSidebarState('collapsed', false);
		}
	});

	window.addEventListener('hashchange', function () {
		setRoute(getRouteFromHash(), false);
	});

	if (mediaQuery && mediaQuery.addEventListener) {
		mediaQuery.addEventListener('change', function () {
			setSidebarState(isMobile() ? 'collapsed' : (getStoredState() || 'expanded'), false);
		});
	}

	setSidebarState(getStoredState() || (isMobile() ? 'collapsed' : 'expanded'), false);
	setRoute(getRouteFromHash(), false);
}());
