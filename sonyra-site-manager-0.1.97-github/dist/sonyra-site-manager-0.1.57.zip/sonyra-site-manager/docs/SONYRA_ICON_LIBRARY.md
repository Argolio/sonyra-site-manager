# SONYRA SVG Icon Library

## Назначение

SONYRA SVG Icon Library — внутренняя библиотека SVG-иконок для SONYRA Site Manager.

Библиотека нужна, чтобы Codex, manager UI, будущие модули и будущий клиентский icon picker использовали стабильные `icon_key`, а не вручную нарисованные SVG и не сырой SVG-код.

## Источник

Основной SVG-источник:

- Tabler Icons.

В SONYRA Site Manager используются только локальные outline SVG.

Запрещено:

- CDN;
- remote SVG;
- icon font;
- bitmap;
- emoji;
- filled/solid pack в core pack;
- brand/trademark icons в core pack;
- ручное рисование новых SVG Codex-агентом.

Плагин должен работать автономно без внешней сети на runtime.

## Хранение

SVG-файлы хранятся локально:

- `assets/icons/tabler/outline/`

Лицензия источника хранится локально:

- `assets/icons/tabler/LICENSE.txt`

Manifest библиотеки:

- `assets/icons/sonyra-icons-manifest.json`

Пользовательские настройки, будущие модули и будущий picker должны хранить `icon_key`, а не raw SVG.

## Manifest

Каждая иконка описывается metadata:

- `key`
- `source`
- `source_name`
- `file`
- `category`
- `title_ru`
- `tags_ru`
- `style`
- `viewBox`
- `stroke`
- `fill`
- `license`

Для core pack `0.1.56`:

- `source`: `tabler`
- `style`: `outline`
- `viewBox`: `0 0 24 24`
- `stroke`: `currentColor`
- `fill`: `none`
- `license`: `MIT`

Все будущие видимые категории, названия и теги для UI должны быть на русском языке.

## Core Pack 0.1.56

Core pack `0.1.56` содержит только выбранный базовый набор из `80–120` outline SVG-иконок.

В этот этап не входят все иконки Tabler, потому что полный upstream-набор слишком большой для первого foundation-патча и не нужен runtime-интерфейсу сейчас.

Core pack покрывает:

- интерфейс;
- навигацию;
- действия;
- сайт;
- страницы;
- дизайн;
- текст;
- медиа;
- формы;
- файлы;
- пользователей;
- контакты;
- сообщения;
- время;
- географию;
- услуги;
- магазин;
- финансы;
- аналитику;
- безопасность;
- устройства;
- интеграции;
- системные состояния.

## Extended Pack

Будущий отдельный этап может расширить библиотеку до `800–1200` outline SVG-иконок.

Расширение должно:

- использовать официальный Tabler outline SVG source;
- не добавлять brand/trademark icons без отдельного решения;
- обновлять manifest;
- проходить sanitizer/security audit;
- не добавлять icon picker без отдельного UI-контракта.

## Renderer

`Sonyra_Site_Manager_Icon_Renderer` принимает `icon_key` и возвращает безопасный inline SVG.

Renderer:

- читает только whitelisted SVG через registry;
- не принимает raw SVG;
- не принимает внешние URL;
- не читает произвольные пути;
- удаляет опасные SVG-теги и event handlers;
- нормализует `class`;
- сохраняет `currentColor`;
- отдаёт decorative SVG с `aria-hidden="true"` и `focusable="false"`;
- отдаёт смысловой SVG с `role="img"` и `aria-label`, если это явно нужно.

## Registry

`Sonyra_Site_Manager_Icon_Registry` отвечает за:

- загрузку manifest;
- проверку `icon_key`;
- возврат metadata;
- возврат SVG path только внутри `assets/icons/tabler/outline/`;
- защиту от path traversal;
- безопасный fallback `circle-dot`.

Разрешённый формат `icon_key`:

- lowercase kebab-case;
- только `a-z`, `0-9`, дефис.

Запрещены:

- `../`;
- slash;
- backslash;
- null byte;
- URL;
- protocol;
- query string;
- произвольный путь.

## Добавление новой иконки

Чтобы добавить новую иконку:

1. Взять официальный Tabler outline SVG.
2. Положить SVG в `assets/icons/tabler/outline/`.
3. Добавить metadata в `assets/icons/sonyra-icons-manifest.json`.
4. Проверить, что `key` unique и kebab-case.
5. Проверить, что файл существует.
6. Проверить sanitizer.
7. Проверить лицензию.
8. Не менять SVG style произвольно.

Raw custom SVG upload не входит в текущий этап и в будущем допускается только через отдельный sanitizer/security contract.
