<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Manager_Renderer {

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	private static function versioned_asset_url( string $url, string $path, string $query_arg = 'ver' ): string {
		if ( ! file_exists( $path ) ) {
			return '';
		}

		$asset_mtime = filemtime( $path );
		$asset_version = SONYRA_SITE_MANAGER_VERSION;

		if ( is_int( $asset_mtime ) ) {
			$asset_version .= '-' . $asset_mtime;
		}

		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( $query_arg, $asset_version, $url );
		}

		return $url . '?' . rawurlencode( $query_arg ) . '=' . rawurlencode( $asset_version );
	}

	private static function render_icon( string $name, string $class_name = 'sonyra-manager-icon' ): void {
		$icons = array(
			'layout-dashboard' => '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
			'list-checks' => '<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
			'files' => '<path d="M15 2H6a2 2 0 0 0-2 2v13"/><path d="M9 22h9a2 2 0 0 0 2-2V7l-5-5"/><path d="M15 2v5h5"/><path d="M8 7H4a2 2 0 0 0-2 2v11"/>',
			'palette' => '<circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6 2 11.5S6.5 22 12 22h1.5a2.5 2.5 0 0 0 0-5H12a1.5 1.5 0 0 1 0-3h1.5C18.2 14 22 11.4 22 8.2 22 4.8 17.5 2 12 2z"/>',
			'blocks' => '<rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/><path d="M14 14h7v7h-7z"/><path d="M3 3h7v7H3z"/>',
			'shield-check' => '<path d="M20 13c0 5-3.5 7.5-7.7 8.9a1 1 0 0 1-.6 0C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.2-2.7a1.2 1.2 0 0 1 1.6 0C14.5 3.8 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
			'settings' => '<path d="M9.7 2.7a2.4 2.4 0 0 1 4.6 0l.2.9a2.4 2.4 0 0 0 3.4 1.4l.8-.4a2.4 2.4 0 0 1 3.2 3.2l-.4.8a2.4 2.4 0 0 0 1.4 3.4l.9.2a2.4 2.4 0 0 1 0 4.6l-.9.2a2.4 2.4 0 0 0-1.4 3.4l.4.8a2.4 2.4 0 0 1-3.2 3.2l-.8-.4a2.4 2.4 0 0 0-3.4 1.4l-.2.9a2.4 2.4 0 0 1-4.6 0l-.2-.9a2.4 2.4 0 0 0-3.4-1.4l-.8.4a2.4 2.4 0 0 1-3.2-3.2l.4-.8A2.4 2.4 0 0 0 1.1 17l-.9-.2a2.4 2.4 0 0 1 0-4.6l.9-.2a2.4 2.4 0 0 0 1.4-3.4l-.4-.8a2.4 2.4 0 0 1 3.2-3.2l.8.4a2.4 2.4 0 0 0 3.4-1.4z"/><circle cx="12" cy="12" r="3"/>',
			'log-out' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
			'panel-right-close' => '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M15 3v18"/><path d="m8 9 3 3-3 3"/>',
			'panel-right-open' => '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M15 3v18"/><path d="m11 9-3 3 3 3"/>',
			'gauge' => '<path d="m12 14 4-4"/><path d="M3.3 14a9 9 0 1 1 17.4 0"/><path d="M5.3 18a9 9 0 0 0 13.4 0"/>',
			'check' => '<path d="M20 6 9 17l-5-5"/>',
			'clock-3' => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16.5 12"/>',
			'circle-dot' => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="1"/>',
			'circle-alert' => '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
		);

		$icon = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['circle-dot'];
		echo '<svg class="' . esc_attr( $class_name ) . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $icon . '</svg>';
	}

	private static function get_nav_items(): array {
		return array(
			array( 'route' => 'dashboard', 'label' => 'manager.nav_dashboard', 'icon' => 'layout-dashboard' ),
			array( 'route' => 'setup', 'label' => 'manager.nav_setup', 'icon' => 'list-checks' ),
			array( 'route' => 'pages', 'label' => 'manager.nav_pages', 'icon' => 'files' ),
			array( 'route' => 'design', 'label' => 'manager.nav_design', 'icon' => 'palette' ),
			array( 'route' => 'modules', 'label' => 'manager.nav_modules', 'icon' => 'blocks' ),
			array( 'route' => 'security', 'label' => 'manager.nav_security', 'icon' => 'shield-check' ),
			array( 'route' => 'settings', 'label' => 'manager.nav_settings', 'icon' => 'settings' ),
		);
	}

	private static function get_views(): array {
		return array(
			'dashboard' => array( 'title' => 'manager.view_dashboard_title', 'subtitle' => 'manager.view_dashboard_subtitle' ),
			'setup' => array( 'title' => 'manager.placeholder_setup_title', 'subtitle' => 'manager.placeholder_setup_subtitle', 'status' => 'manager.placeholder_foundation', 'icon' => 'list-checks' ),
			'pages' => array( 'title' => 'manager.placeholder_pages_title', 'subtitle' => 'manager.placeholder_pages_subtitle', 'status' => 'manager.placeholder_preparing', 'icon' => 'files' ),
			'design' => array( 'title' => 'manager.placeholder_design_title', 'subtitle' => 'manager.placeholder_design_subtitle', 'status' => 'manager.placeholder_preparing', 'icon' => 'palette' ),
			'modules' => array( 'title' => 'manager.placeholder_modules_title', 'subtitle' => 'manager.placeholder_modules_subtitle', 'status' => 'manager.placeholder_preparing', 'icon' => 'blocks' ),
			'security' => array( 'title' => 'manager.placeholder_security_title', 'subtitle' => 'manager.placeholder_security_subtitle', 'status' => 'manager.placeholder_security_status', 'icon' => 'shield-check' ),
			'settings' => array( 'title' => 'manager.placeholder_settings_title', 'subtitle' => 'manager.placeholder_settings_subtitle', 'status' => 'manager.placeholder_preparing', 'icon' => 'settings' ),
		);
	}

	public static function render_shell(): void {
		$css_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/css/sonyra-manager.css';
		$css_url = plugins_url( 'assets/css/sonyra-manager.css', SONYRA_SITE_MANAGER_FILE );
		$js_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/js/sonyra-manager.js';
		$js_url = plugins_url( 'assets/js/sonyra-manager.js', SONYRA_SITE_MANAGER_FILE );
		$logo_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-logo.png';
		$logo_url = plugins_url( 'assets/images/brand/pult-site-logo.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_ico_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon.ico';
		$favicon_ico_url = plugins_url( 'assets/images/brand/pult-site-favicon.ico', SONYRA_SITE_MANAGER_FILE );
		$favicon_32_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-32.png';
		$favicon_32_url = plugins_url( 'assets/images/brand/pult-site-favicon-32.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_192_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-192.png';
		$favicon_192_url = plugins_url( 'assets/images/brand/pult-site-favicon-192.png', SONYRA_SITE_MANAGER_FILE );
		$apple_touch_icon_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-apple-touch-icon-180.png';
		$apple_touch_icon_url = plugins_url( 'assets/images/brand/pult-site-apple-touch-icon-180.png', SONYRA_SITE_MANAGER_FILE );
		$logout_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/logout' ) : '';
		$login_url = function_exists( 'home_url' ) ? home_url( '/manager/login' ) : '/manager/login';
		$nonce = function_exists( 'wp_create_nonce' ) ? wp_create_nonce( 'wp_rest' ) : '';
		$year = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );
		$views = self::get_views();
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( self::text( 'manager.view_dashboard_title' ) ); ?></title>
	<?php if ( '' !== self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" href="<?php echo esc_url( self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ); ?>" sizes="any">
	<link rel="shortcut icon" href="<?php echo esc_url( self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ); ?>" type="image/x-icon">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' ) ) : ?>
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( self::versioned_asset_url( $css_url, $css_path ) ); ?>">
</head>
<body class="sonyra-manager-page">
	<div class="sonyra-manager-shell" data-sidebar-state="expanded" data-manager-shell data-logout-url="<?php echo esc_url( $logout_url ); ?>" data-login-url="<?php echo esc_url( $login_url ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>">
		<div class="sonyra-manager-backdrop" data-manager-backdrop hidden></div>

		<main class="sonyra-manager-main">
			<header class="sonyra-manager-topbar">
				<div class="sonyra-manager-topbar-copy">
					<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( 'manager.brand_name' ) ); ?></p>
					<h1 class="sonyra-manager-topbar-title" data-manager-title><?php echo esc_html( self::text( 'manager.view_dashboard_title' ) ); ?></h1>
					<p class="sonyra-manager-topbar-subtitle" data-manager-subtitle><?php echo esc_html( self::text( 'manager.topbar_subtitle' ) ); ?></p>
				</div>
				<div class="sonyra-manager-session-chip">
					<?php self::render_icon( 'shield-check', 'sonyra-manager-icon sonyra-manager-chip-icon' ); ?>
					<span><?php echo esc_html( self::text( 'manager.session_active' ) ); ?></span>
				</div>
			</header>

			<div class="sonyra-manager-notice" data-manager-logout-error hidden>
				<?php self::render_icon( 'circle-alert', 'sonyra-manager-icon sonyra-manager-notice-icon' ); ?>
				<span><?php echo esc_html( self::text( 'manager.logout_error' ) ); ?></span>
				<small><?php echo esc_html( self::text( 'manager.logout_error_hint' ) ); ?></small>
			</div>

			<section class="sonyra-manager-view sonyra-manager-view-dashboard" data-manager-view="dashboard">
				<div class="sonyra-manager-hero">
					<div class="sonyra-manager-hero-icon"><?php self::render_icon( 'list-checks', 'sonyra-manager-icon sonyra-manager-hero-svg' ); ?></div>
					<div>
						<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( 'manager.nav_setup' ) ); ?></p>
						<h2><?php echo esc_html( self::text( 'manager.setup_title' ) ); ?></h2>
						<p><?php echo esc_html( self::text( 'manager.setup_subtitle' ) ); ?></p>
					</div>
				</div>

				<div class="sonyra-manager-dashboard-grid">
					<article class="sonyra-manager-card sonyra-manager-progress-card">
						<div class="sonyra-manager-card-head">
							<?php self::render_icon( 'gauge', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
							<h3><?php echo esc_html( self::text( 'manager.progress_title' ) ); ?></h3>
						</div>
						<div class="sonyra-manager-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="25" aria-label="<?php echo esc_attr( self::text( 'manager.progress_title' ) ); ?>">
							<span style="width:25%"></span>
						</div>
						<strong><?php echo esc_html( self::text( 'manager.progress_status' ) ); ?></strong>
						<p><?php echo esc_html( self::text( 'manager.progress_hint' ) ); ?></p>
					</article>

					<article class="sonyra-manager-card sonyra-manager-health-card">
						<div class="sonyra-manager-card-head">
							<?php self::render_icon( 'layout-dashboard', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
							<h3><?php echo esc_html( self::text( 'manager.health_title' ) ); ?></h3>
						</div>
						<p><?php echo esc_html( self::text( 'manager.health_subtitle' ) ); ?></p>
						<div class="sonyra-manager-metrics">
							<?php self::render_metric( 'manager.metric_visitors' ); ?>
							<?php self::render_metric( 'manager.metric_clicks' ); ?>
							<?php self::render_metric( 'manager.metric_requests' ); ?>
							<?php self::render_metric( 'manager.metric_health' ); ?>
						</div>
					</article>
				</div>

				<div class="sonyra-manager-dashboard-grid sonyra-manager-dashboard-grid-wide">
					<section class="sonyra-manager-card">
						<h3><?php echo esc_html( self::text( 'manager.next_title' ) ); ?></h3>
						<div class="sonyra-manager-step-list">
							<?php self::render_step( 'shield-check', 'manager.step_auth_title', 'manager.step_auth_hint', 'manager.step_done', 'done' ); ?>
							<?php self::render_step( 'layout-dashboard', 'manager.step_workspace_title', 'manager.step_workspace_hint', 'manager.step_working', 'work' ); ?>
							<?php self::render_step( 'files', 'manager.step_pages_title', 'manager.step_pages_hint', 'manager.step_next', 'next' ); ?>
							<?php self::render_step( 'palette', 'manager.step_design_title', 'manager.step_design_hint', 'manager.step_next', 'next' ); ?>
							<?php self::render_step( 'blocks', 'manager.step_modules_title', 'manager.step_modules_hint', 'manager.step_next', 'next' ); ?>
						</div>
					</section>
					<section class="sonyra-manager-card">
						<h3><?php echo esc_html( self::text( 'manager.quick_actions_title' ) ); ?></h3>
						<div class="sonyra-manager-action-grid">
							<button type="button" class="sonyra-manager-action" data-manager-route="setup"><?php self::render_icon( 'list-checks' ); ?><span><?php echo esc_html( self::text( 'manager.action_setup' ) ); ?></span></button>
							<button type="button" class="sonyra-manager-action" data-manager-route="security"><?php self::render_icon( 'shield-check' ); ?><span><?php echo esc_html( self::text( 'manager.action_security' ) ); ?></span></button>
						</div>
					</section>
				</div>
			</section>

			<?php foreach ( $views as $route => $view ) : ?>
				<?php if ( 'dashboard' === $route ) : ?>
					<?php continue; ?>
				<?php endif; ?>
				<section class="sonyra-manager-view sonyra-manager-view-placeholder" data-manager-view="<?php echo esc_attr( $route ); ?>" hidden>
					<div class="sonyra-manager-placeholder-card">
						<div class="sonyra-manager-hero-icon"><?php self::render_icon( (string) $view['icon'], 'sonyra-manager-icon sonyra-manager-hero-svg' ); ?></div>
						<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( 'manager.brand_name' ) ); ?></p>
						<h2><?php echo esc_html( self::text( (string) $view['title'] ) ); ?></h2>
						<p><?php echo esc_html( self::text( (string) $view['subtitle'] ) ); ?></p>
						<span class="sonyra-manager-status-pill"><?php echo esc_html( self::text( (string) $view['status'] ) ); ?></span>
					</div>
				</section>
			<?php endforeach; ?>
		</main>

		<aside class="sonyra-manager-sidebar" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_label' ) ); ?>">
			<div class="sonyra-manager-brand-row">
				<div class="sonyra-manager-brand">
					<span class="sonyra-manager-logo-tile">
						<?php if ( '' !== self::versioned_asset_url( $logo_url, $logo_path ) ) : ?>
							<img src="<?php echo esc_url( self::versioned_asset_url( $logo_url, $logo_path ) ); ?>" alt="" aria-hidden="true" decoding="async">
						<?php endif; ?>
					</span>
					<span class="sonyra-manager-brand-copy">
						<strong><?php echo esc_html( self::text( 'manager.brand_name' ) ); ?></strong>
						<small><?php echo esc_html( self::text( 'manager.publisher' ) ); ?></small>
					</span>
				</div>
				<button type="button" class="sonyra-manager-sidebar-toggle" data-manager-sidebar-toggle aria-expanded="true" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-expanded="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-collapsed="<?php echo esc_attr( self::text( 'manager.sidebar_expand' ) ); ?>">
					<span class="sonyra-manager-toggle-icon sonyra-manager-toggle-icon-expanded"><?php self::render_icon( 'panel-right-close' ); ?></span>
					<span class="sonyra-manager-toggle-icon sonyra-manager-toggle-icon-collapsed"><?php self::render_icon( 'panel-right-open' ); ?></span>
				</button>
			</div>

			<nav class="sonyra-manager-nav">
				<ul>
					<?php foreach ( self::get_nav_items() as $item ) : ?>
						<li>
							<button type="button" class="sonyra-manager-nav-item" data-manager-route="<?php echo esc_attr( $item['route'] ); ?>" data-title="<?php echo esc_attr( self::text( $views[ $item['route'] ]['title'] ) ); ?>" data-subtitle="<?php echo esc_attr( self::text( $views[ $item['route'] ]['subtitle'] ) ); ?>" data-tooltip="<?php echo esc_attr( self::text( $item['label'] ) ); ?>" <?php echo 'dashboard' === $item['route'] ? 'aria-current="page"' : ''; ?>>
								<span class="sonyra-manager-nav-icon-slot"><?php self::render_icon( $item['icon'], 'sonyra-manager-icon sonyra-manager-nav-icon' ); ?></span>
								<span class="sonyra-manager-nav-label"><?php echo esc_html( self::text( $item['label'] ) ); ?></span>
							</button>
						</li>
					<?php endforeach; ?>
				</ul>
			</nav>

			<div class="sonyra-manager-sidebar-bottom">
				<button type="button" class="sonyra-manager-nav-item sonyra-manager-logout" data-manager-logout data-tooltip="<?php echo esc_attr( self::text( 'manager.nav_logout' ) ); ?>">
					<span class="sonyra-manager-nav-icon-slot"><?php self::render_icon( 'log-out', 'sonyra-manager-icon sonyra-manager-nav-icon' ); ?></span>
					<span class="sonyra-manager-nav-label"><?php echo esc_html( self::text( 'manager.nav_logout' ) ); ?></span>
				</button>
				<div class="sonyra-manager-footer">
					<span><?php echo esc_html( self::text( 'manager.publisher' ) ); ?></span>
					<span><?php echo esc_html( '© ' . $year ); ?></span>
					<span><?php echo esc_html( SONYRA_SITE_MANAGER_VERSION ); ?></span>
				</div>
			</div>
		</aside>
	</div>
	<script src="<?php echo esc_url( self::versioned_asset_url( $js_url, $js_path ) ); ?>" defer></script>
</body>
</html>
		<?php
	}

	private static function render_metric( string $label_key ): void {
		?>
		<div class="sonyra-manager-metric">
			<span><?php echo esc_html( self::text( $label_key ) ); ?></span>
			<strong><?php echo esc_html( self::text( 'manager.metric_empty' ) ); ?></strong>
			<small><?php echo esc_html( self::text( 'manager.metric_pending' ) ); ?></small>
		</div>
		<?php
	}

	private static function render_step( string $icon, string $title_key, string $hint_key, string $status_key, string $state ): void {
		?>
		<div class="sonyra-manager-step sonyra-manager-step-<?php echo esc_attr( $state ); ?>">
			<span class="sonyra-manager-step-icon"><?php self::render_icon( $icon ); ?></span>
			<span>
				<strong><?php echo esc_html( self::text( $title_key ) ); ?></strong>
				<small><?php echo esc_html( self::text( $hint_key ) ); ?></small>
			</span>
			<em><?php echo esc_html( self::text( $status_key ) ); ?></em>
		</div>
		<?php
	}
}
