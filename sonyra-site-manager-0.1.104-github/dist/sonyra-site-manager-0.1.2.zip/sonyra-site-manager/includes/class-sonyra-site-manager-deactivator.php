<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Deactivator {

	public static function deactivate() {
		// Права и настройки не удаляются при деактивации, чтобы сохранить безопасный откат.
	}
}
