# SONYRA Security Rules

## Manager access rules

Manager SONYRA Site Manager должен быть закрыт от гостей и пользователей без прав.

Доступ к manager-интерфейсу разрешается только авторизованным пользователям с подходящей capability.

Отказ доступа должен быть обработан безопасно, без раскрытия секретов, и видимый пользовательский интерфейс отказа должен быть только на русском языке.

## Capability foundation

Будущая модель прав должна учитывать роли:

- owner;
- admin;
- editor;
- moderator;
- viewer.

Каждое действие manager, REST endpoint, diagnostics, export/embed-настройка и изменение публичного рендера должны иметь явную capability foundation.

## REST nonce rules

Все будущие приватные REST endpoints должны иметь:

- nonce/session check;
- capability check;
- sanitize input;
- validate input;
- escape output;
- audit log для важных действий;
- запрет доступа гостям, если endpoint не является публичным по контракту.

REST permissions callbacks обязательны для каждого endpoint.

## Sanitize, validate, escape

Правило обработки данных:

- sanitize input перед использованием;
- validate input перед сохранением или действием;
- escape output перед выводом;
- не доверять данным из REST, query, post body, meta, options, embed params или iframe params.

## Audit log

Audit log обязателен для важных действий:

- изменение настроек;
- изменение страниц;
- публикация;
- удаление;
- изменение маршрутов;
- изменение embed/iframe-настроек;
- изменение прав доступа;
- security-denied события;
- release-sensitive действия.

Audit log не должен хранить секреты, nonce, пароли, токены в открытом виде или приватные payload без необходимости.

## Denied access events

Отказы доступа должны фиксироваться как security events, если это важно для диагностики или защиты.

Denied access events должны различать:

- guest access;
- authenticated user without capability;
- invalid nonce;
- expired session;
- forbidden route;
- invalid embed token;
- disallowed domain.

## Public/private route distinction

Каждый route должен иметь явный статус:

- public по контракту;
- private для manager/API;
- embed-only;
- iframe-only;
- internal diagnostics.

Гостевой доступ запрещён ко всем private routes.

## Embed token foundation

Будущие embed-сценарии должны иметь token foundation:

- токен не должен раскрывать секреты;
- токен должен иметь понятный scope;
- token validation обязательна для приватных или ограниченных embed-сценариев;
- invalid token должен давать безопасный отказ;
- видимый отказ должен быть на русском языке.

## iframe security foundation

Будущие iframe-сценарии должны учитывать:

- allowed domains foundation;
- frame headers;
- sandbox policy, если применимо;
- origin validation;
- безопасный обмен сообщениями;
- запрет раскрытия приватных данных;
- русские видимые сообщения об ошибках.

## Allowed domains foundation

Для embed и iframe должен быть предусмотрен список разрешённых доменов.

Если домен не разрешён, доступ должен быть отклонён, событие должно быть зафиксировано, а видимое сообщение должно быть на русском языке.

## Rate limit foundation for future OTP

Будущие OTP, login, recovery или sensitive endpoints должны иметь rate limit foundation.

Rate limit должен учитывать:

- пользователя;
- IP;
- route;
- действие;
- временное окно;
- audit log для превышений.

## Private updater security

Будущий private updater должен иметь package checksum verification.

Signed manifest plan обязателен до внедрения автоматического обновления.

Разрешённый update domain должен быть явно задан.

Unsafe package URL запрещён.

Update install без validation запрещён.

Если update server unavailable, плагин должен завершать проверку gracefully и без fatal error.

Недоступность https://updates.dobromap.ru/public/index.php?action=check не должна ломать сайт.
