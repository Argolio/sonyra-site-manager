<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Login_Renderer {

	public static function get_preview_state(): string {
		$state = 'identifier';

		if ( isset( $_GET['sonyra_login_preview'] ) ) {
			$state = sanitize_key( wp_unslash( $_GET['sonyra_login_preview'] ) );
		}

		$allowed_states = array( 'identifier', 'code', 'success', 'error' );

		if ( ! in_array( $state, $allowed_states, true ) ) {
			return 'identifier';
		}

		return $state;
	}

	public static function render_placeholder(): void {
		self::render_login_shell();
	}

	public static function render_login_shell(): void {
		$state   = self::get_preview_state();
		$title   = 'Вход в Пульт сайта';
		$css_url = plugins_url( 'assets/css/sonyra-login.css', SONYRA_SITE_MANAGER_FILE );
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?></title>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( SONYRA_SITE_MANAGER_VERSION ); ?>">
</head>
<body class="sonyra-login-page">
	<div id="sonyra-login-root">
		<div class="sonyra-login-shell">
			<div class="sonyra-login-brand" aria-label="Пульт сайта">
				<div class="sonyra-login-brand-mark" aria-hidden="true"></div>
				<div class="sonyra-login-brand-copy">
					<div class="sonyra-login-brand-title">Пульт сайта</div>
					<div class="sonyra-login-brand-meta">SONYRA STUDIO</div>
				</div>
			</div>

			<main class="sonyra-login-card">
				<?php if ( 'code' === $state ) : ?>
					<?php self::render_code_state(); ?>
				<?php elseif ( 'success' === $state ) : ?>
					<?php self::render_success_state(); ?>
				<?php elseif ( 'error' === $state ) : ?>
					<?php self::render_error_state(); ?>
				<?php else : ?>
					<?php self::render_identifier_state(); ?>
				<?php endif; ?>
			</main>

			<footer class="sonyra-login-footer">SONYRA STUDIO</footer>
		</div>
	</div>
</body>
</html>
		<?php
	}

	private static function render_identifier_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-identifier" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker">Пульт сайта</p>
				<h1 id="sonyra-login-title" class="sonyra-login-title">Вход в Пульт сайта</h1>
				<p class="sonyra-login-lead">Введите электронную почту или логин, чтобы получить код доступа.</p>
			</div>

			<form class="sonyra-login-form" aria-describedby="sonyra-login-status">
				<div class="sonyra-login-field">
					<label class="sonyra-login-label" for="sonyra-login-identifier">Электронная почта или логин</label>
					<input class="sonyra-login-input" id="sonyra-login-identifier" type="text" name="sonyra_login_identifier" autocomplete="username" inputmode="email" placeholder="name@example.com или login">
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="button">Получить код</button>

				<p class="sonyra-login-hint">Пароль не нужен. Мы отправим одноразовый код, если доступ разрешён.</p>
			</form>

			<div id="sonyra-login-status" class="sonyra-login-status" aria-live="polite">Если доступ разрешён, код будет отправлен на указанную почту.</div>
			<p class="sonyra-login-note">После подтверждения входа доступ к Пульту сайта будет проверен отдельно.</p>
		</section>
		<?php
	}

	private static function render_code_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-code" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker">Пульт сайта</p>
				<h1 id="sonyra-login-title" class="sonyra-login-title">Введите код из письма</h1>
				<p class="sonyra-login-lead">Введите шестизначный код, который был отправлен после запроса доступа.</p>
			</div>

			<form class="sonyra-login-form" aria-describedby="sonyra-login-status">
				<div class="sonyra-login-field">
					<label class="sonyra-login-label" for="sonyra-login-code">Код из письма</label>
					<input class="sonyra-login-input sonyra-login-input-code" id="sonyra-login-code" type="text" name="sonyra_login_code" maxlength="6" inputmode="numeric" autocomplete="one-time-code" placeholder="••••••">
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="button">Войти</button>

				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button">Отправить код ещё раз</button>
					<button class="sonyra-login-text-button" type="button">Изменить почту или логин</button>
				</div>
			</form>

			<div id="sonyra-login-status" class="sonyra-login-status" aria-live="polite">Проверка кода будет подключена следующим этапом.</div>
		</section>
		<?php
	}

	private static function render_success_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-success" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker">Пульт сайта</p>
				<h1 id="sonyra-login-title" class="sonyra-login-title">Вход подтверждён.</h1>
				<p class="sonyra-login-lead">Переход к Пульту сайта будет доступен после проверки доступа.</p>
			</div>

			<div class="sonyra-login-badge" aria-live="polite">Проверка доступа</div>
			<p class="sonyra-login-note">После подтверждения входа доступ к Пульту сайта будет проверен отдельно.</p>
		</section>
		<?php
	}

	private static function render_error_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-error" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker">Пульт сайта</p>
				<h1 id="sonyra-login-title" class="sonyra-login-title">Вход не подтверждён</h1>
				<p class="sonyra-login-lead">Проверьте код и попробуйте ещё раз.</p>
			</div>

			<div class="sonyra-login-form">
				<button class="sonyra-login-button sonyra-login-button-primary" type="button">Повторить</button>
				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button">Изменить почту или логин</button>
				</div>
			</div>
		</section>
		<?php
	}
}
