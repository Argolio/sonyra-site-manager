# SONYRA Manager Section UX Standard

## 1. Назначение стандарта

- раздел `Страницы` является базовым эталоном оформления ПУЛЬТА САЙТА;
- все будущие разделы, подразделы и рабочие экраны должны следовать этому стандарту;
- Codex не должен придумывать новый layout, если нет явного разрешения на отдельный redesign;
- любые безопасные отклонения сначала сверяются с текущим UX-паттерном раздела `Страницы`.

## 2. Master UX Reference

Эталонным источником паттернов считаются:

- главный экран `Страницы`;
- workspace `Секции`;
- workspace `Виджеты`;
- workspace `Поп-апы`;
- связанные modal, badge, tooltip и notice patterns внутри раздела `Страницы`.

Этот документ не заменяет текущий UI `Страницы`, а фиксирует уже принятый стандарт.

## 3. Page Header Standard

- каждый раздел использует один большой верхний page header manager shell;
- eyebrow = название раздела;
- main title = смысл раздела и рабочая задача раздела;
- description = короткое спокойное объяснение раздела;
- actions размещаются справа в зоне actions существующего header;
- meta badges/chips показываются только если это реальные данные;
- второй hero/header внутри body запрещён.

## 4. Page Header Typography

Стандарт заголовка закрепляется по текущему эталону `Страницы`:

- eyebrow uppercase, фиолетовый, с letter-spacing;
- main title остаётся компактным manager title, а не display-hero;
- description использует muted спокойный стиль;
- title не должен превращаться в обычный случайный sentence-case paragraph;
- внутри body нельзя создавать произвольные огромные заголовки, дублирующие header.

## 5. Context Card Standard

Context card используется для внутренних рабочих режимов:

- располагается сразу под большим page header;
- показывает текущий контекст пользователя;
- слева содержит uppercase label и основной context title/subline;
- справа содержит релевантные actions;
- применяется в `Секции`, `Виджеты`, `Поп-апы`;
- будущие рабочие режимы должны использовать его вместо случайных hero-блоков.

## 6. Context Card Variants

### Variant A — Entity Context

Для режимов, где редактируется структура конкретной сущности.

Пример:

- `ТЕКУЩАЯ СТРАНИЦА`
- `Тестовая страница`
- `[К списку страниц]`

### Variant B — Page-Level Layer Context

Для page-level слоёв одной страницы.

Примеры:

- `ВИДЖЕТЫ СТРАНИЦЫ [?]`
- `Тестовая страница`
- `[К списку страниц] [Добавить виджет]`

- `ПОП-АПЫ СТРАНИЦЫ [?]`
- `Тестовая страница`
- `[К списку страниц] [Добавить поп-ап]`

### Variant C — Tool Context

Для внутренних инструментов раздела.

Пример будущего паттерна:

- `ЦВЕТОВАЯ БИБЛИОТЕКА [?]`
- `Цвета, градиенты и паттерны сайта`
- `[Вернуться в раздел Дизайн]`

## 7. Section Landing Cards Standard

Для разделов, где внутри будет несколько инструментов:

- раздел не должен сразу разворачивать один инструмент на весь экран, если архитектурно это tool section;
- внутри landing section должны быть cards/tools;
- инструмент открывается через явное action вроде `Настроить`;
- карточка инструмента показывает title, description и понятное action;
- паттерн обязателен для будущих design/tools sections, включая будущую цветовую библиотеку.

## 8. Workspace Body Standard

- body начинается после context card;
- body не дублирует заголовок из context card;
- body не дублирует primary action, если этот action уже стоит в context card;
- внутри body размещаются list/grid/empty state/editor;
- запрещены лишние hero/cards, повторяющие тот же смысл.

## 9. Panel Standard

Для двухколоночных и составных рабочих областей:

- panel title обязателен;
- help icon ставится рядом с panel title;
- action, если нужен, размещается справа от title row;
- контент панели начинается после понятного заголовочного ряда;
- spacing должен визуально отделять heading от content;
- glued elements и слипшиеся control rows запрещены.

## 10. Cards Standard

Для section/block/widget/popup cards:

- drag handle размещается отдельно слева;
- icon tile отделён от drag handle;
- card показывает title;
- card показывает type label;
- card показывает meta badges;
- actions размещаются справа;
- active state должен быть заметен, но не шумен;
- вертикальный слом текста недопустим;
- icon tile не должен “плавать” отдельно от content;
- `settings/delete` должны иметь приоритет над card select;
- drag handle должен быть визуально отличим от смысловой иконки.

## 11. Badge Standard

- statuses являются состояниями, а не действиями;
- корректные статусы: `Включён`, `Выключен`;
- некорректный badge-текст: `Включить виджет`;
- enabled state использует success-soft presentation;
- disabled state использует danger или muted-danger soft presentation;
- position, trigger и type metadata используют neutral/violet-soft presentation;
- badge должен выглядеть как badge, а не как plain text;
- счётчики обязаны использовать корректную русскую форму.

## 12. Help Icon / Tooltip Standard

- используется маленькая question icon, а не большая secondary button;
- иконка ставится рядом с heading, context label или panel title;
- help content приходит через Help Library key;
- открытие работает по hover, focus и click;
- `Escape` и click outside закрывают popover;
- popover должен оставаться viewport-safe;
- длинные объяснения живут в tooltip, а не дублируются видимым абзацем рядом.

## 13. Button Placement Standard

- primary action размещается в page header или context card;
- в body не должно быть дубля той же primary action;
- тексты desktop buttons должны оставаться в одну строку;
- `К списку страниц` или `Вернуться…` ставятся левее primary add action;
- glued buttons и случайные action clusters запрещены.

## 14. Modal Standard

- add modal, settings modal и destructive modal используют общий contract;
- modal состоит из header, body и footer;
- close button обязателен;
- destructive modal должен содержать item name;
- удаление без подтверждения запрещено;
- destructive style должен читаться визуально сразу.

## 15. Empty State Standard

- empty state должен быть спокойным и честным;
- fake buttons запрещены;
- слова вроде `заглушка` или `будущий этап` в видимом UI запрещены;
- если action реально работает, кнопку можно показать;
- если action не работает, показывать фейковое действие нельзя.

## 16. Russian Text / I18N Standard

- все видимые строки идут через `includes/i18n/ru.php`;
- English UI запрещён;
- i18n keys не содержат кириллицу;
- hardcoded RU в JS запрещён;
- сухие безличные заглушки нежелательны;
- по возможности избегается сиротский перенос одного слова;
- счётчики используют корректную русскую плюрализацию.

## 17. Future Section Requirements

Каждый будущий Codex prompt для section UI должен включать:

- использовать `SONYRA_MANAGER_SECTION_UX_STANDARD.md`;
- перед изменением провести аудит текущего section/workspace;
- не создавать второй hero/header;
- использовать context card pattern там, где есть внутренний рабочий режим;
- подключать help icons через Help Library;
- соблюдать badge standard;
- соблюдать button placement standard;
- отдавать финальный visual/UX report.

## 18. Color Library Future Pattern

- `Дизайн` должен развиваться как landing section, а не как один fullscreen tool по умолчанию;
- будущий экран цветовой библиотеки должен открываться как tool screen внутри раздела `Дизайн`;
- visible name инструмента должен быть `Цветовая библиотека`;
- technical naming `Color Controller` может сохраняться в архитектуре, store и service layer;
- tool screen цветовой библиотеки обязан использовать Variant C tool context card.

## 19. Component-Level Visual Details Standard

### Context label standard

- context labels являются service labels, а не primary accent;
- для context label запрещён произвольный фиолетовый accent, если это не active navigation state;
- используется тот же muted selector/pattern, что и в `Страницы`, прежде всего `.sonyra-pages-section .sonyra-pages-sections-context-label`;
- `font-size`, `font-weight`, `line-height`, `letter-spacing`, `color`, uppercase-подача и gap до title должны повторять эталонный selector, а не подбираться визуально;
- если в target-screen label стоит рядом с help icon, используется тот же label-row pattern и тот же gap, что у эталона `Страницы`.

### Help icon standard

- help icon обязан переиспользовать тот же DOM/class pattern, что и `Секции` / `Блоки секции`;
- canonical pattern: `.sonyra-help-tooltip-wrap` + `.sonyra-help-tooltip-trigger` + `.sonyra-help-popover`;
- trigger остаётся маленьким round secondary control, а не accent button;
- `padding`, `border-radius`, `background`, `border`, `color`, `hover`, `focus`, `icon size`, `line-height` и vertical alignment берутся из эталонного selector;
- per-screen custom visuals для help icon запрещены;
- tooltip content приходит только через Help Library key.

### Back action standard

- любой action вида `Вернуться…` / `К списку…` обязан использовать стандартный back button pattern;
- canonical button pattern берётся с `К списку страниц`;
- left arrow icon обязателен и ставится перед текстом;
- размер icon, gap между icon и text, `min-height`, `padding`, `font-size`, `font-weight`, `border-radius`, `border`, `background`, normal/hover/focus state должны совпадать с эталоном;
- plain text-only back actions запрещены;
- custom button shape для back action запрещён.

### Tabs/meta panel standard

- segmented tabs и meta counters живут внутри одной padded panel row;
- canonical container pattern берётся из `.sonyra-pages-toolbar-panel`;
- canonical tabs group pattern берётся из `.sonyra-pages-filter-group` и `.sonyra-pages-filter-chip`;
- первая tab не должна касаться левого edge panel;
- counters/meta row не должна касаться правого edge panel;
- desktop pattern: tabs слева, counters справа;
- mobile pattern: clean wrap с теми же стандартными gap, без схлопывания spacing;
- oversized stats cards запрещены, если inline counters уже достаточно.

### Spacing standard

- каждый internal tool screen обязан копировать эталон `Страницы` для `context card padding`, `body panel padding`, `tabs panel padding`, `row gaps`, `gap between label and help icon`, `gap between context card and workspace body`, `gap between tabs panel and cards grid/list`;
- нельзя клеить controls/text к краям panel или viewport;
- нельзя использовать arbitrary “почти такие же” spacing values, если эталонный selector уже существует;
- при отсутствии централизованного utility нужно либо переиспользовать existing class, либо документировать extracted standard value до merge.

### Final visual report requirement

- для каждого будущего UI patch обязателен DOM/CSS match table;
- в таблице должны быть: reference component from `Страницы`, target component, DOM/classes, CSS selectors, declared/computed values;
- обязательно фиксируются: `color`, `font-size`, `font-weight`, `line-height`, `letter-spacing`, `padding`, `margin/gap`, `border-radius`, `border`, `background`, `min-height`, `icon size`, `vertical alignment`;
- если target заметно отличается от reference и difference заранее не одобрен пользователем, Codex должен остановиться до внесения такого отклонения.
