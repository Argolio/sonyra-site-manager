<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Color_Controller {

	const OPTION_NAME    = 'sonyra_site_manager_color_controller';
	const OPTION_VERSION = '0.1.0';
	const NONCE_ACTION   = 'sonyra_color_controller';

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	public static function get_option_name() {
		return self::OPTION_NAME;
	}

	public static function get_default_data() {
		$defaults = array(
			'version'      => self::OPTION_VERSION,
			'colors'       => array(
				array(
					'id'         => 'color-brand-primary',
					'name'       => 'Основной фиолетовый',
					'slug'       => 'brand-primary',
					'type'       => 'color',
					'value_hex'  => '#7C3AED',
					'value_rgb'  => array( 124, 58, 237 ),
					'role'       => 'brand.primary',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-brand-deep',
					'name'       => 'Глубокий фиолетовый',
					'slug'       => 'brand-deep',
					'type'       => 'color',
					'value_hex'  => '#4C1D95',
					'value_rgb'  => array( 76, 29, 149 ),
					'role'       => 'brand.deep',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-surface-light',
					'name'       => 'Светлый фон',
					'slug'       => 'surface-light',
					'type'       => 'color',
					'value_hex'  => '#F8FAFC',
					'value_rgb'  => array( 248, 250, 252 ),
					'role'       => 'surface.light',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-text-primary',
					'name'       => 'Тёмный текст',
					'slug'       => 'text-primary',
					'type'       => 'color',
					'value_hex'  => '#111827',
					'value_rgb'  => array( 17, 24, 39 ),
					'role'       => 'text.primary',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-text-secondary',
					'name'       => 'Вторичный текст',
					'slug'       => 'text-secondary',
					'type'       => 'color',
					'value_hex'  => '#64748B',
					'value_rgb'  => array( 100, 116, 139 ),
					'role'       => 'text.secondary',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-brand-accent',
					'name'       => 'Акцентный розовый',
					'slug'       => 'brand-accent',
					'type'       => 'color',
					'value_hex'  => '#EC4899',
					'value_rgb'  => array( 236, 72, 153 ),
					'role'       => 'brand.accent',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
			),
			'gradients'    => array(
				array(
					'id'            => 'gradient-violet-accent',
					'name'          => 'Фиолетовый акцент',
					'slug'          => 'violet-accent',
					'type'          => 'gradient',
					'gradient_type' => 'linear',
					'angle'         => 135,
					'stops'         => array(
						array(
							'color_hex' => '#7C3AED',
							'position'  => 0,
						),
						array(
							'color_hex' => '#EC4899',
							'position'  => 55,
						),
						array(
							'color_hex' => '#F97316',
							'position'  => 100,
						),
					),
					'source'        => 'core',
					'created_at'    => '',
					'updated_at'    => '',
				),
			),
			'patterns'     => array(
				array(
					'id'           => 'pattern-soft-glow',
					'name'         => 'Мягкое свечение',
					'slug'         => 'soft-glow',
					'type'         => 'pattern',
					'pattern_type' => 'soft_glow',
					'colors'       => array(
						'base'     => '#FFFFFF',
						'accent_a' => '#EDE9FE',
						'accent_b' => '#FCE7F3',
						'accent_c' => '#DBEAFE',
					),
					'settings'     => array(
						'intensity' => 72,
						'blur'      => 24,
					),
					'source'       => 'core',
					'created_at'   => '',
					'updated_at'   => '',
				),
			),
			'presets'      => array(),
			'library_meta' => array(
				'updated_at' => '',
				'created_by' => 'core',
			),
		);

		return self::normalize_data( $defaults );
	}

	public static function get_data() {
		$stored = get_option( self::OPTION_NAME, null );

		if ( ! is_array( $stored ) ) {
			$default_data = self::get_default_data();
			self::persist_data( $default_data );
			return $default_data;
		}

		$normalized = self::normalize_data( $stored );

		if ( $normalized !== $stored ) {
			self::persist_data( $normalized );
		}

		return $normalized;
	}

	public static function save_data( array $data ) {
		$normalized = self::normalize_data( $data );
		$persisted  = self::persist_data( $normalized );

		if ( ! $persisted ) {
			return new WP_Error( 'sonyra_color_controller_save_failed', self::text( 'manager.design.colors.save_failed' ), array( 'status' => 500 ) );
		}

		return $normalized;
	}

	public static function normalize_data( array $data ) {
		$normalized_colors = array();
		$normalized_gradients = array();
		$normalized_patterns = array();
		$normalized_presets = array();
		$seen = array(
			'colors'    => array(),
			'gradients' => array(),
			'patterns'  => array(),
			'presets'   => array(),
		);

		foreach ( isset( $data['colors'] ) && is_array( $data['colors'] ) ? $data['colors'] : array() as $color ) {
			if ( ! is_array( $color ) ) {
				continue;
			}

			$normalized_color = self::normalize_color( $color );

			if ( empty( $normalized_color ) ) {
				continue;
			}

			$key = $normalized_color['slug'];

			if ( isset( $seen['colors'][ $key ] ) ) {
				continue;
			}

			$seen['colors'][ $key ] = true;
			$normalized_colors[]    = $normalized_color;
		}

		foreach ( isset( $data['gradients'] ) && is_array( $data['gradients'] ) ? $data['gradients'] : array() as $gradient ) {
			if ( ! is_array( $gradient ) ) {
				continue;
			}

			$normalized_gradient = self::normalize_gradient( $gradient );

			if ( empty( $normalized_gradient ) ) {
				continue;
			}

			$key = $normalized_gradient['slug'];

			if ( isset( $seen['gradients'][ $key ] ) ) {
				continue;
			}

			$seen['gradients'][ $key ] = true;
			$normalized_gradients[]    = $normalized_gradient;
		}

		foreach ( isset( $data['patterns'] ) && is_array( $data['patterns'] ) ? $data['patterns'] : array() as $pattern ) {
			if ( ! is_array( $pattern ) ) {
				continue;
			}

			$normalized_pattern = self::normalize_pattern( $pattern );

			if ( empty( $normalized_pattern ) ) {
				continue;
			}

			$key = $normalized_pattern['slug'];

			if ( isset( $seen['patterns'][ $key ] ) ) {
				continue;
			}

			$seen['patterns'][ $key ] = true;
			$normalized_patterns[]    = $normalized_pattern;
		}

		foreach ( isset( $data['presets'] ) && is_array( $data['presets'] ) ? $data['presets'] : array() as $preset ) {
			if ( ! is_array( $preset ) ) {
				continue;
			}

			$normalized_preset = self::normalize_preset( $preset );

			if ( empty( $normalized_preset ) ) {
				continue;
			}

			$key = $normalized_preset['slug'];

			if ( isset( $seen['presets'][ $key ] ) ) {
				continue;
			}

			$seen['presets'][ $key ] = true;
			$normalized_presets[]    = $normalized_preset;
		}

		$updated_at = isset( $data['library_meta']['updated_at'] ) ? sanitize_text_field( (string) $data['library_meta']['updated_at'] ) : '';
		$created_by = isset( $data['library_meta']['created_by'] ) ? self::sanitize_source( (string) $data['library_meta']['created_by'] ) : 'core';

		return array(
			'version'      => self::OPTION_VERSION,
			'colors'       => $normalized_colors,
			'gradients'    => $normalized_gradients,
			'patterns'     => $normalized_patterns,
			'presets'      => $normalized_presets,
			'library_meta' => array(
				'updated_at' => $updated_at,
				'created_by' => '' !== $created_by ? $created_by : 'core',
			),
		);
	}

	public static function normalize_color( array $color ) {
		$name      = isset( $color['name'] ) ? sanitize_text_field( (string) $color['name'] ) : '';
		$hex       = self::normalize_hex( isset( $color['value_hex'] ) ? $color['value_hex'] : '' );
		$rgb       = self::normalize_rgb( isset( $color['value_rgb'] ) ? $color['value_rgb'] : array() );
		$role      = self::sanitize_role( isset( $color['role'] ) ? (string) $color['role'] : '' );
		$source    = self::sanitize_source( isset( $color['source'] ) ? (string) $color['source'] : 'core' );
		$slug      = self::sanitize_slug( isset( $color['slug'] ) ? (string) $color['slug'] : $name );
		$created_at = isset( $color['created_at'] ) ? sanitize_text_field( (string) $color['created_at'] ) : '';
		$updated_at = isset( $color['updated_at'] ) ? sanitize_text_field( (string) $color['updated_at'] ) : '';

		if ( '' === $name || '' === $hex || empty( $rgb ) || '' === $slug ) {
			return array();
		}

		return array(
			'id'         => self::sanitize_id( isset( $color['id'] ) ? (string) $color['id'] : 'color-' . $slug ),
			'name'       => $name,
			'slug'       => $slug,
			'type'       => 'color',
			'value_hex'  => $hex,
			'value_rgb'  => $rgb,
			'role'       => $role,
			'source'     => '' !== $source ? $source : 'core',
			'created_at' => $created_at,
			'updated_at' => $updated_at,
		);
	}

	public static function normalize_gradient( array $gradient ) {
		$name          = isset( $gradient['name'] ) ? sanitize_text_field( (string) $gradient['name'] ) : '';
		$slug          = self::sanitize_slug( isset( $gradient['slug'] ) ? (string) $gradient['slug'] : $name );
		$gradient_type = isset( $gradient['gradient_type'] ) ? sanitize_key( (string) $gradient['gradient_type'] ) : 'linear';
		$angle         = isset( $gradient['angle'] ) ? (int) $gradient['angle'] : 135;
		$source        = self::sanitize_source( isset( $gradient['source'] ) ? (string) $gradient['source'] : 'core' );
		$created_at    = isset( $gradient['created_at'] ) ? sanitize_text_field( (string) $gradient['created_at'] ) : '';
		$updated_at    = isset( $gradient['updated_at'] ) ? sanitize_text_field( (string) $gradient['updated_at'] ) : '';
		$stops         = array();

		if ( 'linear' !== $gradient_type || '' === $name || '' === $slug ) {
			return array();
		}

		foreach ( isset( $gradient['stops'] ) && is_array( $gradient['stops'] ) ? $gradient['stops'] : array() as $stop ) {
			if ( ! is_array( $stop ) ) {
				continue;
			}

			$color_hex = self::normalize_hex( isset( $stop['color_hex'] ) ? $stop['color_hex'] : '' );
			$position  = isset( $stop['position'] ) ? (int) $stop['position'] : -1;

			if ( '' === $color_hex || $position < 0 || $position > 100 ) {
				continue;
			}

			$stops[] = array(
				'color_hex' => $color_hex,
				'position'  => $position,
			);
		}

		if ( count( $stops ) < 2 || count( $stops ) > 5 || $angle < 0 || $angle > 360 ) {
			return array();
		}

		usort(
			$stops,
			static function ( array $left, array $right ): int {
				return (int) $left['position'] <=> (int) $right['position'];
			}
		);

		return array(
			'id'            => self::sanitize_id( isset( $gradient['id'] ) ? (string) $gradient['id'] : 'gradient-' . $slug ),
			'name'          => $name,
			'slug'          => $slug,
			'type'          => 'gradient',
			'gradient_type' => 'linear',
			'angle'         => $angle,
			'stops'         => $stops,
			'source'        => '' !== $source ? $source : 'core',
			'created_at'    => $created_at,
			'updated_at'    => $updated_at,
		);
	}

	public static function normalize_pattern( array $pattern ) {
		$name         = isset( $pattern['name'] ) ? sanitize_text_field( (string) $pattern['name'] ) : '';
		$slug         = self::sanitize_slug( isset( $pattern['slug'] ) ? (string) $pattern['slug'] : $name );
		$pattern_type = isset( $pattern['pattern_type'] ) ? sanitize_key( (string) $pattern['pattern_type'] ) : '';
		$source       = self::sanitize_source( isset( $pattern['source'] ) ? (string) $pattern['source'] : 'core' );
		$created_at   = isset( $pattern['created_at'] ) ? sanitize_text_field( (string) $pattern['created_at'] ) : '';
		$updated_at   = isset( $pattern['updated_at'] ) ? sanitize_text_field( (string) $pattern['updated_at'] ) : '';
		$colors       = array();
		$settings     = array();

		if ( '' === $name || '' === $slug || ! in_array( $pattern_type, self::get_pattern_allowlist(), true ) ) {
			return array();
		}

		foreach ( isset( $pattern['colors'] ) && is_array( $pattern['colors'] ) ? $pattern['colors'] : array() as $key => $value ) {
			$key = sanitize_key( (string) $key );
			$hex = self::normalize_hex( $value );

			if ( '' === $key || '' === $hex ) {
				continue;
			}

			$colors[ $key ] = $hex;
		}

		foreach ( isset( $pattern['settings'] ) && is_array( $pattern['settings'] ) ? $pattern['settings'] : array() as $key => $value ) {
			$key = sanitize_key( (string) $key );

			if ( '' === $key ) {
				continue;
			}

			if ( is_numeric( $value ) ) {
				$settings[ $key ] = max( 0, min( 100, (int) $value ) );
			} elseif ( is_bool( $value ) ) {
				$settings[ $key ] = $value;
			} elseif ( is_string( $value ) ) {
				$settings[ $key ] = sanitize_text_field( $value );
			}
		}

		if ( empty( $colors ) ) {
			return array();
		}

		return array(
			'id'           => self::sanitize_id( isset( $pattern['id'] ) ? (string) $pattern['id'] : 'pattern-' . $slug ),
			'name'         => $name,
			'slug'         => $slug,
			'type'         => 'pattern',
			'pattern_type' => $pattern_type,
			'colors'       => $colors,
			'settings'     => $settings,
			'source'       => '' !== $source ? $source : 'core',
			'created_at'   => $created_at,
			'updated_at'   => $updated_at,
		);
	}

	public static function validate_hex( $value ) {
		return '' !== self::normalize_hex( $value );
	}

	public static function normalize_hex( $value ) {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return '';
		}

		$value = trim( (string) $value );

		if ( '' === $value || preg_match( '/javascript:|expression|url\(|var\(|rgb\(|hsl\(|calc\(/i', $value ) ) {
			return '';
		}

		$value = strtoupper( ltrim( $value, '#' ) );

		if ( preg_match( '/^[A-F0-9]{3}$/', $value ) ) {
			return '#' . $value[0] . $value[0] . $value[1] . $value[1] . $value[2] . $value[2];
		}

		if ( preg_match( '/^[A-F0-9]{6}$/', $value ) ) {
			return '#' . $value;
		}

		return '';
	}

	public static function normalize_rgb( $value ) {
		$components = array();

		if ( is_array( $value ) ) {
			if ( isset( $value['r'], $value['g'], $value['b'] ) ) {
				$components = array( $value['r'], $value['g'], $value['b'] );
			} else {
				$components = array_values( $value );
			}
		} elseif ( is_string( $value ) ) {
			if ( preg_match( '/javascript:|expression|url\(|var\(|rgb\(/i', $value ) ) {
				return array();
			}

			$components = preg_split( '/\s*,\s*/', trim( $value ) );
		}

		if ( 3 !== count( $components ) ) {
			return array();
		}

		$normalized = array();

		foreach ( $components as $component ) {
			if ( '' === (string) $component || ! is_numeric( $component ) ) {
				return array();
			}

			$channel = (int) $component;

			if ( $channel < 0 || $channel > 255 ) {
				return array();
			}

			$normalized[] = $channel;
		}

		return $normalized;
	}

	public static function hex_to_rgb( $hex ) {
		$normalized = self::normalize_hex( $hex );

		if ( '' === $normalized ) {
			return array();
		}

		return array(
			hexdec( substr( $normalized, 1, 2 ) ),
			hexdec( substr( $normalized, 3, 2 ) ),
			hexdec( substr( $normalized, 5, 2 ) ),
		);
	}

	public static function rgb_to_hex( $rgb ) {
		$normalized = self::normalize_rgb( $rgb );

		if ( empty( $normalized ) ) {
			return '';
		}

		return sprintf( '#%02X%02X%02X', $normalized[0], $normalized[1], $normalized[2] );
	}

	public static function create_nonce( array $context = array() ): string {
		$session_uuid = self::get_session_uuid_from_context( $context );

		if ( '' === $session_uuid ) {
			return '';
		}

		return self::build_nonce_for_tick( $session_uuid, self::get_nonce_tick() );
	}

	public static function verify_nonce( string $nonce, array $context = array() ): bool {
		$nonce        = sanitize_text_field( $nonce );
		$session_uuid = self::get_session_uuid_from_context( $context );

		if ( '' === $nonce || '' === $session_uuid ) {
			return false;
		}

		$current_tick = self::get_nonce_tick();

		return hash_equals( self::build_nonce_for_tick( $session_uuid, $current_tick ), $nonce )
			|| hash_equals( self::build_nonce_for_tick( $session_uuid, $current_tick - 1 ), $nonce );
	}

	public static function get_summary( array $data = array() ): array {
		if ( empty( $data ) ) {
			$data = self::get_data();
		}

		return array(
			'colors'    => isset( $data['colors'] ) && is_array( $data['colors'] ) ? count( $data['colors'] ) : 0,
			'gradients' => isset( $data['gradients'] ) && is_array( $data['gradients'] ) ? count( $data['gradients'] ) : 0,
			'patterns'  => isset( $data['patterns'] ) && is_array( $data['patterns'] ) ? count( $data['patterns'] ) : 0,
			'presets'   => isset( $data['presets'] ) && is_array( $data['presets'] ) ? count( $data['presets'] ) : 0,
		);
	}

	public static function get_i18n_keys(): array {
		return array(
			'manager.design.eyebrow',
			'manager.design.title',
			'manager.design.description',
			'manager.design.tools.color_library.title',
			'manager.design.tools.color_library.description',
			'manager.design.tools.color_library.action',
			'manager.design.colors.title',
			'manager.design.colors.description',
			'manager.design.colors.context_title',
			'manager.design.colors.context_subtitle',
			'manager.design.colors.back_to_design',
			'manager.design.colors.tab_colors',
			'manager.design.colors.tab_gradients',
			'manager.design.colors.tab_patterns',
			'manager.design.colors.colors_title',
			'manager.design.colors.gradients_title',
			'manager.design.colors.patterns_title',
			'manager.design.colors.colors_count',
			'manager.design.colors.gradients_count',
			'manager.design.colors.patterns_count',
			'manager.design.colors.empty_title',
			'manager.design.colors.empty_description',
			'manager.design.colors.preview_color',
			'manager.design.colors.preview_gradient',
			'manager.design.colors.preview_pattern',
			'manager.design.colors.hex_label',
			'manager.design.colors.rgb_label',
			'manager.design.colors.role_label',
			'manager.design.colors.updated_label',
			'manager.design.colors.gradient_angle_label',
			'manager.design.colors.gradient_stops_label',
			'manager.design.colors.pattern_type_label',
			'manager.design.colors.pattern_colors_label',
			'manager.design.colors.count_color_one',
			'manager.design.colors.count_color_few',
			'manager.design.colors.count_color_many',
			'manager.design.colors.count_gradient_one',
			'manager.design.colors.count_gradient_few',
			'manager.design.colors.count_gradient_many',
			'manager.design.colors.count_pattern_one',
			'manager.design.colors.count_pattern_few',
			'manager.design.colors.count_pattern_many',
			'manager.design.colors.library_group_colors',
			'manager.design.colors.library_group_gradients',
			'manager.design.colors.library_group_patterns',
			'manager.pages.actions.help_tooltip',
		);
	}

	public static function get_manager_payload( string $api_url = '', string $nonce = '' ): array {
		$payload = class_exists( 'Sonyra_Site_Manager_I18n' ) ? Sonyra_Site_Manager_I18n::get_payload() : array(
			'currentLocale'  => 'ru_RU',
			'fallbackLocale' => 'ru_RU',
			'dictionary'     => array(),
		);
		$dictionary = array();

		foreach ( self::get_i18n_keys() as $key ) {
			$dictionary[ $key ] = self::text( $key );
		}

		$payload['dictionary'] = $dictionary;
		$payload['data']       = self::get_data();
		$payload['summary']    = self::get_summary( $payload['data'] );
		$payload['apiUrl']     = esc_url_raw( $api_url );
		$payload['nonce']      = sanitize_text_field( $nonce );
		$payload['helpKey']    = 'design.colors.controller';

		return $payload;
	}

	private static function normalize_preset( array $preset ) {
		$name       = isset( $preset['name'] ) ? sanitize_text_field( (string) $preset['name'] ) : '';
		$slug       = self::sanitize_slug( isset( $preset['slug'] ) ? (string) $preset['slug'] : $name );
		$source     = self::sanitize_source( isset( $preset['source'] ) ? (string) $preset['source'] : 'core' );
		$created_at = isset( $preset['created_at'] ) ? sanitize_text_field( (string) $preset['created_at'] ) : '';
		$updated_at = isset( $preset['updated_at'] ) ? sanitize_text_field( (string) $preset['updated_at'] ) : '';

		if ( '' === $name || '' === $slug ) {
			return array();
		}

		return array(
			'id'         => self::sanitize_id( isset( $preset['id'] ) ? (string) $preset['id'] : 'preset-' . $slug ),
			'name'       => $name,
			'slug'       => $slug,
			'type'       => 'preset',
			'colors'     => self::sanitize_reference_list( isset( $preset['colors'] ) && is_array( $preset['colors'] ) ? $preset['colors'] : array() ),
			'gradients'  => self::sanitize_reference_list( isset( $preset['gradients'] ) && is_array( $preset['gradients'] ) ? $preset['gradients'] : array() ),
			'patterns'   => self::sanitize_reference_list( isset( $preset['patterns'] ) && is_array( $preset['patterns'] ) ? $preset['patterns'] : array() ),
			'source'     => '' !== $source ? $source : 'core',
			'created_at' => $created_at,
			'updated_at' => $updated_at,
		);
	}

	private static function sanitize_reference_list( array $references ): array {
		$normalized = array();

		foreach ( $references as $reference ) {
			$reference = self::sanitize_slug( (string) $reference );

			if ( '' === $reference || in_array( $reference, $normalized, true ) ) {
				continue;
			}

			$normalized[] = $reference;
		}

		return $normalized;
	}

	private static function get_pattern_allowlist(): array {
		return array(
			'soft_glow',
			'soft_blobs',
			'diagonal_wave',
			'accent_orbit',
			'deep_background',
			'color_splash',
			'subtle_grid',
			'radial_aura',
		);
	}

	private static function persist_data( array $data ): bool {
		if ( false === get_option( self::OPTION_NAME, false ) ) {
			return add_option( self::OPTION_NAME, $data, '', false );
		}

		return update_option( self::OPTION_NAME, $data, false );
	}

	private static function sanitize_slug( string $value ): string {
		$slug = sanitize_title( $value );

		return sanitize_key( $slug );
	}

	private static function sanitize_id( string $value ): string {
		$value = strtolower( trim( $value ) );
		$value = (string) preg_replace( '/[^a-z0-9_-]/', '-', $value );
		$value = trim( $value, '-' );

		return '' !== $value ? $value : sanitize_key( uniqid( 'sonyra-color-', true ) );
	}

	private static function sanitize_role( string $value ): string {
		$value = strtolower( trim( $value ) );

		return (string) preg_replace( '/[^a-z0-9._-]/', '', $value );
	}

	private static function sanitize_source( string $value ): string {
		$value = strtolower( trim( $value ) );

		return (string) preg_replace( '/[^a-z0-9._-]/', '', $value );
	}

	private static function get_session_uuid_from_context( array $context ): string {
		if ( empty( $context ) && class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			$context = Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();
		}

		return isset( $context['session_uuid'] ) ? sanitize_text_field( (string) $context['session_uuid'] ) : '';
	}

	private static function get_nonce_tick(): int {
		return (int) ceil( time() / ( 12 * HOUR_IN_SECONDS ) );
	}

	private static function build_nonce_for_tick( string $session_uuid, int $tick ): string {
		$data = $session_uuid . '|' . self::NONCE_ACTION . '|' . (string) $tick;

		return substr( wp_hash( $data, 'nonce' ), -12, 10 );
	}
}
