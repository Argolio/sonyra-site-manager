<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Status {

	public static function get_product_name(): string {
		return 'Пульт сайта';
	}

	public static function get_platform_name(): string {
		return 'SONYRA Site Platform';
	}

	public static function get_publisher(): string {
		return 'SONYRA STUDIO';
	}

	public static function get_licensor(): string {
		return 'ИП Катаев С.А. / IPKTFSA';
	}

	public static function get_technical_name(): string {
		return 'sonyra-site-manager';
	}

	public static function get_version(): string {
		return SONYRA_SITE_MANAGER_VERSION;
	}

	public static function get_release_channel(): string {
		return 'manual_zip';
	}

	public static function get_build_type(): string {
		return 'foundation';
	}

	public static function get_release_metadata(): array {
		return array(
			'product_name'    => self::get_product_name(),
			'platform_name'   => self::get_platform_name(),
			'publisher'       => self::get_publisher(),
			'licensor'        => self::get_licensor(),
			'technical_name'  => self::get_technical_name(),
			'version'         => self::get_version(),
			'release_channel' => self::get_release_channel(),
			'build_type'      => self::get_build_type(),
			'text_domain'     => 'sonyra-site-manager',
			'main_file'       => 'sonyra-site-manager.php',
			'copyright'       => '© 2026 SONYRA STUDIO',
		);
	}

	public static function get_runtime_status(): array {
		$owner_user_id      = 0;
		$capabilities_count = 0;

		if ( class_exists( 'Sonyra_Site_Manager_Permissions' ) ) {
			$owner_user_id      = Sonyra_Site_Manager_Permissions::get_owner_user_id();
			$capabilities_count = count( Sonyra_Site_Manager_Permissions::get_capabilities() );
		}

		return array(
			'product_name'        => self::get_product_name(),
			'version'             => self::get_version(),
			'installed_version'   => (string) get_option( 'sonyra_site_manager_version', '' ),
			'last_known_version'  => (string) get_option( 'sonyra_site_manager_last_known_version', '' ),
			'owner_user_id'       => $owner_user_id,
			'release_channel'     => self::get_release_channel(),
			'build_type'          => self::get_build_type(),
			'php_version'         => PHP_VERSION,
			'wp_version'          => get_bloginfo( 'version' ),
			'capabilities_count'  => $capabilities_count,
			'is_foundation_ready' => '' !== self::get_version() && class_exists( 'Sonyra_Site_Manager_Permissions' ) && $capabilities_count > 0,
		);
	}
}
