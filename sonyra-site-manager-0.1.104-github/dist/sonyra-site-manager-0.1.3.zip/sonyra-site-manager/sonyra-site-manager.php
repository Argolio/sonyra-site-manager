<?php
/**
 * Plugin Name: Пульт сайта
 * Description: Базовый плагин платформы SONYRA Site Platform для управления самостоятельными страницами, брендом, модулями и кодами вставки.
 * Version: 0.1.3
 * Author: SONYRA STUDIO
 * Text Domain: sonyra-site-manager
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SONYRA_SITE_MANAGER_VERSION', '0.1.3' );
define( 'SONYRA_SITE_MANAGER_FILE', __FILE__ );
define( 'SONYRA_SITE_MANAGER_DIR', plugin_dir_path( __FILE__ ) );
define( 'SONYRA_SITE_MANAGER_URL', plugin_dir_url( __FILE__ ) );
define( 'SONYRA_SITE_MANAGER_BASENAME', plugin_basename( __FILE__ ) );

require_once SONYRA_SITE_MANAGER_DIR . 'includes/class-sonyra-site-manager-plugin.php';
require_once SONYRA_SITE_MANAGER_DIR . 'includes/class-sonyra-site-manager-permissions.php';
require_once SONYRA_SITE_MANAGER_DIR . 'includes/class-sonyra-site-manager-status.php';
require_once SONYRA_SITE_MANAGER_DIR . 'includes/class-sonyra-site-manager-installer.php';
require_once SONYRA_SITE_MANAGER_DIR . 'includes/class-sonyra-site-manager-activator.php';
require_once SONYRA_SITE_MANAGER_DIR . 'includes/class-sonyra-site-manager-deactivator.php';

register_activation_hook( __FILE__, array( 'Sonyra_Site_Manager_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Sonyra_Site_Manager_Deactivator', 'deactivate' ) );

$sonyra_site_manager_plugin = new Sonyra_Site_Manager_Plugin( SONYRA_SITE_MANAGER_VERSION );
$sonyra_site_manager_plugin->run();
