<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Public_Page_Route {

	public static function register_hooks(): void {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render_public_page' ), 8 );
	}

	public static function maybe_render_public_page(): void {
		if ( self::should_skip_request() || ! class_exists( 'Sonyra_Site_Manager_Pages_Store' ) ) {
			return;
		}

		$preview_request = self::get_preview_request();

		if ( null !== $preview_request ) {
			if ( ! self::can_access_preview() ) {
				self::render_safe_404();
				exit;
			}

			$page = Sonyra_Site_Manager_Pages_Store::find_page_for_preview( $preview_request['identifier'], $preview_request['mode'] );

			if ( empty( $page ) ) {
				self::render_safe_404();
				exit;
			}

			self::render_page( $page, true );
			exit;
		}

		$slug = self::get_request_slug();

		if ( null === $slug ) {
			return;
		}

		if ( '' !== $slug && ! function_exists( 'is_404' ) ) {
			return;
		}

		if ( '' !== $slug && ! is_404() ) {
			return;
		}

		$page = Sonyra_Site_Manager_Pages_Store::find_public_page_by_slug( $slug );

		if ( empty( $page ) ) {
			return;
		}

		self::render_page( $page, false );
		exit;
	}

	private static function should_skip_request(): bool {
		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ) {
			return true;
		}

		$path = self::get_request_path();

		if ( preg_match( '#\.(?:css|js|json|xml|txt|ico|png|jpg|jpeg|gif|webp|svg|woff|woff2|ttf|map)$#i', $path ) ) {
			return true;
		}

		foreach ( array( 'manager', 'wp-admin', 'wp-json', 'wp-content', 'wp-includes' ) as $prefix ) {
			if ( $prefix === $path || 0 === strpos( $path, $prefix . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	private static function get_request_slug(): ?string {
		$path = self::get_request_path();

		if ( '' === $path ) {
			return '';
		}

		if ( false !== strpos( $path, '/' ) ) {
			return null;
		}

		return sanitize_title( $path );
	}

	private static function get_preview_request(): ?array {
		$path = self::get_request_path();

		if ( 0 !== strpos( $path, 'sonyra-preview/' ) ) {
			return null;
		}

		$parts = array_values( array_filter( explode( '/', $path ) ) );

		if ( 3 === count( $parts ) && 'id' === $parts[1] ) {
			return array(
				'mode'       => 'id',
				'identifier' => sanitize_key( $parts[2] ),
			);
		}

		if ( 2 === count( $parts ) ) {
			return array(
				'mode'       => 'slug',
				'identifier' => sanitize_title( $parts[1] ),
			);
		}

		return null;
	}

	private static function get_request_path(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );

		if ( '' !== $home_path && '/' !== $home_path && 0 === strpos( $path, $home_path ) ) {
			$path = substr( $path, strlen( $home_path ) );
		}

		return trim( $path, '/' );
	}

	private static function render_page( array $page, bool $is_preview = false ): void {
		$title = '' !== (string) $page['seo_title'] ? (string) $page['seo_title'] : (string) $page['title'];
		$description = isset( $page['seo_description'] ) ? (string) $page['seo_description'] : '';

		if ( function_exists( 'status_header' ) ) {
			status_header( 200 );
		}

		if ( function_exists( 'nocache_headers' ) ) {
			nocache_headers();
		}

		if ( $is_preview ) {
			header( 'X-Robots-Tag: noindex, nofollow', true );
		}

			?>
	<!doctype html>
	<html <?php language_attributes(); ?>>
	<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php echo esc_html( $title ); ?></title>
		<?php if ( '' !== $description ) : ?>
		<meta name="description" content="<?php echo esc_attr( $description ); ?>">
		<?php endif; ?>
		<?php if ( $is_preview ) : ?>
		<meta name="robots" content="noindex,nofollow">
		<?php endif; ?>
		<?php self::render_stylesheet_link(); ?>
		<?php wp_head(); ?>
	</head>
	<body class="sonyra-public-site<?php echo $is_preview ? ' sonyra-public-site-preview' : ''; ?>">
		<main class="sonyra-public-site-main sonyra-public-site-shell">
			<header class="sonyra-public-page-header">
				<h1><?php echo esc_html( (string) $page['title'] ); ?></h1>
			</header>
			<?php self::render_sections( isset( $page['sections'] ) && is_array( $page['sections'] ) ? $page['sections'] : array(), $page ); ?>
		</main>
		<?php wp_footer(); ?>
	</body>
	</html>
			<?php
	}

	private static function render_sections( array $sections, array $page ): void {
		unset( $page );
		$has_renderable_blocks = false;

		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) || self::should_skip_unavailable_section( $section ) ) {
				continue;
			}

			$blocks = self::get_section_blocks( $section );

			if ( ! empty( $blocks ) ) {
				$has_renderable_blocks = true;
				break;
			}
		}

		if ( ! $has_renderable_blocks ) {
			$legacy_blocks = array();

			foreach ( $sections as $section ) {
				if ( is_array( $section ) && self::has_legacy_section_content( $section ) ) {
					$legacy_blocks[] = $section;
				}
			}

			$has_renderable_blocks = ! empty( $legacy_blocks );
		}

		if ( empty( $sections ) || ! $has_renderable_blocks ) {
			?>
				<section class="sonyra-public-section sonyra-public-section-text sonyra-public-section-empty">
					<p><?php echo esc_html( self::text( 'manager.pages.preview.empty_sections' ) ); ?></p>
				</section>
				<?php
			return;
		}

		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) || self::should_skip_unavailable_section( $section ) ) {
				continue;
			}

			self::render_section( $section );
		}
	}

	private static function render_section( array $section ): void {
		$type   = isset( $section['type'] ) ? sanitize_key( (string) $section['type'] ) : 'text';
		$blocks = self::get_section_blocks( $section );

		if ( empty( $blocks ) ) {
			return;
		}

		if ( in_array( $type, array( 'hero', 'text', 'contacts' ), true ) && 1 === count( $blocks ) ) {
			$block = $blocks[0];
			$block_type = isset( $block['type'] ) ? sanitize_key( (string) $block['type'] ) : 'text';

			if ( 'hero' === $block_type ) {
				self::render_hero_section( $block );
				return;
			}

			if ( 'contacts' === $block_type ) {
				self::render_contacts_section( $block );
				return;
			}

			self::render_text_section( $block );
			return;
		}

		self::render_generic_section( $section, $blocks );
	}

	private static function render_hero_section( array $section ): void {
		?>
		<section class="sonyra-public-section sonyra-public-section-hero">
			<?php if ( ! empty( $section['kicker'] ) ) : ?>
				<p class="sonyra-public-kicker"><?php echo esc_html( (string) $section['kicker'] ); ?></p>
			<?php endif; ?>
				<?php if ( ! empty( $section['heading'] ) ) : ?>
					<h1><?php echo esc_html( (string) $section['heading'] ); ?></h1>
				<?php endif; ?>
			<?php if ( ! empty( $section['text'] ) ) : ?>
				<p><?php echo nl2br( esc_html( (string) $section['text'] ) ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $section['button_label'] ) && ! empty( $section['button_url'] ) ) : ?>
				<a class="sonyra-public-button" href="<?php echo esc_url( (string) $section['button_url'] ); ?>"><?php echo esc_html( (string) $section['button_label'] ); ?></a>
			<?php endif; ?>
		</section>
		<?php
	}

	private static function render_text_section( array $section ): void {
		?>
		<section class="sonyra-public-section sonyra-public-section-text">
				<?php if ( ! empty( $section['heading'] ) ) : ?>
					<h2><?php echo esc_html( (string) $section['heading'] ); ?></h2>
				<?php endif; ?>
			<?php if ( ! empty( $section['text'] ) ) : ?>
				<p><?php echo nl2br( esc_html( (string) $section['text'] ) ); ?></p>
			<?php endif; ?>
		</section>
		<?php
	}

	private static function render_contacts_section( array $section ): void {
		?>
		<section class="sonyra-public-section sonyra-public-section-contacts">
				<?php if ( ! empty( $section['heading'] ) ) : ?>
					<h2><?php echo esc_html( (string) $section['heading'] ); ?></h2>
				<?php endif; ?>
				<?php if ( ! empty( $section['description'] ) ) : ?>
					<p><?php echo nl2br( esc_html( (string) $section['description'] ) ); ?></p>
				<?php elseif ( ! empty( $section['text'] ) ) : ?>
					<p><?php echo nl2br( esc_html( (string) $section['text'] ) ); ?></p>
				<?php endif; ?>
			<div class="sonyra-public-contact-list">
				<?php if ( ! empty( $section['email'] ) ) : ?>
					<a href="<?php echo esc_url( 'mailto:' . sanitize_email( (string) $section['email'] ) ); ?>"><?php echo esc_html( (string) $section['email'] ); ?></a>
				<?php endif; ?>
				<?php if ( ! empty( $section['phone'] ) ) : ?>
					<span><?php echo esc_html( (string) $section['phone'] ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $section['address'] ) ) : ?>
					<span><?php echo esc_html( (string) $section['address'] ); ?></span>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	private static function render_generic_section( array $section, array $blocks ): void {
		$type = isset( $section['type'] ) ? sanitize_key( (string) $section['type'] ) : 'text';
		$heading = self::get_section_heading( $section, $blocks );
		?>
		<section class="sonyra-public-section sonyra-public-section-generic sonyra-public-section-<?php echo esc_attr( $type ); ?>">
			<?php if ( '' !== $heading ) : ?>
				<h2><?php echo esc_html( $heading ); ?></h2>
			<?php endif; ?>
			<div class="sonyra-public-section-stack">
				<?php foreach ( $blocks as $block ) : ?>
					<?php self::render_generic_block( is_array( $block ) ? $block : array() ); ?>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
	}

	private static function render_generic_block( array $block ): void {
		$heading = isset( $block['heading'] ) ? (string) $block['heading'] : '';
		$text = isset( $block['text'] ) ? (string) $block['text'] : '';
		$description = isset( $block['description'] ) ? (string) $block['description'] : '';
		?>
		<article class="sonyra-public-generic-block">
			<?php if ( '' !== $heading ) : ?>
				<h3><?php echo esc_html( $heading ); ?></h3>
			<?php endif; ?>
			<?php if ( '' !== $description ) : ?>
				<p><?php echo nl2br( esc_html( $description ) ); ?></p>
			<?php elseif ( '' !== $text ) : ?>
				<p><?php echo nl2br( esc_html( $text ) ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $block['button_label'] ) && ! empty( $block['button_url'] ) ) : ?>
				<a class="sonyra-public-button" href="<?php echo esc_url( (string) $block['button_url'] ); ?>"><?php echo esc_html( (string) $block['button_label'] ); ?></a>
			<?php endif; ?>
		</article>
		<?php
	}

	private static function can_access_preview(): bool {
		if ( ! class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			return false;
		}

		$context = Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();

		return ! empty( $context['authenticated'] ) && Sonyra_Site_Manager_Auth_Access_Guard::can_manage_content( $context );
	}

	private static function render_safe_404(): void {
		if ( function_exists( 'status_header' ) ) {
			status_header( 404 );
		}

		if ( function_exists( 'nocache_headers' ) ) {
			nocache_headers();
		}
	}

	private static function render_stylesheet_link(): void {
		$version = defined( 'SONYRA_SITE_MANAGER_VERSION' ) ? SONYRA_SITE_MANAGER_VERSION : '1';

		if ( defined( 'SONYRA_SITE_MANAGER_FILE' ) ) {
			$css_url = plugins_url( 'assets/css/sonyra-manager.css', SONYRA_SITE_MANAGER_FILE );
			?>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( $version ); ?>">
			<?php
		}
	}

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	private static function get_section_blocks( array $section ): array {
		if ( isset( $section['blocks'] ) && is_array( $section['blocks'] ) && ! empty( $section['blocks'] ) ) {
			return $section['blocks'];
		}

		if ( self::has_legacy_section_content( $section ) ) {
			return array(
				array(
					'type'         => isset( $section['type'] ) ? (string) $section['type'] : 'text',
					'kicker'       => isset( $section['kicker'] ) ? (string) $section['kicker'] : '',
					'heading'      => isset( $section['title'] ) ? (string) $section['title'] : '',
					'text'         => isset( $section['text'] ) ? (string) $section['text'] : '',
					'description'  => isset( $section['text'] ) ? (string) $section['text'] : '',
					'button_label' => isset( $section['button_label'] ) ? (string) $section['button_label'] : '',
					'button_url'   => isset( $section['button_url'] ) ? (string) $section['button_url'] : '',
					'email'        => isset( $section['email'] ) ? (string) $section['email'] : '',
					'phone'        => isset( $section['phone'] ) ? (string) $section['phone'] : '',
					'address'      => isset( $section['address'] ) ? (string) $section['address'] : '',
				),
			);
		}

		return array();
	}

	private static function get_section_heading( array $section, array $blocks ): string {
		if ( isset( $blocks[0]['heading'] ) && '' !== (string) $blocks[0]['heading'] ) {
			return (string) $blocks[0]['heading'];
		}

		if ( ! empty( $section['name'] ) ) {
			return (string) $section['name'];
		}

		$definition = self::get_section_definition( isset( $section['type'] ) ? (string) $section['type'] : '' );

		return isset( $definition['label'] ) ? (string) $definition['label'] : '';
	}

	private static function get_section_definition( string $type ): array {
		if ( class_exists( 'Sonyra_Site_Manager_Page_Elements_Library' ) ) {
			return Sonyra_Site_Manager_Page_Elements_Library::get_section_definition( $type );
		}

		return array();
	}

	private static function should_skip_unavailable_section( array $section ): bool {
		$type = isset( $section['type'] ) ? sanitize_key( (string) $section['type'] ) : '';

		if ( empty( $section['unavailable'] ) ) {
			return false;
		}

		return empty( self::get_section_definition( $type ) );
	}

	private static function has_legacy_section_content( array $section ): bool {
		foreach ( array( 'kicker', 'title', 'text', 'button_label', 'button_url', 'email', 'phone', 'address' ) as $key ) {
			if ( ! empty( $section[ $key ] ) ) {
				return true;
			}
		}

		return false;
	}
}
