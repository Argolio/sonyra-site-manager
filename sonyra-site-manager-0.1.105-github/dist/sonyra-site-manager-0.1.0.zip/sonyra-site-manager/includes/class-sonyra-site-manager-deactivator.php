<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Deactivator {

	public static function deactivate() {
		// Данные и настройки не удаляются на деактивации.
	}
}
