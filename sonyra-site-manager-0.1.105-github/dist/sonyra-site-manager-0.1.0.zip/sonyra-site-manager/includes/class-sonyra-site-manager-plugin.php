<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Plugin {

	/**
	 * @var string
	 */
	private $version;

	public function __construct( $version ) {
		$this->version = $version;
	}

	public function run() {
		// Загрузка подсистем будет добавляться отдельными безопасными этапами.
	}

	public function get_version() {
		return $this->version;
	}
}
