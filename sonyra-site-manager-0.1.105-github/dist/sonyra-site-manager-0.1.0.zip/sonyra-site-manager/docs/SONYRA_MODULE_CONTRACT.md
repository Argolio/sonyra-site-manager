# SONYRA Module Contract

## Назначение

Этот документ фиксирует контракт будущей модульной системы SONYRA Site Manager.

SONYRA Site Manager должен развиваться как модульная система SONYRA Site Platform, а не как монолитный комбайн.

## Общие правила SONYRA

Во всех будущих модулях используются только канонические написания:

- SONYRA
- SONYRA Site Platform
- SONYRA Site Manager
- SONYRA STUDIO

Неправильные варианты Sonira, Sanira, Sunaira, Сонира нельзя использовать как рабочие названия.

Весь видимый пользовательский интерфейс будущего продукта должен быть только на русском языке.

Английские пользовательские UI-строки и англицизмы запрещены.

Исключения допустимы только для технически неизбежных терминов: API, REST, HTML, iframe, URL, JSON, CSS, JS, PHP, WordPress, shortcode, nonce, slug.

Пользовательские строки будущего интерфейса должны идти через i18n.

Будущий основной i18n-файл:

- assets/i18n/i18n-ru.js

Будущий helper:

- t('key')

Никаких “красивых, но мёртвых” кнопок. Каждый интерактивный элемент должен иметь рабочую цепочку:

DOM/root selector -> selector элемента -> handler -> loading state -> request/action -> success/error render -> UI update.

Deploy по умолчанию запрещён. Будущие zip-релизы собираются только в ./dist/. Предыдущие zip-релизы нельзя удалять.

## Принцип модульной архитектуры

Ядро SONYRA Site Manager не должно становиться монолитным комбайном.

Будущие модули подключаются через Module Registry.

Личный кабинет не встраивается в ядро как основная логика. Он подключается как будущий модуль SONYRA Account или SONYRA Personal Cabinet.

Ядро может содержать только foundation для OTP, account routes и permissions.

## Ограничения модулей

Модуль не может:

- напрямую ломать ядро;
- самовольно создавать публичные маршруты без регистрации;
- добавлять видимые строки вне i18n;
- добавлять английские пользовательские UI-строки;
- подключать случайные стили, обходя design system;
- обходить Permission Service;
- обходить Audit Log для важных действий;
- использовать WordPress Pages как основу публичных страниц;
- использовать shortcode как основу архитектуры страниц;
- использовать старый NDD-код, manager-app.js или manager-v2 как основу.

## Module Registry

Module Registry должен быть единственной точкой регистрации будущих модулей.

Registry отвечает за:

- регистрацию manifest;
- проверку dependencies;
- регистрацию permissions;
- регистрацию manager routes;
- регистрацию REST endpoints;
- регистрацию page blocks;
- регистрацию i18n-ключей;
- регистрацию assets;
- регистрацию embeds и shortcodes;
- отключение модуля без поломки ядра.

## Manifest format

Будущий manifest модуля должен предусматривать поля:

- id
- name
- version
- description
- status
- dependencies
- permissions
- manager_menu_items
- manager_routes
- dashboard_widgets
- page_blocks
- rest_routes
- assets
- i18n
- settings_schema
- embeds
- shortcodes
- account_routes
- billing_features
- analytics_events

## Security contract

Каждый модуль должен использовать Permission Service для действий, routes, REST endpoints, manager UI и embed/export-сценариев.

Важные действия модуля должны создавать audit events через Audit Log.

Модуль не может регистрировать приватный REST endpoint без nonce/session check, capability check, sanitize input, validate input и escape output.

## UI contract

Каждый UI-элемент модуля должен:

- иметь видимые строки только на русском языке;
- получать пользовательские строки через assets/i18n/i18n-ru.js и t('key');
- соблюдать design system;
- иметь доказанную рабочую цепочку;
- не содержать английские fallback-строки.

## Модульный отчёт

Каждый будущий этап добавления или изменения модуля должен включать отчёт:

- какие routes добавлены;
- какие permissions нужны;
- какие i18n keys добавлены;
- какие assets подключены;
- какие REST endpoints добавлены;
- какие audit events создаются;
- какие UI-цепочки доказаны;
- какие проверки выполнены;
- есть ли STOP-срабатывания.

## STOP-условия

Немедленно остановиться, если модуль требует обхода Module Registry, Permission Service, Audit Log, i18n, design system, security rules или правил русского UI.
