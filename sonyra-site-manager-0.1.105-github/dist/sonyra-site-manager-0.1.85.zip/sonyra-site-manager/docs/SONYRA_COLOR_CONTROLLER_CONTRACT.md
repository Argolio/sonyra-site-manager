# SONYRA Color Controller Contract

## 1. Purpose

Color Controller is the system design layer of SONYRA Site Manager. It stores colors, gradients, patterns and the reusable site library that will later connect to sections, blocks, widgets, popups, header, footer and global text colors.

Visible UX for this system must follow `docs/SONYRA_MANAGER_SECTION_UX_STANDARD.md`.

## 2. Store

- option name: `sonyra_site_manager_color_controller`
- autoload: `false`
- current store version: `0.1.0`
- DB migration is not used in releases `0.1.76` and `0.1.77`

Root shape:

- `version`
- `colors[]`
- `gradients[]`
- `patterns[]`
- `presets[]`
- `library_meta`

## 3. Colors

- each color stores `value_hex` and `value_rgb`
- HEX is normalized to uppercase `#RRGGBB`
- RGB is stored as a numeric array `[r, g, b]`
- roles use technical keys such as `brand.primary` and `text.secondary`
- invalid colors are rejected and not saved

## 4. Gradients

- only `linear` gradients are allowed in `0.1.77`
- each gradient stores `angle` and `stops[]`
- manager CRUD in `0.1.77` saves a safe two-stop gradient form and persists normalized stops
- each stop stores valid `color_hex`
- each stop position is limited to `0–100`
- raw CSS input is not accepted

## 5. Patterns

- patterns use an allowlist of `pattern_type`
- arbitrary CSS patterns are not accepted
- pattern colors are stored as normalized HEX values
- settings are limited to safe scalar values

Allowed pattern types:

- `dots`
- `grid`
- `diagonal_lines`
- `soft_glow`
- `soft_blobs`
- `diagonal_wave`
- `accent_orbit`
- `deep_background`
- `color_splash`
- `subtle_grid`
- `radial_aura`

## 6. Library

- the library stores saved colors, gradients and patterns
- the manager UI shows the default core library immediately after first load
- future releases may add user-created presets and richer reuse workflows

## 7. Tokens

- future integrations should reference design tokens instead of raw display values when possible
- token references should still keep safe fallback values for stable rendering

## 8. Integration Roadmap

Future connection points:

- sections
- blocks
- widgets
- popups
- header
- footer
- global text colors
- public CSS variables

## 9. Security

- no raw CSS injection
- no arbitrary CSS persistence
- no `url()`, `var()`, `expression()` or `javascript:` user input
- no public style application in release `0.1.77`
- validators normalize or reject unsafe input before saving

## 10. Release Scope

Release `0.1.76` includes:

- Color Controller architecture
- dedicated store and option
- `Дизайн` landing section with a real tool card for `Цветовая библиотека`
- dedicated internal tool screen in `Дизайн`
- default core library
- validation methods for colors, gradients and patterns

Release `0.1.76` does not include:

- full color CRUD
- gradient builder UI
- pattern builder UI
- picker integration into sections, blocks, widgets or popups
- public style application

Release `0.1.77` adds:

- working CRUD for colors in `Дизайн → Цветовая библиотека`
- working CRUD for gradients in `Дизайн → Цветовая библиотека`
- working CRUD for patterns in `Дизайн → Цветовая библиотека`
- REST create/update/delete endpoints for library entities
- standard destructive modal for delete actions
- toolbar create actions tied to the active tab
- landing card copy clarified as library-only scope
- landing counters rendered as meta chips aligned to the tool card content
- all delete actions use the global shared destructive modal helper

Release `0.1.77` still does not include:

- applying library items to sections, blocks, widgets or popups
- public CSS variables
- header/footer integration
- global text color integration
- presets CRUD
- advanced color picker workflows

Release `0.1.81` adds:

- compact swatch-based color editor;
- visual gradient editor with live preview and direction chips;
- grouped pattern registry with visual gallery tiles;
- image pattern storage through WordPress attachment IDs;
- media upload and media-library selection endpoints for image patterns;
- hidden auto-generated system keys for colors, gradients and patterns.

Release `0.1.82` hotfix adds:

- visible card surface for color, gradient and pattern items;
- action zone fixed inside each library card;
- REST response contract returns both `data` and `library` plus `updated_at`;
- frontend `applyResponse` cannot wipe collections when response shape is incomplete.

Release `0.1.83` hotfix adds:

- bootstrap collection normalization accepts safe object-like collections and restores item visibility;
- landing card counters align with the content column instead of the card edge;
- landing action `Настроить` uses `settings` icon semantics.

Release `0.1.84` hotfix adds:

- stored option recovery restores default colors, gradients and patterns only for empty or missing core collections;
- recovery preserves existing non-empty collections and does not overwrite user-created items in other collections;
- summary is derived from the same normalized collections that are returned to REST and frontend state;
- successful save and reload cannot keep stale `6/1/1` counters against empty visible lists.

Release `0.1.85` hotfix adds:

- the `Дизайн` body mount no longer depends on shared icon templates living only inside the hidden `Страницы` subtree;
- shared icon templates required by Color Library render are available at shell level before the first landing render;
- Color Library landing render no longer fails blank when the shared `settings` action icon cannot be resolved from the `pages` workspace DOM.

## 11. UX Positioning Standard

- `Дизайн` should evolve as a section landing, not as a permanent full-screen Color Controller surface;
- the internal tool screen should use the tool context card pattern from `SONYRA_MANAGER_SECTION_UX_STANDARD.md`;
- the visible product name of the tool should be `Цветовая библиотека`;
- the technical name `Color Controller` may remain in architecture, option keys, REST layer and internal code;
- the internal screen keeps only `Цвета`, `Градиенты` and `Паттерны` tabs;
- the internal screen does not render a duplicate hero/header inside the body;
- counters belong to the tool card and the compact tabs/meta panel, not to the big `Дизайн` page header;
- future Color Library UI work must align with the `Страницы`-derived section UX standard after CRUD as well;
- the Color Library tool context card must reuse the `Страницы` context/panel standard one-to-one;
- Color Library shared UI anatomy must consume `assets/js/sonyra-manager-ui.js` helpers instead of local lookalike helpers;
- the visible label `ЦВЕТОВАЯ БИБЛИОТЕКА` remains a muted service label, not a violet accent;
- the help icon must reuse the shared help trigger component and Help Library behavior;
- the back action `Вернуться в раздел Дизайн` must use the shared arrow-back button pattern;
- the tabs/meta row must use the same padded toolbar logic as `Страницы`.
- the Color Library toolbar counters must use meta-chip style, not dot-separated loose text;
- the back action must remain vertically centered inside the context card;
- footer spacing is a global manager shell responsibility, not a Color Library-only hack;
- Color Library delete actions must use the global shared destructive modal;
- Color Library cannot define local destructive modal markup;
- color, gradient and pattern delete actions only pass config to the shared helper;
- modal visuals for color, gradient and pattern deletion must be identical to section/block deletion modal;
- future delete actions inside Color Library also use the same helper;
- help icon рядом с `ЦВЕТОВАЯ БИБЛИОТЕКА` must reuse the same shared help trigger pattern as `Страницы → Секции / Блоки секции`;
- help tooltip for Color Library must open by hover, focus and click through the global help layer;
- Color Library must never expose raw translation keys in modal copy, counters, badges or help UI;
- future product decision may still split card layouts: colors may become a compact grid later, while gradients and patterns may keep large preview cards;
- release `0.1.76` hotfix does not change card sizes and does not introduce CRUD.
