<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Status {

	public static function get_product_name(): string {
		return 'Пульт сайта';
	}

	public static function get_platform_name(): string {
		return 'SONYRA Site Platform';
	}

	public static function get_publisher(): string {
		return 'SONYRA STUDIO';
	}

	public static function get_licensor(): string {
		return 'ИП Катаев С.А. / IPKTFSA';
	}

	public static function get_technical_name(): string {
		return 'sonyra-site-manager';
	}

	public static function get_version(): string {
		return SONYRA_SITE_MANAGER_VERSION;
	}

	public static function get_release_channel(): string {
		return 'manual_zip';
	}

	public static function get_build_type(): string {
		return 'foundation';
	}

	public static function get_release_metadata(): array {
		return array(
			'product_name'    => self::get_product_name(),
			'platform_name'   => self::get_platform_name(),
			'publisher'       => self::get_publisher(),
			'licensor'        => self::get_licensor(),
			'technical_name'  => self::get_technical_name(),
			'version'         => self::get_version(),
			'release_channel' => self::get_release_channel(),
			'build_type'      => self::get_build_type(),
			'text_domain'     => 'sonyra-site-manager',
			'main_file'       => 'sonyra-site-manager.php',
			'copyright'       => '© 2026 SONYRA STUDIO',
		);
	}

	public static function get_runtime_status(): array {
		$owner_user_id                       = 0;
		$capabilities_count                  = 0;
		$audit_log_ready                     = class_exists( 'Sonyra_Site_Manager_Audit_Log' );
		$audit_events_count                  = 0;
		$db_version                          = (string) get_option( 'sonyra_site_manager_db_version', '' );
		$db_required_version                 = defined( 'SONYRA_SITE_MANAGER_DB_VERSION' ) ? SONYRA_SITE_MANAGER_DB_VERSION : '';
		$database_ready                      = false;
		$database_missing_tables             = array();
		$database_health_ready               = false;
		$database_health_checked             = false;
		$database_tables_total               = 0;
		$database_tables_existing            = 0;
		$database_tables_missing_count       = 0;
		$database_db_version_matches         = false;
		$seed_version                        = (string) get_option( 'sonyra_site_manager_seed_version', '' );
		$seed_required_version               = defined( 'SONYRA_SITE_MANAGER_SEED_VERSION' ) ? SONYRA_SITE_MANAGER_SEED_VERSION : '';
		$seed_ready                          = false;
		$seed_has_required_records           = false;
		$auth_tables_required_count          = 0;
		$auth_tables_existing_count          = 0;
		$auth_tables_missing_count           = 0;
		$auth_database_ready                 = false;
		$auth_foundation_ready               = false;
		$auth_visible_name                   = '';
		$auth_email_provider_ready           = false;
		$auth_owner_identity_ready           = false;
		$auth_roles_count                    = 0;
		$auth_providers_count                = 0;
		$otp_policy_ready                    = false;
		$otp_code_length                     = 0;
		$otp_code_ttl_seconds                = 0;
		$otp_max_attempts                    = 0;
		$email_otp_service_ready             = class_exists( 'Sonyra_Site_Manager_Email_OTP' );
		$email_delivery_ready                = false;
		$email_delivery_channel              = '';
		$email_delivery_provider             = '';
		$email_delivery_supports_html        = false;

		if ( class_exists( 'Sonyra_Site_Manager_Permissions' ) ) {
			$owner_user_id      = Sonyra_Site_Manager_Permissions::get_owner_user_id();
			$capabilities_count = count( Sonyra_Site_Manager_Permissions::get_capabilities() );
		}

		if ( $audit_log_ready ) {
			$audit_events_count = Sonyra_Site_Manager_Audit_Log::count_events();
		}

		if ( class_exists( 'Sonyra_Site_Manager_Database' ) ) {
			$database_status         = Sonyra_Site_Manager_Database::tables_exist();
			$database_ready          = (bool) $database_status['is_ready'];
			$database_missing_tables = $database_status['missing'];
			$auth_table_keys         = self::get_auth_table_keys();
			$auth_existing_tables    = array_intersect( $auth_table_keys, $database_status['existing'] );
			$auth_missing_tables     = array_intersect( $auth_table_keys, $database_status['missing'] );
			$auth_tables_required_count = count( $auth_table_keys );
			$auth_tables_existing_count = count( $auth_existing_tables );
			$auth_tables_missing_count  = count( $auth_missing_tables );
			$auth_database_ready        = 0 === $auth_tables_missing_count && $auth_tables_required_count > 0;
		}

		if ( class_exists( 'Sonyra_Site_Manager_Database_Health' ) ) {
			$database_health_checked       = true;
			$database_version_status       = Sonyra_Site_Manager_Database_Health::check_db_version();
			$database_table_status         = Sonyra_Site_Manager_Database_Health::check_tables();
			$database_db_version_matches   = (bool) $database_version_status['matches'];
			$database_tables_total         = (int) $database_table_status['total_required'];
			$database_tables_existing      = (int) $database_table_status['total_existing'];
			$database_tables_missing_count = count( $database_table_status['missing'] );
			$database_health_ready         = $database_db_version_matches && (bool) $database_table_status['is_ready'];
		}

		if ( class_exists( 'Sonyra_Site_Manager_Seeder' ) ) {
			$seed_status                = Sonyra_Site_Manager_Seeder::get_seed_status();
			$seed_version               = (string) $seed_status['installed_seed_version'];
			$seed_required_version      = (string) $seed_status['required_seed_version'];
			$seed_ready                 = (bool) $seed_status['is_ready'];
			$seed_has_required_records  = (bool) $seed_status['has_required_records'];
		}

		if ( class_exists( 'Sonyra_Site_Manager_Auth' ) ) {
			$auth_status                = Sonyra_Site_Manager_Auth::get_foundation_status();
			$auth_foundation_ready      = (bool) $auth_status['is_ready'];
			$auth_visible_name          = (string) $auth_status['visible_name'];
			$auth_email_provider_ready  = (bool) $auth_status['email_provider_ready'];
			$auth_owner_identity_ready  = (bool) $auth_status['owner_identity_ready'];
			$auth_roles_count           = (int) $auth_status['roles_count'];
			$auth_providers_count       = (int) $auth_status['providers_count'];
		}

		if ( class_exists( 'Sonyra_Site_Manager_OTP_Policy' ) ) {
			$otp_policy_ready     = true;
			$otp_code_length      = Sonyra_Site_Manager_OTP_Policy::get_code_length();
			$otp_code_ttl_seconds = Sonyra_Site_Manager_OTP_Policy::get_code_ttl_seconds();
			$otp_max_attempts     = Sonyra_Site_Manager_OTP_Policy::get_max_verify_attempts();
		}

		if ( class_exists( 'Sonyra_Site_Manager_Email_Delivery' ) ) {
			$email_delivery_status        = Sonyra_Site_Manager_Email_Delivery::get_delivery_status();
			$email_delivery_ready         = (bool) $email_delivery_status['is_ready'];
			$email_delivery_channel       = (string) $email_delivery_status['channel'];
			$email_delivery_provider      = (string) $email_delivery_status['provider'];
			$email_delivery_supports_html = (bool) $email_delivery_status['supports_html'];
		}

		return array(
			'product_name'                  => self::get_product_name(),
			'version'                       => self::get_version(),
			'db_version'                    => $db_version,
			'db_required_version'           => $db_required_version,
			'database_ready'                => $database_ready,
			'database_missing_tables'       => $database_missing_tables,
			'database_health_ready'         => $database_health_ready,
			'database_health_checked'       => $database_health_checked,
			'database_tables_total'         => $database_tables_total,
			'database_tables_existing'      => $database_tables_existing,
			'database_tables_missing_count' => $database_tables_missing_count,
			'database_db_version_matches'   => $database_db_version_matches,
			'seed_version'                  => $seed_version,
			'seed_required_version'         => $seed_required_version,
			'seed_ready'                    => $seed_ready,
			'seed_has_required_records'     => $seed_has_required_records,
			'auth_tables_required_count'    => $auth_tables_required_count,
			'auth_tables_existing_count'    => $auth_tables_existing_count,
			'auth_tables_missing_count'     => $auth_tables_missing_count,
			'auth_database_ready'           => $auth_database_ready,
			'auth_foundation_ready'         => $auth_foundation_ready,
			'auth_visible_name'             => $auth_visible_name,
			'auth_email_provider_ready'     => $auth_email_provider_ready,
			'auth_owner_identity_ready'     => $auth_owner_identity_ready,
			'auth_roles_count'              => $auth_roles_count,
			'auth_providers_count'          => $auth_providers_count,
			'otp_policy_ready'              => $otp_policy_ready,
			'otp_code_length'               => $otp_code_length,
			'otp_code_ttl_seconds'          => $otp_code_ttl_seconds,
			'otp_max_attempts'              => $otp_max_attempts,
			'email_otp_service_ready'       => $email_otp_service_ready,
			'email_delivery_ready'          => $email_delivery_ready,
			'email_delivery_channel'        => $email_delivery_channel,
			'email_delivery_provider'       => $email_delivery_provider,
			'email_delivery_supports_html'  => $email_delivery_supports_html,
			'installed_version'             => (string) get_option( 'sonyra_site_manager_version', '' ),
			'last_known_version'            => (string) get_option( 'sonyra_site_manager_last_known_version', '' ),
			'owner_user_id'                 => $owner_user_id,
			'release_channel'               => self::get_release_channel(),
			'build_type'                    => self::get_build_type(),
			'php_version'                   => PHP_VERSION,
			'wp_version'                    => get_bloginfo( 'version' ),
			'capabilities_count'            => $capabilities_count,
			'audit_log_ready'               => $audit_log_ready,
			'audit_events_count'            => $audit_events_count,
			'is_foundation_ready'           => '' !== self::get_version() && class_exists( 'Sonyra_Site_Manager_Permissions' ) && $capabilities_count > 0,
		);
	}

	private static function get_auth_table_keys(): array {
		return array(
			'auth_identities',
			'auth_otp_challenges',
			'auth_sessions',
			'auth_attempts',
			'auth_trusted_devices',
			'auth_providers',
		);
	}
}
