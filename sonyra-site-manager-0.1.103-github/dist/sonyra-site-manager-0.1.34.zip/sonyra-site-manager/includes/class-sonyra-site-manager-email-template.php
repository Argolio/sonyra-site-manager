<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Email_Template {

	public static function get_otp_subject(): string {
		return 'Код входа в Пульт сайта';
	}

	public static function render_otp_plain_text( string $code, array $context = array() ): string {
		if ( ! self::is_valid_code( $code ) ) {
			return '';
		}

		$safe_context = self::get_safe_context( $context );
		unset( $safe_context );

		return implode(
			"\n",
			array(
				'Ваш код входа в Пульт сайта: ' . $code,
				'Код действует 5 минут.',
				'Если вы не запрашивали вход, просто проигнорируйте это письмо.',
				'SONYRA STUDIO',
			)
		);
	}

	public static function render_otp_html( string $code, array $context = array() ): string {
		if ( ! self::is_valid_code( $code ) ) {
			return '';
		}

		$safe_context = self::get_safe_context( $context );
		unset( $safe_context );

		$escaped_code = function_exists( 'esc_html' ) ? esc_html( $code ) : htmlspecialchars( $code, ENT_QUOTES, 'UTF-8' );

		return '<!doctype html><html><head><meta charset="UTF-8"><title>Код входа в Пульт сайта</title></head><body style="margin:0;padding:0;background:#f5f7fb;font-family:Arial,Helvetica,sans-serif;color:#172033;">'
			. '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="width:100%;background:#f5f7fb;margin:0;padding:24px 0;"><tr><td align="center">'
			. '<table role="presentation" width="560" cellspacing="0" cellpadding="0" style="width:560px;max-width:92%;background:#ffffff;border-radius:18px;border:1px solid #e6ebf3;overflow:hidden;">'
			. '<tr><td style="padding:28px 32px 12px 32px;font-size:18px;line-height:26px;font-weight:700;color:#172033;">Пульт сайта</td></tr>'
			. '<tr><td style="padding:0 32px 18px 32px;font-size:28px;line-height:34px;font-weight:800;color:#172033;">Код входа</td></tr>'
			. '<tr><td style="padding:0 32px 12px 32px;font-size:16px;line-height:24px;color:#3d4b63;">Ваш код</td></tr>'
			. '<tr><td style="padding:0 32px 20px 32px;"><div style="font-size:36px;line-height:44px;font-weight:800;letter-spacing:4px;color:#111827;background:#f1f5ff;border-radius:14px;padding:18px 20px;text-align:center;">' . $escaped_code . '</div></td></tr>'
			. '<tr><td style="padding:0 32px 10px 32px;font-size:16px;line-height:24px;color:#3d4b63;">Код действует 5 минут.</td></tr>'
			. '<tr><td style="padding:0 32px 28px 32px;font-size:14px;line-height:22px;color:#6b7280;">Если вы не запрашивали вход, просто проигнорируйте это письмо.</td></tr>'
			. '<tr><td style="padding:18px 32px;background:#f8fafc;font-size:13px;line-height:20px;color:#6b7280;">SONYRA STUDIO</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	public static function get_otp_headers(): array {
		return array(
			'Content-Type: text/html; charset=UTF-8',
		);
	}

	public static function get_safe_context( array $context ): array {
		$unsafe_keys = array(
			'code',
			'otp',
			'token',
			'secret',
			'password',
			'nonce',
			'cookie',
			'authorization',
			'api_key',
			'email',
		);

		foreach ( $unsafe_keys as $key ) {
			if ( array_key_exists( $key, $context ) ) {
				unset( $context[ $key ] );
			}
		}

		return $context;
	}

	private static function is_valid_code( string $code ): bool {
		return 1 === preg_match( '/^\d{6}$/', $code );
	}
}
