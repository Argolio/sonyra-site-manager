<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Color_Controller {

	const OPTION_NAME    = 'sonyra_site_manager_color_controller';
	const OPTION_VERSION = '0.1.0';
	const NONCE_ACTION   = 'sonyra_color_controller';

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	public static function get_option_name() {
		return self::OPTION_NAME;
	}

	public static function get_default_data() {
		$defaults = array(
			'version'      => self::OPTION_VERSION,
			'colors'       => array(
				array(
					'id'         => 'color-brand-primary',
					'name'       => 'Основной фиолетовый',
					'slug'       => 'brand-primary',
					'type'       => 'color',
					'value_hex'  => '#7C3AED',
					'value_rgb'  => array( 124, 58, 237 ),
					'role'       => 'brand.primary',
					'description' => '',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-brand-deep',
					'name'       => 'Глубокий фиолетовый',
					'slug'       => 'brand-deep',
					'type'       => 'color',
					'value_hex'  => '#4C1D95',
					'value_rgb'  => array( 76, 29, 149 ),
					'role'       => 'brand.deep',
					'description' => '',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-surface-light',
					'name'       => 'Светлый фон',
					'slug'       => 'surface-light',
					'type'       => 'color',
					'value_hex'  => '#F8FAFC',
					'value_rgb'  => array( 248, 250, 252 ),
					'role'       => 'surface.light',
					'description' => '',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-text-primary',
					'name'       => 'Тёмный текст',
					'slug'       => 'text-primary',
					'type'       => 'color',
					'value_hex'  => '#111827',
					'value_rgb'  => array( 17, 24, 39 ),
					'role'       => 'text.primary',
					'description' => '',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-text-secondary',
					'name'       => 'Вторичный текст',
					'slug'       => 'text-secondary',
					'type'       => 'color',
					'value_hex'  => '#64748B',
					'value_rgb'  => array( 100, 116, 139 ),
					'role'       => 'text.secondary',
					'description' => '',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
				array(
					'id'         => 'color-brand-accent',
					'name'       => 'Акцентный розовый',
					'slug'       => 'brand-accent',
					'type'       => 'color',
					'value_hex'  => '#EC4899',
					'value_rgb'  => array( 236, 72, 153 ),
					'role'       => 'brand.accent',
					'description' => '',
					'source'     => 'core',
					'created_at' => '',
					'updated_at' => '',
				),
			),
			'gradients'    => array(
				array(
					'id'            => 'gradient-violet-accent',
					'name'          => 'Фиолетовый акцент',
					'slug'          => 'violet-accent',
					'type'          => 'gradient',
					'gradient_type' => 'linear',
					'angle'         => 135,
					'role'          => 'gradient.brand-accent',
					'description'   => '',
					'stops'         => array(
						array(
							'color_hex' => '#7C3AED',
							'position'  => 0,
						),
						array(
							'color_hex' => '#EC4899',
							'position'  => 55,
						),
						array(
							'color_hex' => '#F97316',
							'position'  => 100,
						),
					),
					'source'        => 'core',
					'created_at'    => '',
					'updated_at'    => '',
				),
			),
			'patterns'     => array(
				array(
					'id'           => 'pattern-soft-glow',
					'name'         => 'Мягкое свечение',
					'slug'         => 'soft-glow',
					'type'         => 'pattern',
					'pattern_type' => 'soft_glow',
					'role'         => 'pattern.soft-glow',
					'description'  => '',
					'colors'       => array(
						'base'     => '#FFFFFF',
						'accent_a' => '#EDE9FE',
						'accent_b' => '#FCE7F3',
						'accent_c' => '#DBEAFE',
					),
					'settings'     => array(
						'intensity' => 72,
						'blur'      => 24,
					),
					'source'       => 'core',
					'created_at'   => '',
					'updated_at'   => '',
				),
			),
			'presets'      => array(),
			'library_meta' => array(
				'updated_at' => '',
				'created_by' => 'core',
			),
		);

		return self::normalize_data( $defaults );
	}

	public static function get_data() {
		$stored = get_option( self::OPTION_NAME, null );

		if ( ! is_array( $stored ) ) {
			$default_data = self::get_default_data();
			self::persist_data( $default_data );
			return $default_data;
		}

		$normalized = self::normalize_data( $stored );
		$recovered  = self::recover_missing_default_collections( $normalized, $stored );

		if ( $recovered !== $stored ) {
			self::persist_data( $recovered );
		}

		return $recovered;
	}

	public static function save_data( array $data ) {
		$normalized = self::normalize_data( $data );
		$persisted  = self::persist_data( $normalized );

		if ( ! $persisted ) {
			return new WP_Error( 'sonyra_color_controller_save_failed', self::text( 'manager.design.colors.save_failed' ), array( 'status' => 500 ) );
		}

		return $normalized;
	}

	public static function normalize_data( array $data ) {
		$normalized_colors = array();
		$normalized_gradients = array();
		$normalized_patterns = array();
		$normalized_presets = array();
		$seen = array(
			'colors'    => array(),
			'gradients' => array(),
			'patterns'  => array(),
			'presets'   => array(),
		);

		foreach ( isset( $data['colors'] ) && is_array( $data['colors'] ) ? $data['colors'] : array() as $color ) {
			if ( ! is_array( $color ) ) {
				continue;
			}

			$normalized_color = self::normalize_color( $color );

			if ( empty( $normalized_color ) ) {
				continue;
			}

			$key = $normalized_color['slug'];

			if ( isset( $seen['colors'][ $key ] ) ) {
				continue;
			}

			$seen['colors'][ $key ] = true;
			$normalized_colors[]    = $normalized_color;
		}

		foreach ( isset( $data['gradients'] ) && is_array( $data['gradients'] ) ? $data['gradients'] : array() as $gradient ) {
			if ( ! is_array( $gradient ) ) {
				continue;
			}

			$normalized_gradient = self::normalize_gradient( $gradient );

			if ( empty( $normalized_gradient ) ) {
				continue;
			}

			$key = $normalized_gradient['slug'];

			if ( isset( $seen['gradients'][ $key ] ) ) {
				continue;
			}

			$seen['gradients'][ $key ] = true;
			$normalized_gradients[]    = $normalized_gradient;
		}

		foreach ( isset( $data['patterns'] ) && is_array( $data['patterns'] ) ? $data['patterns'] : array() as $pattern ) {
			if ( ! is_array( $pattern ) ) {
				continue;
			}

			$normalized_pattern = self::normalize_pattern( $pattern );

			if ( empty( $normalized_pattern ) ) {
				continue;
			}

			$key = $normalized_pattern['slug'];

			if ( isset( $seen['patterns'][ $key ] ) ) {
				continue;
			}

			$seen['patterns'][ $key ] = true;
			$normalized_patterns[]    = $normalized_pattern;
		}

		foreach ( isset( $data['presets'] ) && is_array( $data['presets'] ) ? $data['presets'] : array() as $preset ) {
			if ( ! is_array( $preset ) ) {
				continue;
			}

			$normalized_preset = self::normalize_preset( $preset );

			if ( empty( $normalized_preset ) ) {
				continue;
			}

			$key = $normalized_preset['slug'];

			if ( isset( $seen['presets'][ $key ] ) ) {
				continue;
			}

			$seen['presets'][ $key ] = true;
			$normalized_presets[]    = $normalized_preset;
		}

		$updated_at = isset( $data['library_meta']['updated_at'] ) ? sanitize_text_field( (string) $data['library_meta']['updated_at'] ) : '';
		$created_by = isset( $data['library_meta']['created_by'] ) ? self::sanitize_source( (string) $data['library_meta']['created_by'] ) : 'core';

		return array(
			'version'      => self::OPTION_VERSION,
			'colors'       => $normalized_colors,
			'gradients'    => $normalized_gradients,
			'patterns'     => $normalized_patterns,
			'presets'      => $normalized_presets,
			'library_meta' => array(
				'updated_at' => $updated_at,
				'created_by' => '' !== $created_by ? $created_by : 'core',
			),
		);
	}

	private static function recover_missing_default_collections( array $normalized, array $stored ): array {
		$defaults       = self::get_default_data();
		$recovered      = $normalized;
		$did_recover    = false;
		$collection_keys = array( 'colors', 'gradients', 'patterns' );

		foreach ( $collection_keys as $collection_key ) {
			$stored_has_collection = array_key_exists( $collection_key, $stored ) && is_array( $stored[ $collection_key ] );
			$current_items         = isset( $normalized[ $collection_key ] ) && is_array( $normalized[ $collection_key ] ) ? $normalized[ $collection_key ] : array();

			if ( ! $stored_has_collection || empty( $current_items ) ) {
				$default_items = isset( $defaults[ $collection_key ] ) && is_array( $defaults[ $collection_key ] ) ? $defaults[ $collection_key ] : array();

				if ( ! empty( $default_items ) ) {
					$recovered[ $collection_key ] = $default_items;
					$did_recover                  = true;
				}
			}
		}

		if ( $did_recover ) {
			$recovered['library_meta']['updated_at'] = self::now_iso8601();
		}

		return $recovered;
	}

	public static function normalize_color( array $color ) {
		$name       = isset( $color['name'] ) ? sanitize_text_field( (string) $color['name'] ) : '';
		$hex        = self::normalize_hex( isset( $color['value_hex'] ) ? $color['value_hex'] : '' );
		$rgb        = self::normalize_rgb( isset( $color['value_rgb'] ) ? $color['value_rgb'] : array() );
		$role       = self::sanitize_role( isset( $color['role'] ) ? (string) $color['role'] : '' );
		$source     = self::sanitize_source( isset( $color['source'] ) ? (string) $color['source'] : 'core' );
		$slug       = self::sanitize_slug( isset( $color['slug'] ) ? (string) $color['slug'] : $name );
		$description = isset( $color['description'] ) ? sanitize_textarea_field( (string) $color['description'] ) : '';
		$created_at = isset( $color['created_at'] ) ? sanitize_text_field( (string) $color['created_at'] ) : '';
		$updated_at = isset( $color['updated_at'] ) ? sanitize_text_field( (string) $color['updated_at'] ) : '';

		if ( '' === $name || '' === $hex || empty( $rgb ) || '' === $slug ) {
			return array();
		}

		return array(
			'id'         => self::sanitize_id( isset( $color['id'] ) ? (string) $color['id'] : 'color-' . $slug ),
			'name'       => $name,
			'slug'       => $slug,
			'type'       => 'color',
			'value_hex'  => $hex,
			'value_rgb'  => $rgb,
			'role'       => $role,
			'description' => $description,
			'source'     => '' !== $source ? $source : 'core',
			'created_at' => $created_at,
			'updated_at' => $updated_at,
		);
	}

	public static function normalize_gradient( array $gradient ) {
		$name          = isset( $gradient['name'] ) ? sanitize_text_field( (string) $gradient['name'] ) : '';
		$slug          = self::sanitize_slug( isset( $gradient['slug'] ) ? (string) $gradient['slug'] : $name );
		$gradient_type = isset( $gradient['gradient_type'] ) ? sanitize_key( (string) $gradient['gradient_type'] ) : 'linear';
		$angle         = isset( $gradient['angle'] ) ? (int) $gradient['angle'] : 135;
		$source         = self::sanitize_source( isset( $gradient['source'] ) ? (string) $gradient['source'] : 'core' );
		$role           = self::sanitize_role( isset( $gradient['role'] ) ? (string) $gradient['role'] : '' );
		$description    = isset( $gradient['description'] ) ? sanitize_textarea_field( (string) $gradient['description'] ) : '';
		$created_at     = isset( $gradient['created_at'] ) ? sanitize_text_field( (string) $gradient['created_at'] ) : '';
		$updated_at     = isset( $gradient['updated_at'] ) ? sanitize_text_field( (string) $gradient['updated_at'] ) : '';
		$stops          = array();

		if ( 'linear' !== $gradient_type || '' === $name || '' === $slug ) {
			return array();
		}

		foreach ( isset( $gradient['stops'] ) && is_array( $gradient['stops'] ) ? $gradient['stops'] : array() as $stop ) {
			if ( ! is_array( $stop ) ) {
				continue;
			}

			$color_hex = self::normalize_hex( isset( $stop['color_hex'] ) ? $stop['color_hex'] : '' );
			$position  = isset( $stop['position'] ) ? (int) $stop['position'] : -1;

			if ( '' === $color_hex || $position < 0 || $position > 100 ) {
				continue;
			}

			$stops[] = array(
				'color_hex' => $color_hex,
				'position'  => $position,
			);
		}

		if ( count( $stops ) < 2 || count( $stops ) > 5 || $angle < 0 || $angle > 360 ) {
			return array();
		}

		usort(
			$stops,
			static function ( array $left, array $right ): int {
				return (int) $left['position'] <=> (int) $right['position'];
			}
		);

		return array(
			'id'            => self::sanitize_id( isset( $gradient['id'] ) ? (string) $gradient['id'] : 'gradient-' . $slug ),
			'name'          => $name,
			'slug'          => $slug,
			'type'          => 'gradient',
			'gradient_type' => 'linear',
			'angle'         => $angle,
			'role'          => $role,
			'description'   => $description,
			'stops'         => $stops,
			'source'        => '' !== $source ? $source : 'core',
			'created_at'    => $created_at,
			'updated_at'    => $updated_at,
		);
	}

	public static function normalize_pattern( array $pattern ) {
		$name         = isset( $pattern['name'] ) ? sanitize_text_field( (string) $pattern['name'] ) : '';
		$slug         = self::sanitize_slug( isset( $pattern['slug'] ) ? (string) $pattern['slug'] : $name );
		$pattern_type = isset( $pattern['pattern_type'] ) ? sanitize_key( (string) $pattern['pattern_type'] ) : '';
		$source        = self::sanitize_source( isset( $pattern['source'] ) ? (string) $pattern['source'] : 'core' );
		$role          = self::sanitize_role( isset( $pattern['role'] ) ? (string) $pattern['role'] : '' );
		$description   = isset( $pattern['description'] ) ? sanitize_textarea_field( (string) $pattern['description'] ) : '';
		$created_at    = isset( $pattern['created_at'] ) ? sanitize_text_field( (string) $pattern['created_at'] ) : '';
		$updated_at    = isset( $pattern['updated_at'] ) ? sanitize_text_field( (string) $pattern['updated_at'] ) : '';
		$colors        = self::sanitize_pattern_colors( $pattern_type, isset( $pattern['colors'] ) && is_array( $pattern['colors'] ) ? $pattern['colors'] : array() );
		$settings      = self::sanitize_pattern_settings( $pattern_type, isset( $pattern['settings'] ) && is_array( $pattern['settings'] ) ? $pattern['settings'] : array() );
		$media         = self::normalize_pattern_media( isset( $pattern['media'] ) && is_array( $pattern['media'] ) ? $pattern['media'] : array() );

		if ( '' === $name || '' === $slug || ! in_array( $pattern_type, self::get_pattern_allowlist(), true ) ) {
			return array();
		}

		if ( empty( $colors ) && 'image_pattern' !== $pattern_type ) {
			return array();
		}

		if ( 'image_pattern' === $pattern_type && empty( $media ) ) {
			return array();
		}

		return array(
			'id'           => self::sanitize_id( isset( $pattern['id'] ) ? (string) $pattern['id'] : 'pattern-' . $slug ),
			'name'         => $name,
			'slug'         => $slug,
			'type'         => 'pattern',
			'pattern_type' => $pattern_type,
			'role'         => $role,
			'description'  => $description,
			'colors'       => $colors,
			'settings'     => $settings,
			'media'        => $media,
			'source'       => '' !== $source ? $source : 'core',
			'created_at'   => $created_at,
			'updated_at'   => $updated_at,
		);
	}

	public static function validate_hex( $value ) {
		return '' !== self::normalize_hex( $value );
	}

	public static function normalize_hex( $value ) {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return '';
		}

		$value = trim( (string) $value );

		if ( '' === $value || preg_match( '/javascript:|expression|url\(|var\(|rgb\(|hsl\(|calc\(/i', $value ) ) {
			return '';
		}

		$value = strtoupper( ltrim( $value, '#' ) );

		if ( preg_match( '/^[A-F0-9]{3}$/', $value ) ) {
			return '#' . $value[0] . $value[0] . $value[1] . $value[1] . $value[2] . $value[2];
		}

		if ( preg_match( '/^[A-F0-9]{6}$/', $value ) ) {
			return '#' . $value;
		}

		return '';
	}

	public static function normalize_rgb( $value ) {
		$components = array();

		if ( is_array( $value ) ) {
			if ( isset( $value['r'], $value['g'], $value['b'] ) ) {
				$components = array( $value['r'], $value['g'], $value['b'] );
			} else {
				$components = array_values( $value );
			}
		} elseif ( is_string( $value ) ) {
			if ( preg_match( '/javascript:|expression|url\(|var\(|rgb\(/i', $value ) ) {
				return array();
			}

			$components = preg_split( '/\s*,\s*/', trim( $value ) );
		}

		if ( 3 !== count( $components ) ) {
			return array();
		}

		$normalized = array();

		foreach ( $components as $component ) {
			if ( '' === (string) $component || ! is_numeric( $component ) ) {
				return array();
			}

			$channel = (int) $component;

			if ( $channel < 0 || $channel > 255 ) {
				return array();
			}

			$normalized[] = $channel;
		}

		return $normalized;
	}

	public static function hex_to_rgb( $hex ) {
		$normalized = self::normalize_hex( $hex );

		if ( '' === $normalized ) {
			return array();
		}

		return array(
			hexdec( substr( $normalized, 1, 2 ) ),
			hexdec( substr( $normalized, 3, 2 ) ),
			hexdec( substr( $normalized, 5, 2 ) ),
		);
	}

	public static function rgb_to_hex( $rgb ) {
		$normalized = self::normalize_rgb( $rgb );

		if ( empty( $normalized ) ) {
			return '';
		}

		return sprintf( '#%02X%02X%02X', $normalized[0], $normalized[1], $normalized[2] );
	}

	public static function create_nonce( array $context = array() ): string {
		$session_uuid = self::get_session_uuid_from_context( $context );

		if ( '' === $session_uuid ) {
			return '';
		}

		return self::build_nonce_for_tick( $session_uuid, self::get_nonce_tick() );
	}

	public static function verify_nonce( string $nonce, array $context = array() ): bool {
		$nonce        = sanitize_text_field( $nonce );
		$session_uuid = self::get_session_uuid_from_context( $context );

		if ( '' === $nonce || '' === $session_uuid ) {
			return false;
		}

		$current_tick = self::get_nonce_tick();

		return hash_equals( self::build_nonce_for_tick( $session_uuid, $current_tick ), $nonce )
			|| hash_equals( self::build_nonce_for_tick( $session_uuid, $current_tick - 1 ), $nonce );
	}

	public static function get_summary( array $data = array() ): array {
		if ( empty( $data ) ) {
			$data = self::get_data();
		}

		return array(
			'colors'    => isset( $data['colors'] ) && is_array( $data['colors'] ) ? count( $data['colors'] ) : 0,
			'gradients' => isset( $data['gradients'] ) && is_array( $data['gradients'] ) ? count( $data['gradients'] ) : 0,
			'patterns'  => isset( $data['patterns'] ) && is_array( $data['patterns'] ) ? count( $data['patterns'] ) : 0,
			'presets'   => isset( $data['presets'] ) && is_array( $data['presets'] ) ? count( $data['presets'] ) : 0,
		);
	}

	public static function create_item( string $entity_type, array $payload ) {
		return self::upsert_item( $entity_type, '', $payload );
	}

	public static function update_item( string $entity_type, string $item_id, array $payload ) {
		return self::upsert_item( $entity_type, $item_id, $payload );
	}

	public static function delete_item( string $entity_type, string $item_id ) {
		$data           = self::get_data();
		$collection_key = self::get_collection_key( $entity_type );
		$item_id        = self::sanitize_id( $item_id );

		if ( '' === $collection_key || '' === $item_id ) {
			return new WP_Error( 'sonyra_color_controller_item_invalid', self::text( 'manager.design.colors.item_not_found' ), array( 'status' => 404 ) );
		}

		$items       = isset( $data[ $collection_key ] ) && is_array( $data[ $collection_key ] ) ? $data[ $collection_key ] : array();
		$target_item = null;
		$next_items  = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			if ( isset( $item['id'] ) && $item_id === self::sanitize_id( (string) $item['id'] ) ) {
				$target_item = $item;
				continue;
			}

			$next_items[] = $item;
		}

		if ( null === $target_item ) {
			return new WP_Error( 'sonyra_color_controller_item_not_found', self::text( 'manager.design.colors.item_not_found' ), array( 'status' => 404 ) );
		}

		$data[ $collection_key ]          = $next_items;
		$data['library_meta']['updated_at'] = self::now_iso8601();

		$saved = self::save_data( $data );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		return array(
			'item'    => $target_item,
			'data'    => $saved,
			'summary' => self::get_summary( $saved ),
		);
	}

	public static function get_i18n_keys(): array {
		return array(
			'manager.design.eyebrow',
			'manager.design.title',
			'manager.design.description',
			'manager.design.tools.color_library.title',
			'manager.design.tools.color_library.description',
			'manager.design.tools.color_library.action',
			'manager.design.colors.title',
			'manager.design.colors.description',
			'manager.design.colors.context_title',
			'manager.design.colors.context_subtitle',
			'manager.design.colors.back_to_design',
			'manager.design.colors.tab_colors',
			'manager.design.colors.tab_gradients',
			'manager.design.colors.tab_patterns',
			'manager.design.colors.create_color',
			'manager.design.colors.create_gradient',
			'manager.design.colors.create_pattern',
			'manager.design.colors.edit_color',
			'manager.design.colors.edit_gradient',
			'manager.design.colors.edit_pattern',
			'manager.design.colors.edit_action',
			'manager.design.colors.color_card_label',
			'manager.design.colors.gradient_card_label',
			'manager.design.colors.pattern_card_label',
			'manager.design.colors.empty_title',
			'manager.design.colors.empty_description',
			'manager.design.colors.preview_color',
			'manager.design.colors.preview_gradient',
			'manager.design.colors.preview_pattern',
			'manager.design.colors.hex_label',
			'manager.design.colors.color_picker_label',
			'manager.design.colors.color_picker_hint',
			'manager.design.colors.color_hex_hint',
			'manager.design.colors.updated_label',
			'manager.design.colors.gradient_angle_label',
			'manager.design.colors.gradient_preview_label',
			'manager.design.colors.gradient_direction_label',
			'manager.design.colors.pattern_type_label',
			'manager.design.colors.pattern_gallery_label',
			'manager.design.colors.pattern_preview_label',
			'manager.design.colors.pattern_media_label',
			'manager.design.colors.pattern_image_mode_label',
			'manager.design.colors.pattern_overlay_label',
			'manager.design.colors.field_name',
			'manager.design.colors.field_hex',
			'manager.design.colors.field_color',
			'manager.design.colors.field_first_color',
			'manager.design.colors.field_second_color',
			'manager.design.colors.field_angle',
			'manager.design.colors.field_pattern_type',
			'manager.design.colors.field_primary_color',
			'manager.design.colors.field_background_color',
			'manager.design.colors.field_accent_color',
			'manager.design.colors.field_overlay_color',
			'manager.design.colors.field_size',
			'manager.design.colors.field_density',
			'manager.design.colors.field_softness',
			'manager.design.colors.field_opacity',
			'manager.design.colors.field_dimness',
			'manager.design.colors.field_blur',
			'manager.design.colors.modal_color_create_description',
			'manager.design.colors.modal_color_edit_description',
			'manager.design.colors.modal_gradient_create_description',
			'manager.design.colors.modal_gradient_edit_description',
			'manager.design.colors.modal_pattern_create_description',
			'manager.design.colors.modal_pattern_edit_description',
			'manager.design.colors.delete_modal_description',
			'manager.design.colors.delete_color_title',
			'manager.design.colors.delete_gradient_title',
			'manager.design.colors.delete_pattern_title',
			'manager.design.colors.delete_color_body',
			'manager.design.colors.delete_gradient_body',
			'manager.design.colors.delete_pattern_body',
			'manager.design.colors.deleting',
			'manager.design.colors.direction_0',
			'manager.design.colors.direction_45',
			'manager.design.colors.direction_90',
			'manager.design.colors.direction_135',
			'manager.design.colors.direction_180',
			'manager.design.colors.size_small',
			'manager.design.colors.size_medium',
			'manager.design.colors.size_large',
			'manager.design.colors.density_low',
			'manager.design.colors.density_medium',
			'manager.design.colors.density_dense',
			'manager.design.colors.softness_crisp',
			'manager.design.colors.softness_medium',
			'manager.design.colors.softness_soft',
			'manager.design.colors.image_mode_cover',
			'manager.design.colors.image_mode_contain',
			'manager.design.colors.image_mode_repeat',
			'manager.design.colors.image_mode_center',
			'manager.design.colors.image_mode_stretch',
			'manager.design.colors.media_upload',
			'manager.design.colors.media_select',
			'manager.design.colors.media_replace',
			'manager.design.colors.media_remove',
			'manager.design.colors.media_empty',
			'manager.design.colors.media_loading',
			'manager.design.colors.media_library_title',
			'manager.design.colors.media_library_empty',
			'manager.design.colors.media_upload_success',
			'manager.design.colors.media_upload_missing',
			'manager.design.colors.media_upload_failed',
			'manager.design.colors.image_requirement_hint',
			'manager.pages.modal.delete_line_one',
			'manager.pages.modal.deleting',
			'manager.pages.modal.close',
			'manager.pages.actions.help_tooltip',
			'manager.design.colors.item_not_found',
			'manager.design.colors.item_type_invalid',
			'manager.design.colors.color_created_notice',
			'manager.design.colors.color_updated_notice',
			'manager.design.colors.color_deleted_notice',
			'manager.design.colors.gradient_created_notice',
			'manager.design.colors.gradient_updated_notice',
			'manager.design.colors.gradient_deleted_notice',
			'manager.design.colors.pattern_created_notice',
			'manager.design.colors.pattern_updated_notice',
			'manager.design.colors.pattern_deleted_notice',
			'manager.design.colors.validation_name_required',
			'manager.design.colors.validation_hex_invalid',
			'manager.design.colors.validation_gradient_colors_required',
			'manager.design.colors.validation_angle_invalid',
			'manager.design.colors.validation_pattern_colors_required',
			'manager.design.colors.validation_pattern_type_invalid',
			'manager.design.colors.validation_image_required',
			'manager.design.colors.validation_image_type_invalid',
			'manager.design.colors.validation_image_size_invalid',
			'manager.design.colors.pattern_type_dots',
			'manager.design.colors.pattern_type_grid',
			'manager.design.colors.pattern_type_soft_grid',
			'manager.design.colors.pattern_type_diagonal_lines',
			'manager.design.colors.pattern_type_diagonal_wave',
			'manager.design.colors.pattern_type_thin_stripes',
			'manager.design.colors.pattern_type_checkerboard',
			'manager.design.colors.pattern_type_isometric_grid',
			'manager.design.colors.pattern_type_orbits',
			'manager.design.colors.pattern_type_radial_lines',
			'manager.design.colors.pattern_type_soft_blobs',
			'manager.design.colors.pattern_type_radial_aura',
			'manager.design.colors.pattern_type_light_burst',
			'manager.design.colors.pattern_type_deep_background',
			'manager.design.colors.pattern_type_accent_orbit',
			'manager.design.colors.pattern_type_gradient_mist',
			'manager.design.colors.pattern_type_aurora',
			'manager.design.colors.pattern_type_soft_glow',
			'manager.design.colors.pattern_type_airy_haze',
			'manager.design.colors.pattern_type_light_spots',
			'manager.design.colors.pattern_type_ink_blots',
			'manager.design.colors.pattern_type_paint_strokes',
			'manager.design.colors.pattern_type_watercolor_spots',
			'manager.design.colors.pattern_type_liquid_gradient',
			'manager.design.colors.pattern_type_marble_flow',
			'manager.design.colors.pattern_type_abstract_waves',
			'manager.design.colors.pattern_type_noisy_texture',
			'manager.design.colors.pattern_type_paper_grain',
			'manager.design.colors.pattern_type_glass_glow',
			'manager.design.colors.pattern_type_plastic_gloss',
			'manager.design.colors.pattern_type_soft_noise',
			'manager.design.colors.pattern_type_stardust',
			'manager.design.colors.pattern_type_pixel_sprinkle',
			'manager.design.colors.pattern_type_motion_lines',
			'manager.design.colors.pattern_type_light_rings',
			'manager.design.colors.pattern_type_bubbles',
			'manager.design.colors.pattern_type_micro_dots',
			'manager.design.colors.pattern_type_fine_texture',
			'manager.design.colors.pattern_type_image_pattern',
			'manager.design.colors.pattern_group_geometric',
			'manager.design.colors.pattern_group_atmospheric',
			'manager.design.colors.pattern_group_artistic',
			'manager.design.colors.pattern_group_decorative',
			'manager.design.colors.pattern_group_image',
			'manager.design.colors.pattern_desc_dots',
			'manager.design.colors.pattern_desc_grid',
			'manager.design.colors.pattern_desc_soft_grid',
			'manager.design.colors.pattern_desc_diagonal_lines',
			'manager.design.colors.pattern_desc_diagonal_wave',
			'manager.design.colors.pattern_desc_thin_stripes',
			'manager.design.colors.pattern_desc_checkerboard',
			'manager.design.colors.pattern_desc_isometric_grid',
			'manager.design.colors.pattern_desc_orbits',
			'manager.design.colors.pattern_desc_radial_lines',
			'manager.design.colors.pattern_desc_soft_blobs',
			'manager.design.colors.pattern_desc_radial_aura',
			'manager.design.colors.pattern_desc_light_burst',
			'manager.design.colors.pattern_desc_deep_background',
			'manager.design.colors.pattern_desc_accent_orbit',
			'manager.design.colors.pattern_desc_gradient_mist',
			'manager.design.colors.pattern_desc_aurora',
			'manager.design.colors.pattern_desc_soft_glow',
			'manager.design.colors.pattern_desc_airy_haze',
			'manager.design.colors.pattern_desc_light_spots',
			'manager.design.colors.pattern_desc_ink_blots',
			'manager.design.colors.pattern_desc_paint_strokes',
			'manager.design.colors.pattern_desc_watercolor_spots',
			'manager.design.colors.pattern_desc_liquid_gradient',
			'manager.design.colors.pattern_desc_marble_flow',
			'manager.design.colors.pattern_desc_abstract_waves',
			'manager.design.colors.pattern_desc_noisy_texture',
			'manager.design.colors.pattern_desc_paper_grain',
			'manager.design.colors.pattern_desc_glass_glow',
			'manager.design.colors.pattern_desc_plastic_gloss',
			'manager.design.colors.pattern_desc_soft_noise',
			'manager.design.colors.pattern_desc_stardust',
			'manager.design.colors.pattern_desc_pixel_sprinkle',
			'manager.design.colors.pattern_desc_motion_lines',
			'manager.design.colors.pattern_desc_light_rings',
			'manager.design.colors.pattern_desc_bubbles',
			'manager.design.colors.pattern_desc_micro_dots',
			'manager.design.colors.pattern_desc_fine_texture',
			'manager.design.colors.pattern_desc_image_pattern',
			'manager.design.colors.count_color_one',
			'manager.design.colors.count_color_few',
			'manager.design.colors.count_color_many',
			'manager.design.colors.count_gradient_one',
			'manager.design.colors.count_gradient_few',
			'manager.design.colors.count_gradient_many',
			'manager.design.colors.count_pattern_one',
			'manager.design.colors.count_pattern_few',
			'manager.design.colors.count_pattern_many',
			'manager.pages.actions.help_tooltip',
			'manager.pages.actions.save',
			'manager.pages.actions.saving',
			'manager.pages.actions.delete',
			'manager.pages.actions.cancel',
			'manager.pages.modal.close',
		);
	}

	public static function get_manager_payload( string $api_url = '', string $nonce = '' ): array {
		$payload = class_exists( 'Sonyra_Site_Manager_I18n' ) ? Sonyra_Site_Manager_I18n::get_payload() : array(
			'currentLocale'  => 'ru_RU',
			'fallbackLocale' => 'ru_RU',
			'dictionary'     => array(),
		);
		$dictionary = array();

		foreach ( self::get_i18n_keys() as $key ) {
			$dictionary[ $key ] = self::text( $key );
		}

		$payload['dictionary'] = $dictionary;
		$payload['messages']   = array(
			'destructiveModalSubtitle' => isset( $dictionary['manager.pages.modal.delete_line_one'] ) ? (string) $dictionary['manager.pages.modal.delete_line_one'] : '',
		);
		$payload['data']              = self::get_data();
		$payload['summary']           = self::get_summary( $payload['data'] );
		$payload['patternRegistry']   = self::get_pattern_registry_payload();
		$payload['apiUrl']            = esc_url_raw( $api_url );
		$payload['mediaUploadUrl']    = function_exists( 'rest_url' ) ? esc_url_raw( rest_url( 'sonyra-site-manager/v1/design/colors/media' ) ) : '';
		$payload['mediaLibraryUrl']   = function_exists( 'rest_url' ) ? esc_url_raw( rest_url( 'sonyra-site-manager/v1/design/colors/media-library' ) ) : '';
		$payload['maxImageUploadSize'] = self::get_max_image_upload_size_bytes();
		$payload['allowedImageMimeTypes'] = self::get_allowed_image_mime_types();
		$payload['nonce']             = sanitize_text_field( $nonce );
		$payload['helpKey']           = 'design.colors.controller';

		return $payload;
	}

	private static function upsert_item( string $entity_type, string $item_id, array $payload ) {
		$data           = self::get_data();
		$collection_key = self::get_collection_key( $entity_type );
		$item_id        = '' !== $item_id ? self::sanitize_id( $item_id ) : '';

		if ( '' === $collection_key ) {
			return new WP_Error( 'sonyra_color_controller_item_type_invalid', self::text( 'manager.design.colors.item_type_invalid' ), array( 'status' => 400 ) );
		}

		$existing_items = isset( $data[ $collection_key ] ) && is_array( $data[ $collection_key ] ) ? $data[ $collection_key ] : array();
		$current_item   = null;
		$next_items     = array();

		foreach ( $existing_items as $existing_item ) {
			if ( ! is_array( $existing_item ) ) {
				continue;
			}

			if ( '' !== $item_id && isset( $existing_item['id'] ) && $item_id === self::sanitize_id( (string) $existing_item['id'] ) ) {
				$current_item = $existing_item;
				continue;
			}

			$next_items[] = $existing_item;
		}

		if ( '' !== $item_id && null === $current_item ) {
			return new WP_Error( 'sonyra_color_controller_item_not_found', self::text( 'manager.design.colors.item_not_found' ), array( 'status' => 404 ) );
		}

		$prepared = self::prepare_item_for_save( $entity_type, $payload, $current_item, $data );

		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}

		$next_items[] = $prepared;
		$data[ $collection_key ]            = array_values( $next_items );
		$data['library_meta']['updated_at'] = self::now_iso8601();

		$saved = self::save_data( $data );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		return array(
			'item'    => $prepared,
			'data'    => $saved,
			'summary' => self::get_summary( $saved ),
		);
	}

	private static function prepare_item_for_save( string $entity_type, array $payload, ?array $current_item, array $full_data ) {
		switch ( $entity_type ) {
			case 'color':
				return self::prepare_color_item( $payload, $current_item, $full_data );
			case 'gradient':
				return self::prepare_gradient_item( $payload, $current_item, $full_data );
			case 'pattern':
				return self::prepare_pattern_item( $payload, $current_item, $full_data );
			default:
				return new WP_Error( 'sonyra_color_controller_item_type_invalid', self::text( 'manager.design.colors.item_type_invalid' ), array( 'status' => 400 ) );
		}
	}

	private static function prepare_color_item( array $payload, ?array $current_item, array $full_data ) {
		$name = isset( $payload['name'] ) ? sanitize_text_field( (string) $payload['name'] ) : '';
		$hex  = self::normalize_hex( isset( $payload['value_hex'] ) ? $payload['value_hex'] : '' );

		if ( '' === $name ) {
			return self::validation_error( 'name', 'manager.design.colors.validation_name_required' );
		}

		if ( '' === $hex ) {
			return self::validation_error( 'value_hex', 'manager.design.colors.validation_hex_invalid' );
		}

		$slug       = self::build_unique_slug( isset( $payload['slug'] ) ? (string) $payload['slug'] : $name, $full_data['colors'], $current_item );
		$role       = self::resolve_role( isset( $payload['role'] ) ? (string) $payload['role'] : '', 'color', $slug, $full_data, $current_item );

		if ( is_wp_error( $role ) ) {
			return $role;
		}
		$created_at = isset( $current_item['created_at'] ) ? sanitize_text_field( (string) $current_item['created_at'] ) : self::now_iso8601();
		$item       = self::normalize_color(
			array(
				'id'          => isset( $current_item['id'] ) ? (string) $current_item['id'] : 'color-' . $slug,
				'name'        => $name,
				'slug'        => $slug,
				'type'        => 'color',
				'value_hex'   => $hex,
				'value_rgb'   => self::hex_to_rgb( $hex ),
				'role'        => $role,
				'description' => isset( $payload['description'] ) ? sanitize_textarea_field( (string) $payload['description'] ) : '',
				'source'      => isset( $current_item['source'] ) ? (string) $current_item['source'] : 'custom',
				'created_at'  => $created_at,
				'updated_at'  => self::now_iso8601(),
			)
		);

		if ( empty( $item ) ) {
			return new WP_Error( 'sonyra_color_controller_item_invalid', self::text( 'manager.design.colors.payload_invalid' ), array( 'status' => 400 ) );
		}

		return $item;
	}

	private static function prepare_gradient_item( array $payload, ?array $current_item, array $full_data ) {
		$name      = isset( $payload['name'] ) ? sanitize_text_field( (string) $payload['name'] ) : '';
		$first_hex = self::normalize_hex( isset( $payload['first_color_hex'] ) ? $payload['first_color_hex'] : '' );
		$second_hex = self::normalize_hex( isset( $payload['second_color_hex'] ) ? $payload['second_color_hex'] : '' );
		$angle     = isset( $payload['angle'] ) ? (int) $payload['angle'] : 135;

		if ( '' === $name ) {
			return self::validation_error( 'name', 'manager.design.colors.validation_name_required' );
		}

		if ( '' === $first_hex || '' === $second_hex ) {
			return self::validation_error( 'stops', 'manager.design.colors.validation_gradient_colors_required' );
		}

		if ( $angle < 0 || $angle > 360 ) {
			return self::validation_error( 'angle', 'manager.design.colors.validation_angle_invalid' );
		}

		$slug       = self::build_unique_slug( isset( $payload['slug'] ) ? (string) $payload['slug'] : $name, $full_data['gradients'], $current_item );
		$role       = self::resolve_role( isset( $payload['role'] ) ? (string) $payload['role'] : '', 'gradient', $slug, $full_data, $current_item );

		if ( is_wp_error( $role ) ) {
			return $role;
		}
		$created_at = isset( $current_item['created_at'] ) ? sanitize_text_field( (string) $current_item['created_at'] ) : self::now_iso8601();
		$item       = self::normalize_gradient(
			array(
				'id'            => isset( $current_item['id'] ) ? (string) $current_item['id'] : 'gradient-' . $slug,
				'name'          => $name,
				'slug'          => $slug,
				'type'          => 'gradient',
				'gradient_type' => 'linear',
				'angle'         => $angle,
				'role'          => $role,
				'description'   => isset( $payload['description'] ) ? sanitize_textarea_field( (string) $payload['description'] ) : '',
				'stops'         => array(
					array(
						'color_hex' => $first_hex,
						'position'  => 0,
					),
					array(
						'color_hex' => $second_hex,
						'position'  => 100,
					),
				),
				'source'        => isset( $current_item['source'] ) ? (string) $current_item['source'] : 'custom',
				'created_at'    => $created_at,
				'updated_at'    => self::now_iso8601(),
			)
		);

		if ( empty( $item ) ) {
			return new WP_Error( 'sonyra_color_controller_item_invalid', self::text( 'manager.design.colors.payload_invalid' ), array( 'status' => 400 ) );
		}

		return $item;
	}

	private static function prepare_pattern_item( array $payload, ?array $current_item, array $full_data ) {
		$name          = isset( $payload['name'] ) ? sanitize_text_field( (string) $payload['name'] ) : '';
		$pattern_type  = isset( $payload['pattern_type'] ) ? sanitize_key( (string) $payload['pattern_type'] ) : '';
		$primary_hex   = self::normalize_hex( isset( $payload['primary_hex'] ) ? $payload['primary_hex'] : '' );
		$background_hex = self::normalize_hex( isset( $payload['background_hex'] ) ? $payload['background_hex'] : '' );
		$accent_hex    = self::normalize_hex( isset( $payload['accent_hex'] ) ? $payload['accent_hex'] : '' );
		$overlay_hex   = self::normalize_hex( isset( $payload['overlay_hex'] ) ? $payload['overlay_hex'] : '' );
		$media         = self::normalize_pattern_media(
			array(
				'attachment_id' => isset( $payload['image_attachment_id'] ) ? (int) $payload['image_attachment_id'] : 0,
				'url'           => isset( $payload['image_url'] ) ? (string) $payload['image_url'] : '',
				'thumb_url'     => isset( $payload['image_thumb_url'] ) ? (string) $payload['image_thumb_url'] : '',
				'name'          => isset( $payload['image_name'] ) ? (string) $payload['image_name'] : '',
				'mime_type'     => isset( $payload['image_mime_type'] ) ? (string) $payload['image_mime_type'] : '',
				'width'         => isset( $payload['image_width'] ) ? (int) $payload['image_width'] : 0,
				'height'        => isset( $payload['image_height'] ) ? (int) $payload['image_height'] : 0,
			)
		);
		$settings      = self::sanitize_pattern_settings(
			$pattern_type,
			array(
				'size'       => isset( $payload['size'] ) ? (string) $payload['size'] : '',
				'density'    => isset( $payload['density'] ) ? (string) $payload['density'] : '',
				'softness'   => isset( $payload['softness'] ) ? (string) $payload['softness'] : '',
				'opacity'    => isset( $payload['opacity'] ) ? (int) $payload['opacity'] : 72,
				'angle'      => isset( $payload['angle'] ) ? (int) $payload['angle'] : 135,
				'image_mode' => isset( $payload['image_mode'] ) ? (string) $payload['image_mode'] : '',
				'dimness'    => isset( $payload['dimness'] ) ? (int) $payload['dimness'] : 0,
				'blur'       => isset( $payload['blur'] ) ? (int) $payload['blur'] : 0,
			)
		);
		$colors        = self::sanitize_pattern_colors(
			$pattern_type,
			array(
				'primary'    => $primary_hex,
				'background' => $background_hex,
				'accent'     => $accent_hex,
				'overlay'    => $overlay_hex,
			)
		);

		if ( '' === $name ) {
			return self::validation_error( 'name', 'manager.design.colors.validation_name_required' );
		}

		if ( 'image_pattern' !== $pattern_type && ( '' === $primary_hex || '' === $background_hex ) ) {
			return self::validation_error( 'colors', 'manager.design.colors.validation_pattern_colors_required' );
		}

		if ( ! in_array( $pattern_type, self::get_pattern_allowlist(), true ) ) {
			return self::validation_error( 'pattern_type', 'manager.design.colors.validation_pattern_type_invalid' );
		}

		if ( 'image_pattern' === $pattern_type && empty( $media ) ) {
			return self::validation_error( 'image_attachment_id', 'manager.design.colors.validation_image_required' );
		}

		$slug       = self::build_unique_slug( isset( $payload['slug'] ) ? (string) $payload['slug'] : $name, $full_data['patterns'], $current_item );
		$role       = self::resolve_role( isset( $payload['role'] ) ? (string) $payload['role'] : '', 'pattern', $slug, $full_data, $current_item );

		if ( is_wp_error( $role ) ) {
			return $role;
		}
		$created_at = isset( $current_item['created_at'] ) ? sanitize_text_field( (string) $current_item['created_at'] ) : self::now_iso8601();
		$item       = self::normalize_pattern(
			array(
				'id'           => isset( $current_item['id'] ) ? (string) $current_item['id'] : 'pattern-' . $slug,
				'name'         => $name,
				'slug'         => $slug,
				'type'         => 'pattern',
				'pattern_type' => $pattern_type,
				'role'         => $role,
				'description'  => isset( $payload['description'] ) ? sanitize_textarea_field( (string) $payload['description'] ) : '',
				'colors'       => $colors,
				'settings'     => $settings,
				'media'        => $media,
				'source'       => isset( $current_item['source'] ) ? (string) $current_item['source'] : 'custom',
				'created_at'   => $created_at,
				'updated_at'   => self::now_iso8601(),
			)
		);

		if ( empty( $item ) ) {
			return new WP_Error( 'sonyra_color_controller_item_invalid', self::text( 'manager.design.colors.payload_invalid' ), array( 'status' => 400 ) );
		}

		return $item;
	}

	private static function normalize_preset( array $preset ) {
		$name       = isset( $preset['name'] ) ? sanitize_text_field( (string) $preset['name'] ) : '';
		$slug       = self::sanitize_slug( isset( $preset['slug'] ) ? (string) $preset['slug'] : $name );
		$source     = self::sanitize_source( isset( $preset['source'] ) ? (string) $preset['source'] : 'core' );
		$created_at = isset( $preset['created_at'] ) ? sanitize_text_field( (string) $preset['created_at'] ) : '';
		$updated_at = isset( $preset['updated_at'] ) ? sanitize_text_field( (string) $preset['updated_at'] ) : '';

		if ( '' === $name || '' === $slug ) {
			return array();
		}

		return array(
			'id'         => self::sanitize_id( isset( $preset['id'] ) ? (string) $preset['id'] : 'preset-' . $slug ),
			'name'       => $name,
			'slug'       => $slug,
			'type'       => 'preset',
			'colors'     => self::sanitize_reference_list( isset( $preset['colors'] ) && is_array( $preset['colors'] ) ? $preset['colors'] : array() ),
			'gradients'  => self::sanitize_reference_list( isset( $preset['gradients'] ) && is_array( $preset['gradients'] ) ? $preset['gradients'] : array() ),
			'patterns'   => self::sanitize_reference_list( isset( $preset['patterns'] ) && is_array( $preset['patterns'] ) ? $preset['patterns'] : array() ),
			'source'     => '' !== $source ? $source : 'core',
			'created_at' => $created_at,
			'updated_at' => $updated_at,
		);
	}

	private static function sanitize_reference_list( array $references ): array {
		$normalized = array();

		foreach ( $references as $reference ) {
			$reference = self::sanitize_slug( (string) $reference );

			if ( '' === $reference || in_array( $reference, $normalized, true ) ) {
				continue;
			}

			$normalized[] = $reference;
		}

		return $normalized;
	}

	private static function get_collection_key( string $entity_type ): string {
		switch ( strtolower( trim( $entity_type ) ) ) {
			case 'color':
			case 'colors':
				return 'colors';
			case 'gradient':
			case 'gradients':
				return 'gradients';
			case 'pattern':
			case 'patterns':
				return 'patterns';
			default:
				return '';
		}
	}

	private static function validation_error( string $field, string $message_key ) {
		return new WP_Error(
			'sonyra_color_controller_validation_failed',
			self::text( $message_key ),
			array(
				'status' => 400,
				'errors' => array(
					$field => self::text( $message_key ),
				),
			)
		);
	}

	private static function build_unique_slug( string $candidate, array $collection, ?array $current_item ): string {
		$base_slug = self::sanitize_slug( $candidate );
		$base_slug = '' !== $base_slug ? $base_slug : sanitize_key( uniqid( 'item-', false ) );
		$slug      = $base_slug;
		$index     = 2;

		while ( self::is_slug_taken( $collection, $slug, $current_item ) ) {
			$slug = $base_slug . '-' . $index;
			$index++;
		}

		return $slug;
	}

	private static function is_slug_taken( array $collection, string $slug, ?array $current_item ): bool {
		$current_id = isset( $current_item['id'] ) ? self::sanitize_id( (string) $current_item['id'] ) : '';

		foreach ( $collection as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			if ( $current_id && isset( $item['id'] ) && $current_id === self::sanitize_id( (string) $item['id'] ) ) {
				continue;
			}

			if ( isset( $item['slug'] ) && $slug === self::sanitize_slug( (string) $item['slug'] ) ) {
				return true;
			}
		}

		return false;
	}

	private static function resolve_role( string $candidate_role, string $entity_type, string $slug, array $full_data, ?array $current_item ) {
		$role = self::sanitize_role( $candidate_role );

		if ( '' === $role ) {
			$role = self::sanitize_role( $entity_type . '.' . str_replace( '-', '.', $slug ) );
		}

		if ( '' === $role ) {
			return self::validation_error( 'role', 'manager.design.colors.validation_role_invalid' );
		}

		if ( self::is_role_taken( $full_data, $role, $current_item ) ) {
			return self::validation_error( 'role', 'manager.design.colors.validation_role_duplicate' );
		}

		return $role;
	}

	private static function is_role_taken( array $full_data, string $role, ?array $current_item ): bool {
		$current_id = isset( $current_item['id'] ) ? self::sanitize_id( (string) $current_item['id'] ) : '';

		foreach ( array( 'colors', 'gradients', 'patterns' ) as $collection_key ) {
			foreach ( isset( $full_data[ $collection_key ] ) && is_array( $full_data[ $collection_key ] ) ? $full_data[ $collection_key ] : array() as $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}

				if ( $current_id && isset( $item['id'] ) && $current_id === self::sanitize_id( (string) $item['id'] ) ) {
					continue;
				}

				if ( isset( $item['role'] ) && $role === self::sanitize_role( (string) $item['role'] ) ) {
					return true;
				}
			}
		}

		return false;
	}

	private static function now_iso8601(): string {
		return gmdate( 'c' );
	}

	private static function get_pattern_allowlist(): array {
		return array_keys( self::get_pattern_registry() );
	}

	public static function get_pattern_registry(): array {
		return array(
			'dots' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_dots',
				'description_key'  => 'manager.design.colors.pattern_desc_dots',
				'preview_style'    => 'dots',
				'allowed_controls' => array( 'size', 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'size' => 'medium', 'density' => 'medium', 'opacity' => 72 ),
			),
			'grid' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_grid',
				'description_key'  => 'manager.design.colors.pattern_desc_grid',
				'preview_style'    => 'grid',
				'allowed_controls' => array( 'size', 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#F8FAFC' ),
				'default_settings' => array( 'size' => 'medium', 'density' => 'medium', 'opacity' => 56 ),
			),
			'soft_grid' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_soft_grid',
				'description_key'  => 'manager.design.colors.pattern_desc_soft_grid',
				'preview_style'    => 'soft_grid',
				'allowed_controls' => array( 'size', 'density', 'opacity', 'softness' ),
				'default_colors'   => array( 'primary' => '#A78BFA', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'size' => 'medium', 'density' => 'medium', 'opacity' => 42, 'softness' => 'soft' ),
			),
			'diagonal_lines' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_diagonal_lines',
				'description_key'  => 'manager.design.colors.pattern_desc_diagonal_lines',
				'preview_style'    => 'diagonal_lines',
				'allowed_controls' => array( 'density', 'opacity', 'angle' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 54, 'angle' => 135 ),
			),
			'diagonal_wave' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_diagonal_wave',
				'description_key'  => 'manager.design.colors.pattern_desc_diagonal_wave',
				'preview_style'    => 'diagonal_wave',
				'allowed_controls' => array( 'density', 'opacity', 'angle', 'softness' ),
				'default_colors'   => array( 'primary' => '#8B5CF6', 'background' => '#F8FAFC' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 60, 'angle' => 135, 'softness' => 'soft' ),
			),
			'thin_stripes' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_thin_stripes',
				'description_key'  => 'manager.design.colors.pattern_desc_thin_stripes',
				'preview_style'    => 'thin_stripes',
				'allowed_controls' => array( 'density', 'opacity', 'angle' ),
				'default_colors'   => array( 'primary' => '#4C1D95', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'dense', 'opacity' => 40, 'angle' => 90 ),
			),
			'checkerboard' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_checkerboard',
				'description_key'  => 'manager.design.colors.pattern_desc_checkerboard',
				'preview_style'    => 'checkerboard',
				'allowed_controls' => array( 'size', 'opacity' ),
				'default_colors'   => array( 'primary' => '#EDE9FE', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'size' => 'medium', 'opacity' => 72 ),
			),
			'isometric_grid' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_isometric_grid',
				'description_key'  => 'manager.design.colors.pattern_desc_isometric_grid',
				'preview_style'    => 'isometric_grid',
				'allowed_controls' => array( 'size', 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'size' => 'medium', 'density' => 'medium', 'opacity' => 48 ),
			),
			'orbits' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_orbits',
				'description_key'  => 'manager.design.colors.pattern_desc_orbits',
				'preview_style'    => 'orbits',
				'allowed_controls' => array( 'opacity', 'softness', 'accent' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF', 'accent' => '#EC4899' ),
				'default_settings' => array( 'opacity' => 64, 'softness' => 'soft' ),
			),
			'radial_lines' => array(
				'group'            => 'geometric',
				'label_key'        => 'manager.design.colors.pattern_type_radial_lines',
				'description_key'  => 'manager.design.colors.pattern_desc_radial_lines',
				'preview_style'    => 'radial_lines',
				'allowed_controls' => array( 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 46 ),
			),
			'soft_blobs' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_soft_blobs',
				'description_key'  => 'manager.design.colors.pattern_desc_soft_blobs',
				'preview_style'    => 'soft_blobs',
				'allowed_controls' => array( 'opacity', 'softness', 'accent' ),
				'default_colors'   => array( 'primary' => '#EDE9FE', 'background' => '#FFFFFF', 'accent' => '#DBEAFE' ),
				'default_settings' => array( 'opacity' => 80, 'softness' => 'soft' ),
			),
			'radial_aura' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_radial_aura',
				'description_key'  => 'manager.design.colors.pattern_desc_radial_aura',
				'preview_style'    => 'radial_aura',
				'allowed_controls' => array( 'opacity', 'softness', 'accent' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#F8FAFC', 'accent' => '#EC4899' ),
				'default_settings' => array( 'opacity' => 78, 'softness' => 'soft' ),
			),
			'light_burst' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_light_burst',
				'description_key'  => 'manager.design.colors.pattern_desc_light_burst',
				'preview_style'    => 'light_burst',
				'allowed_controls' => array( 'opacity', 'accent' ),
				'default_colors'   => array( 'primary' => '#A78BFA', 'background' => '#FFFFFF', 'accent' => '#F97316' ),
				'default_settings' => array( 'opacity' => 72 ),
			),
			'deep_background' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_deep_background',
				'description_key'  => 'manager.design.colors.pattern_desc_deep_background',
				'preview_style'    => 'deep_background',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#1E1B4B', 'background' => '#0F172A', 'accent' => '#7C3AED' ),
				'default_settings' => array( 'opacity' => 86, 'softness' => 'soft' ),
			),
			'accent_orbit' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_accent_orbit',
				'description_key'  => 'manager.design.colors.pattern_desc_accent_orbit',
				'preview_style'    => 'accent_orbit',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#111827', 'background' => '#FFFFFF', 'accent' => '#EC4899' ),
				'default_settings' => array( 'opacity' => 72, 'softness' => 'soft' ),
			),
			'gradient_mist' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_gradient_mist',
				'description_key'  => 'manager.design.colors.pattern_desc_gradient_mist',
				'preview_style'    => 'gradient_mist',
				'allowed_controls' => array( 'opacity', 'accent', 'angle', 'softness' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#F8FAFC', 'accent' => '#DBEAFE' ),
				'default_settings' => array( 'opacity' => 74, 'angle' => 135, 'softness' => 'soft' ),
			),
			'aurora' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_aurora',
				'description_key'  => 'manager.design.colors.pattern_desc_aurora',
				'preview_style'    => 'aurora',
				'allowed_controls' => array( 'opacity', 'accent', 'softness', 'angle' ),
				'default_colors'   => array( 'primary' => '#22C55E', 'background' => '#0F172A', 'accent' => '#38BDF8' ),
				'default_settings' => array( 'opacity' => 72, 'softness' => 'soft', 'angle' => 135 ),
			),
			'soft_glow' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_soft_glow',
				'description_key'  => 'manager.design.colors.pattern_desc_soft_glow',
				'preview_style'    => 'soft_glow',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#EDE9FE', 'background' => '#FFFFFF', 'accent' => '#FCE7F3' ),
				'default_settings' => array( 'opacity' => 82, 'softness' => 'soft' ),
			),
			'airy_haze' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_airy_haze',
				'description_key'  => 'manager.design.colors.pattern_desc_airy_haze',
				'preview_style'    => 'airy_haze',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#DBEAFE', 'background' => '#FFFFFF', 'accent' => '#EDE9FE' ),
				'default_settings' => array( 'opacity' => 70, 'softness' => 'soft' ),
			),
			'light_spots' => array(
				'group'            => 'atmospheric',
				'label_key'        => 'manager.design.colors.pattern_type_light_spots',
				'description_key'  => 'manager.design.colors.pattern_desc_light_spots',
				'preview_style'    => 'light_spots',
				'allowed_controls' => array( 'density', 'opacity', 'accent' ),
				'default_colors'   => array( 'primary' => '#F59E0B', 'background' => '#FFFFFF', 'accent' => '#EC4899' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 68 ),
			),
			'ink_blots' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_ink_blots',
				'description_key'  => 'manager.design.colors.pattern_desc_ink_blots',
				'preview_style'    => 'ink_blots',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#312E81', 'background' => '#F8FAFC', 'accent' => '#7C3AED' ),
				'default_settings' => array( 'opacity' => 76, 'softness' => 'medium' ),
			),
			'paint_strokes' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_paint_strokes',
				'description_key'  => 'manager.design.colors.pattern_desc_paint_strokes',
				'preview_style'    => 'paint_strokes',
				'allowed_controls' => array( 'opacity', 'accent', 'angle' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF', 'accent' => '#F97316' ),
				'default_settings' => array( 'opacity' => 72, 'angle' => 45 ),
			),
			'watercolor_spots' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_watercolor_spots',
				'description_key'  => 'manager.design.colors.pattern_desc_watercolor_spots',
				'preview_style'    => 'watercolor_spots',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#C4B5FD', 'background' => '#FFFFFF', 'accent' => '#FBCFE8' ),
				'default_settings' => array( 'opacity' => 76, 'softness' => 'soft' ),
			),
			'liquid_gradient' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_liquid_gradient',
				'description_key'  => 'manager.design.colors.pattern_desc_liquid_gradient',
				'preview_style'    => 'liquid_gradient',
				'allowed_controls' => array( 'opacity', 'accent', 'angle', 'softness' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#F8FAFC', 'accent' => '#EC4899' ),
				'default_settings' => array( 'opacity' => 82, 'angle' => 135, 'softness' => 'soft' ),
			),
			'marble_flow' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_marble_flow',
				'description_key'  => 'manager.design.colors.pattern_desc_marble_flow',
				'preview_style'    => 'marble_flow',
				'allowed_controls' => array( 'opacity', 'accent', 'angle' ),
				'default_colors'   => array( 'primary' => '#EDE9FE', 'background' => '#FFFFFF', 'accent' => '#C4B5FD' ),
				'default_settings' => array( 'opacity' => 70, 'angle' => 90 ),
			),
			'abstract_waves' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_abstract_waves',
				'description_key'  => 'manager.design.colors.pattern_desc_abstract_waves',
				'preview_style'    => 'abstract_waves',
				'allowed_controls' => array( 'opacity', 'accent', 'softness', 'angle' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF', 'accent' => '#DBEAFE' ),
				'default_settings' => array( 'opacity' => 68, 'softness' => 'soft', 'angle' => 135 ),
			),
			'noisy_texture' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_noisy_texture',
				'description_key'  => 'manager.design.colors.pattern_desc_noisy_texture',
				'preview_style'    => 'noisy_texture',
				'allowed_controls' => array( 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#334155', 'background' => '#F8FAFC' ),
				'default_settings' => array( 'density' => 'dense', 'opacity' => 30 ),
			),
			'paper_grain' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_paper_grain',
				'description_key'  => 'manager.design.colors.pattern_desc_paper_grain',
				'preview_style'    => 'paper_grain',
				'allowed_controls' => array( 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#CBD5E1', 'background' => '#FFFBEB' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 40 ),
			),
			'glass_glow' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_glass_glow',
				'description_key'  => 'manager.design.colors.pattern_desc_glass_glow',
				'preview_style'    => 'glass_glow',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#FFFFFF', 'background' => '#DBEAFE', 'accent' => '#C4B5FD' ),
				'default_settings' => array( 'opacity' => 62, 'softness' => 'soft' ),
			),
			'plastic_gloss' => array(
				'group'            => 'artistic',
				'label_key'        => 'manager.design.colors.pattern_type_plastic_gloss',
				'description_key'  => 'manager.design.colors.pattern_desc_plastic_gloss',
				'preview_style'    => 'plastic_gloss',
				'allowed_controls' => array( 'opacity', 'accent' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#FFFFFF', 'accent' => '#FFFFFF' ),
				'default_settings' => array( 'opacity' => 64 ),
			),
			'soft_noise' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_soft_noise',
				'description_key'  => 'manager.design.colors.pattern_desc_soft_noise',
				'preview_style'    => 'soft_noise',
				'allowed_controls' => array( 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#475569', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 24 ),
			),
			'stardust' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_stardust',
				'description_key'  => 'manager.design.colors.pattern_desc_stardust',
				'preview_style'    => 'stardust',
				'allowed_controls' => array( 'density', 'opacity', 'accent' ),
				'default_colors'   => array( 'primary' => '#FFFFFF', 'background' => '#111827', 'accent' => '#A78BFA' ),
				'default_settings' => array( 'density' => 'dense', 'opacity' => 72 ),
			),
			'pixel_sprinkle' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_pixel_sprinkle',
				'description_key'  => 'manager.design.colors.pattern_desc_pixel_sprinkle',
				'preview_style'    => 'pixel_sprinkle',
				'allowed_controls' => array( 'density', 'opacity', 'accent' ),
				'default_colors'   => array( 'primary' => '#7C3AED', 'background' => '#F8FAFC', 'accent' => '#EC4899' ),
				'default_settings' => array( 'density' => 'dense', 'opacity' => 58 ),
			),
			'motion_lines' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_motion_lines',
				'description_key'  => 'manager.design.colors.pattern_desc_motion_lines',
				'preview_style'    => 'motion_lines',
				'allowed_controls' => array( 'density', 'opacity', 'angle' ),
				'default_colors'   => array( 'primary' => '#0F172A', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'dense', 'opacity' => 34, 'angle' => 0 ),
			),
			'light_rings' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_light_rings',
				'description_key'  => 'manager.design.colors.pattern_desc_light_rings',
				'preview_style'    => 'light_rings',
				'allowed_controls' => array( 'opacity', 'accent', 'softness' ),
				'default_colors'   => array( 'primary' => '#A78BFA', 'background' => '#FFFFFF', 'accent' => '#DBEAFE' ),
				'default_settings' => array( 'opacity' => 58, 'softness' => 'soft' ),
			),
			'bubbles' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_bubbles',
				'description_key'  => 'manager.design.colors.pattern_desc_bubbles',
				'preview_style'    => 'bubbles',
				'allowed_controls' => array( 'density', 'opacity', 'accent' ),
				'default_colors'   => array( 'primary' => '#DBEAFE', 'background' => '#FFFFFF', 'accent' => '#C4B5FD' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 60 ),
			),
			'micro_dots' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_micro_dots',
				'description_key'  => 'manager.design.colors.pattern_desc_micro_dots',
				'preview_style'    => 'micro_dots',
				'allowed_controls' => array( 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#64748B', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'dense', 'opacity' => 42 ),
			),
			'fine_texture' => array(
				'group'            => 'decorative',
				'label_key'        => 'manager.design.colors.pattern_type_fine_texture',
				'description_key'  => 'manager.design.colors.pattern_desc_fine_texture',
				'preview_style'    => 'fine_texture',
				'allowed_controls' => array( 'density', 'opacity' ),
				'default_colors'   => array( 'primary' => '#CBD5E1', 'background' => '#FFFFFF' ),
				'default_settings' => array( 'density' => 'medium', 'opacity' => 36 ),
			),
			'image_pattern' => array(
				'group'            => 'image',
				'label_key'        => 'manager.design.colors.pattern_type_image_pattern',
				'description_key'  => 'manager.design.colors.pattern_desc_image_pattern',
				'preview_style'    => 'image_pattern',
				'allowed_controls' => array( 'image', 'image_mode', 'opacity', 'dimness', 'blur', 'overlay' ),
				'default_colors'   => array( 'overlay' => '#0F172A' ),
				'default_settings' => array( 'image_mode' => 'cover', 'opacity' => 100, 'dimness' => 0, 'blur' => 0 ),
				'requires_media'   => true,
			),
		);
	}

	public static function get_pattern_registry_payload(): array {
		$payload = array();

		foreach ( self::get_pattern_registry() as $key => $definition ) {
			$payload[] = array(
				'key'              => $key,
				'group'            => isset( $definition['group'] ) ? (string) $definition['group'] : 'decorative',
				'group_label'      => self::text( 'manager.design.colors.pattern_group_' . ( isset( $definition['group'] ) ? (string) $definition['group'] : 'decorative' ) ),
				'label'            => self::text( isset( $definition['label_key'] ) ? (string) $definition['label_key'] : '' ),
				'description'      => self::text( isset( $definition['description_key'] ) ? (string) $definition['description_key'] : '' ),
				'preview_style'    => isset( $definition['preview_style'] ) ? (string) $definition['preview_style'] : $key,
				'allowed_controls' => isset( $definition['allowed_controls'] ) && is_array( $definition['allowed_controls'] ) ? array_values( array_map( 'strval', $definition['allowed_controls'] ) ) : array(),
				'default_colors'   => isset( $definition['default_colors'] ) && is_array( $definition['default_colors'] ) ? $definition['default_colors'] : array(),
				'default_settings' => isset( $definition['default_settings'] ) && is_array( $definition['default_settings'] ) ? $definition['default_settings'] : array(),
				'requires_media'   => ! empty( $definition['requires_media'] ),
			);
		}

		return $payload;
	}

	private static function sanitize_pattern_colors( string $pattern_type, array $colors ): array {
		$allowed = array(
			'primary',
			'background',
			'accent',
			'overlay',
			'base',
			'accent_a',
			'accent_b',
			'accent_c',
		);
		$normalized = array();

		foreach ( $colors as $key => $value ) {
			$key = sanitize_key( (string) $key );
			$hex = self::normalize_hex( $value );

			if ( '' === $key || '' === $hex || ! in_array( $key, $allowed, true ) ) {
				continue;
			}

			$normalized[ $key ] = $hex;
		}

		if ( 'image_pattern' === $pattern_type && empty( $normalized['overlay'] ) ) {
			$normalized['overlay'] = '#0F172A';
		}

		return $normalized;
	}

	private static function sanitize_pattern_settings( string $pattern_type, array $settings ): array {
		$definition = self::get_pattern_registry();
		$allowed    = isset( $definition[ $pattern_type ]['allowed_controls'] ) && is_array( $definition[ $pattern_type ]['allowed_controls'] ) ? $definition[ $pattern_type ]['allowed_controls'] : array();
		$defaults   = isset( $definition[ $pattern_type ]['default_settings'] ) && is_array( $definition[ $pattern_type ]['default_settings'] ) ? $definition[ $pattern_type ]['default_settings'] : array();
		$normalized = $defaults;

		if ( in_array( 'size', $allowed, true ) ) {
			$normalized['size'] = self::sanitize_enum_value( isset( $settings['size'] ) ? (string) $settings['size'] : ( isset( $defaults['size'] ) ? (string) $defaults['size'] : 'medium' ), array( 'small', 'medium', 'large' ), 'medium' );
		}

		if ( in_array( 'density', $allowed, true ) ) {
			$normalized['density'] = self::sanitize_enum_value( isset( $settings['density'] ) ? (string) $settings['density'] : ( isset( $defaults['density'] ) ? (string) $defaults['density'] : 'medium' ), array( 'low', 'medium', 'dense' ), 'medium' );
		}

		if ( in_array( 'softness', $allowed, true ) ) {
			$normalized['softness'] = self::sanitize_enum_value( isset( $settings['softness'] ) ? (string) $settings['softness'] : ( isset( $defaults['softness'] ) ? (string) $defaults['softness'] : 'soft' ), array( 'crisp', 'medium', 'soft' ), 'soft' );
		}

		if ( in_array( 'opacity', $allowed, true ) ) {
			$normalized['opacity'] = self::sanitize_percentage_value( isset( $settings['opacity'] ) ? $settings['opacity'] : ( isset( $defaults['opacity'] ) ? $defaults['opacity'] : 72 ), 72 );
		}

		if ( in_array( 'angle', $allowed, true ) ) {
			$normalized['angle'] = self::sanitize_angle_value( isset( $settings['angle'] ) ? $settings['angle'] : ( isset( $defaults['angle'] ) ? $defaults['angle'] : 135 ), 135 );
		}

		if ( in_array( 'image_mode', $allowed, true ) ) {
			$normalized['image_mode'] = self::sanitize_enum_value( isset( $settings['image_mode'] ) ? (string) $settings['image_mode'] : ( isset( $defaults['image_mode'] ) ? (string) $defaults['image_mode'] : 'cover' ), array( 'cover', 'contain', 'repeat', 'center', 'stretch' ), 'cover' );
		}

		if ( in_array( 'dimness', $allowed, true ) ) {
			$normalized['dimness'] = self::sanitize_percentage_value( isset( $settings['dimness'] ) ? $settings['dimness'] : ( isset( $defaults['dimness'] ) ? $defaults['dimness'] : 0 ), 0 );
		}

		if ( in_array( 'blur', $allowed, true ) ) {
			$normalized['blur'] = max( 0, min( 16, isset( $settings['blur'] ) ? (int) $settings['blur'] : ( isset( $defaults['blur'] ) ? (int) $defaults['blur'] : 0 ) ) );
		}

		return $normalized;
	}

	private static function normalize_pattern_media( array $media ): array {
		$attachment_id = isset( $media['attachment_id'] ) ? (int) $media['attachment_id'] : 0;

		if ( $attachment_id <= 0 || ! function_exists( 'wp_get_attachment_url' ) ) {
			return array();
		}

		$url  = wp_get_attachment_url( $attachment_id );
		$mime = function_exists( 'get_post_mime_type' ) ? (string) get_post_mime_type( $attachment_id ) : '';
		$post = function_exists( 'get_post' ) ? get_post( $attachment_id ) : null;

		if ( empty( $url ) || ! self::is_allowed_image_mime_type( $mime ) || ! $post || 'attachment' !== $post->post_type ) {
			return array();
		}

		$metadata  = function_exists( 'wp_get_attachment_metadata' ) ? wp_get_attachment_metadata( $attachment_id ) : array();
		$thumb_url = function_exists( 'wp_get_attachment_image_url' ) ? wp_get_attachment_image_url( $attachment_id, 'medium' ) : '';

		return array(
			'attachment_id' => $attachment_id,
			'url'           => esc_url_raw( $url ),
			'thumb_url'     => esc_url_raw( $thumb_url ? $thumb_url : $url ),
			'name'          => sanitize_text_field( get_the_title( $attachment_id ) ),
			'mime_type'     => sanitize_text_field( $mime ),
			'width'         => isset( $metadata['width'] ) ? (int) $metadata['width'] : 0,
			'height'        => isset( $metadata['height'] ) ? (int) $metadata['height'] : 0,
		);
	}

	public static function get_allowed_image_mime_types(): array {
		return array(
			'image/jpeg',
			'image/png',
			'image/webp',
		);
	}

	public static function is_allowed_image_mime_type( string $mime_type ): bool {
		return in_array( strtolower( trim( $mime_type ) ), self::get_allowed_image_mime_types(), true );
	}

	public static function get_max_image_upload_size_bytes(): int {
		$max = function_exists( 'wp_max_upload_size' ) ? (int) wp_max_upload_size() : 8 * 1024 * 1024;

		return max( 1024 * 1024, $max );
	}

	private static function sanitize_enum_value( string $value, array $allowed, string $fallback ): string {
		$value = sanitize_key( $value );

		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	private static function sanitize_percentage_value( $value, int $fallback ): int {
		if ( ! is_numeric( $value ) ) {
			return $fallback;
		}

		return max( 0, min( 100, (int) $value ) );
	}

	private static function sanitize_angle_value( $value, int $fallback ): int {
		if ( ! is_numeric( $value ) ) {
			return $fallback;
		}

		$angle = (int) $value;

		return $angle >= 0 && $angle <= 360 ? $angle : $fallback;
	}

	private static function persist_data( array $data ): bool {
		if ( false === get_option( self::OPTION_NAME, false ) ) {
			return add_option( self::OPTION_NAME, $data, '', false );
		}

		return update_option( self::OPTION_NAME, $data, false );
	}

	private static function sanitize_slug( string $value ): string {
		$slug = sanitize_title( $value );

		return sanitize_key( $slug );
	}

	private static function sanitize_id( string $value ): string {
		$value = strtolower( trim( $value ) );
		$value = (string) preg_replace( '/[^a-z0-9_-]/', '-', $value );
		$value = trim( $value, '-' );

		return '' !== $value ? $value : sanitize_key( uniqid( 'sonyra-color-', true ) );
	}

	private static function sanitize_role( string $value ): string {
		$value = strtolower( trim( $value ) );

		return (string) preg_replace( '/[^a-z0-9._-]/', '', $value );
	}

	private static function sanitize_source( string $value ): string {
		$value = strtolower( trim( $value ) );

		return (string) preg_replace( '/[^a-z0-9._-]/', '', $value );
	}

	private static function get_session_uuid_from_context( array $context ): string {
		if ( empty( $context ) && class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			$context = Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();
		}

		return isset( $context['session_uuid'] ) ? sanitize_text_field( (string) $context['session_uuid'] ) : '';
	}

	private static function get_nonce_tick(): int {
		return (int) ceil( time() / ( 12 * HOUR_IN_SECONDS ) );
	}

	private static function build_nonce_for_tick( string $session_uuid, int $tick ): string {
		$data = $session_uuid . '|' . self::NONCE_ACTION . '|' . (string) $tick;

		return substr( wp_hash( $data, 'nonce' ), -12, 10 );
	}
}
