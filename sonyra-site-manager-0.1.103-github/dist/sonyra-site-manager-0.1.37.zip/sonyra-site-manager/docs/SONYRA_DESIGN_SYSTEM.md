# SONYRA Design System

## Назначение

Этот документ фиксирует контракт будущей дизайн-системы SONYRA Site Manager.

Интерфейс должен выглядеть как готовый premium SaaS-продукт, а не как техническая админка.

## Общие правила SONYRA

Во всех будущих design-этапах используются только канонические написания:

- SONYRA
- SONYRA Site Platform
- SONYRA Site Manager
- SONYRA STUDIO

Неправильные варианты Sonira, Sanira, Sunaira, Сонира нельзя использовать как рабочие названия.

Весь видимый пользовательский интерфейс будущего продукта должен быть только на русском языке.

Английские пользовательские UI-строки и англицизмы запрещены.

Исключения допустимы только для технически неизбежных терминов: API, REST, HTML, iframe, URL, JSON, CSS, JS, PHP, WordPress, shortcode, nonce, slug.

Пользовательские строки будущего интерфейса должны идти через i18n.

Будущий основной i18n-файл:

- assets/i18n/i18n-ru.js

Будущий helper:

- t('key')

Никаких “красивых, но мёртвых” кнопок. Каждый интерактивный элемент должен иметь рабочую цепочку:

DOM/root selector -> selector элемента -> handler -> loading state -> request/action -> success/error render -> UI update.

Deploy по умолчанию запрещён. Будущие zip-релизы собираются только в ./dist/. Предыдущие zip-релизы нельзя удалять.

## Design foundation

Дизайн строится через:

- tokens;
- components;
- layout;
- states.

Случайные цвета в отдельных экранах запрещены.

Случайные размеры, тени, радиусы и отступы запрещены.

Будущие файлы design foundation:

- assets/design/sonyra-tokens.css
- assets/design/sonyra-components.css
- assets/design/sonyra-layout.css
- assets/design/sonyra-states.css
- assets/design/sonyra-manager.css

## Component states

Все компоненты должны иметь состояния:

- обычное;
- наведение;
- фокус;
- загрузка;
- успех;
- ошибка;
- отключено;
- пустое состояние.

## Обязательные компоненты

Design system должен описывать и поддерживать:

- кнопки;
- карточки;
- панели;
- поля ввода;
- переключатели;
- бейджи;
- модальные окна;
- выезжающие панели;
- уведомления;
- боковое меню;
- верхняя панель;
- пустые состояния;
- состояния загрузки;
- состояния ошибки;
- состояния успеха;
- прогресс;
- карточки дашборда;
- карточки модулей;
- панель кода вставки;
- управление логотипом;
- управление градиентами.

Видимые названия компонентов в пользовательском UI должны быть по-русски. Технические имена классов и файлов могут быть на английском.

## Layout contract

Layout должен обеспечивать:

- предсказуемую manager-навигацию;
- читаемые рабочие области;
- responsive-поведение для desktop, tablet и mobile;
- отсутствие визуального хаоса при пустых, загрузочных и ошибочных состояниях;
- совместимость с будущими module screens.

## Visual acceptance rule

Любой UI/design-этап не принят, если Codex не дал визуальный отчёт:

- DOM-структура;
- CSS-слои;
- responsive-поведение;
- состояния элементов;
- i18n-источник видимых строк;
- отсутствие английских UI-слов;
- рабочая цепочка controls.

## Login shell design pattern

Login shell должен использовать premium SaaS pattern:

- centered auth card;
- brand area;
- clean SaaS background;
- identifier input “Электронная почта или логин”;
- code input state;
- primary action button;
- secondary text actions;
- accessible inputs;
- status messages;
- mobile responsive pattern;
- no raw technical styling;
- no global selectors;
- no password field on first release.

## STOP-условия

Немедленно остановиться, если design-этап требует случайных CSS-решений вне design system, английских видимых UI-строк, обхода i18n, обхода security rules или создания декоративных controls без рабочей цепочки.
