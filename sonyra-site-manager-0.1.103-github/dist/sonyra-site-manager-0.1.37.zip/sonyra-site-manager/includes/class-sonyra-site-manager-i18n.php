<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_I18n {

	/**
	 * @var array|null
	 */
	private static $ru_strings = null;

	public static function get_ru_source_path(): string {
		return SONYRA_SITE_MANAGER_DIR . 'includes/i18n/ru.php';
	}

	public static function get_ru_strings(): array {
		if ( null !== self::$ru_strings ) {
			return self::$ru_strings;
		}

		$source_path = self::get_ru_source_path();

		if ( ! file_exists( $source_path ) ) {
			self::$ru_strings = array();

			return self::$ru_strings;
		}

		$strings = require $source_path;

		if ( ! is_array( $strings ) ) {
			self::$ru_strings = array();

			return self::$ru_strings;
		}

		self::$ru_strings = $strings;

		return self::$ru_strings;
	}

	public static function t( string $key, string $fallback = '' ): string {
		$strings = self::get_ru_strings();

		if ( array_key_exists( $key, $strings ) && is_string( $strings[ $key ] ) ) {
			return $strings[ $key ];
		}

		return $fallback;
	}

	public static function has( string $key ): bool {
		$strings = self::get_ru_strings();

		return array_key_exists( $key, $strings ) && is_string( $strings[ $key ] );
	}

	public static function get_status(): array {
		$required_login_keys = array(
			'login.title_identifier',
			'login.title_code',
			'login.title_success',
			'login.title_error',
			'login.identifier_label',
			'login.request_button',
		);

		$login_strings_ready = true;

		foreach ( $required_login_keys as $key ) {
			if ( ! self::has( $key ) ) {
				$login_strings_ready = false;
				break;
			}
		}

		return array(
			'i18n_ready'          => file_exists( self::get_ru_source_path() ) && count( self::get_ru_strings() ) > 0,
			'i18n_source'         => self::get_ru_source_path(),
			'ru_strings_count'    => count( self::get_ru_strings() ),
			'login_strings_ready' => $login_strings_ready,
		);
	}
}
