(function () {
	'use strict';

	var STORAGE_KEY = 'sonyra_manager_sidebar_state';
	var MOBILE_QUERY = '(max-width: 780px)';
	var shell = document.querySelector('[data-manager-shell]');

	if (!shell) {
		return;
	}

	var toggleButton = shell.querySelector('[data-manager-sidebar-toggle]');
	var logoButton = shell.querySelector('[data-manager-logo-toggle]');
	var sidebar = shell.querySelector('.sonyra-manager-sidebar');
	var backdrop = shell.querySelector('[data-manager-backdrop]');
	var routeButtons = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-route]'));
	var views = Array.prototype.slice.call(shell.querySelectorAll('[data-manager-view]'));
	var pageKicker = shell.querySelector('[data-manager-kicker]');
	var topbarTitle = shell.querySelector('[data-manager-title]');
	var pageDescription = shell.querySelector('[data-manager-description]');
	var pageHeaderIcon = shell.querySelector('[data-manager-header-icon]');
	var pageBadges = shell.querySelector('[data-manager-badges]');
	var logoutButton = shell.querySelector('[data-manager-logout]');
	var logoutError = shell.querySelector('[data-manager-logout-error]');
	var mediaQuery = window.matchMedia ? window.matchMedia(MOBILE_QUERY) : null;
	var sidebarMotionTimer = 0;

	function isMobile() {
		return mediaQuery ? mediaQuery.matches : window.innerWidth <= 780;
	}

	function getStoredState() {
		try {
			var value = window.localStorage.getItem(STORAGE_KEY);
			return value === 'collapsed' || value === 'expanded' ? value : '';
		} catch (error) {
			return '';
		}
	}

	function storeState(state) {
		try {
			window.localStorage.setItem(STORAGE_KEY, state);
		} catch (error) {}
	}

	function clearSidebarMotionTimer() {
		if (sidebarMotionTimer) {
			window.clearTimeout(sidebarMotionTimer);
			sidebarMotionTimer = 0;
		}
	}

	function finishSidebarMotion() {
		clearSidebarMotionTimer();
		shell.removeAttribute('data-sidebar-motion');
	}

	function beginSidebarMotion() {
		clearSidebarMotionTimer();
		shell.setAttribute('data-sidebar-motion', 'active');
		sidebarMotionTimer = window.setTimeout(finishSidebarMotion, 340);
	}

	function setSidebarState(state, shouldStore, shouldAnimate) {
		var nextState = state === 'collapsed' ? 'collapsed' : 'expanded';
		var currentState = shell.getAttribute('data-sidebar-state') || '';
		var shouldRunMotion = shouldAnimate === true && currentState && currentState !== nextState;
		var expanded = nextState === 'expanded';

		if (shouldRunMotion) {
			beginSidebarMotion();
		}

		shell.setAttribute('data-sidebar-state', nextState);
		shell.classList.toggle('sonyra-manager-mobile-open', expanded && isMobile());

		if (toggleButton) {
			toggleButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			toggleButton.setAttribute('aria-label', expanded ? (toggleButton.dataset.labelExpanded || '') : (toggleButton.dataset.labelCollapsed || ''));
		}

		if (logoButton) {
			logoButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			logoButton.setAttribute('aria-label', expanded ? (logoButton.dataset.labelExpanded || '') : (logoButton.dataset.labelCollapsed || ''));
		}

		if (backdrop) {
			backdrop.hidden = !(expanded && isMobile());
		}

		if (shouldStore) {
			storeState(nextState);
		}
	}

	function handleSidebarTransitionEnd(event) {
		if (!shell.hasAttribute('data-sidebar-motion')) {
			return;
		}

		if (
			(event.target === shell && event.propertyName === 'grid-template-columns') ||
			(event.target === sidebar && event.propertyName === 'width')
		) {
			finishSidebarMotion();
		}
	}

	function getRouteFromHash() {
		var hash = window.location.hash || '';
		var route = hash.replace(/^#\/?/, '').replace(/^\//, '');
		return route || 'dashboard';
	}

	function normalizeRoute(route) {
		var found = views.some(function (view) {
			return view.getAttribute('data-manager-view') === route;
		});

		return found ? route : 'dashboard';
	}

	function findTemplate(selector, route) {
		return shell.querySelector(selector + '="' + route + '"]');
	}

	function clearNode(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function updateHeaderIcon(route) {
		var iconTemplate = findTemplate('[data-manager-icon-template', route);

		if (pageHeaderIcon && iconTemplate && iconTemplate.firstElementChild) {
			clearNode(pageHeaderIcon);
			pageHeaderIcon.appendChild(iconTemplate.firstElementChild.cloneNode(true));
		}
	}

	function updateHeaderBadges(route) {
		var badgeTemplate = findTemplate('[data-manager-badge-template', route);

		if (pageBadges && badgeTemplate && badgeTemplate.firstElementChild) {
			pageBadges.parentNode.replaceChild(badgeTemplate.firstElementChild.cloneNode(true), pageBadges);
			pageBadges = shell.querySelector('[data-manager-badges]');
		}
	}

	function setRoute(route, shouldUpdateHash) {
		var nextRoute = normalizeRoute(route);
		var activeButton = null;

		views.forEach(function (view) {
			view.hidden = view.getAttribute('data-manager-view') !== nextRoute;
		});

		routeButtons.forEach(function (button) {
			var isActive = button.getAttribute('data-manager-route') === nextRoute;
			button.classList.toggle('sonyra-manager-nav-item-active', isActive);

			if (isActive) {
				button.setAttribute('aria-current', 'page');
				activeButton = button;
			} else {
				button.removeAttribute('aria-current');
			}
		});

		if (activeButton) {
			if (pageKicker) {
				pageKicker.textContent = activeButton.dataset.kicker || '';
			}

			if (topbarTitle) {
				topbarTitle.textContent = activeButton.dataset.title || activeButton.textContent || '';
			}

			if (pageDescription) {
				pageDescription.textContent = activeButton.dataset.description || '';
			}

			updateHeaderIcon(nextRoute);
			updateHeaderBadges(nextRoute);
		}

		if (shouldUpdateHash && window.location.hash !== '#/' + nextRoute) {
			window.location.hash = '#/' + nextRoute;
		}

		if (isMobile()) {
			setSidebarState('collapsed', false, true);
		}
	}

	function showLogoutError() {
		if (logoutError) {
			logoutError.hidden = false;
		}
	}

	function redirectToLogin() {
		var loginUrl = shell.getAttribute('data-login-url') || '/manager/login';
		window.location.assign(loginUrl);
	}

	function runLogout() {
		var logoutUrl = shell.getAttribute('data-logout-url') || '';

		if (!logoutUrl || logoutUrl.indexOf('://') === -1 && logoutUrl.charAt(0) !== '/') {
			showLogoutError();
			return;
		}

		if (logoutButton) {
			logoutButton.disabled = true;
		}

		fetch(logoutUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': shell.getAttribute('data-nonce') || ''
			},
			body: '{}'
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('logout_failed');
			}

			return response.json().catch(function () {
				return {};
			});
		}).then(function () {
			redirectToLogin();
		}).catch(function () {
			showLogoutError();

			if (logoutButton) {
				logoutButton.disabled = false;
			}
		});
	}

	routeButtons.forEach(function (button) {
		button.addEventListener('click', function () {
			setRoute(button.getAttribute('data-manager-route') || 'dashboard', true);
		});
	});

	if (toggleButton) {
		toggleButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true, true);
		});
	}

	if (logoButton) {
		logoButton.addEventListener('click', function () {
			setSidebarState(shell.getAttribute('data-sidebar-state') === 'expanded' ? 'collapsed' : 'expanded', true, true);
		});
	}

	if (backdrop) {
		backdrop.addEventListener('click', function () {
			setSidebarState('collapsed', false, true);
		});
	}

	if (logoutButton) {
		logoutButton.addEventListener('click', runLogout);
	}

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && isMobile() && shell.getAttribute('data-sidebar-state') === 'expanded') {
			setSidebarState('collapsed', false, true);
		}
	});

	window.addEventListener('hashchange', function () {
		setRoute(getRouteFromHash(), false);
	});

	if (mediaQuery && mediaQuery.addEventListener) {
		mediaQuery.addEventListener('change', function () {
			setSidebarState(isMobile() ? 'collapsed' : (getStoredState() || 'expanded'), false);
		});
	}

	shell.addEventListener('transitionend', handleSidebarTransitionEnd);

	if (sidebar) {
		sidebar.addEventListener('transitionend', handleSidebarTransitionEnd);
	}

	setSidebarState(getStoredState() || (isMobile() ? 'collapsed' : 'expanded'), false);
	setRoute(getRouteFromHash(), false);
}());
