<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Manager_Renderer {

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	private static function versioned_asset_url( string $url, string $path, string $query_arg = 'ver' ): string {
		if ( ! file_exists( $path ) ) {
			return '';
		}

		$asset_mtime = filemtime( $path );
		$asset_version = SONYRA_SITE_MANAGER_VERSION;

		if ( is_int( $asset_mtime ) ) {
			$asset_version .= '-' . $asset_mtime;
		}

		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( $query_arg, $asset_version, $url );
		}

		return $url . '?' . rawurlencode( $query_arg ) . '=' . rawurlencode( $asset_version );
	}

	private static function render_icon( string $name, string $class_name = 'sonyra-manager-icon' ): void {
		if ( class_exists( 'Sonyra_Site_Manager_Icon_Renderer' ) ) {
			Sonyra_Site_Manager_Icon_Renderer::display(
				$name,
				array(
					'class'       => 'sonyra-icon ' . $class_name,
					'aria_hidden' => true,
				)
			);
		}
	}

	private static function get_sections(): array {
		return array(
			'dashboard' => array(
				'route'       => 'dashboard',
				'nav_label'   => 'manager.nav_dashboard',
				'title'       => 'manager.section_dashboard_title',
				'kicker'      => 'manager.section_dashboard_kicker',
				'description' => 'manager.section_dashboard_description',
				'icon_key'    => 'layout-dashboard',
				'badges'      => array(
					array(
						'label'    => 'manager.badge_work_mode',
						'icon_key' => 'circle-check',
						'tone'     => 'ready',
					),
				),
				'enabled'     => true,
			),
			'setup'     => array(
				'route'       => 'setup',
				'nav_label'   => 'manager.nav_site',
				'title'       => 'manager.section_setup_title',
				'kicker'      => 'manager.section_setup_kicker',
				'description' => 'manager.section_setup_description',
				'icon_key'    => 'app-window',
				'badges'      => array(),
				'enabled'     => true,
			),
			'pages'     => array(
				'route'       => 'pages',
				'nav_label'   => 'manager.nav_pages',
				'title'       => 'manager.section_pages_title',
				'kicker'      => 'manager.section_pages_kicker',
				'description' => 'manager.section_pages_description',
				'icon_key'    => 'file-text',
				'badges'      => array(),
				'enabled'     => true,
			),
			'design'    => array(
				'route'       => 'design',
				'nav_label'   => 'manager.nav_design',
				'title'       => 'manager.section_design_title',
				'kicker'      => 'manager.section_design_kicker',
				'description' => 'manager.section_design_description',
				'icon_key'    => 'brush',
				'badges'      => array(),
				'enabled'     => true,
			),
			'modules'   => array(
				'route'       => 'modules',
				'nav_label'   => 'manager.nav_modules',
				'title'       => 'manager.section_modules_title',
				'kicker'      => 'manager.section_modules_kicker',
				'description' => 'manager.section_modules_description',
				'icon_key'    => 'components',
				'badges'      => array(),
				'enabled'     => true,
			),
			'security'  => array(
				'route'       => 'security',
				'nav_label'   => 'manager.nav_security',
				'title'       => 'manager.section_security_title',
				'kicker'      => 'manager.section_security_kicker',
				'description' => 'manager.section_security_description',
				'icon_key'    => 'shield-check',
				'badges'      => array(),
				'enabled'     => true,
			),
			'settings'  => array(
				'route'       => 'settings',
				'nav_label'   => 'manager.nav_settings',
				'title'       => 'manager.section_settings_title',
				'kicker'      => 'manager.section_settings_kicker',
				'description' => 'manager.section_settings_description',
				'icon_key'    => 'settings',
				'badges'      => array(),
				'enabled'     => true,
			),
		);
	}

	private static function get_nav_items(): array {
		return array_values( self::get_sections() );
	}

	private static function get_views(): array {
		return self::get_sections();
	}

	private static function render_page_badges( array $badges, string $attr_name = '' ): void {
		$badges = array_slice( $badges, 0, 4 );
		$hidden = empty( $badges ) ? ' hidden' : '';
		?>
		<div class="sonyra-manager-page-badges"<?php echo '' !== $attr_name ? ' ' . esc_attr( $attr_name ) : ''; ?><?php echo $hidden; ?>>
			<?php foreach ( $badges as $badge ) : ?>
				<?php
				$badge_icon = isset( $badge['icon_key'] ) ? (string) $badge['icon_key'] : 'info-circle';
				$badge_tone = isset( $badge['tone'] ) ? (string) $badge['tone'] : 'neutral';
				?>
				<span class="sonyra-manager-page-badge sonyra-manager-page-badge-<?php echo esc_attr( $badge_tone ); ?>">
					<?php self::render_icon( $badge_icon, 'sonyra-manager-icon sonyra-manager-page-badge-icon' ); ?>
					<span><?php echo esc_html( self::text( (string) $badge['label'] ) ); ?></span>
				</span>
			<?php endforeach; ?>
		</div>
		<?php
	}

	private static function render_page_header( array $section ): void {
		?>
		<header class="sonyra-manager-topbar sonyra-manager-page-header">
			<div class="sonyra-manager-page-header-icon" data-manager-header-icon>
				<?php self::render_icon( (string) $section['icon_key'], 'sonyra-manager-icon sonyra-manager-page-header-svg' ); ?>
			</div>
			<div class="sonyra-manager-page-header-copy">
				<p class="sonyra-manager-page-kicker" data-manager-kicker><?php echo esc_html( self::text( (string) $section['kicker'] ) ); ?></p>
				<h1 class="sonyra-manager-page-title" data-manager-title><?php echo esc_html( self::text( (string) $section['title'] ) ); ?></h1>
				<p class="sonyra-manager-page-description" data-manager-description><?php echo esc_html( self::text( (string) $section['description'] ) ); ?></p>
			</div>
			<?php self::render_page_badges( isset( $section['badges'] ) ? (array) $section['badges'] : array(), 'data-manager-badges' ); ?>
		</header>
		<?php
	}

	private static function render_page_header_templates( array $sections ): void {
		?>
		<div class="sonyra-manager-header-templates" hidden>
			<?php foreach ( $sections as $section ) : ?>
				<span data-manager-icon-template="<?php echo esc_attr( $section['route'] ); ?>"><?php self::render_icon( (string) $section['icon_key'], 'sonyra-manager-icon sonyra-manager-page-header-svg' ); ?></span>
				<span data-manager-badge-template="<?php echo esc_attr( $section['route'] ); ?>"><?php self::render_page_badges( isset( $section['badges'] ) ? (array) $section['badges'] : array(), 'data-manager-badges' ); ?></span>
			<?php endforeach; ?>
		</div>
		<?php
	}

	public static function render_shell(): void {
		$css_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/css/sonyra-manager.css';
		$css_url = plugins_url( 'assets/css/sonyra-manager.css', SONYRA_SITE_MANAGER_FILE );
		$js_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/js/sonyra-manager.js';
		$js_url = plugins_url( 'assets/js/sonyra-manager.js', SONYRA_SITE_MANAGER_FILE );
		$logo_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-logo.png';
		$logo_url = plugins_url( 'assets/images/brand/pult-site-logo.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_ico_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon.ico';
		$favicon_ico_url = plugins_url( 'assets/images/brand/pult-site-favicon.ico', SONYRA_SITE_MANAGER_FILE );
		$favicon_32_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-32.png';
		$favicon_32_url = plugins_url( 'assets/images/brand/pult-site-favicon-32.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_192_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-192.png';
		$favicon_192_url = plugins_url( 'assets/images/brand/pult-site-favicon-192.png', SONYRA_SITE_MANAGER_FILE );
		$apple_touch_icon_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-apple-touch-icon-180.png';
		$apple_touch_icon_url = plugins_url( 'assets/images/brand/pult-site-apple-touch-icon-180.png', SONYRA_SITE_MANAGER_FILE );
		$logout_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/logout' ) : '';
		$login_url = function_exists( 'home_url' ) ? home_url( '/manager/login' ) : '/manager/login';
		$nonce = function_exists( 'wp_create_nonce' ) ? wp_create_nonce( 'wp_rest' ) : '';
		$year = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );
		$sections = self::get_sections();
		$views = self::get_views();
		$active_section = $sections['dashboard'];
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
		<title><?php echo esc_html( self::text( (string) $active_section['title'] ) ); ?></title>
	<?php if ( '' !== self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" href="<?php echo esc_url( self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ); ?>" sizes="any">
	<link rel="shortcut icon" href="<?php echo esc_url( self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' ) ); ?>" type="image/x-icon">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' ) ) : ?>
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<?php if ( '' !== self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' ) ) : ?>
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' ) ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( self::versioned_asset_url( $css_url, $css_path ) ); ?>">
</head>
<body class="sonyra-manager-page">
	<div class="sonyra-manager-shell" data-sidebar-state="expanded" data-manager-shell data-logout-url="<?php echo esc_url( $logout_url ); ?>" data-login-url="<?php echo esc_url( $login_url ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>">
		<div class="sonyra-manager-backdrop" data-manager-backdrop hidden></div>

			<main class="sonyra-manager-main">
				<?php self::render_page_header( $active_section ); ?>
				<?php self::render_page_header_templates( $sections ); ?>

			<div class="sonyra-manager-notice" data-manager-logout-error hidden>
				<?php self::render_icon( 'alert-circle', 'sonyra-manager-icon sonyra-manager-notice-icon' ); ?>
				<span><?php echo esc_html( self::text( 'manager.logout_error' ) ); ?></span>
				<small><?php echo esc_html( self::text( 'manager.logout_error_hint' ) ); ?></small>
			</div>

			<section class="sonyra-manager-view sonyra-manager-view-dashboard" data-manager-view="dashboard">
				<div class="sonyra-manager-hero">
						<div class="sonyra-manager-hero-icon"><?php self::render_icon( (string) $sections['setup']['icon_key'], 'sonyra-manager-icon sonyra-manager-hero-svg' ); ?></div>
					<div>
						<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( 'manager.nav_setup' ) ); ?></p>
						<h2><?php echo esc_html( self::text( 'manager.setup_title' ) ); ?></h2>
						<p><?php echo esc_html( self::text( 'manager.setup_subtitle' ) ); ?></p>
					</div>
				</div>

				<div class="sonyra-manager-dashboard-grid">
					<article class="sonyra-manager-card sonyra-manager-progress-card">
						<div class="sonyra-manager-card-head">
							<?php self::render_icon( 'gauge', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
							<h3><?php echo esc_html( self::text( 'manager.progress_title' ) ); ?></h3>
						</div>
						<div class="sonyra-manager-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="25" aria-label="<?php echo esc_attr( self::text( 'manager.progress_title' ) ); ?>">
							<span style="width:25%"></span>
						</div>
						<strong><?php echo esc_html( self::text( 'manager.progress_status' ) ); ?></strong>
						<p><?php echo esc_html( self::text( 'manager.progress_hint' ) ); ?></p>
					</article>

					<article class="sonyra-manager-card sonyra-manager-health-card">
						<div class="sonyra-manager-card-head">
							<?php self::render_icon( 'layout-dashboard', 'sonyra-manager-icon sonyra-manager-card-icon' ); ?>
							<h3><?php echo esc_html( self::text( 'manager.health_title' ) ); ?></h3>
						</div>
						<p><?php echo esc_html( self::text( 'manager.health_subtitle' ) ); ?></p>
						<div class="sonyra-manager-metrics">
							<?php self::render_metric( 'manager.metric_visitors' ); ?>
							<?php self::render_metric( 'manager.metric_clicks' ); ?>
							<?php self::render_metric( 'manager.metric_requests' ); ?>
							<?php self::render_metric( 'manager.metric_health' ); ?>
						</div>
					</article>
				</div>

				<div class="sonyra-manager-dashboard-grid sonyra-manager-dashboard-grid-wide">
					<section class="sonyra-manager-card">
						<h3><?php echo esc_html( self::text( 'manager.next_title' ) ); ?></h3>
						<div class="sonyra-manager-step-list">
							<?php self::render_step( 'shield-check', 'manager.step_auth_title', 'manager.step_auth_hint', 'manager.step_done', 'done' ); ?>
							<?php self::render_step( 'layout-dashboard', 'manager.step_workspace_title', 'manager.step_workspace_hint', 'manager.step_working', 'work' ); ?>
							<?php self::render_step( 'file-text', 'manager.step_pages_title', 'manager.step_pages_hint', 'manager.step_next', 'next' ); ?>
							<?php self::render_step( 'brush', 'manager.step_design_title', 'manager.step_design_hint', 'manager.step_next', 'next' ); ?>
							<?php self::render_step( 'components', 'manager.step_modules_title', 'manager.step_modules_hint', 'manager.step_next', 'next' ); ?>
						</div>
					</section>
					<section class="sonyra-manager-card">
						<h3><?php echo esc_html( self::text( 'manager.quick_actions_title' ) ); ?></h3>
						<div class="sonyra-manager-action-grid">
							<button type="button" class="sonyra-manager-action" data-manager-route="setup"><?php self::render_icon( 'list-check' ); ?><span><?php echo esc_html( self::text( 'manager.action_setup' ) ); ?></span></button>
							<button type="button" class="sonyra-manager-action" data-manager-route="security"><?php self::render_icon( 'shield-check' ); ?><span><?php echo esc_html( self::text( 'manager.action_security' ) ); ?></span></button>
						</div>
					</section>
				</div>
			</section>

			<?php foreach ( $views as $route => $view ) : ?>
				<?php if ( 'dashboard' === $route ) : ?>
					<?php continue; ?>
				<?php endif; ?>
					<section class="sonyra-manager-view sonyra-manager-view-placeholder" data-manager-view="<?php echo esc_attr( $route ); ?>" hidden>
						<div class="sonyra-manager-placeholder-card">
							<div class="sonyra-manager-hero-icon"><?php self::render_icon( (string) $view['icon_key'], 'sonyra-manager-icon sonyra-manager-hero-svg' ); ?></div>
							<p class="sonyra-manager-kicker"><?php echo esc_html( self::text( (string) $view['kicker'] ) ); ?></p>
							<h2><?php echo esc_html( self::text( (string) $view['title'] ) ); ?></h2>
							<p><?php echo esc_html( self::text( (string) $view['description'] ) ); ?></p>
						</div>
					</section>
				<?php endforeach; ?>

				<footer class="sonyra-login-footer">
					<span class="sonyra-login-footer-item"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></span>
					<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
					<span class="sonyra-login-footer-item"><?php echo esc_html( '© ' . $year . ' ' . self::text( 'login.footer_rights_holder' ) ); ?></span>
					<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
					<span class="sonyra-login-footer-item sonyra-login-footer-version"><?php echo esc_html( self::text( 'login.version_label' ) . ' ' . SONYRA_SITE_MANAGER_VERSION ); ?></span>
				</footer>
		</main>

		<aside class="sonyra-manager-sidebar" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_label' ) ); ?>">
			<div class="sonyra-manager-brand-row">
				<div class="sonyra-manager-brand">
					<button type="button" class="sonyra-manager-logo-tile" data-manager-logo-toggle aria-expanded="true" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-expanded="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-collapsed="<?php echo esc_attr( self::text( 'manager.sidebar_expand' ) ); ?>" data-tooltip="<?php echo esc_attr( self::text( 'manager.sidebar_expand_hint' ) ); ?>">
						<?php if ( '' !== self::versioned_asset_url( $logo_url, $logo_path ) ) : ?>
							<img src="<?php echo esc_url( self::versioned_asset_url( $logo_url, $logo_path ) ); ?>" alt="" aria-hidden="true" decoding="async">
						<?php endif; ?>
					</button>
					<span class="sonyra-manager-brand-copy">
						<strong><?php echo esc_html( self::text( 'manager.brand_name' ) ); ?></strong>
						<small><?php echo esc_html( self::text( 'manager.publisher' ) ); ?></small>
					</span>
				</div>
				<button type="button" class="sonyra-manager-sidebar-toggle" data-manager-sidebar-toggle aria-expanded="true" aria-label="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-expanded="<?php echo esc_attr( self::text( 'manager.sidebar_collapse' ) ); ?>" data-label-collapsed="<?php echo esc_attr( self::text( 'manager.sidebar_expand' ) ); ?>">
					<span class="sonyra-manager-toggle-icon"><?php self::render_icon( 'layout-sidebar-left-collapse' ); ?></span>
				</button>
			</div>

			<nav class="sonyra-manager-nav">
					<ul>
						<?php foreach ( self::get_nav_items() as $item ) : ?>
							<li>
								<button type="button" class="sonyra-manager-nav-item" data-manager-route="<?php echo esc_attr( $item['route'] ); ?>" data-kicker="<?php echo esc_attr( self::text( (string) $item['kicker'] ) ); ?>" data-title="<?php echo esc_attr( self::text( (string) $item['title'] ) ); ?>" data-description="<?php echo esc_attr( self::text( (string) $item['description'] ) ); ?>" data-tooltip="<?php echo esc_attr( self::text( (string) $item['nav_label'] ) ); ?>" <?php echo 'dashboard' === $item['route'] ? 'aria-current="page"' : ''; ?>>
									<span class="sonyra-manager-nav-icon-slot"><?php self::render_icon( (string) $item['icon_key'], 'sonyra-manager-icon sonyra-manager-nav-icon' ); ?></span>
									<span class="sonyra-manager-nav-label"><?php echo esc_html( self::text( (string) $item['nav_label'] ) ); ?></span>
								</button>
							</li>
						<?php endforeach; ?>
						<li class="sonyra-manager-nav-logout-row">
							<button type="button" class="sonyra-manager-nav-item sonyra-manager-logout" data-manager-logout data-tooltip="<?php echo esc_attr( self::text( 'manager.nav_logout' ) ); ?>">
								<span class="sonyra-manager-nav-icon-slot"><?php self::render_icon( 'logout', 'sonyra-manager-icon sonyra-manager-nav-icon' ); ?></span>
								<span class="sonyra-manager-nav-label"><?php echo esc_html( self::text( 'manager.nav_logout' ) ); ?></span>
							</button>
						</li>
					</ul>
				</nav>
			</aside>
	</div>
	<script src="<?php echo esc_url( self::versioned_asset_url( $js_url, $js_path ) ); ?>" defer></script>
</body>
</html>
		<?php
	}

	private static function render_metric( string $label_key ): void {
		?>
		<div class="sonyra-manager-metric">
			<span><?php echo esc_html( self::text( $label_key ) ); ?></span>
			<strong><?php echo esc_html( self::text( 'manager.metric_empty' ) ); ?></strong>
			<small><?php echo esc_html( self::text( 'manager.metric_pending' ) ); ?></small>
		</div>
		<?php
	}

	private static function render_step( string $icon, string $title_key, string $hint_key, string $status_key, string $state ): void {
		?>
		<div class="sonyra-manager-step sonyra-manager-step-<?php echo esc_attr( $state ); ?>">
			<span class="sonyra-manager-step-icon"><?php self::render_icon( $icon ); ?></span>
			<span>
				<strong><?php echo esc_html( self::text( $title_key ) ); ?></strong>
				<small><?php echo esc_html( self::text( $hint_key ) ); ?></small>
			</span>
			<em><?php echo esc_html( self::text( $status_key ) ); ?></em>
		</div>
		<?php
	}
}
