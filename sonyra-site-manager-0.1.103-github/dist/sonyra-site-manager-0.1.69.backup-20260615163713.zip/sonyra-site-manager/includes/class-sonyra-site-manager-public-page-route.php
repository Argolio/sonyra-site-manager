<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Public_Page_Route {

	public static function register_hooks(): void {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render_public_page' ), 8 );
	}

	public static function maybe_render_public_page(): void {
		if ( self::should_skip_request() || ! class_exists( 'Sonyra_Site_Manager_Pages_Store' ) ) {
			return;
		}

		$slug = self::get_request_slug();

		if ( null === $slug ) {
			return;
		}

		if ( '' !== $slug && ! function_exists( 'is_404' ) ) {
			return;
		}

		if ( '' !== $slug && ! is_404() ) {
			return;
		}

		$page = Sonyra_Site_Manager_Pages_Store::find_public_page_by_slug( $slug );

		if ( empty( $page ) ) {
			return;
		}

		self::render_page( $page );
		exit;
	}

	private static function should_skip_request(): bool {
		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ) {
			return true;
		}

		$path = self::get_request_path();

		if ( preg_match( '#\.(?:css|js|json|xml|txt|ico|png|jpg|jpeg|gif|webp|svg|woff|woff2|ttf|map)$#i', $path ) ) {
			return true;
		}

		foreach ( array( 'manager', 'wp-admin', 'wp-json', 'wp-content', 'wp-includes' ) as $prefix ) {
			if ( $prefix === $path || 0 === strpos( $path, $prefix . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	private static function get_request_slug(): ?string {
		$path = self::get_request_path();

		if ( '' === $path ) {
			return '';
		}

		if ( false !== strpos( $path, '/' ) ) {
			return null;
		}

		return sanitize_title( $path );
	}

	private static function get_request_path(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );

		if ( '' !== $home_path && '/' !== $home_path && 0 === strpos( $path, $home_path ) ) {
			$path = substr( $path, strlen( $home_path ) );
		}

		return trim( $path, '/' );
	}

	private static function render_page( array $page ): void {
		$menu_items = Sonyra_Site_Manager_Pages_Store::get_menu_items();
		$site_name = self::get_site_name();
		$title = '' !== (string) $page['seo_title'] ? (string) $page['seo_title'] : (string) $page['title'];
		$description = isset( $page['seo_description'] ) ? (string) $page['seo_description'] : '';
		$year = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );

		if ( function_exists( 'status_header' ) ) {
			status_header( 200 );
		}

		if ( function_exists( 'nocache_headers' ) ) {
			nocache_headers();
		}

		?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( $title ); ?></title>
	<?php if ( '' !== $description ) : ?>
	<meta name="description" content="<?php echo esc_attr( $description ); ?>">
	<?php endif; ?>
	<?php self::render_stylesheet_link(); ?>
	<?php wp_head(); ?>
</head>
<body class="sonyra-public-site">
	<header class="sonyra-public-site-header">
		<a class="sonyra-public-site-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( $site_name ); ?></a>
		<?php if ( ! empty( $menu_items ) ) : ?>
			<nav class="sonyra-public-site-nav" aria-label="<?php echo esc_attr( self::text( 'manager.public.nav_label' ) ); ?>">
				<?php foreach ( $menu_items as $menu_item ) : ?>
					<a href="<?php echo esc_url( Sonyra_Site_Manager_Pages_Store::get_page_url( $menu_item ) ); ?>"><?php echo esc_html( '' !== (string) $menu_item['menu_title'] ? (string) $menu_item['menu_title'] : (string) $menu_item['title'] ); ?></a>
				<?php endforeach; ?>
			</nav>
		<?php endif; ?>
	</header>
	<main class="sonyra-public-site-main">
		<?php self::render_sections( isset( $page['sections'] ) && is_array( $page['sections'] ) ? $page['sections'] : array(), $page ); ?>
	</main>
	<footer class="sonyra-public-site-footer">
		<span><?php echo esc_html( '© ' . $year . ' ' . $site_name ); ?></span>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>
		<?php
	}

	private static function render_sections( array $sections, array $page ): void {
		if ( empty( $sections ) ) {
			?>
			<section class="sonyra-public-section sonyra-public-section-text">
				<h1><?php echo esc_html( (string) $page['title'] ); ?></h1>
			</section>
			<?php
			return;
		}

		foreach ( $sections as $section ) {
			$type = isset( $section['type'] ) ? (string) $section['type'] : 'text';

			if ( 'hero' === $type ) {
				self::render_hero_section( $section );
			} elseif ( 'contacts' === $type ) {
				self::render_contacts_section( $section );
			} else {
				self::render_text_section( $section );
			}
		}
	}

	private static function render_hero_section( array $section ): void {
		?>
		<section class="sonyra-public-section sonyra-public-section-hero">
			<?php if ( ! empty( $section['kicker'] ) ) : ?>
				<p class="sonyra-public-kicker"><?php echo esc_html( (string) $section['kicker'] ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $section['title'] ) ) : ?>
				<h1><?php echo esc_html( (string) $section['title'] ); ?></h1>
			<?php endif; ?>
			<?php if ( ! empty( $section['text'] ) ) : ?>
				<p><?php echo nl2br( esc_html( (string) $section['text'] ) ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $section['button_label'] ) && ! empty( $section['button_url'] ) ) : ?>
				<a class="sonyra-public-button" href="<?php echo esc_url( (string) $section['button_url'] ); ?>"><?php echo esc_html( (string) $section['button_label'] ); ?></a>
			<?php endif; ?>
		</section>
		<?php
	}

	private static function render_text_section( array $section ): void {
		?>
		<section class="sonyra-public-section sonyra-public-section-text">
			<?php if ( ! empty( $section['title'] ) ) : ?>
				<h2><?php echo esc_html( (string) $section['title'] ); ?></h2>
			<?php endif; ?>
			<?php if ( ! empty( $section['text'] ) ) : ?>
				<p><?php echo nl2br( esc_html( (string) $section['text'] ) ); ?></p>
			<?php endif; ?>
		</section>
		<?php
	}

	private static function render_contacts_section( array $section ): void {
		?>
		<section class="sonyra-public-section sonyra-public-section-contacts">
			<?php if ( ! empty( $section['title'] ) ) : ?>
				<h2><?php echo esc_html( (string) $section['title'] ); ?></h2>
			<?php endif; ?>
			<?php if ( ! empty( $section['text'] ) ) : ?>
				<p><?php echo nl2br( esc_html( (string) $section['text'] ) ); ?></p>
			<?php endif; ?>
			<div class="sonyra-public-contact-list">
				<?php if ( ! empty( $section['email'] ) ) : ?>
					<a href="<?php echo esc_url( 'mailto:' . sanitize_email( (string) $section['email'] ) ); ?>"><?php echo esc_html( (string) $section['email'] ); ?></a>
				<?php endif; ?>
				<?php if ( ! empty( $section['phone'] ) ) : ?>
					<span><?php echo esc_html( (string) $section['phone'] ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $section['address'] ) ) : ?>
					<span><?php echo esc_html( (string) $section['address'] ); ?></span>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	private static function get_site_name(): string {
		$name = function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'name' ) : '';

		return '' !== $name ? $name : self::text( 'manager.public.site_name_fallback' );
	}

	private static function render_stylesheet_link(): void {
		$version = defined( 'SONYRA_SITE_MANAGER_VERSION' ) ? SONYRA_SITE_MANAGER_VERSION : '1';

		if ( defined( 'SONYRA_SITE_MANAGER_FILE' ) ) {
			$css_url = plugins_url( 'assets/css/sonyra-manager.css', SONYRA_SITE_MANAGER_FILE );
			?>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( $version ); ?>">
			<?php
		}
	}

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}
}
