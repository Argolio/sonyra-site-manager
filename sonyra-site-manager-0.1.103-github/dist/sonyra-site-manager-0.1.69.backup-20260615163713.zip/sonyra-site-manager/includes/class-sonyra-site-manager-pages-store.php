<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Pages_Store {

	const OPTION_NAME = 'sonyra_site_manager_pages';
	const OPTION_VERSION = 1;
	const NONCE_ACTION = 'sonyra_pages';

	public static function get_default_data(): array {
		return array(
			'version' => self::OPTION_VERSION,
			'items'   => array(),
		);
	}

	public static function get_data(): array {
		$data = get_option( self::OPTION_NAME, self::get_default_data() );

		if ( ! is_array( $data ) ) {
			return self::get_default_data();
		}

		$items = isset( $data['items'] ) && is_array( $data['items'] ) ? $data['items'] : array();

		return array(
			'version' => self::OPTION_VERSION,
			'items'   => self::normalize_items( $items ),
		);
	}

	public static function get_items(): array {
		$data = self::get_data();

		return $data['items'];
	}

	public static function save_items( array $items ) {
		$sanitized = self::sanitize_items( $items );

		if ( is_wp_error( $sanitized ) ) {
			return $sanitized;
		}

		$data = array(
			'version' => self::OPTION_VERSION,
			'items'   => $sanitized,
		);

		$updated = update_option( self::OPTION_NAME, $data, false );

		if ( ! $updated && self::get_data() !== $data ) {
			return new WP_Error( 'sonyra_pages_save_failed', self::text( 'manager.pages.errors.save_failed' ), array( 'status' => 500 ) );
		}

		return $data;
	}

	public static function get_public_items(): array {
		return array_values(
			array_filter(
				self::get_items(),
				static function ( array $item ): bool {
					return in_array( (string) $item['status'], array( 'published', 'hidden' ), true );
				}
			)
		);
	}

	public static function get_menu_items(): array {
		$items = array_values(
			array_filter(
				self::get_items(),
				static function ( array $item ): bool {
					return 'published' === (string) $item['status'] && ! empty( $item['show_in_menu'] );
				}
			)
		);

		usort(
			$items,
			static function ( array $left, array $right ): int {
				$left_order = isset( $left['menu_order'] ) ? (int) $left['menu_order'] : 10;
				$right_order = isset( $right['menu_order'] ) ? (int) $right['menu_order'] : 10;

				if ( $left_order === $right_order ) {
					return strcmp( (string) $left['title'], (string) $right['title'] );
				}

				return $left_order < $right_order ? -1 : 1;
			}
		);

		return $items;
	}

	public static function find_home_page(): array {
		foreach ( self::get_public_items() as $item ) {
			if ( ! empty( $item['is_home'] ) ) {
				return $item;
			}
		}

		return array();
	}

	public static function find_public_page_by_slug( string $slug ): array {
		$slug = self::sanitize_slug_value( $slug );

		if ( '' === $slug ) {
			return self::find_home_page();
		}

		foreach ( self::get_public_items() as $item ) {
			if ( empty( $item['is_home'] ) && $slug === (string) $item['slug'] ) {
				return $item;
			}
		}

		return array();
	}

	public static function create_nonce( array $context = array() ): string {
		$session_uuid = self::get_session_uuid_from_context( $context );

		if ( '' === $session_uuid ) {
			return '';
		}

		return self::build_nonce_for_tick( $session_uuid, self::get_nonce_tick() );
	}

	public static function verify_nonce( string $nonce, array $context = array() ): bool {
		$nonce = sanitize_text_field( $nonce );
		$session_uuid = self::get_session_uuid_from_context( $context );

		if ( '' === $nonce || '' === $session_uuid ) {
			return false;
		}

		$current_tick = self::get_nonce_tick();

		return hash_equals( self::build_nonce_for_tick( $session_uuid, $current_tick ), $nonce )
			|| hash_equals( self::build_nonce_for_tick( $session_uuid, $current_tick - 1 ), $nonce );
	}

	public static function get_page_url( array $item ): string {
		if ( ! empty( $item['is_home'] ) ) {
			return home_url( '/' );
		}

		$slug = isset( $item['slug'] ) ? (string) $item['slug'] : '';

		return '' === $slug ? home_url( '/' ) : home_url( '/' . $slug . '/' );
	}

	private static function normalize_items( array $items ): array {
		$normalized = array();

		foreach ( $items as $item ) {
			if ( is_array( $item ) ) {
				$normalized[] = self::normalize_item( $item );
			}
		}

		return $normalized;
	}

	private static function sanitize_items( array $items ) {
		$sanitized = array();
		$used_ids = array();
		$used_slugs = array();
		$home_id = '';

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$next_item = self::sanitize_item( $item );

			if ( is_wp_error( $next_item ) ) {
				return $next_item;
			}

			if ( isset( $used_ids[ $next_item['id'] ] ) ) {
				$next_item['id'] = self::create_id();
			}

			$used_ids[ $next_item['id'] ] = true;

			if ( ! empty( $next_item['is_home'] ) ) {
				if ( '' !== $home_id ) {
					$next_item['is_home'] = false;
				} else {
					$home_id = $next_item['id'];
					$next_item['slug'] = 'home';
				}
			}

			if ( empty( $next_item['is_home'] ) ) {
				if ( '' === $next_item['slug'] ) {
					return new WP_Error( 'sonyra_pages_slug_required', self::text( 'manager.pages.errors.slug_required' ), array( 'status' => 400 ) );
				}

				if ( isset( $used_slugs[ $next_item['slug'] ] ) ) {
					return new WP_Error( 'sonyra_pages_slug_duplicate', self::text( 'manager.pages.errors.slug_duplicate' ), array( 'status' => 400 ) );
				}

				$slug_error = self::validate_slug( $next_item['slug'] );

				if ( is_wp_error( $slug_error ) ) {
					return $slug_error;
				}

				$used_slugs[ $next_item['slug'] ] = true;
			}

			$sanitized[] = $next_item;
		}

		return $sanitized;
	}

	private static function normalize_item( array $item ): array {
		$created_at = isset( $item['created_at'] ) ? sanitize_text_field( (string) $item['created_at'] ) : '';
		$updated_at = isset( $item['updated_at'] ) ? sanitize_text_field( (string) $item['updated_at'] ) : '';

		return array(
			'id'              => isset( $item['id'] ) && '' !== (string) $item['id'] ? sanitize_key( (string) $item['id'] ) : self::create_id(),
			'title'           => isset( $item['title'] ) ? sanitize_text_field( (string) $item['title'] ) : '',
			'slug'            => isset( $item['slug'] ) ? self::sanitize_slug_value( (string) $item['slug'] ) : '',
			'status'          => self::sanitize_status( isset( $item['status'] ) ? (string) $item['status'] : 'draft' ),
			'is_home'         => ! empty( $item['is_home'] ),
			'show_in_menu'    => ! empty( $item['show_in_menu'] ),
			'menu_title'      => isset( $item['menu_title'] ) ? sanitize_text_field( (string) $item['menu_title'] ) : '',
			'menu_order'      => isset( $item['menu_order'] ) ? max( 0, min( 999, absint( $item['menu_order'] ) ) ) : 10,
			'seo_title'       => isset( $item['seo_title'] ) ? sanitize_text_field( (string) $item['seo_title'] ) : '',
			'seo_description' => isset( $item['seo_description'] ) ? sanitize_textarea_field( (string) $item['seo_description'] ) : '',
			'sections'        => isset( $item['sections'] ) && is_array( $item['sections'] ) ? self::normalize_sections( $item['sections'] ) : array(),
			'created_at'      => '' !== $created_at ? $created_at : self::current_time(),
			'updated_at'      => '' !== $updated_at ? $updated_at : self::current_time(),
		);
	}

	private static function sanitize_item( array $item ) {
		$next_item = self::normalize_item( $item );

		if ( '' === $next_item['title'] ) {
			return new WP_Error( 'sonyra_pages_title_required', self::text( 'manager.pages.errors.title_required' ), array( 'status' => 400 ) );
		}

		if ( ! in_array( $next_item['status'], array( 'draft', 'published', 'hidden' ), true ) ) {
			return new WP_Error( 'sonyra_pages_status_invalid', self::text( 'manager.pages.errors.status_invalid' ), array( 'status' => 400 ) );
		}

		if ( 'published' !== $next_item['status'] ) {
			$next_item['show_in_menu'] = false;
		}

		$next_item['updated_at'] = self::current_time();

		return $next_item;
	}

	private static function normalize_sections( array $sections ): array {
		$normalized = array();

		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) ) {
				continue;
			}

			$normalized[] = self::normalize_section( $section );
		}

		return $normalized;
	}

	private static function normalize_section( array $section ): array {
		$type = isset( $section['type'] ) ? sanitize_key( (string) $section['type'] ) : 'text';

		if ( ! in_array( $type, array( 'hero', 'text', 'contacts' ), true ) ) {
			$type = 'text';
		}

		return array(
			'id'           => isset( $section['id'] ) && '' !== (string) $section['id'] ? sanitize_key( (string) $section['id'] ) : self::create_id(),
			'type'         => $type,
			'kicker'       => isset( $section['kicker'] ) ? sanitize_text_field( (string) $section['kicker'] ) : '',
			'title'        => isset( $section['title'] ) ? sanitize_text_field( (string) $section['title'] ) : '',
			'text'         => isset( $section['text'] ) ? sanitize_textarea_field( (string) $section['text'] ) : '',
			'button_label' => isset( $section['button_label'] ) ? sanitize_text_field( (string) $section['button_label'] ) : '',
			'button_url'   => isset( $section['button_url'] ) ? esc_url_raw( (string) $section['button_url'] ) : '',
			'email'        => isset( $section['email'] ) ? sanitize_email( (string) $section['email'] ) : '',
			'phone'        => isset( $section['phone'] ) ? sanitize_text_field( (string) $section['phone'] ) : '',
			'address'      => isset( $section['address'] ) ? sanitize_text_field( (string) $section['address'] ) : '',
		);
	}

	private static function sanitize_status( string $status ): string {
		return in_array( $status, array( 'draft', 'published', 'hidden' ), true ) ? $status : 'draft';
	}

	private static function sanitize_slug_value( string $slug ): string {
		$slug = trim( $slug, " \t\n\r\0\x0B/" );

		return sanitize_title( $slug );
	}

	private static function validate_slug( string $slug ) {
		if ( in_array( $slug, self::get_reserved_slugs(), true ) ) {
			return new WP_Error( 'sonyra_pages_slug_reserved', self::text( 'manager.pages.errors.slug_reserved' ), array( 'status' => 400 ) );
		}

		if ( self::wordpress_permalink_exists( $slug ) ) {
			return new WP_Error( 'sonyra_pages_slug_conflict', self::text( 'manager.pages.errors.slug_conflict' ), array( 'status' => 400 ) );
		}

		return true;
	}

	private static function wordpress_permalink_exists( string $slug ): bool {
		if ( function_exists( 'url_to_postid' ) && url_to_postid( home_url( '/' . $slug . '/' ) ) > 0 ) {
			return true;
		}

		if ( function_exists( 'get_page_by_path' ) ) {
			$post = get_page_by_path( $slug, OBJECT, array( 'page', 'post' ) );

			return is_object( $post );
		}

		return false;
	}

	private static function get_reserved_slugs(): array {
		return array(
			'manager',
			'wp-admin',
			'wp-login-php',
			'wp-json',
			'feed',
			'sitemap-xml',
			'robots-txt',
			'favicon-ico',
			'xmlrpc-php',
			'wp-content',
			'wp-includes',
			'author',
			'category',
			'tag',
			'search',
		);
	}

	private static function create_id(): string {
		if ( function_exists( 'wp_generate_uuid4' ) ) {
			return sanitize_key( wp_generate_uuid4() );
		}

		return sanitize_key( uniqid( 'sonyra-page-', true ) );
	}

	private static function current_time(): string {
		return function_exists( 'current_time' ) ? current_time( 'mysql' ) : gmdate( 'Y-m-d H:i:s' );
	}

	private static function get_session_uuid_from_context( array $context ): string {
		if ( empty( $context ) && class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			$context = Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();
		}

		return isset( $context['session_uuid'] ) ? sanitize_text_field( (string) $context['session_uuid'] ) : '';
	}

	private static function get_nonce_tick(): int {
		return (int) ceil( time() / ( 12 * HOUR_IN_SECONDS ) );
	}

	private static function build_nonce_for_tick( string $session_uuid, int $tick ): string {
		$data = $session_uuid . '|' . self::NONCE_ACTION . '|' . (string) $tick;

		return substr( wp_hash( $data, 'nonce' ), -12, 10 );
	}

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}
}
