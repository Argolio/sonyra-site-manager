(function () {
	'use strict';

	var root = document.querySelector('[data-color-controller-root]');
	var app = root ? root.querySelector('[data-color-controller-app]') : null;
	var payloadNode = document.getElementById('sonyra-manager-color-controller-payload');
	var helpEntriesNode = document.getElementById('sonyra-manager-help-entries');

	if (!root || !app || !payloadNode) {
		return;
	}

	var payload = parseJson(payloadNode.textContent || '{}') || {};
	var helpEntries = parseJson(helpEntriesNode ? (helpEntriesNode.textContent || '[]') : '[]') || [];
	var helpMap = {};
	var patternRegistry = normalizePatternRegistry(payload.patternRegistry || []);

	helpEntries.forEach(function (entry) {
		if (entry && entry.key) {
			helpMap[String(entry.key)] = entry;
		}
	});

	var state = {
		routeActive: false,
		view: 'landing',
		activeTab: 'colors',
		data: normalizeData(payload.data || {}),
		summary: normalizeSummary(payload.summary || {}),
		apiUrl: String(payload.apiUrl || ''),
		mediaUploadUrl: String(payload.mediaUploadUrl || ''),
		mediaLibraryUrl: String(payload.mediaLibraryUrl || ''),
		nonce: String(payload.nonce || ''),
		helpKey: String(payload.helpKey || ''),
		message: null,
		modal: null,
		helpOpen: false
	};

	function parseJson(source) {
		try {
			return JSON.parse(source);
		} catch (error) {
			return null;
		}
	}

	function t(key, fallback) {
		var dictionary = payload && payload.dictionary ? payload.dictionary : {};
		return dictionary[key] || fallback || '';
	}

	function getManagerUi() {
		if (!window.SonyraManagerUI) {
			throw new Error('[SonyraManagerUI] Shared manager UI library is not loaded.');
		}

		return window.SonyraManagerUI;
	}

	function normalizePatternRegistry(entries) {
		var map = {};

		(entries || []).forEach(function (entry) {
			if (!entry || !entry.key) {
				return;
			}

			map[String(entry.key)] = {
				key: String(entry.key),
				group: String(entry.group || 'decorative'),
				groupLabel: String(entry.group_label || ''),
				label: String(entry.label || ''),
				description: String(entry.description || ''),
				previewStyle: String(entry.preview_style || entry.key),
				allowedControls: Array.isArray(entry.allowed_controls) ? entry.allowed_controls.slice() : [],
				defaultColors: entry.default_colors && typeof entry.default_colors === 'object' ? entry.default_colors : {},
				defaultSettings: entry.default_settings && typeof entry.default_settings === 'object' ? entry.default_settings : {},
				requiresMedia: entry.requires_media === true
			};
		});

		return map;
	}

	function normalizeData(data) {
		return {
			colors: Array.isArray(data.colors) ? data.colors.slice() : [],
			gradients: Array.isArray(data.gradients) ? data.gradients.slice() : [],
			patterns: Array.isArray(data.patterns) ? data.patterns.slice() : [],
			presets: Array.isArray(data.presets) ? data.presets.slice() : [],
			library_meta: data.library_meta && typeof data.library_meta === 'object' ? data.library_meta : {}
		};
	}

	function normalizeSummary(summary) {
		return {
			colors: Number(summary.colors || 0),
			gradients: Number(summary.gradients || 0),
			patterns: Number(summary.patterns || 0),
			presets: Number(summary.presets || 0)
		};
	}

	function createNode(tag, className, text) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (typeof text === 'string') {
			node.textContent = text;
		}
		return node;
	}

	function createButton(className, text, iconName) {
		return getManagerUi().renderButton({
			className: className,
			text: text,
			iconKey: normalizeSharedIconKey(iconName)
		});
	}

	function normalizeSharedIconKey(iconName) {
		if (iconName === 'arrowLeft') {
			return 'arrow-left';
		}

		if (iconName === 'close') {
			return 'x';
		}

		return iconName;
	}

	function clearNode(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function normalizeHex(value) {
		var next = String(value || '').trim().toUpperCase();
		if (next && next.charAt(0) !== '#') {
			next = '#' + next;
		}
		return /^#[0-9A-F]{6}$/.test(next) ? next : '';
	}

	function formatUpdated(value) {
		if (!value) {
			return '—';
		}
		var date = new Date(value);
		if (isNaN(date.getTime())) {
			return '—';
		}
		return date.toLocaleString(payload.currentLocale || 'ru-RU', {
			day: '2-digit',
			month: '2-digit',
			year: 'numeric',
			hour: '2-digit',
			minute: '2-digit'
		});
	}

	function formatCount(value, oneKey, fewKey, manyKey) {
		var count = Math.max(0, Number(value || 0));
		var mod10 = count % 10;
		var mod100 = count % 100;
		var noun = t(manyKey);

		if (mod10 === 1 && mod100 !== 11) {
			noun = t(oneKey);
		} else if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) {
			noun = t(fewKey);
		}

		return String(count) + ' ' + noun;
	}

	function getCollectionKey(entityType) {
		if (entityType === 'color') {
			return 'colors';
		}
		if (entityType === 'gradient') {
			return 'gradients';
		}
		return 'patterns';
	}

	function getCurrentEntityType() {
		if (state.activeTab === 'colors') {
			return 'color';
		}
		if (state.activeTab === 'gradients') {
			return 'gradient';
		}
		return 'pattern';
	}

	function getEntityCollection() {
		return state.data[getCollectionKey(getCurrentEntityType())] || [];
	}

	function getEntityCreateKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.create_color';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.create_gradient';
		}
		return 'manager.design.colors.create_pattern';
	}

	function getEntityEditKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.edit_color';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.edit_gradient';
		}
		return 'manager.design.colors.edit_pattern';
	}

	function getEntityDeleteTitleKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.delete_color_title';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.delete_gradient_title';
		}
		return 'manager.design.colors.delete_pattern_title';
	}

	function getEntityDeleteBodyKey(entityType) {
		if (entityType === 'color') {
			return 'manager.design.colors.delete_color_body';
		}
		if (entityType === 'gradient') {
			return 'manager.design.colors.delete_gradient_body';
		}
		return 'manager.design.colors.delete_pattern_body';
	}

	function getModalDescriptionKey(entityType, mode) {
		if (entityType === 'color') {
			return mode === 'edit' ? 'manager.design.colors.modal_color_edit_description' : 'manager.design.colors.modal_color_create_description';
		}
		if (entityType === 'gradient') {
			return mode === 'edit' ? 'manager.design.colors.modal_gradient_edit_description' : 'manager.design.colors.modal_gradient_create_description';
		}
		return mode === 'edit' ? 'manager.design.colors.modal_pattern_edit_description' : 'manager.design.colors.modal_pattern_create_description';
	}

	function getPatternDefinition(patternType) {
		return patternRegistry[String(patternType || '')] || null;
	}

	function getDefaultPatternType() {
		return 'dots';
	}

	function getColorValue(item, key, fallbackKey) {
		var colors = item && item.colors ? item.colors : {};
		return String(colors[key] || colors[fallbackKey] || '');
	}

	function getGradientStopColor(item, index) {
		var stops = Array.isArray(item && item.stops) ? item.stops : [];
		var stop = stops[index] || stops[stops.length - 1] || null;
		return stop && stop.color_hex ? String(stop.color_hex) : '';
	}

	function getPatternSetting(item, key, fallback) {
		var settings = item && item.settings ? item.settings : {};
		return settings[key] !== undefined ? settings[key] : fallback;
	}

	function hasCollectionShape(data) {
		return !!(data && typeof data === 'object' && Array.isArray(data.colors) && Array.isArray(data.gradients) && Array.isArray(data.patterns));
	}

	function buildSummaryFromData(data) {
		var normalized = normalizeData(data || {});
		return normalizeSummary({
			colors: normalized.colors.length,
			gradients: normalized.gradients.length,
			patterns: normalized.patterns.length,
			presets: normalized.presets.length
		});
	}

	function applyResponse(response) {
		var nextData = hasCollectionShape(response && response.data) ? response.data : (hasCollectionShape(response && response.library) ? response.library : null);

		if (nextData) {
			state.data = normalizeData(nextData);
		}

		if (response && response.summary && typeof response.summary === 'object') {
			state.summary = normalizeSummary(response.summary);
		} else if (nextData) {
			state.summary = buildSummaryFromData(nextData);
		}

		state.message = response.message ? { type: 'success', text: String(response.message) } : null;
	}

	function getDestructiveModalSubtitleText() {
		return String(payload && payload.messages && payload.messages.destructiveModalSubtitle ? payload.messages.destructiveModalSubtitle : t('manager.design.colors.delete_modal_description'));
	}

	function buildSummaryChips() {
		var wrap = createNode('div', 'sonyra-manager-meta-chip-group');
		[
			formatCount(state.summary.colors, 'manager.design.colors.count_color_one', 'manager.design.colors.count_color_few', 'manager.design.colors.count_color_many'),
			formatCount(state.summary.gradients, 'manager.design.colors.count_gradient_one', 'manager.design.colors.count_gradient_few', 'manager.design.colors.count_gradient_many'),
			formatCount(state.summary.patterns, 'manager.design.colors.count_pattern_one', 'manager.design.colors.count_pattern_few', 'manager.design.colors.count_pattern_many')
		].forEach(function (label) {
			wrap.appendChild(getManagerUi().renderMetaChip({
				className: 'sonyra-manager-meta-chip',
				text: label
			}));
		});
		return wrap;
	}

	function buildHelpTooltip() {
		var triggerId = 'help-trigger-' + String(state.helpKey || 'design-colors-controller').replace(/[^a-z0-9_-]/gi, '-');

		return getManagerUi().renderHelpTrigger({
			helpKey: state.helpKey || 'design.colors.controller',
			triggerId: triggerId,
			ariaLabel: t('manager.pages.actions.help_tooltip'),
			expanded: state.helpOpen,
			triggerAttributeName: 'data-color-help-toggle'
		});
	}

	function buildLandingCard() {
		var card = createNode('article', 'sonyra-color-controller__tool-card sonyra-color-controller__landing');
		var head = createNode('div', 'sonyra-color-controller__tool-card-head');
		var icon = createNode('div', 'sonyra-color-controller__tool-card-icon');
		var copy = createNode('div', 'sonyra-color-controller__tool-card-copy');
		var title = createNode('h2', 'sonyra-color-controller__tool-card-title', t('manager.design.tools.color_library.title'));
		var description = createNode('p', 'sonyra-color-controller__tool-card-description', t('manager.design.tools.color_library.description'));
		var footer = createNode('div', 'sonyra-color-controller__tool-card-footer');
		var action = createButton('sonyra-manager-pages-primary', t('manager.design.tools.color_library.action'), 'plus');

		action.setAttribute('data-color-open-library', 'true');
		head.appendChild(icon);
		copy.appendChild(title);
		copy.appendChild(description);
		head.appendChild(copy);
		footer.appendChild(buildSummaryChips());
		footer.appendChild(action);
		card.appendChild(head);
		card.appendChild(footer);

		return card;
	}

	function buildContext() {
		var back = createButton('sonyra-manager-pages-secondary', t('manager.design.colors.back_to_design'), 'arrowLeft');

		back.setAttribute('data-color-back', 'true');

		return getManagerUi().renderContextCard({
			className: 'sonyra-pages-sections-context sonyra-pages-layer-context sonyra-manager-pages-table-card sonyra-color-controller__context',
			copyClassName: 'sonyra-pages-sections-context-copy sonyra-pages-layer-context-copy',
			titleWrapClassName: 'sonyra-pages-panel-title-wrap',
			actionsClassName: 'sonyra-pages-layer-context-actions sonyra-color-controller__context-actions',
			labelNode: createNode('span', 'sonyra-pages-sections-context-label', t('manager.design.colors.context_title')),
			helpNode: buildHelpTooltip(),
			titleNode: createNode('strong', 'sonyra-pages-sections-context-title', t('manager.design.colors.context_subtitle')),
			actions: [back]
		});
	}

	function buildToolbar() {
		var toolbar = createNode('div', 'sonyra-pages-toolbar-panel');
		var filtersWrap = createNode('div', 'sonyra-pages-toolbar-controls');
		var filterGroup = createNode('div', 'sonyra-pages-filter-group sonyra-color-controller__tabs');
		var actions = createNode('div', 'sonyra-color-controller__toolbar-actions');
		var createAction = createButton('sonyra-manager-pages-primary', t(getEntityCreateKey(getCurrentEntityType())), 'plus');

		[
			{ key: 'colors', label: t('manager.design.colors.tab_colors') },
			{ key: 'gradients', label: t('manager.design.colors.tab_gradients') },
			{ key: 'patterns', label: t('manager.design.colors.tab_patterns') }
		].forEach(function (tab) {
			var chip = createButton('sonyra-pages-filter-chip', tab.label);
			chip.setAttribute('data-color-tab', tab.key);
			chip.setAttribute('aria-pressed', state.activeTab === tab.key ? 'true' : 'false');
			chip.classList.toggle('is-active', state.activeTab === tab.key);
			filterGroup.appendChild(chip);
		});

		createAction.setAttribute('data-color-create', getCurrentEntityType());
		filtersWrap.appendChild(filterGroup);
		actions.appendChild(buildSummaryChips());
		actions.appendChild(createAction);
		toolbar.appendChild(filtersWrap);
		toolbar.appendChild(actions);

		return toolbar;
	}

	function buildMessage() {
		if (!state.message || !state.message.text) {
			return null;
		}

		var note = createNode('div', 'sonyra-color-controller__notice sonyra-color-controller__notice-' + state.message.type);
		var close = createButton('sonyra-color-controller__notice-close', '', 'close');

		note.appendChild(createNode('span', 'sonyra-color-controller__notice-text', state.message.text));
		close.setAttribute('aria-label', t('manager.pages.modal.close'));
		close.setAttribute('data-color-dismiss-message', 'true');
		note.appendChild(close);

		return note;
	}

	function renderColorSwatch(hex, large) {
		var swatch = createNode('span', 'sonyra-color-controller__swatch' + (large ? ' is-large' : ''));
		swatch.style.background = normalizeHex(hex) || '#FFFFFF';
		return swatch;
	}

	function renderGradientPreview(item, large) {
		var preview = createNode('div', 'sonyra-color-controller__gradient-preview' + (large ? ' is-large' : ''));
		var stops = Array.isArray(item && item.stops) ? item.stops : [
			{ color_hex: getGradientStopColor(item, 0) || '#7C3AED', position: 0 },
			{ color_hex: getGradientStopColor(item, 1) || '#EC4899', position: 100 }
		];
		var angle = Number(item && item.angle !== undefined ? item.angle : 135);
		var parts = stops.map(function (stop) {
			return (stop.color_hex || '#FFFFFF') + ' ' + String(Number(stop.position || 0)) + '%';
		});

		preview.style.background = 'linear-gradient(' + angle + 'deg, ' + parts.join(', ') + ')';
		return preview;
	}

	function getPatternRenderState(item, fallbackDefinition) {
		var definition = fallbackDefinition || getPatternDefinition(item.pattern_type) || getPatternDefinition(getDefaultPatternType());
		var settings = item && item.settings ? item.settings : {};
		var colors = item && item.colors ? item.colors : {};
		var media = item && item.media ? item.media : {};

		return {
			definition: definition,
			patternType: item.pattern_type || getDefaultPatternType(),
			primary: normalizeHex(colors.primary || colors.accent_a) || '#7C3AED',
			background: normalizeHex(colors.background || colors.base) || '#FFFFFF',
			accent: normalizeHex(colors.accent || colors.accent_b || colors.accent_c) || '#EC4899',
			overlay: normalizeHex(colors.overlay) || '#0F172A',
			size: String(settings.size || 'medium'),
			density: String(settings.density || 'medium'),
			softness: String(settings.softness || 'soft'),
			opacity: Number(settings.opacity !== undefined ? settings.opacity : 72),
			angle: Number(settings.angle !== undefined ? settings.angle : 135),
			imageMode: String(settings.image_mode || 'cover'),
			dimness: Number(settings.dimness !== undefined ? settings.dimness : 0),
			blur: Number(settings.blur !== undefined ? settings.blur : 0),
			media: media
		};
	}

	function densityToNumber(density) {
		if (density === 'low') {
			return 0.72;
		}
		if (density === 'dense') {
			return 1.28;
		}
		return 1;
	}

	function sizeToNumber(size) {
		if (size === 'small') {
			return 0.82;
		}
		if (size === 'large') {
			return 1.24;
		}
		return 1;
	}

	function softnessToBlur(softness) {
		if (softness === 'crisp') {
			return 0;
		}
		if (softness === 'medium') {
			return 10;
		}
		return 18;
	}

	function hexToRgba(hex, alpha) {
		var normalized = normalizeHex(hex);
		if (!normalized) {
			return 'rgba(124,58,237,' + String(alpha || 0.25) + ')';
		}
		return 'rgba('
			+ parseInt(normalized.slice(1, 3), 16) + ','
			+ parseInt(normalized.slice(3, 5), 16) + ','
			+ parseInt(normalized.slice(5, 7), 16) + ','
			+ String(alpha || 0.25) + ')';
	}

	function renderPatternPreview(item, large, definitionOverride) {
		var preview = createNode('div', 'sonyra-color-controller__pattern-preview' + (large ? ' is-large' : ''));
		var renderState = getPatternRenderState(item, definitionOverride);
		var densityFactor = densityToNumber(renderState.density);
		var sizeFactor = sizeToNumber(renderState.size);
		var blur = renderState.blur || softnessToBlur(renderState.softness);
		var alpha = Math.max(0.08, Math.min(1, renderState.opacity / 100));
		var style = renderState.definition ? renderState.definition.previewStyle : renderState.patternType;
		var stripesGap = Math.max(10, Math.round(18 / densityFactor * sizeFactor));
		var dotSize = Math.max(1.5, 2.2 * densityFactor);

		preview.style.backgroundColor = renderState.background;

		if (style === 'image_pattern') {
			preview.classList.add('has-image');
			preview.style.backgroundImage = renderState.media && renderState.media.url ? 'url("' + String(renderState.media.url).replace(/"/g, '%22') + '")' : '';
			preview.style.backgroundSize = renderState.imageMode === 'repeat' ? '140px 140px' : (renderState.imageMode === 'contain' ? 'contain' : (renderState.imageMode === 'stretch' ? '100% 100%' : 'cover'));
			preview.style.backgroundRepeat = renderState.imageMode === 'repeat' ? 'repeat' : 'no-repeat';
			preview.style.backgroundPosition = renderState.imageMode === 'center' ? 'center center' : 'center';
			preview.style.filter = renderState.blur ? 'blur(' + String(renderState.blur) + 'px)' : '';
			if (renderState.dimness > 0 || renderState.overlay) {
				var overlay = createNode('span', 'sonyra-color-controller__pattern-overlay');
				overlay.style.background = 'linear-gradient(0deg, ' + hexToRgba(renderState.overlay, Math.min(0.82, renderState.dimness / 100)) + ', ' + hexToRgba(renderState.overlay, Math.min(0.82, renderState.dimness / 100)) + ')';
				preview.appendChild(overlay);
			}
			return preview;
		}

		if (style === 'dots' || style === 'micro_dots' || style === 'pixel_sprinkle' || style === 'stardust' || style === 'bubbles' || style === 'light_spots') {
			preview.style.backgroundImage =
				'radial-gradient(' + hexToRgba(renderState.primary, alpha) + ' ' + String(dotSize) + 'px, transparent ' + String(dotSize + 1.8) + 'px), '
				+ 'radial-gradient(' + hexToRgba(renderState.accent, alpha * 0.88) + ' ' + String(dotSize * 0.86) + 'px, transparent ' + String(dotSize + 1.4) + 'px)';
			preview.style.backgroundPosition = '0 0, 18px 18px';
			preview.style.backgroundSize = String(Math.max(14, 28 / densityFactor * sizeFactor)) + 'px ' + String(Math.max(14, 28 / densityFactor * sizeFactor)) + 'px';
			return preview;
		}

		if (style === 'grid' || style === 'soft_grid' || style === 'checkerboard' || style === 'isometric_grid' || style === 'radial_lines' || style === 'motion_lines' || style === 'thin_stripes' || style === 'diagonal_lines' || style === 'diagonal_wave') {
			if (style === 'checkerboard') {
				preview.style.backgroundImage =
					'linear-gradient(45deg, ' + hexToRgba(renderState.primary, alpha) + ' 25%, transparent 25%),'
					+ 'linear-gradient(-45deg, ' + hexToRgba(renderState.primary, alpha) + ' 25%, transparent 25%),'
					+ 'linear-gradient(45deg, transparent 75%, ' + hexToRgba(renderState.primary, alpha) + ' 75%),'
					+ 'linear-gradient(-45deg, transparent 75%, ' + hexToRgba(renderState.primary, alpha) + ' 75%)';
				preview.style.backgroundSize = String(24 * sizeFactor) + 'px ' + String(24 * sizeFactor) + 'px';
				preview.style.backgroundPosition = '0 0, 0 12px, 12px -12px, -12px 0';
				return preview;
			}

			if (style === 'isometric_grid') {
				preview.style.backgroundImage =
					'linear-gradient(30deg, ' + hexToRgba(renderState.primary, alpha) + ' 12%, transparent 12.5%, transparent 87%, ' + hexToRgba(renderState.primary, alpha) + ' 87.5%, ' + hexToRgba(renderState.primary, alpha) + '),'
					+ 'linear-gradient(150deg, ' + hexToRgba(renderState.primary, alpha) + ' 12%, transparent 12.5%, transparent 87%, ' + hexToRgba(renderState.primary, alpha) + ' 87.5%, ' + hexToRgba(renderState.primary, alpha) + '),'
					+ 'linear-gradient(90deg, ' + hexToRgba(renderState.primary, alpha * 0.8) + ' 2%, transparent 2.5%, transparent 97%, ' + hexToRgba(renderState.primary, alpha * 0.8) + ' 98%)';
				preview.style.backgroundSize = String(Math.max(26, 34 * sizeFactor)) + 'px ' + String(Math.max(26, 34 * sizeFactor)) + 'px';
				return preview;
			}

			if (style === 'radial_lines') {
				preview.style.backgroundImage = 'repeating-conic-gradient(from 0deg, ' + hexToRgba(renderState.primary, alpha) + ' 0deg 2deg, transparent 2deg 14deg)';
				return preview;
			}

			if (style === 'motion_lines') {
				preview.style.backgroundImage = 'repeating-linear-gradient(' + String(renderState.angle) + 'deg, ' + hexToRgba(renderState.primary, alpha) + ' 0 2px, transparent 2px ' + String(stripesGap) + 'px)';
				return preview;
			}

			if (style === 'thin_stripes') {
				preview.style.backgroundImage = 'repeating-linear-gradient(' + String(renderState.angle) + 'deg, ' + hexToRgba(renderState.primary, alpha) + ' 0 1px, transparent 1px ' + String(Math.max(8, stripesGap * 0.7)) + 'px)';
				return preview;
			}

			if (style === 'diagonal_lines' || style === 'diagonal_wave') {
				preview.style.backgroundImage = 'repeating-linear-gradient(' + String(renderState.angle) + 'deg, ' + hexToRgba(renderState.primary, alpha) + ' 0 2px, transparent 2px ' + String(stripesGap) + 'px)';
				if (style === 'diagonal_wave') {
					var wave = createNode('span', 'sonyra-color-controller__pattern-wave');
					wave.style.background = 'radial-gradient(circle at 20% 20%, ' + hexToRgba(renderState.accent, alpha * 0.6) + ' 0, transparent 40%), radial-gradient(circle at 80% 70%, ' + hexToRgba(renderState.primary, alpha * 0.56) + ' 0, transparent 42%)';
					wave.style.filter = 'blur(' + String(softnessToBlur(renderState.softness)) + 'px)';
					preview.appendChild(wave);
				}
				return preview;
			}

			preview.style.backgroundImage =
				'linear-gradient(' + hexToRgba(renderState.primary, style === 'soft_grid' ? alpha * 0.65 : alpha) + ' 1px, transparent 1px),'
				+ 'linear-gradient(90deg, ' + hexToRgba(renderState.primary, style === 'soft_grid' ? alpha * 0.65 : alpha) + ' 1px, transparent 1px)';
			preview.style.backgroundSize = String(Math.max(16, 26 / densityFactor * sizeFactor)) + 'px ' + String(Math.max(16, 26 / densityFactor * sizeFactor)) + 'px';
			return preview;
		}

		preview.style.background =
			'radial-gradient(circle at 18% 24%, ' + hexToRgba(renderState.primary, alpha) + ', transparent 36%),'
			+ 'radial-gradient(circle at 76% 28%, ' + hexToRgba(renderState.accent, alpha * 0.9) + ', transparent 34%),'
			+ 'radial-gradient(circle at 54% 80%, ' + hexToRgba(renderState.primary, alpha * 0.64) + ', transparent 38%),'
			+ 'linear-gradient(' + String(renderState.angle) + 'deg, ' + renderState.background + ', ' + hexToRgba(renderState.background, 0.82) + ')';

		if (style === 'deep_background' || style === 'aurora' || style === 'accent_orbit') {
			preview.style.background = 'linear-gradient(135deg, ' + renderState.background + ', ' + hexToRgba(renderState.primary, 0.86) + '),'
				+ 'radial-gradient(circle at 18% 24%, ' + hexToRgba(renderState.accent, alpha) + ', transparent 36%),'
				+ 'radial-gradient(circle at 76% 28%, ' + hexToRgba(renderState.primary, alpha * 0.82) + ', transparent 34%)';
		}

		if (style === 'paint_strokes' || style === 'abstract_waves' || style === 'liquid_gradient' || style === 'gradient_mist' || style === 'marble_flow') {
			var texture = createNode('span', 'sonyra-color-controller__pattern-texture');
			texture.style.background =
				'linear-gradient(' + String(renderState.angle) + 'deg, transparent 0 15%, ' + hexToRgba(renderState.accent, alpha * 0.54) + ' 15% 28%, transparent 28% 42%, ' + hexToRgba(renderState.primary, alpha * 0.48) + ' 42% 56%, transparent 56% 72%, ' + hexToRgba(renderState.accent, alpha * 0.36) + ' 72% 88%, transparent 88% 100%)';
			texture.style.filter = 'blur(' + String(blur) + 'px)';
			preview.appendChild(texture);
		}

		if (style === 'noisy_texture' || style === 'paper_grain' || style === 'soft_noise' || style === 'fine_texture') {
			var noise = createNode('span', 'sonyra-color-controller__pattern-noise');
			noise.style.backgroundImage =
				'radial-gradient(' + hexToRgba(renderState.primary, alpha * 0.45) + ' 0.9px, transparent 1px),'
				+ 'radial-gradient(' + hexToRgba(renderState.accent, alpha * 0.22) + ' 0.7px, transparent 1px)';
			noise.style.backgroundSize = style === 'fine_texture' ? '8px 8px' : '12px 12px';
			noise.style.opacity = String(Math.min(1, alpha + 0.1));
			preview.appendChild(noise);
		}

		if (style === 'light_rings' || style === 'orbits' || style === 'bubbles' || style === 'glass_glow' || style === 'plastic_gloss') {
			var rings = createNode('span', 'sonyra-color-controller__pattern-rings');
			rings.style.background =
				'radial-gradient(circle at 72% 24%, transparent 0 14%, ' + hexToRgba(renderState.accent, alpha * 0.74) + ' 14% 15.5%, transparent 15.5% 100%),'
				+ 'radial-gradient(circle at 28% 74%, transparent 0 12%, ' + hexToRgba(renderState.primary, alpha * 0.62) + ' 12% 13.5%, transparent 13.5% 100%)';
			preview.appendChild(rings);
		}

		return preview;
	}

	function buildCardActions(entityType, itemId) {
		var actions = createNode('div', 'sonyra-pages-card-actions');
		var edit = createButton('sonyra-pages-card-action', '', 'settings');
		var remove = createButton('sonyra-pages-card-action sonyra-pages-card-action-danger', '', 'trash');

		edit.setAttribute('aria-label', t('manager.design.colors.edit_action'));
		edit.setAttribute('title', t('manager.design.colors.edit_action'));
		edit.setAttribute('data-color-edit', itemId);
		edit.setAttribute('data-color-entity', entityType);

		remove.setAttribute('aria-label', t('manager.pages.actions.delete'));
		remove.setAttribute('title', t('manager.pages.actions.delete'));
		remove.setAttribute('data-color-delete', itemId);
		remove.setAttribute('data-color-entity', entityType);

		actions.appendChild(edit);
		actions.appendChild(remove);
		return actions;
	}

	function buildColorCard(item) {
		var card = createNode('article', 'sonyra-pages-card sonyra-color-controller__entity-card sonyra-color-controller__entity-card-color');
		var body = createNode('div', 'sonyra-color-controller__entity-row');
		var visual = createNode('div', 'sonyra-color-controller__entity-visual');
		var copy = createNode('div', 'sonyra-color-controller__entity-copy');
		var actions = buildCardActions('color', item.id);
		var title = createNode('strong', 'sonyra-color-controller__entity-title', item.name || '—');
		var meta = createNode('div', 'sonyra-color-controller__entity-meta');
		var type = getManagerUi().renderMetaChip({ className: 'sonyra-manager-meta-chip sonyra-color-controller__type-chip', text: t('manager.design.colors.color_card_label') });
		var hex = getManagerUi().renderMetaChip({ className: 'sonyra-manager-meta-chip sonyra-color-controller__value-chip', text: item.value_hex || '—' });
		var updated = createNode('span', 'sonyra-color-controller__entity-updated', formatUpdated(item.updated_at));

		visual.appendChild(renderColorSwatch(item.value_hex, true));
		meta.appendChild(type);
		meta.appendChild(hex);
		copy.appendChild(title);
		copy.appendChild(meta);
		copy.appendChild(updated);
		body.appendChild(visual);
		body.appendChild(copy);
		body.appendChild(actions);
		card.appendChild(body);

		return card;
	}

	function buildGradientCard(item) {
		var card = createNode('article', 'sonyra-pages-card sonyra-color-controller__entity-card');
		var body = createNode('div', 'sonyra-color-controller__entity-stack');
		var top = createNode('div', 'sonyra-color-controller__entity-head');
		var copy = createNode('div', 'sonyra-color-controller__entity-copy');
		var actions = buildCardActions('gradient', item.id);
		var title = createNode('strong', 'sonyra-color-controller__entity-title', item.name || '—');
		var meta = createNode('div', 'sonyra-color-controller__entity-meta');
		var type = getManagerUi().renderMetaChip({ className: 'sonyra-manager-meta-chip sonyra-color-controller__type-chip', text: t('manager.design.colors.gradient_card_label') });
		var angle = getManagerUi().renderMetaChip({ className: 'sonyra-manager-meta-chip sonyra-color-controller__value-chip', text: String(Number(item.angle || 135)) + '°' });

		meta.appendChild(type);
		meta.appendChild(angle);
		copy.appendChild(title);
		copy.appendChild(meta);
		copy.appendChild(createNode('span', 'sonyra-color-controller__entity-updated', formatUpdated(item.updated_at)));
		top.appendChild(copy);
		top.appendChild(actions);
		body.appendChild(renderGradientPreview(item, true));
		body.appendChild(top);
		card.appendChild(body);

		return card;
	}

	function buildPatternCard(item) {
		var definition = getPatternDefinition(item.pattern_type);
		var card = createNode('article', 'sonyra-pages-card sonyra-color-controller__entity-card');
		var body = createNode('div', 'sonyra-color-controller__entity-stack');
		var top = createNode('div', 'sonyra-color-controller__entity-head');
		var copy = createNode('div', 'sonyra-color-controller__entity-copy');
		var actions = buildCardActions('pattern', item.id);
		var title = createNode('strong', 'sonyra-color-controller__entity-title', item.name || '—');
		var meta = createNode('div', 'sonyra-color-controller__entity-meta');
		var type = getManagerUi().renderMetaChip({ className: 'sonyra-manager-meta-chip sonyra-color-controller__type-chip', text: definition ? definition.label : String(item.pattern_type || '') });
		var group = getManagerUi().renderMetaChip({ className: 'sonyra-manager-meta-chip sonyra-color-controller__value-chip', text: definition ? definition.groupLabel : '' });

		meta.appendChild(type);
		if (definition && definition.groupLabel) {
			meta.appendChild(group);
		}
		copy.appendChild(title);
		copy.appendChild(meta);
		copy.appendChild(createNode('span', 'sonyra-color-controller__entity-updated', formatUpdated(item.updated_at)));
		top.appendChild(copy);
		top.appendChild(actions);
		body.appendChild(renderPatternPreview(item, true));
		body.appendChild(top);
		card.appendChild(body);

		return card;
	}

	function buildEmptyState() {
		var empty = createNode('div', 'sonyra-color-controller__empty');
		empty.appendChild(createNode('strong', '', t('manager.design.colors.empty_title')));
		empty.appendChild(createNode('p', '', t('manager.design.colors.empty_description')));
		return empty;
	}

	function buildGrid() {
		var grid = createNode('div', 'sonyra-color-controller__grid sonyra-color-controller__grid-' + state.activeTab);
		var collection = getEntityCollection();
		var entityType = getCurrentEntityType();

		if (!collection.length) {
			grid.appendChild(buildEmptyState());
			return grid;
		}

		collection.forEach(function (item) {
			if (entityType === 'color') {
				grid.appendChild(buildColorCard(item));
			} else if (entityType === 'gradient') {
				grid.appendChild(buildGradientCard(item));
			} else {
				grid.appendChild(buildPatternCard(item));
			}
		});

		return grid;
	}

	function buildWorkspace() {
		var workspace = createNode('div', 'sonyra-color-controller__workspace');
		var message = buildMessage();

		workspace.appendChild(buildContext());
		workspace.appendChild(buildToolbar());
		if (message) {
			workspace.appendChild(message);
		}
		workspace.appendChild(buildGrid());

		return workspace;
	}

	function getItemById(entityType, itemId) {
		var collection = state.data[getCollectionKey(entityType)] || [];
		return collection.find(function (item) {
			return String(item.id || '') === String(itemId || '');
		}) || null;
	}

	function createColorDraft(item) {
		return {
			name: item ? String(item.name || '') : '',
			value_hex: normalizeHex(item && item.value_hex ? item.value_hex : '') || '#7C3AED'
		};
	}

	function createGradientDraft(item) {
		return {
			name: item ? String(item.name || '') : '',
			first_color_hex: normalizeHex(getGradientStopColor(item, 0)) || '#7C3AED',
			second_color_hex: normalizeHex(getGradientStopColor(item, 1)) || '#EC4899',
			angle: String(Number(item && item.angle !== undefined ? item.angle : 135))
		};
	}

	function createPatternDraft(item) {
		var definition = getPatternDefinition(item && item.pattern_type ? item.pattern_type : getDefaultPatternType()) || getPatternDefinition(getDefaultPatternType());
		var media = item && item.media ? item.media : {};

		return {
			name: item ? String(item.name || '') : '',
			pattern_type: item ? String(item.pattern_type || getDefaultPatternType()) : getDefaultPatternType(),
			primary_hex: normalizeHex(getColorValue(item, 'primary', 'accent_a')) || normalizeHex(definition.defaultColors.primary) || '#7C3AED',
			background_hex: normalizeHex(getColorValue(item, 'background', 'base')) || normalizeHex(definition.defaultColors.background) || '#FFFFFF',
			accent_hex: normalizeHex(getColorValue(item, 'accent', 'accent_b')) || normalizeHex(definition.defaultColors.accent) || '#EC4899',
			overlay_hex: normalizeHex(getColorValue(item, 'overlay', 'overlay')) || normalizeHex(definition.defaultColors.overlay) || '#0F172A',
			size: String(getPatternSetting(item, 'size', definition.defaultSettings.size || 'medium')),
			density: String(getPatternSetting(item, 'density', definition.defaultSettings.density || 'medium')),
			softness: String(getPatternSetting(item, 'softness', definition.defaultSettings.softness || 'soft')),
			opacity: String(Number(getPatternSetting(item, 'opacity', definition.defaultSettings.opacity || 72))),
			angle: String(Number(getPatternSetting(item, 'angle', definition.defaultSettings.angle || 135))),
			image_mode: String(getPatternSetting(item, 'image_mode', definition.defaultSettings.image_mode || 'cover')),
			dimness: String(Number(getPatternSetting(item, 'dimness', definition.defaultSettings.dimness || 0))),
			blur: String(Number(getPatternSetting(item, 'blur', definition.defaultSettings.blur || 0))),
			image_attachment_id: media && media.attachment_id ? String(media.attachment_id) : '',
			image_url: media && media.url ? String(media.url) : '',
			image_thumb_url: media && media.thumb_url ? String(media.thumb_url) : '',
			image_name: media && media.name ? String(media.name) : '',
			image_mime_type: media && media.mime_type ? String(media.mime_type) : '',
			image_width: media && media.width ? String(media.width) : '',
			image_height: media && media.height ? String(media.height) : '',
			mediaBrowserOpen: false,
			mediaBrowserLoading: false,
			mediaBrowserLoaded: false,
			mediaBrowserError: '',
			mediaLibraryItems: []
		};
	}

	function createDraft(entityType, item) {
		if (entityType === 'color') {
			return createColorDraft(item);
		}
		if (entityType === 'gradient') {
			return createGradientDraft(item);
		}
		return createPatternDraft(item);
	}

	function openFormModal(entityType, itemId) {
		var item = itemId ? getItemById(entityType, itemId) : null;

		state.modal = {
			kind: 'form',
			entityType: entityType,
			itemId: itemId || '',
			mode: item ? 'edit' : 'create',
			draft: createDraft(entityType, item),
			errors: {},
			loading: false
		};
		state.message = null;
		render();
	}

	function replaceNamePlaceholder(text, name) {
		return String(text || '').replace(/%s/g, name || '—');
	}

	function openDeleteModal(entityType, itemId, trigger) {
		var item = getItemById(entityType, itemId);
		if (!item || typeof window.openManagerDestructiveModal !== 'function') {
			return;
		}

		state.message = null;

		window.openManagerDestructiveModal({
			entityType: entityType,
			entityName: String(item.name || ''),
			title: replaceNamePlaceholder(t(getEntityDeleteTitleKey(entityType)), String(item.name || '')),
			subtitle: getDestructiveModalSubtitleText(),
			bodyText: replaceNamePlaceholder(t(getEntityDeleteBodyKey(entityType)), String(item.name || '')),
			warningText: '',
			confirmLabel: t('manager.pages.actions.delete'),
			cancelLabel: t('manager.pages.actions.cancel'),
			closeLabel: t('manager.pages.modal.close'),
			loadingLabel: t('manager.pages.modal.deleting'),
			errorFallbackText: t('manager.design.colors.save_failed'),
			trigger: trigger || document.activeElement,
			onConfirm: function () {
				return requestJson('DELETE', buildRequestUrl(entityType, itemId)).then(function (response) {
					applyResponse(response);
					render();
				});
			}
		});
	}

	function closeModal() {
		state.modal = null;
		render();
	}

	function buildRequestUrl(entityType, itemId) {
		var base = state.apiUrl.replace(/\/$/, '');
		var path = '/' + getCollectionKey(entityType);

		if (itemId) {
			path += '/' + encodeURIComponent(itemId);
		}

		return base + path;
	}

	function requestJson(method, url, body) {
		return fetch(url, {
			method: method,
			headers: {
				'Content-Type': 'application/json',
				'X-Sonyra-Color-Controller-Nonce': state.nonce
			},
			body: body ? JSON.stringify(body) : undefined,
			credentials: 'same-origin'
		}).then(function (response) {
			return response.json().catch(function () {
				return {};
			}).then(function (json) {
				if (!response.ok) {
					var error = new Error(json.message || t('manager.design.colors.save_failed'));
					error.payload = json;
					throw error;
				}
				return json;
			});
		});
	}

	function requestUpload(url, formData) {
		return fetch(url, {
			method: 'POST',
			headers: {
				'X-Sonyra-Color-Controller-Nonce': state.nonce
			},
			body: formData,
			credentials: 'same-origin'
		}).then(function (response) {
			return response.json().catch(function () {
				return {};
			}).then(function (json) {
				if (!response.ok) {
					var error = new Error(json.message || t('manager.design.colors.media_upload_failed'));
					error.payload = json;
					throw error;
				}
				return json;
			});
		});
	}

	function buildField(labelText, control, errorText, helperText, wide) {
		var field = createNode('label', 'sonyra-manager-pages-field' + (wide ? ' sonyra-manager-pages-field-wide' : ''));
		field.appendChild(createNode('span', '', labelText));
		field.appendChild(control);
		if (helperText) {
			field.appendChild(createNode('small', 'sonyra-color-controller__field-helper', helperText));
		}
		if (errorText) {
			field.appendChild(createNode('small', 'sonyra-color-controller__field-error', errorText));
		}
		return field;
	}

	function buildTextInput(fieldKey, value) {
		var input = document.createElement('input');
		input.type = 'text';
		input.value = value || '';
		input.setAttribute('data-color-modal-field', fieldKey);
		return input;
	}

	function buildRangeInput(fieldKey, value) {
		var input = document.createElement('input');
		input.type = 'range';
		input.min = '0';
		input.max = '100';
		input.value = value || '0';
		input.setAttribute('data-color-modal-field', fieldKey);
		return input;
	}

	function buildSwatchControl(fieldKey, value, labelKey) {
		var wrap = createNode('div', 'sonyra-color-controller__swatch-control');
		var button = createNode('button', 'sonyra-color-controller__swatch-button');
		var colorInput = document.createElement('input');
		var hexInput = buildTextInput(fieldKey, value || '');

		button.type = 'button';
		button.setAttribute('data-color-swatch-button', fieldKey);
		button.setAttribute('aria-label', t(labelKey));
		button.appendChild(renderColorSwatch(value || '#FFFFFF', false));

		colorInput.type = 'color';
		colorInput.value = normalizeHex(value || '#7C3AED') || '#7C3AED';
		colorInput.setAttribute('data-color-picker-input', fieldKey);
		colorInput.className = 'sonyra-color-controller__native-picker';

		hexInput.classList.add('sonyra-color-controller__hex-input');
		wrap.appendChild(button);
		wrap.appendChild(hexInput);
		wrap.appendChild(colorInput);

		return wrap;
	}

	function buildDirectionControl(value) {
		var wrap = createNode('div', 'sonyra-color-controller__direction-control');
		['0', '45', '90', '135', '180'].forEach(function (angle) {
			var chip = createButton('sonyra-pages-filter-chip', t('manager.design.colors.direction_' + angle));
			chip.setAttribute('data-color-angle', angle);
			chip.setAttribute('aria-pressed', String(value || '135') === angle ? 'true' : 'false');
			chip.classList.toggle('is-active', String(value || '135') === angle);
			wrap.appendChild(chip);
		});
		return wrap;
	}

	function buildEnumChips(fieldKey, currentValue, options) {
		var wrap = createNode('div', 'sonyra-color-controller__option-chips');
		options.forEach(function (option) {
			var chip = createButton('sonyra-pages-filter-chip', option.label);
			chip.setAttribute('data-color-option-field', fieldKey);
			chip.setAttribute('data-color-option-value', option.value);
			chip.setAttribute('aria-pressed', String(currentValue || '') === option.value ? 'true' : 'false');
			chip.classList.toggle('is-active', String(currentValue || '') === option.value);
			wrap.appendChild(chip);
		});
		return wrap;
	}

	function buildColorEditorBody(modal) {
		var draft = modal.draft;
		var body = createNode('div', 'sonyra-color-controller__modal-form');
		var row = createNode('div', 'sonyra-color-controller__editor-preview-row');
		var live = createNode('div', 'sonyra-color-controller__editor-color-preview');

		live.style.background = normalizeHex(draft.value_hex) || '#7C3AED';
		row.appendChild(live);
		row.appendChild(createNode('span', 'sonyra-color-controller__editor-preview-copy', t('manager.design.colors.color_picker_hint')));

		body.appendChild(buildField(t('manager.design.colors.field_name'), buildTextInput('name', draft.name || ''), modal.errors.name, '', true));
		body.appendChild(buildField(t('manager.design.colors.field_color'), buildSwatchControl('value_hex', draft.value_hex || '#7C3AED', 'manager.design.colors.field_color'), modal.errors.value_hex, t('manager.design.colors.color_hex_hint'), true));
		body.appendChild(row);
		return body;
	}

	function buildGradientEditorBody(modal) {
		var draft = modal.draft;
		var body = createNode('div', 'sonyra-color-controller__modal-form');
		var preview = renderGradientPreview({
			angle: Number(draft.angle || 135),
			stops: [
				{ color_hex: normalizeHex(draft.first_color_hex) || '#7C3AED', position: 0 },
				{ color_hex: normalizeHex(draft.second_color_hex) || '#EC4899', position: 100 }
			]
		}, true);

		body.appendChild(buildField(t('manager.design.colors.field_name'), buildTextInput('name', draft.name || ''), modal.errors.name, '', true));
		body.appendChild(buildField(t('manager.design.colors.gradient_preview_label'), preview, '', '', true));
		body.appendChild(buildField(t('manager.design.colors.field_first_color'), buildSwatchControl('first_color_hex', draft.first_color_hex || '#7C3AED', 'manager.design.colors.field_first_color'), modal.errors.stops || modal.errors.first_color_hex, '', true));
		body.appendChild(buildField(t('manager.design.colors.field_second_color'), buildSwatchControl('second_color_hex', draft.second_color_hex || '#EC4899', 'manager.design.colors.field_second_color'), modal.errors.stops || modal.errors.second_color_hex, '', true));
		body.appendChild(buildField(t('manager.design.colors.gradient_direction_label'), buildDirectionControl(draft.angle || '135'), modal.errors.angle, '', true));
		return body;
	}

	function buildPatternGallery(currentType) {
		var wrap = createNode('div', 'sonyra-color-controller__pattern-gallery');
		var groups = {};

		Object.keys(patternRegistry).forEach(function (key) {
			var definition = patternRegistry[key];
			if (!groups[definition.group]) {
				groups[definition.group] = {
					label: definition.groupLabel,
					items: []
				};
			}
			groups[definition.group].items.push(definition);
		});

		Object.keys(groups).forEach(function (groupKey) {
			var section = createNode('section', 'sonyra-color-controller__pattern-group');
			var title = createNode('strong', 'sonyra-color-controller__pattern-group-title', groups[groupKey].label);
			var grid = createNode('div', 'sonyra-color-controller__pattern-gallery-grid');

			(groups[groupKey].items || []).forEach(function (definition) {
				var button = createNode('button', 'sonyra-color-controller__pattern-tile' + (definition.key === currentType ? ' is-active' : ''));
				var preview = renderPatternPreview({
					pattern_type: definition.key,
					colors: definition.defaultColors,
					settings: definition.defaultSettings,
					media: {}
				}, false, definition);
				var copy = createNode('div', 'sonyra-color-controller__pattern-tile-copy');

				button.type = 'button';
				button.setAttribute('data-color-pattern-type', definition.key);
				button.appendChild(preview);
				copy.appendChild(createNode('strong', 'sonyra-color-controller__pattern-tile-title', definition.label));
				copy.appendChild(createNode('span', 'sonyra-color-controller__pattern-tile-description', definition.description));
				button.appendChild(copy);
				grid.appendChild(button);
			});

			section.appendChild(title);
			section.appendChild(grid);
			wrap.appendChild(section);
		});

		return wrap;
	}

	function buildMediaLibrary(draft) {
		var block = createNode('div', 'sonyra-color-controller__media-library');

		if (draft.mediaBrowserLoading) {
			block.appendChild(createNode('p', 'sonyra-color-controller__media-state', t('manager.design.colors.media_loading')));
			return block;
		}

		if (draft.mediaBrowserError) {
			block.appendChild(createNode('p', 'sonyra-color-controller__media-state is-error', draft.mediaBrowserError));
			return block;
		}

		if (!draft.mediaLibraryItems.length) {
			block.appendChild(createNode('p', 'sonyra-color-controller__media-state', t('manager.design.colors.media_library_empty')));
			return block;
		}

		draft.mediaLibraryItems.forEach(function (item) {
			var button = createNode('button', 'sonyra-color-controller__media-tile');
			var image = createNode('img', 'sonyra-color-controller__media-thumb');
			var copy = createNode('div', 'sonyra-color-controller__media-copy');

			button.type = 'button';
			button.setAttribute('data-color-media-select', String(item.attachment_id || ''));
			image.src = String(item.thumb_url || item.url || '');
			image.alt = '';
			copy.appendChild(createNode('strong', 'sonyra-color-controller__media-name', String(item.name || '')));
			copy.appendChild(createNode('span', 'sonyra-color-controller__media-meta', String(item.mime_type || '')));
			button.appendChild(image);
			button.appendChild(copy);
			block.appendChild(button);
		});

		return block;
	}

	function buildMediaControl(modal) {
		var draft = modal.draft;
		var wrap = createNode('div', 'sonyra-color-controller__media-block');
		var actions = createNode('div', 'sonyra-color-controller__media-actions');
		var upload = createButton('sonyra-manager-pages-secondary', draft.image_attachment_id ? t('manager.design.colors.media_replace') : t('manager.design.colors.media_upload'), 'photo');
		var select = createButton('sonyra-manager-pages-secondary', t('manager.design.colors.media_select'), 'file');
		var remove = createButton('sonyra-manager-pages-secondary', t('manager.design.colors.media_remove'), 'trash');
		var fileInput = document.createElement('input');

		upload.setAttribute('data-color-media-upload', 'true');
		select.setAttribute('data-color-media-open-library', 'true');
		remove.setAttribute('data-color-media-remove', 'true');

		fileInput.type = 'file';
		fileInput.accept = '.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp';
		fileInput.hidden = true;
		fileInput.setAttribute('data-color-media-file', 'true');

		actions.appendChild(upload);
		actions.appendChild(select);
		if (draft.image_attachment_id) {
			actions.appendChild(remove);
		}

		if (draft.image_thumb_url || draft.image_url) {
			var preview = createNode('div', 'sonyra-color-controller__media-preview');
			var image = createNode('img', 'sonyra-color-controller__media-preview-image');
			var meta = createNode('div', 'sonyra-color-controller__media-preview-copy');

			image.src = String(draft.image_thumb_url || draft.image_url);
			image.alt = '';
			meta.appendChild(createNode('strong', 'sonyra-color-controller__media-name', draft.image_name || ''));
			meta.appendChild(createNode('span', 'sonyra-color-controller__media-meta', draft.image_mime_type || ''));
			preview.appendChild(image);
			preview.appendChild(meta);
			wrap.appendChild(preview);
		} else {
			wrap.appendChild(createNode('p', 'sonyra-color-controller__media-state', t('manager.design.colors.media_empty')));
		}

		wrap.appendChild(actions);
		wrap.appendChild(fileInput);

		if (draft.mediaBrowserOpen) {
			wrap.appendChild(createNode('strong', 'sonyra-color-controller__media-library-title', t('manager.design.colors.media_library_title')));
			wrap.appendChild(buildMediaLibrary(draft));
		}

		return wrap;
	}

	function buildPatternPreviewFromDraft(draft) {
		return renderPatternPreview({
			pattern_type: draft.pattern_type,
			colors: {
				primary: draft.primary_hex,
				background: draft.background_hex,
				accent: draft.accent_hex,
				overlay: draft.overlay_hex
			},
			settings: {
				size: draft.size,
				density: draft.density,
				softness: draft.softness,
				opacity: Number(draft.opacity || 0),
				angle: Number(draft.angle || 135),
				image_mode: draft.image_mode,
				dimness: Number(draft.dimness || 0),
				blur: Number(draft.blur || 0)
			},
			media: {
				attachment_id: draft.image_attachment_id,
				url: draft.image_url,
				thumb_url: draft.image_thumb_url,
				name: draft.image_name,
				mime_type: draft.image_mime_type,
				width: draft.image_width,
				height: draft.image_height
			}
		}, true, getPatternDefinition(draft.pattern_type));
	}

	function buildPatternEditorBody(modal) {
		var draft = modal.draft;
		var definition = getPatternDefinition(draft.pattern_type) || getPatternDefinition(getDefaultPatternType());
		var body = createNode('div', 'sonyra-color-controller__modal-form');
		var controlMap = {};

		(definition.allowedControls || []).forEach(function (control) {
			controlMap[control] = true;
		});

		body.appendChild(buildField(t('manager.design.colors.field_name'), buildTextInput('name', draft.name || ''), modal.errors.name, '', true));
		body.appendChild(buildField(t('manager.design.colors.pattern_gallery_label'), buildPatternGallery(draft.pattern_type), modal.errors.pattern_type, '', true));
		body.appendChild(buildField(t('manager.design.colors.pattern_preview_label'), buildPatternPreviewFromDraft(draft), modal.errors.colors || modal.errors.image_attachment_id, '', true));

		if (!definition.requiresMedia) {
			body.appendChild(buildField(t('manager.design.colors.field_primary_color'), buildSwatchControl('primary_hex', draft.primary_hex || '#7C3AED', 'manager.design.colors.field_primary_color'), modal.errors.colors || modal.errors.primary_hex, '', true));
			body.appendChild(buildField(t('manager.design.colors.field_background_color'), buildSwatchControl('background_hex', draft.background_hex || '#FFFFFF', 'manager.design.colors.field_background_color'), modal.errors.colors || modal.errors.background_hex, '', true));
		}

		if (controlMap.accent) {
			body.appendChild(buildField(t('manager.design.colors.field_accent_color'), buildSwatchControl('accent_hex', draft.accent_hex || '#EC4899', 'manager.design.colors.field_accent_color'), '', '', true));
		}

		if (controlMap.overlay) {
			body.appendChild(buildField(t('manager.design.colors.field_overlay_color'), buildSwatchControl('overlay_hex', draft.overlay_hex || '#0F172A', 'manager.design.colors.field_overlay_color'), '', '', true));
		}

		if (controlMap.image) {
			body.appendChild(buildField(t('manager.design.colors.pattern_media_label'), buildMediaControl(modal), modal.errors.image_attachment_id, t('manager.design.colors.image_requirement_hint'), true));
		}

		if (controlMap.size) {
			body.appendChild(buildField(
				t('manager.design.colors.field_size'),
				buildEnumChips('size', draft.size, [
					{ value: 'small', label: t('manager.design.colors.size_small') },
					{ value: 'medium', label: t('manager.design.colors.size_medium') },
					{ value: 'large', label: t('manager.design.colors.size_large') }
				]),
				'',
				'',
				true
			));
		}

		if (controlMap.density) {
			body.appendChild(buildField(
				t('manager.design.colors.field_density'),
				buildEnumChips('density', draft.density, [
					{ value: 'low', label: t('manager.design.colors.density_low') },
					{ value: 'medium', label: t('manager.design.colors.density_medium') },
					{ value: 'dense', label: t('manager.design.colors.density_dense') }
				]),
				'',
				'',
				true
			));
		}

		if (controlMap.softness) {
			body.appendChild(buildField(
				t('manager.design.colors.field_softness'),
				buildEnumChips('softness', draft.softness, [
					{ value: 'crisp', label: t('manager.design.colors.softness_crisp') },
					{ value: 'medium', label: t('manager.design.colors.softness_medium') },
					{ value: 'soft', label: t('manager.design.colors.softness_soft') }
				]),
				'',
				'',
				true
			));
		}

		if (controlMap.image_mode) {
			body.appendChild(buildField(
				t('manager.design.colors.pattern_image_mode_label'),
				buildEnumChips('image_mode', draft.image_mode, [
					{ value: 'cover', label: t('manager.design.colors.image_mode_cover') },
					{ value: 'contain', label: t('manager.design.colors.image_mode_contain') },
					{ value: 'repeat', label: t('manager.design.colors.image_mode_repeat') },
					{ value: 'center', label: t('manager.design.colors.image_mode_center') },
					{ value: 'stretch', label: t('manager.design.colors.image_mode_stretch') }
				]),
				'',
				'',
				true
			));
		}

		if (controlMap.opacity) {
			body.appendChild(buildField(t('manager.design.colors.field_opacity'), buildRangeInput('opacity', draft.opacity || '72'), '', '', true));
		}

		if (controlMap.angle) {
			body.appendChild(buildField(t('manager.design.colors.field_angle'), buildDirectionControl(draft.angle || '135'), '', '', true));
		}

		if (controlMap.dimness) {
			body.appendChild(buildField(t('manager.design.colors.field_dimness'), buildRangeInput('dimness', draft.dimness || '0'), '', '', true));
		}

		if (controlMap.blur) {
			body.appendChild(buildField(t('manager.design.colors.field_blur'), buildRangeInput('blur', draft.blur || '0'), '', '', true));
		}

		return body;
	}

	function buildModalBody() {
		if (!state.modal) {
			return createNode('div');
		}
		if (state.modal.entityType === 'color') {
			return buildColorEditorBody(state.modal);
		}
		if (state.modal.entityType === 'gradient') {
			return buildGradientEditorBody(state.modal);
		}
		return buildPatternEditorBody(state.modal);
	}

	function renderModal() {
		if (!state.modal) {
			if (!(window.isManagerDestructiveModalOpen && window.isManagerDestructiveModalOpen())) {
				document.body.classList.remove('sonyra-manager-modal-open');
			}
			return null;
		}

		document.body.classList.add('sonyra-manager-modal-open');

		var chrome = getManagerUi().renderStandardModal({
			iconKey: 'settings',
			closeIconKey: 'x',
			titleId: 'sonyra-color-modal-title',
			panelAttributes: {
				role: 'dialog',
				'aria-modal': 'true'
			},
			closeAttributes: {
				'data-color-close-modal': 'true',
				'aria-label': t('manager.pages.modal.close')
			}
		});
		var overlay = chrome.overlay;
		var title = chrome.title;
		var description = chrome.description;
		var body = chrome.body;
		var footer = chrome.footer;
		var cancel = createButton('sonyra-manager-pages-secondary', t('manager.pages.actions.cancel'));
		var save = createButton('sonyra-manager-pages-primary', state.modal.loading ? t('manager.pages.actions.saving') : t('manager.pages.actions.save'));

		overlay.setAttribute('data-color-modal-overlay', 'true');
		title.textContent = t(getEntityEditKey(state.modal.entityType), '') && state.modal.mode === 'edit'
			? t(getEntityEditKey(state.modal.entityType))
			: t(getEntityCreateKey(state.modal.entityType));
		description.textContent = t(getModalDescriptionKey(state.modal.entityType, state.modal.mode));
		body.appendChild(buildModalBody());
		cancel.setAttribute('data-color-close-modal', 'true');
		save.setAttribute('data-color-save-modal', 'true');
		if (state.modal.loading) {
			save.disabled = true;
		}
		footer.appendChild(cancel);
		footer.appendChild(save);

		return overlay;
	}

	function renderGlobalHelpPopover() {
		var layer = document.querySelector('[data-manager-help-layer]');
		var trigger;
		var triggerRect;
		var popover;
		var help = helpMap[state.helpKey] || null;
		var preferredWidth = 360;
		var gap = 10;
		var viewportPadding = 14;
		var viewportWidth = window.innerWidth || 0;
		var viewportHeight = window.innerHeight || 0;
		var left = 0;
		var top = 0;
		var placement = 'right';
		var clampedWidth;
		var popoverHeight;

		if (!state.helpOpen || !layer || !help) {
			return;
		}

		trigger = root.querySelector('[data-sonyra-help-key="' + String(state.helpKey || 'design.colors.controller') + '"]');

		if (!trigger) {
			return;
		}

		popover = createNode('article', 'sonyra-help-popover sonyra-color-controller__help-popover');
		popover.setAttribute('data-sonyra-help-scope', 'design');
		popover.setAttribute('data-color-help-popover', 'true');
		popover.setAttribute('role', 'tooltip');
		popover.appendChild(createNode('strong', 'sonyra-help-popover__title sonyra-color-controller__help-title', help.title || ''));
		popover.appendChild(createNode('p', 'sonyra-help-popover__body sonyra-color-controller__help-body', help.body || ''));
		layer.appendChild(popover);

		triggerRect = trigger.getBoundingClientRect();
		clampedWidth = Math.min(preferredWidth, Math.max(220, viewportWidth - (viewportPadding * 2)));
		popover.style.maxWidth = String(clampedWidth) + 'px';

		if (triggerRect.right + gap + clampedWidth <= viewportWidth - viewportPadding) {
			left = triggerRect.right + gap;
			placement = 'right';
		} else if (triggerRect.left - gap - clampedWidth >= viewportPadding) {
			left = triggerRect.left - gap - clampedWidth;
			placement = 'left';
		} else {
			left = Math.max(viewportPadding, Math.min(triggerRect.left, viewportWidth - clampedWidth - viewportPadding));
			placement = 'bottom';
		}

		popoverHeight = Math.ceil(popover.getBoundingClientRect().height || popover.offsetHeight || 0);

		if (placement === 'right' || placement === 'left') {
			if (triggerRect.top < viewportHeight * 0.45 && triggerRect.bottom + gap + popoverHeight <= viewportHeight - viewportPadding) {
				top = triggerRect.bottom + gap;
			} else if (triggerRect.top - gap - popoverHeight >= viewportPadding) {
				top = triggerRect.top - popoverHeight - gap;
			} else {
				top = Math.max(viewportPadding, Math.min(triggerRect.top, viewportHeight - popoverHeight - viewportPadding));
			}
		} else {
			if (triggerRect.bottom + gap + popoverHeight <= viewportHeight - viewportPadding) {
				top = triggerRect.bottom + gap;
			} else {
				top = triggerRect.top - popoverHeight - gap;
				placement = 'top';
			}
			top = Math.max(viewportPadding, Math.min(top, viewportHeight - popoverHeight - viewportPadding));
		}

		left = Math.max(viewportPadding, Math.min(left, viewportWidth - clampedWidth - viewportPadding));
		popover.style.left = String(left) + 'px';
		popover.style.top = String(top) + 'px';
		popover.setAttribute('data-popover-placement', placement);
	}

	function clearHelpPopoverScope(scope) {
		var layer = document.querySelector('[data-manager-help-layer]');
		var selector;

		if (!layer) {
			return;
		}

		selector = scope ? ('[data-sonyra-help-scope="' + scope + '"]') : '[data-sonyra-help-scope]';
		Array.prototype.slice.call(layer.querySelectorAll(selector)).forEach(function (node) {
			if (node && node.parentNode) {
				node.parentNode.removeChild(node);
			}
		});
	}

	function render() {
		clearHelpPopoverScope('design');
		clearNode(app);
		app.appendChild(state.view === 'landing' ? buildLandingCard() : buildWorkspace());
		var modal = renderModal();
		if (modal) {
			app.appendChild(modal);
		}
		renderGlobalHelpPopover();
	}

	function updateDraftField(field, value) {
		if (!state.modal || state.modal.kind !== 'form') {
			return;
		}
		state.modal.draft[field] = value;
		if (state.modal.errors && state.modal.errors[field]) {
			delete state.modal.errors[field];
		}
	}

	function setDraftEnum(field, value) {
		if (!state.modal || !state.modal.draft) {
			return;
		}
		state.modal.draft[field] = value;
		render();
	}

	function setPatternType(patternType) {
		if (!state.modal || state.modal.entityType !== 'pattern') {
			return;
		}

		var definition = getPatternDefinition(patternType) || getPatternDefinition(getDefaultPatternType());
		var draft = state.modal.draft;

		draft.pattern_type = patternType;
		draft.primary_hex = normalizeHex(draft.primary_hex) || normalizeHex(definition.defaultColors.primary) || '#7C3AED';
		draft.background_hex = normalizeHex(draft.background_hex) || normalizeHex(definition.defaultColors.background) || '#FFFFFF';
		draft.accent_hex = normalizeHex(draft.accent_hex) || normalizeHex(definition.defaultColors.accent) || '#EC4899';
		draft.overlay_hex = normalizeHex(draft.overlay_hex) || normalizeHex(definition.defaultColors.overlay) || '#0F172A';
		draft.size = String(draft.size || definition.defaultSettings.size || 'medium');
		draft.density = String(draft.density || definition.defaultSettings.density || 'medium');
		draft.softness = String(draft.softness || definition.defaultSettings.softness || 'soft');
		draft.opacity = String(draft.opacity || definition.defaultSettings.opacity || 72);
		draft.angle = String(draft.angle || definition.defaultSettings.angle || 135);
		draft.image_mode = String(draft.image_mode || definition.defaultSettings.image_mode || 'cover');
		draft.dimness = String(draft.dimness || definition.defaultSettings.dimness || 0);
		draft.blur = String(draft.blur || definition.defaultSettings.blur || 0);
		render();
	}

	function buildSubmitPayload() {
		var draft = state.modal.draft;

		if (state.modal.entityType === 'color') {
			return {
				name: String(draft.name || '').trim(),
				value_hex: normalizeHex(draft.value_hex || '')
			};
		}

		if (state.modal.entityType === 'gradient') {
			return {
				name: String(draft.name || '').trim(),
				first_color_hex: normalizeHex(draft.first_color_hex || ''),
				second_color_hex: normalizeHex(draft.second_color_hex || ''),
				angle: Number(draft.angle || 135)
			};
		}

		return {
			name: String(draft.name || '').trim(),
			pattern_type: String(draft.pattern_type || getDefaultPatternType()),
			primary_hex: normalizeHex(draft.primary_hex || ''),
			background_hex: normalizeHex(draft.background_hex || ''),
			accent_hex: normalizeHex(draft.accent_hex || ''),
			overlay_hex: normalizeHex(draft.overlay_hex || ''),
			size: String(draft.size || 'medium'),
			density: String(draft.density || 'medium'),
			softness: String(draft.softness || 'soft'),
			opacity: Number(draft.opacity || 72),
			angle: Number(draft.angle || 135),
			image_mode: String(draft.image_mode || 'cover'),
			dimness: Number(draft.dimness || 0),
			blur: Number(draft.blur || 0),
			image_attachment_id: Number(draft.image_attachment_id || 0),
			image_url: String(draft.image_url || ''),
			image_thumb_url: String(draft.image_thumb_url || ''),
			image_name: String(draft.image_name || ''),
			image_mime_type: String(draft.image_mime_type || ''),
			image_width: Number(draft.image_width || 0),
			image_height: Number(draft.image_height || 0)
		};
	}

	function submitModal() {
		if (!state.modal || state.modal.kind !== 'form' || state.modal.loading) {
			return;
		}

		state.modal.loading = true;
		render();

		requestJson(
			state.modal.mode === 'edit' ? 'PUT' : 'POST',
			buildRequestUrl(state.modal.entityType, state.modal.mode === 'edit' ? state.modal.itemId : ''),
			{ item: buildSubmitPayload() }
		).then(function (response) {
			applyResponse(response);
			state.modal = null;
			render();
		}).catch(function (error) {
			var payloadData = error && error.payload && error.payload.data ? error.payload.data : {};
			state.modal.loading = false;
			state.modal.errors = payloadData.errors && typeof payloadData.errors === 'object' ? payloadData.errors : {};
			state.message = {
				type: 'error',
				text: error.message || t('manager.design.colors.save_failed')
			};
			render();
		});
	}

	function openMediaLibrary() {
		if (!state.modal || state.modal.entityType !== 'pattern') {
			return;
		}

		var draft = state.modal.draft;
		draft.mediaBrowserOpen = !draft.mediaBrowserOpen;
		draft.mediaBrowserError = '';

		if (!draft.mediaBrowserOpen || draft.mediaBrowserLoaded || draft.mediaBrowserLoading || !state.mediaLibraryUrl) {
			render();
			return;
		}

		draft.mediaBrowserLoading = true;
		render();

		requestJson('GET', state.mediaLibraryUrl).then(function (response) {
			draft.mediaBrowserLoading = false;
			draft.mediaBrowserLoaded = true;
			draft.mediaLibraryItems = Array.isArray(response.items) ? response.items : [];
			render();
		}).catch(function (error) {
			draft.mediaBrowserLoading = false;
			draft.mediaBrowserError = error.message || t('manager.design.colors.media_upload_failed');
			render();
		});
	}

	function assignMediaItem(item) {
		if (!state.modal || state.modal.entityType !== 'pattern' || !item) {
			return;
		}

		var draft = state.modal.draft;
		draft.image_attachment_id = String(item.attachment_id || '');
		draft.image_url = String(item.url || '');
		draft.image_thumb_url = String(item.thumb_url || item.url || '');
		draft.image_name = String(item.name || '');
		draft.image_mime_type = String(item.mime_type || '');
		draft.image_width = String(item.width || '');
		draft.image_height = String(item.height || '');
		draft.mediaBrowserOpen = false;
		draft.mediaBrowserError = '';
		render();
	}

	function removeAssignedMedia() {
		if (!state.modal || state.modal.entityType !== 'pattern') {
			return;
		}

		var draft = state.modal.draft;
		draft.image_attachment_id = '';
		draft.image_url = '';
		draft.image_thumb_url = '';
		draft.image_name = '';
		draft.image_mime_type = '';
		draft.image_width = '';
		draft.image_height = '';
		render();
	}

	function uploadMediaFile(file) {
		if (!state.modal || state.modal.entityType !== 'pattern' || !file || !state.mediaUploadUrl) {
			return;
		}

		var formData = new FormData();

		formData.append('file', file);
		state.modal.loading = true;
		render();

		requestUpload(state.mediaUploadUrl, formData).then(function (response) {
			state.modal.loading = false;
			assignMediaItem(response.item || null);
			state.message = response.message ? { type: 'success', text: String(response.message) } : null;
			render();
		}).catch(function (error) {
			state.modal.loading = false;
			state.message = {
				type: 'error',
				text: error.message || t('manager.design.colors.media_upload_failed')
			};
			render();
		});
	}

	root.addEventListener('click', function (event) {
		var openLibrary = event.target.closest('[data-color-open-library]');
		var back = event.target.closest('[data-color-back]');
		var tab = event.target.closest('[data-color-tab]');
		var create = event.target.closest('[data-color-create]');
		var edit = event.target.closest('[data-color-edit]');
		var remove = event.target.closest('[data-color-delete]');
		var close = event.target.closest('[data-color-close-modal]');
		var save = event.target.closest('[data-color-save-modal]');
		var dismiss = event.target.closest('[data-color-dismiss-message]');
		var helpToggle = event.target.closest('[data-color-help-toggle]');
		var overlay = event.target.closest('[data-color-modal-overlay]');
		var swatchButton = event.target.closest('[data-color-swatch-button]');
		var angleChip = event.target.closest('[data-color-angle]');
		var optionChip = event.target.closest('[data-color-option-field]');
		var patternType = event.target.closest('[data-color-pattern-type]');
		var mediaUpload = event.target.closest('[data-color-media-upload]');
		var mediaOpenLibrary = event.target.closest('[data-color-media-open-library]');
		var mediaSelect = event.target.closest('[data-color-media-select]');
		var mediaRemove = event.target.closest('[data-color-media-remove]');
		var fileInput;
		var mediaItem;

		if (openLibrary) {
			state.view = 'library';
			state.helpOpen = false;
			render();
			return;
		}

		if (back) {
			state.view = 'landing';
			state.helpOpen = false;
			state.message = null;
			render();
			return;
		}

		if (tab) {
			state.activeTab = tab.getAttribute('data-color-tab') || 'colors';
			state.helpOpen = false;
			state.message = null;
			render();
			return;
		}

		if (create) {
			openFormModal(create.getAttribute('data-color-create') || getCurrentEntityType());
			return;
		}

		if (edit) {
			openFormModal(edit.getAttribute('data-color-entity') || getCurrentEntityType(), edit.getAttribute('data-color-edit') || '');
			return;
		}

		if (remove) {
			openDeleteModal(remove.getAttribute('data-color-entity') || getCurrentEntityType(), remove.getAttribute('data-color-delete') || '', remove);
			return;
		}

		if (close) {
			closeModal();
			return;
		}

		if (save) {
			submitModal();
			return;
		}

		if (dismiss) {
			state.message = null;
			render();
			return;
		}

		if (helpToggle) {
			state.helpOpen = !state.helpOpen;
			render();
			return;
		}

		if (swatchButton) {
			fileInput = root.querySelector('[data-color-picker-input="' + swatchButton.getAttribute('data-color-swatch-button') + '"]');
			if (fileInput) {
				fileInput.click();
			}
			return;
		}

		if (angleChip) {
			setDraftEnum('angle', angleChip.getAttribute('data-color-angle') || '135');
			return;
		}

		if (optionChip) {
			setDraftEnum(optionChip.getAttribute('data-color-option-field') || '', optionChip.getAttribute('data-color-option-value') || '');
			return;
		}

		if (patternType) {
			setPatternType(patternType.getAttribute('data-color-pattern-type') || getDefaultPatternType());
			return;
		}

		if (mediaUpload) {
			fileInput = root.querySelector('[data-color-media-file="true"]');
			if (fileInput) {
				fileInput.click();
			}
			return;
		}

		if (mediaOpenLibrary) {
			openMediaLibrary();
			return;
		}

		if (mediaSelect) {
			mediaItem = (state.modal && state.modal.draft && Array.isArray(state.modal.draft.mediaLibraryItems) ? state.modal.draft.mediaLibraryItems : []).find(function (item) {
				return String(item.attachment_id || '') === String(mediaSelect.getAttribute('data-color-media-select') || '');
			}) || null;
			assignMediaItem(mediaItem);
			return;
		}

		if (mediaRemove) {
			removeAssignedMedia();
			return;
		}

		if (overlay && event.target === overlay) {
			closeModal();
		}
	});

	root.addEventListener('input', function (event) {
		var field = event.target.closest('[data-color-modal-field]');
		var fieldName;

		if (field) {
			fieldName = field.getAttribute('data-color-modal-field') || '';
			updateDraftField(fieldName, field.value);
			if (
				fieldName === 'value_hex' ||
				fieldName === 'first_color_hex' ||
				fieldName === 'second_color_hex' ||
				fieldName === 'primary_hex' ||
				fieldName === 'background_hex' ||
				fieldName === 'accent_hex' ||
				fieldName === 'overlay_hex' ||
				fieldName === 'opacity' ||
				fieldName === 'dimness' ||
				fieldName === 'blur'
			) {
				render();
			}
		}
	});

	root.addEventListener('change', function (event) {
		var file = event.target.closest('[data-color-media-file]');
		var picker = event.target.closest('[data-color-picker-input]');

		if (picker) {
			updateDraftField(picker.getAttribute('data-color-picker-input') || '', picker.value);
			render();
			return;
		}

		if (file && file.files && file.files[0]) {
			uploadMediaFile(file.files[0]);
		}
	});

	getManagerUi().bindHelpTooltipLayer(root, {
		triggerSelector: '[data-color-help-toggle]',
		popoverSelector: '[data-color-help-popover]',
		onOpen: function () {
			if (!state.helpOpen) {
				state.helpOpen = true;
				render();
			}
		},
		onClose: function () {
			if (state.helpOpen) {
				state.helpOpen = false;
				render();
			}
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			if (state.modal) {
				closeModal();
			} else if (state.helpOpen) {
				state.helpOpen = false;
				render();
			}
		}
	});

	document.addEventListener('click', function (event) {
		if (!root.contains(event.target) && !event.target.closest('[data-color-help-popover]') && state.helpOpen) {
			state.helpOpen = false;
			render();
		}
	});

	window.addEventListener('resize', function () {
		if (state.helpOpen) {
			render();
		}
	});

	window.SonyraColorController = {
		init: function () {
			render();
		},
		handleRouteChange: function (route) {
			state.routeActive = route === 'design';
			if (!state.routeActive) {
				state.helpOpen = false;
				state.modal = null;
			}
			render();
		}
	};
}());
