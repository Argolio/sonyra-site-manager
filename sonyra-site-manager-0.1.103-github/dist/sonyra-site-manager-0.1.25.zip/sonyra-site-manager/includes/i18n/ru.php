<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'login.product_name'           => 'Пульт сайта',
	'login.publisher'              => 'SONYRA STUDIO',
	'login.kicker'                 => 'ПУЛЬТ САЙТА',
	'login.title_identifier'       => 'ВХОД В ПУЛЬТ САЙТА',
	'login.description_identifier' => 'Введите электронную почту или логин, чтобы получить код доступа',
	'login.identifier_label'       => 'Электронная почта или логин',
	'login.identifier_placeholder' => 'name@example.com или логин',
	'login.request_button'         => 'Получить код',
	'login.neutral_status'         => 'Пароль не нужен — если доступ разрешён, код будет отправлен на указанную почту',
	'login.title_code'             => 'ВВЕДИТЕ КОД ИЗ ПИСЬМА',
	'login.description_code'       => 'Введите шестизначный код, который был отправлен после запроса доступа',
	'login.code_label'             => 'Код из письма',
	'login.code_placeholder'       => '••••••',
	'login.verify_button'          => 'Войти',
	'login.resend'                 => 'Отправить код ещё раз',
	'login.change_identifier'      => 'Изменить почту или логин',
	'login.title_success'          => 'ВХОД ПОДТВЕРЖДЁН',
	'login.description_success'    => 'Переход к Пульту сайта будет доступен после проверки доступа',
	'login.title_error'            => 'ВХОД НЕ ПОДТВЕРЖДЁН',
	'login.description_error'      => 'Проверьте код и попробуйте ещё раз',
	'login.retry_button'           => 'Повторить',
	'login.footer_rights_holder'   => 'ИП Катаев С.А.',
);
