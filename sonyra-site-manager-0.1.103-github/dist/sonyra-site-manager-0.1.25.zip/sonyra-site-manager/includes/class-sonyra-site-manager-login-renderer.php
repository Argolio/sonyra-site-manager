<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Login_Renderer {

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	public static function get_preview_state(): string {
		$state = 'identifier';

		if ( isset( $_GET['sonyra_login_preview'] ) ) {
			$state = sanitize_key( wp_unslash( $_GET['sonyra_login_preview'] ) );
		}

		$allowed_states = array( 'identifier', 'code', 'success', 'error' );

		if ( ! in_array( $state, $allowed_states, true ) ) {
			return 'identifier';
		}

		return $state;
	}

	public static function render_placeholder(): void {
		self::render_login_shell();
	}

	public static function render_login_shell(): void {
		$state    = self::get_preview_state();
		$title    = self::text( 'login.title_identifier' );
		$css_url  = plugins_url( 'assets/css/sonyra-login.css', SONYRA_SITE_MANAGER_FILE );
		$icon_url = plugins_url( 'assets/images/sonyra-site-manager-icon.svg', SONYRA_SITE_MANAGER_FILE );
		$year     = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );

		if ( function_exists( 'add_query_arg' ) ) {
			$icon_url = add_query_arg( 'ver', SONYRA_SITE_MANAGER_VERSION, $icon_url );
		} else {
			$icon_url .= '?ver=' . rawurlencode( SONYRA_SITE_MANAGER_VERSION );
		}
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?></title>
	<link rel="icon" type="image/svg+xml" href="<?php echo esc_url( $icon_url ); ?>">
	<link rel="shortcut icon" href="<?php echo esc_url( $icon_url ); ?>">
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( SONYRA_SITE_MANAGER_VERSION ); ?>">
</head>
<body class="sonyra-login-page">
	<div id="sonyra-login-root">
		<div class="sonyra-login-shell">
			<div class="sonyra-login-brand" aria-label="<?php echo esc_attr( self::text( 'login.product_name' ) ); ?>">
				<img src="<?php echo esc_url( $icon_url ); ?>" alt="" class="sonyra-login-brand-icon" aria-hidden="true">
				<div class="sonyra-login-brand-copy">
					<div class="sonyra-login-brand-title"><?php echo esc_html( self::text( 'login.product_name' ) ); ?></div>
					<div class="sonyra-login-brand-meta"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></div>
				</div>
			</div>

			<main class="sonyra-login-card">
				<?php if ( 'code' === $state ) : ?>
					<?php self::render_code_state(); ?>
				<?php elseif ( 'success' === $state ) : ?>
					<?php self::render_success_state(); ?>
				<?php elseif ( 'error' === $state ) : ?>
					<?php self::render_error_state(); ?>
				<?php else : ?>
					<?php self::render_identifier_state(); ?>
				<?php endif; ?>
			</main>

			<footer class="sonyra-login-footer">
				<div><?php echo esc_html( self::text( 'login.publisher' ) ); ?></div>
				<div><?php echo esc_html( '© ' . $year . ' ' . self::text( 'login.footer_rights_holder' ) ); ?></div>
			</footer>
		</div>
	</div>
</body>
</html>
		<?php
	}

	private static function render_identifier_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-identifier" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_identifier' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_identifier' ) ); ?></p>
			</div>

			<form class="sonyra-login-form" aria-describedby="sonyra-login-status">
				<div class="sonyra-login-field">
					<label class="sonyra-login-label" for="sonyra-login-identifier"><?php echo esc_html( self::text( 'login.identifier_label' ) ); ?></label>
					<input class="sonyra-login-input" id="sonyra-login-identifier" type="text" name="sonyra_login_identifier" autocomplete="username" inputmode="email" placeholder="<?php echo esc_attr( self::text( 'login.identifier_placeholder' ) ); ?>">
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.request_button' ) ); ?></button>
			</form>

			<div id="sonyra-login-status" class="sonyra-login-status" aria-live="polite"><?php echo esc_html( self::text( 'login.neutral_status' ) ); ?></div>
		</section>
		<?php
	}

	private static function render_code_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-code" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_code' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_code' ) ); ?></p>
			</div>

			<form class="sonyra-login-form">
				<div class="sonyra-login-field">
					<label class="sonyra-login-label" for="sonyra-login-code"><?php echo esc_html( self::text( 'login.code_label' ) ); ?></label>
					<input class="sonyra-login-input sonyra-login-input-code" id="sonyra-login-code" type="text" name="sonyra_login_code" maxlength="6" inputmode="numeric" autocomplete="one-time-code" placeholder="<?php echo esc_attr( self::text( 'login.code_placeholder' ) ); ?>">
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.verify_button' ) ); ?></button>

				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.resend' ) ); ?></button>
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.change_identifier' ) ); ?></button>
				</div>
			</form>
		</section>
		<?php
	}

	private static function render_success_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-success" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_success' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_success' ) ); ?></p>
			</div>
		</section>
		<?php
	}

	private static function render_error_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-error" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_error' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_error' ) ); ?></p>
			</div>

			<div class="sonyra-login-form">
				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.retry_button' ) ); ?></button>
				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.change_identifier' ) ); ?></button>
				</div>
			</div>
		</section>
		<?php
	}
}
