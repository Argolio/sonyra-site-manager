<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_REST_Color_Controller {

	const REST_NAMESPACE = 'sonyra-site-manager/v1';

	public static function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/design/colors',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_data' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_design' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'save_data' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_design_with_nonce' ),
				),
			)
		);
	}

	public static function permission_manage_design( WP_REST_Request $request ) {
		unset( $request );

		$context = self::get_auth_context();

		if ( empty( $context['authenticated'] ) || ! class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) || ! Sonyra_Site_Manager_Auth_Access_Guard::can_manage_settings( $context ) ) {
			return new WP_Error( 'sonyra_color_controller_forbidden', self::text( 'manager.design.colors.forbidden' ), array( 'status' => 403 ) );
		}

		return true;
	}

	public static function permission_manage_design_with_nonce( WP_REST_Request $request ) {
		$permission = self::permission_manage_design( $request );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$context = self::get_auth_context();
		$nonce   = (string) $request->get_header( 'x-sonyra-color-controller-nonce' );

		if ( ! class_exists( 'Sonyra_Site_Manager_Color_Controller' ) || ! Sonyra_Site_Manager_Color_Controller::verify_nonce( $nonce, $context ) ) {
			return new WP_Error( 'sonyra_color_controller_invalid_nonce', self::text( 'manager.design.colors.invalid_nonce' ), array( 'status' => 403 ) );
		}

		return true;
	}

	public static function get_data( WP_REST_Request $request ) {
		unset( $request );

		return rest_ensure_response( self::build_response() );
	}

	public static function save_data( WP_REST_Request $request ) {
		$payload = $request->get_json_params();

		if ( ! is_array( $payload ) || ! isset( $payload['data'] ) || ! is_array( $payload['data'] ) ) {
			return new WP_Error( 'sonyra_color_controller_payload_invalid', self::text( 'manager.design.colors.payload_invalid' ), array( 'status' => 400 ) );
		}

		$saved = Sonyra_Site_Manager_Color_Controller::save_data( $payload['data'] );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		if ( class_exists( 'Sonyra_Site_Manager_Audit_Log' ) ) {
			Sonyra_Site_Manager_Audit_Log::log_event(
				'design.colors.saved',
				array(
					'colors'    => count( isset( $saved['colors'] ) && is_array( $saved['colors'] ) ? $saved['colors'] : array() ),
					'gradients' => count( isset( $saved['gradients'] ) && is_array( $saved['gradients'] ) ? $saved['gradients'] : array() ),
					'patterns'  => count( isset( $saved['patterns'] ) && is_array( $saved['patterns'] ) ? $saved['patterns'] : array() ),
				),
				'info'
			);
		}

		return rest_ensure_response( self::build_response( self::text( 'manager.design.colors.saved_notice' ) ) );
	}

	private static function build_response( string $message = '' ): array {
		$data = class_exists( 'Sonyra_Site_Manager_Color_Controller' ) ? Sonyra_Site_Manager_Color_Controller::get_data() : array();

		return array(
			'success' => true,
			'message' => $message,
			'summary' => class_exists( 'Sonyra_Site_Manager_Color_Controller' ) ? Sonyra_Site_Manager_Color_Controller::get_summary( $data ) : array(),
			'data'    => $data,
		);
	}

	private static function get_auth_context(): array {
		if ( ! class_exists( 'Sonyra_Site_Manager_Auth_Access_Guard' ) ) {
			return array();
		}

		return Sonyra_Site_Manager_Auth_Access_Guard::get_current_auth_context();
	}

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}
}

if ( function_exists( 'add_action' ) ) {
	add_action( 'rest_api_init', array( 'Sonyra_Site_Manager_REST_Color_Controller', 'register_routes' ) );
}
