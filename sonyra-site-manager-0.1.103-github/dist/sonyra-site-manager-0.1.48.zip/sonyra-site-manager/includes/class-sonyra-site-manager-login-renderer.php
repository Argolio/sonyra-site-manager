<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sonyra_Site_Manager_Login_Renderer {

	private static function text( string $key ): string {
		if ( class_exists( 'Sonyra_Site_Manager_I18n' ) ) {
			return Sonyra_Site_Manager_I18n::t( $key );
		}

		return '';
	}

	private static function versioned_asset_url( string $url, string $path, string $query_arg = 'ver' ): string {
		if ( ! file_exists( $path ) ) {
			return '';
		}

		$asset_mtime = filemtime( $path );
		$asset_version = SONYRA_SITE_MANAGER_VERSION;

		if ( is_int( $asset_mtime ) ) {
			$asset_version .= '-' . $asset_mtime;
		}

		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( $query_arg, $asset_version, $url );
		}

		return $url . '?' . rawurlencode( $query_arg ) . '=' . rawurlencode( $asset_version );
	}

	private static function render_word_spans( string $text ): void {
		$words = preg_split( '/\s+/u', trim( $text ) );

		if ( ! is_array( $words ) || empty( $words ) ) {
			echo esc_html( $text );
			return;
		}

		foreach ( $words as $word ) {
			if ( '' === $word ) {
				continue;
			}

			echo '<span class="sonyra-login-title-word">' . esc_html( $word ) . '</span>';
		}
	}

	private static function get_request_code_config(): array {
		$rest_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/request-code' ) : '';
		$verify_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/verify-code' ) : '';
		$setup_device_code_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/setup-device-code' ) : '';
		$device_code_login_url = function_exists( 'rest_url' ) ? rest_url( 'sonyra-site-manager/v1/auth/device-code-login' ) : '';
		$nonce = function_exists( 'wp_create_nonce' ) ? wp_create_nonce( 'wp_rest' ) : '';
		$initial_step = self::should_show_quick_login() ? 'quick-login' : 'identifier';

		return array(
			'restUrl'            => $rest_url,
			'verifyUrl'          => $verify_url,
			'setupDeviceCodeUrl' => $setup_device_code_url,
			'deviceCodeLoginUrl' => $device_code_login_url,
			'nonce'              => $nonce,
			'initialStep'        => $initial_step,
			'messages'           => array(
				'loading'        => self::text( 'login.request_loading' ),
				'success'        => self::text( 'login.request_success' ),
				'error'          => self::text( 'login.request_error' ),
				'empty'          => self::text( 'login.request_empty' ),
				'verifyLoading'  => self::text( 'login.verify_loading' ),
				'verifySuccess'  => self::text( 'login.verify_success' ),
				'verifyError'    => self::text( 'login.verify_error' ),
				'verifyErrorHint' => self::text( 'login.verify_error_hint' ),
				'verifyEmpty'    => self::text( 'login.verify_empty' ),
				'verifyInvalid'  => self::text( 'login.verify_invalid' ),
				'verifyNotReady' => self::text( 'login.verify_not_ready' ),
				'verifyNotReadyHint' => self::text( 'login.verify_not_ready_hint' ),
				'verifyInvalidCode' => self::text( 'login.verify_invalid_code' ),
				'verifyInvalidCodeHint' => self::text( 'login.verify_invalid_code_hint' ),
				'verifyExpiredCode' => self::text( 'login.verify_expired_code' ),
				'verifyExpiredCodeHint' => self::text( 'login.verify_expired_code_hint' ),
				'verifyTooManyAttempts' => self::text( 'login.verify_too_many_attempts' ),
				'verifyTooManyAttemptsHint' => self::text( 'login.verify_too_many_attempts_hint' ),
				'successStatus'  => self::text( 'login.success_status' ),
				'requestSuccessHint' => self::text( 'login.request_success_hint' ),
				'requestErrorHint' => self::text( 'login.request_error_hint' ),
				'requestNeutralTitle' => self::text( 'login.request_neutral_title' ),
				'requestNeutralHint' => self::text( 'login.request_neutral_hint' ),
				'requestCooldownTitle' => self::text( 'login.request_cooldown_title' ),
				'requestCooldownHint' => self::text( 'login.request_cooldown_hint' ),
				'requestLimitTitle' => self::text( 'login.request_limit_title' ),
				'requestLimitHint' => self::text( 'login.request_limit_hint' ),
				'requestLockedTitle' => self::text( 'login.request_locked_title' ),
				'requestLockedHint' => self::text( 'login.request_locked_hint' ),
				'rememberDeviceFailedTitle' => self::text( 'login.remember_device_failed_title' ),
				'rememberDeviceFailedHint' => self::text( 'login.remember_device_failed_hint' ),
				'deviceCodeInvalidFormat' => self::text( 'login.device_code_invalid_format' ),
				'deviceCodeInvalidFormatHint' => self::text( 'login.device_code_invalid_format_hint' ),
				'deviceCodeMissing3' => self::text( 'login.device_code_missing_3' ),
				'deviceCodeMissing2' => self::text( 'login.device_code_missing_2' ),
				'deviceCodeMissing1' => self::text( 'login.device_code_missing_1' ),
				'deviceCodeMissingHint' => self::text( 'login.device_code_missing_hint' ),
				'deviceCodeEmptyHint' => self::text( 'login.device_code_empty_hint' ),
				'deviceCodeMismatch' => self::text( 'login.device_code_mismatch' ),
				'deviceCodeMismatchHint' => self::text( 'login.device_code_mismatch_hint' ),
				'deviceCodeInvalid' => self::text( 'login.device_code_invalid' ),
				'deviceCodeInvalidHint' => self::text( 'login.device_code_invalid_hint' ),
				'deviceCodeLocked' => self::text( 'login.device_code_locked' ),
				'deviceCodeLockedHint' => self::text( 'login.device_code_locked_hint' ),
				'deviceCodeUnavailable' => self::text( 'login.device_code_unavailable' ),
				'deviceCodeUnavailableHint' => self::text( 'login.device_code_unavailable_hint' ),
				'deviceCodeSetupFailed' => self::text( 'login.device_code_setup_failed' ),
				'deviceCodeSetupFailedHint' => self::text( 'login.device_code_setup_failed_hint' ),
				'deviceCodeSetupSavedStatus' => self::text( 'login.device_code_setup_success_status' ),
				'deviceCodeSetupSavedLead' => self::text( 'login.device_code_setup_success_lead' ),
				'quickLoginLoading' => self::text( 'login.device_code_login_loading' ),
				'quickLoginSuccess' => self::text( 'login.device_code_login_success' ),
				'quickLoginSuccessHint' => self::text( 'login.device_code_login_success_hint' ),
				'setupLoading' => self::text( 'login.device_code_setup_loading' ),
			),
		);
	}

	private static function should_show_quick_login(): bool {
		if ( ! class_exists( 'Sonyra_Site_Manager_Auth_Cookie' ) || ! class_exists( 'Sonyra_Site_Manager_Auth_Trusted_Devices' ) ) {
			return false;
		}

		$session_result = Sonyra_Site_Manager_Auth_Cookie::validate_cookie();

		if ( ! empty( $session_result['valid'] ) ) {
			return false;
		}

		$device_status = Sonyra_Site_Manager_Auth_Trusted_Devices::get_current_device_login_status();

		return ! empty( $device_status['available'] );
	}

	private static function render_request_code_config(): void {
		$config = self::get_request_code_config();
		$json_options = 0;

		if ( defined( 'JSON_HEX_TAG' ) ) {
			$json_options = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
		}

		$encoded = function_exists( 'wp_json_encode' ) ? wp_json_encode( $config, $json_options ) : json_encode( $config, $json_options );

		if ( ! is_string( $encoded ) ) {
			$encoded = '{}';
		}
		?>
		<script type="application/json" id="sonyra-login-request-code-config"><?php echo $encoded; ?></script>
		<?php
	}

	private static function render_request_code_script(): void {
		?>
		<script>
			(function () {
				'use strict';

				function setStatus(statusElement, message, hint, state) {
					if (!statusElement) {
						return;
					}

					statusElement.classList.remove('sonyra-login-status-neutral', 'sonyra-login-status-success', 'sonyra-login-status-warning', 'sonyra-login-status-error');
					statusElement.classList.add('sonyra-login-status-' + (state === 'success' || state === 'warning' || state === 'error' ? state : 'neutral'));
					statusElement.textContent = '';

					if (message) {
						var messageElement = document.createElement('span');
						messageElement.textContent = message;
						statusElement.appendChild(messageElement);
					}

					if (hint) {
						var hintElement = document.createElement('span');
						hintElement.textContent = hint;
						statusElement.appendChild(hintElement);
					}
				}

				function getConfig() {
					var configElement = document.getElementById('sonyra-login-request-code-config');

					if (!configElement) {
						return {};
					}

					try {
						return JSON.parse(configElement.textContent || '{}');
					} catch (error) {
						return {};
					}
				}

				function readPath(data, key) {
					if (!data) {
						return '';
					}

					if (data[key]) {
						return String(data[key]);
					}

					if (data.data && data.data[key]) {
						return String(data.data[key]);
					}

					if (data.result && data.result[key]) {
						return String(data.result[key]);
					}

					return '';
				}

				function getChallengeUuid(data) {
					return readPath(data, 'challenge_uuid');
				}

				function getErrorCode(data) {
					return readPath(data, 'reason_code') || readPath(data, 'error_code') || readPath(data, 'code');
				}

				function getRequestStatusMessage(data, messages, hasChallenge) {
					var reasonCode = getErrorCode(data);
					var title = readPath(data, 'message');
					var hint = readPath(data, 'hint');

					if (hasChallenge) {
						return { title: title || messages.success || '', hint: hint || messages.requestSuccessHint || '', state: 'success' };
					}

					if (reasonCode === 'cooldown') {
						return { title: title || messages.requestCooldownTitle || '', hint: hint || messages.requestCooldownHint || '', state: 'warning' };
					}

					if (reasonCode === 'send_window_limit') {
						return { title: title || messages.requestLimitTitle || '', hint: hint || messages.requestLimitHint || '', state: 'warning' };
					}

					if (reasonCode === 'locked') {
						return { title: title || messages.requestLockedTitle || '', hint: hint || messages.requestLockedHint || '', state: 'warning' };
					}

					if (reasonCode === 'technical') {
						return { title: title || messages.error || '', hint: hint || messages.requestErrorHint || '', state: 'error' };
					}

					return { title: title || messages.requestNeutralTitle || '', hint: hint || messages.requestNeutralHint || '', state: 'neutral' };
				}

				function getVerifyErrorMessage(errorData, messages) {
					var errorCode = getErrorCode(errorData);

					if (errorCode === 'invalid_code') {
						return { title: messages.verifyInvalidCode || '', hint: messages.verifyInvalidCodeHint || '' };
					}

					if (errorCode === 'expired_code') {
						return { title: messages.verifyExpiredCode || '', hint: messages.verifyExpiredCodeHint || '' };
					}

					if (errorCode === 'too_many_attempts') {
						return { title: messages.verifyTooManyAttempts || '', hint: messages.verifyTooManyAttemptsHint || '' };
					}

					return { title: messages.verifyError || '', hint: messages.verifyErrorHint || '' };
				}

				function getDeviceCodeErrorMessage(errorData, messages) {
					var errorCode = getErrorCode(errorData);
					var title = readPath(errorData, 'message');
					var hint = readPath(errorData, 'hint');

					if (errorCode === 'invalid_format') {
						return { title: title || messages.deviceCodeInvalidFormat || '', hint: hint || messages.deviceCodeInvalidFormatHint || '' };
					}

					if (errorCode === 'mismatch') {
						return { title: title || messages.deviceCodeMismatch || '', hint: hint || messages.deviceCodeMismatchHint || '' };
					}

					if (errorCode === 'invalid_code') {
						return { title: title || messages.deviceCodeInvalid || '', hint: hint || messages.deviceCodeInvalidHint || '' };
					}

					if (errorCode === 'locked') {
						return { title: title || messages.deviceCodeLocked || '', hint: hint || messages.deviceCodeLockedHint || '' };
					}

					if (errorCode === 'device_unavailable') {
						return { title: title || messages.deviceCodeUnavailable || '', hint: hint || messages.deviceCodeUnavailableHint || '' };
					}

					return { title: title || messages.deviceCodeSetupFailed || '', hint: hint || messages.deviceCodeSetupFailedHint || '' };
				}

				function getIncompleteDeviceCodeMessage(code, messages) {
					var digitsCount = (code || '').replace(/\D+/g, '').slice(0, 4).length;
					var missingCount = Math.max(0, 4 - digitsCount);

					if (missingCount === 3) {
						return { title: messages.deviceCodeMissing3 || '', hint: messages.deviceCodeMissingHint || '' };
					}

					if (missingCount === 2) {
						return { title: messages.deviceCodeMissing2 || '', hint: messages.deviceCodeMissingHint || '' };
					}

					if (missingCount === 1) {
						return { title: messages.deviceCodeMissing1 || '', hint: messages.deviceCodeMissingHint || '' };
					}

					return { title: messages.deviceCodeInvalidFormat || '', hint: messages.deviceCodeEmptyHint || '' };
				}

				function showStep(steps, name) {
					steps.forEach(function (step) {
						step.hidden = step.getAttribute('data-sonyra-login-step') !== name;
					});
				}

				function getCodeFromCells(codeCells) {
					return codeCells.map(function (cell) {
						return (cell.value || '').replace(/\D+/g, '').slice(0, 1);
					}).join('');
				}

				function clearCells(codeCells) {
					codeCells.forEach(function (cell) {
						cell.value = '';
						cell.classList.remove('sonyra-login-code-cell-filled');
					});
					setCodeCellsState(codeCells, '');
				}

				function setCodeCellsState(codeCells, state) {
					if (!codeCells[0]) {
						return;
					}

					var group = codeCells[0].closest('.sonyra-login-code-cells');

					if (!group) {
						return;
					}

					group.classList.remove('sonyra-login-code-cells-error', 'sonyra-login-code-cells-success');

					if (state === 'error' || state === 'success') {
						group.classList.add('sonyra-login-code-cells-' + state);
					}
				}

				function fillCodeCells(codeCells, value, startIndex) {
					var digits = (value || '').replace(/\D+/g, '').slice(0, codeCells.length);
					var index = Math.max(0, startIndex || 0);

					digits.split('').forEach(function (digit) {
						if (codeCells[index]) {
							codeCells[index].value = digit;
							codeCells[index].classList.toggle('sonyra-login-code-cell-filled', digit !== '');
							index += 1;
						}
					});

					if (codeCells[Math.min(index, codeCells.length - 1)]) {
						codeCells[Math.min(index, codeCells.length - 1)].focus();
					}
				}

				function bindDigitCells(codeCells) {
					codeCells.forEach(function (cell, index) {
						cell.addEventListener('input', function () {
							var digits = (cell.value || '').replace(/\D+/g, '');
							cell.value = '';
							cell.classList.remove('sonyra-login-code-cell-filled');
							setCodeCellsState(codeCells, '');
							fillCodeCells(codeCells, digits, index);
						});

						cell.addEventListener('paste', function (event) {
							event.preventDefault();
							fillCodeCells(codeCells, event.clipboardData ? event.clipboardData.getData('text') : '', index);
						});

						cell.addEventListener('keydown', function (event) {
							if (event.key === 'Backspace' && !cell.value && codeCells[index - 1]) {
								event.preventDefault();
								codeCells[index - 1].value = '';
								codeCells[index - 1].classList.remove('sonyra-login-code-cell-filled');
								setCodeCellsState(codeCells, '');
								codeCells[index - 1].focus();
							}

							if (event.key === 'ArrowLeft' && codeCells[index - 1]) {
								event.preventDefault();
								codeCells[index - 1].focus();
							}

							if (event.key === 'ArrowRight' && codeCells[index + 1]) {
								event.preventDefault();
								codeCells[index + 1].focus();
							}
						});
					});
				}

				function updateSuccess(successTitle, successLead, title, lead) {
					if (successTitle && title) {
						successTitle.textContent = title;
					}

					if (successLead && lead) {
						successLead.textContent = lead;
					}
				}

				document.addEventListener('DOMContentLoaded', function () {
					var steps = Array.prototype.slice.call(document.querySelectorAll('[data-sonyra-login-step]'));
					var form = document.querySelector('[data-sonyra-login-request-form]');
					var identifierInput = document.querySelector('[data-sonyra-login-identifier]');
					var submitButton = document.querySelector('[data-sonyra-login-request-button]');
					var statusElement = document.querySelector('[data-sonyra-login-status]');
					var verifyForm = document.querySelector('[data-sonyra-login-verify-form]');
					var codeCells = Array.prototype.slice.call(document.querySelectorAll('[data-sonyra-login-code-cell]'));
					var setupForm = document.querySelector('[data-sonyra-login-setup-code-form]');
					var setupCodeCells = Array.prototype.slice.call(document.querySelectorAll('[data-sonyra-login-setup-code-cell]'));
					var setupConfirmCells = Array.prototype.slice.call(document.querySelectorAll('[data-sonyra-login-setup-confirm-cell]'));
					var setupButton = document.querySelector('[data-sonyra-login-setup-code-button]');
					var setupSkipButton = document.querySelector('[data-sonyra-login-setup-skip]');
					var quickForm = document.querySelector('[data-sonyra-login-quick-form]');
					var quickCodeCells = Array.prototype.slice.call(document.querySelectorAll('[data-sonyra-login-quick-code-cell]'));
					var quickButton = document.querySelector('[data-sonyra-login-quick-button]');
					var quickAlternativeButton = document.querySelector('[data-sonyra-login-quick-alternative]');
					var verifyButton = document.querySelector('[data-sonyra-login-verify-button]');
					var rememberDeviceSwitch = document.querySelector('[data-sonyra-login-remember-switch]');
					var rememberDevicePanel = document.querySelector('[data-sonyra-login-remember-panel]');
					var rememberDeviceInfoButton = document.querySelector('[data-sonyra-login-remember-info]');
					var rememberDeviceTooltip = document.querySelector('[data-sonyra-login-remember-tooltip]');
					var changeIdentifierButton = document.querySelector('[data-sonyra-login-change-identifier]');
					var successTitle = document.querySelector('[data-sonyra-login-success-title]');
					var successLead = document.querySelector('[data-sonyra-login-success-lead]');
					var config = getConfig();
					var messages = config.messages || {};
					var buttonText = submitButton ? submitButton.textContent : '';
					var verifyButtonText = verifyButton ? verifyButton.textContent : '';
					var setupButtonText = setupButton ? setupButton.textContent : '';
					var quickButtonText = quickButton ? quickButton.textContent : '';
					var defaultSuccessTitle = successTitle ? successTitle.textContent : '';
					var defaultSuccessLead = successLead ? successLead.textContent : '';
					var requestChallengeUuid = '';
					var rememberDevice = false;

					if (!form || !identifierInput || !submitButton || !statusElement || !config.restUrl) {
						return;
					}

					bindDigitCells(codeCells);
					bindDigitCells(setupCodeCells);
					bindDigitCells(setupConfirmCells);
					bindDigitCells(quickCodeCells);

					function setRememberDeviceState(isChecked) {
						rememberDevice = isChecked === true;

						if (rememberDeviceSwitch) {
							rememberDeviceSwitch.setAttribute('aria-checked', rememberDevice ? 'true' : 'false');
							rememberDeviceSwitch.classList.toggle('sonyra-login-switch-checked', rememberDevice);
						}

						if (rememberDevicePanel) {
							rememberDevicePanel.classList.toggle('sonyra-login-switch-panel-checked', rememberDevice);
						}
					}

					function setRememberTooltipOpen(isOpen) {
						if (!rememberDeviceInfoButton || !rememberDeviceTooltip) {
							return;
						}

						rememberDeviceInfoButton.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
						rememberDeviceTooltip.hidden = isOpen !== true;

						if (rememberDevicePanel) {
							rememberDevicePanel.classList.toggle('sonyra-login-switch-panel-tooltip-open', isOpen === true);
						}
					}

					function closeRememberTooltip() {
						setRememberTooltipOpen(false);
					}

					if (rememberDeviceSwitch) {
						setRememberDeviceState(false);
						rememberDeviceSwitch.addEventListener('click', function () { setRememberDeviceState(!rememberDevice); });
						rememberDeviceSwitch.addEventListener('keydown', function (event) {
							if (event.key === ' ' || event.key === 'Enter') {
								event.preventDefault();
								setRememberDeviceState(!rememberDevice);
							}
						});
					}

					if (rememberDeviceInfoButton && rememberDeviceTooltip) {
						setRememberTooltipOpen(false);
						rememberDeviceInfoButton.addEventListener('mouseenter', function () { setRememberTooltipOpen(true); });
						rememberDeviceInfoButton.addEventListener('focus', function () { setRememberTooltipOpen(true); });
						rememberDeviceInfoButton.addEventListener('click', function (event) {
							event.preventDefault();
							event.stopPropagation();
							setRememberTooltipOpen(rememberDeviceTooltip.hidden === true);
						});
					}

					if (rememberDevicePanel && rememberDeviceTooltip) {
						rememberDevicePanel.addEventListener('mouseleave', closeRememberTooltip);
						rememberDevicePanel.addEventListener('focusout', function (event) {
							if (!rememberDevicePanel.contains(event.relatedTarget)) {
								closeRememberTooltip();
							}
						});
					}

					document.addEventListener('keydown', function (event) {
						if (event.key === 'Escape') {
							closeRememberTooltip();
						}
					});

					document.addEventListener('click', function (event) {
						if (rememberDevicePanel && !rememberDevicePanel.contains(event.target)) {
							closeRememberTooltip();
						}
					});

					if (config.initialStep === 'quick-login' && quickCodeCells[0]) {
						showStep(steps, 'quick-login');
						quickCodeCells[0].focus();
					}

					form.addEventListener('submit', function (event) {
						event.preventDefault();
						requestChallengeUuid = '';
						clearCells(codeCells);

						var identifier = (identifierInput.value || '').trim();

						if (!identifier) {
							setStatus(statusElement, messages.empty || '');
							identifierInput.focus();
							return;
						}

						submitButton.disabled = true;
						submitButton.textContent = messages.loading || buttonText;
						setStatus(statusElement, messages.loading || '', '', 'neutral');

						fetch(config.restUrl, {
							method: 'POST',
							credentials: 'same-origin',
							headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
							body: JSON.stringify({ email: identifier, identifier: identifier })
						}).then(function (response) {
							if (!response.ok) {
								throw new Error('request_failed');
							}

							return response.json();
						}).then(function (data) {
							if (!data || data.success === false) {
								throw new Error('request_failed');
							}

							requestChallengeUuid = getChallengeUuid(data);
							var requestStatus = getRequestStatusMessage(data, messages, !!requestChallengeUuid);
							setStatus(statusElement, requestStatus.title, requestStatus.hint, requestStatus.state);

							if (requestChallengeUuid) {
								showStep(steps, 'verify');
								if (codeCells[0]) {
									codeCells[0].focus();
								}
							}
						}).catch(function () {
							setStatus(statusElement, messages.error || '', messages.requestErrorHint || '', 'error');
						}).finally(function () {
							submitButton.disabled = false;
							submitButton.textContent = buttonText;
						});
					});

					if (changeIdentifierButton) {
						changeIdentifierButton.addEventListener('click', function () {
							requestChallengeUuid = '';
							clearCells(codeCells);
							setStatus(statusElement, '', '', 'neutral');
							showStep(steps, 'identifier');
							identifierInput.focus();
						});
					}

					if (quickAlternativeButton) {
						quickAlternativeButton.addEventListener('click', function () {
							clearCells(quickCodeCells);
							setStatus(statusElement, '', '', 'neutral');
							showStep(steps, 'identifier');
							identifierInput.focus();
						});
					}

					if (verifyForm && codeCells.length === 6 && verifyButton && config.verifyUrl) {
						verifyForm.addEventListener('submit', function (event) {
							event.preventDefault();

							var code = getCodeFromCells(codeCells);

							if (!code) {
								setStatus(statusElement, messages.verifyEmpty || '');
								codeCells[0].focus();
								return;
							}

							if (!/^\d{6}$/.test(code)) {
								setStatus(statusElement, messages.verifyInvalid || '');
								(codeCells.find(function (cell) { return !cell.value; }) || codeCells[0]).focus();
								return;
							}

							if (!requestChallengeUuid) {
								setStatus(statusElement, messages.verifyNotReady || '', messages.verifyNotReadyHint || '', 'warning');
								return;
							}

							verifyButton.disabled = true;
							verifyButton.textContent = messages.verifyLoading || verifyButtonText;
							setStatus(statusElement, messages.verifyLoading || '', '', 'neutral');

							fetch(config.verifyUrl, {
								method: 'POST',
								credentials: 'same-origin',
								headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
								body: JSON.stringify({ challenge_uuid: requestChallengeUuid, code: code, remember_device: rememberDevice === true })
							}).then(function (response) {
								return response.json().catch(function () { return {}; }).then(function (data) {
									data = data || {};
									data.responseOk = response.ok;
									return data;
								});
							}).then(function (data) {
								if (!data || data.responseOk !== true || data.authenticated !== true) {
									throw data || {};
								}

								if (data.next_step === 'setup_device_code' || data.device_code_setup_required === true) {
									setStatus(statusElement, readPath(data, 'message') || messages.verifySuccess || '', '', 'success');
									showStep(steps, 'setup-device-code');
									if (setupCodeCells[0]) {
										setupCodeCells[0].focus();
									}
									return;
								}

								if (data.device_remember_failed === true) {
									setStatus(statusElement, readPath(data, 'message') || messages.rememberDeviceFailedTitle || '', readPath(data, 'hint') || messages.rememberDeviceFailedHint || '', 'warning');
								} else {
									setStatus(statusElement, messages.successStatus || '', '', 'success');
								}

								updateSuccess(successTitle, successLead, defaultSuccessTitle, defaultSuccessLead);
								showStep(steps, 'success');
							}).catch(function (errorData) {
								var errorMessage = getVerifyErrorMessage(errorData, messages);
								setStatus(statusElement, errorMessage.title, errorMessage.hint, 'error');
							}).finally(function () {
								verifyButton.disabled = false;
								verifyButton.textContent = verifyButtonText;
							});
						});
					}

					if (setupForm && setupButton && config.setupDeviceCodeUrl) {
						setupForm.addEventListener('submit', function (event) {
							event.preventDefault();

							var setupCode = getCodeFromCells(setupCodeCells);
							var setupConfirm = getCodeFromCells(setupConfirmCells);

							if (!/^\d{4}$/.test(setupCode)) {
								var setupCodeMessage = getIncompleteDeviceCodeMessage(setupCode, messages);
								setCodeCellsState(setupCodeCells, 'error');
								setStatus(statusElement, setupCodeMessage.title, setupCodeMessage.hint, 'error');
								(setupCodeCells.find(function (cell) { return !cell.value; }) || setupCodeCells[0]).focus();
								return;
							}

							if (!/^\d{4}$/.test(setupConfirm)) {
								var setupConfirmMessage = getIncompleteDeviceCodeMessage(setupConfirm, messages);
								setCodeCellsState(setupConfirmCells, 'error');
								setStatus(statusElement, setupConfirmMessage.title, setupConfirmMessage.hint, 'error');
								(setupConfirmCells.find(function (cell) { return !cell.value; }) || setupConfirmCells[0]).focus();
								return;
							}

							if (setupCode !== setupConfirm) {
								setCodeCellsState(setupCodeCells, 'error');
								setStatus(statusElement, messages.deviceCodeMismatch || '', messages.deviceCodeMismatchHint || '', 'error');
								setupConfirmCells.forEach(function (cell) {
									cell.value = '';
									cell.classList.remove('sonyra-login-code-cell-filled');
								});
								setCodeCellsState(setupConfirmCells, 'error');
								if (setupConfirmCells[0]) {
									setupConfirmCells[0].focus();
								}
								return;
							}

							setupButton.disabled = true;
							setupButton.textContent = messages.setupLoading || setupButtonText;
							setStatus(statusElement, messages.setupLoading || '', '', 'neutral');

							fetch(config.setupDeviceCodeUrl, {
								method: 'POST',
								credentials: 'same-origin',
								headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
								body: JSON.stringify({ code: setupCode, code_confirm: setupConfirm })
							}).then(function (response) {
								return response.json().catch(function () { return {}; }).then(function (data) {
									data = data || {};
									data.responseOk = response.ok;
									return data;
								});
							}).then(function (data) {
								if (!data || data.responseOk !== true || data.success !== true) {
									throw data || {};
								}

								updateSuccess(successTitle, successLead, messages.deviceCodeSetupSavedStatus || '', messages.deviceCodeSetupSavedLead || '');
								setCodeCellsState(setupCodeCells, 'success');
								setCodeCellsState(setupConfirmCells, 'success');
								setStatus(statusElement, messages.deviceCodeSetupSavedStatus || '', '', 'success');
								showStep(steps, 'success');
							}).catch(function (errorData) {
								var errorMessage = getDeviceCodeErrorMessage(errorData, messages);
								setCodeCellsState(setupCodeCells, 'error');
								setCodeCellsState(setupConfirmCells, 'error');
								setStatus(statusElement, errorMessage.title, errorMessage.hint, 'error');
							}).finally(function () {
								setupButton.disabled = false;
								setupButton.textContent = setupButtonText;
							});
						});
					}

					if (setupSkipButton) {
						setupSkipButton.addEventListener('click', function () {
							clearCells(setupCodeCells);
							clearCells(setupConfirmCells);
							updateSuccess(successTitle, successLead, defaultSuccessTitle, defaultSuccessLead);
							setStatus(statusElement, messages.successStatus || '', '', 'success');
							showStep(steps, 'success');
						});
					}

					if (quickForm && quickButton && config.deviceCodeLoginUrl) {
						quickForm.addEventListener('submit', function (event) {
							event.preventDefault();

							var quickCode = getCodeFromCells(quickCodeCells);

							if (!/^\d{4}$/.test(quickCode)) {
								var quickCodeMessage = getIncompleteDeviceCodeMessage(quickCode, messages);
								setCodeCellsState(quickCodeCells, 'error');
								setStatus(statusElement, quickCodeMessage.title, quickCodeMessage.hint, 'error');
								(quickCodeCells.find(function (cell) { return !cell.value; }) || quickCodeCells[0]).focus();
								return;
							}

							quickButton.disabled = true;
							quickButton.textContent = messages.quickLoginLoading || quickButtonText;
							setStatus(statusElement, messages.quickLoginLoading || '', '', 'neutral');

							fetch(config.deviceCodeLoginUrl, {
								method: 'POST',
								credentials: 'same-origin',
								headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
								body: JSON.stringify({ code: quickCode })
							}).then(function (response) {
								return response.json().catch(function () { return {}; }).then(function (data) {
									data = data || {};
									data.responseOk = response.ok;
									return data;
								});
							}).then(function (data) {
								if (!data || data.responseOk !== true || data.authenticated !== true) {
									throw data || {};
								}

								updateSuccess(successTitle, successLead, messages.quickLoginSuccess || '', messages.quickLoginSuccessHint || '');
								setCodeCellsState(quickCodeCells, 'success');
								setStatus(statusElement, readPath(data, 'message') || messages.quickLoginSuccess || '', readPath(data, 'hint') || messages.quickLoginSuccessHint || '', 'success');
								showStep(steps, 'success');
							}).catch(function (errorData) {
								var errorMessage = getDeviceCodeErrorMessage(errorData, messages);
								setCodeCellsState(quickCodeCells, 'error');
								setStatus(statusElement, errorMessage.title, errorMessage.hint, 'error');
							}).finally(function () {
								quickButton.disabled = false;
								quickButton.textContent = quickButtonText;
							});
						});
					}
				});
			}());
		</script>
		<?php
	}

	public static function get_preview_state(): string {
		$state = 'identifier';

		if ( isset( $_GET['sonyra_login_preview'] ) ) {
			$state = sanitize_key( wp_unslash( $_GET['sonyra_login_preview'] ) );
		}

		$allowed_states = array( 'identifier', 'code', 'success', 'error' );

		if ( ! in_array( $state, $allowed_states, true ) ) {
			return 'identifier';
		}

		return $state;
	}

	public static function render_placeholder(): void {
		self::render_login_shell();
	}

	public static function render_manager_placeholder(): void {
		$title = self::text( 'manager.placeholder_title' );
		$css_url  = plugins_url( 'assets/css/sonyra-login.css', SONYRA_SITE_MANAGER_FILE );
		$logo_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-logo.png';
		$logo_url  = plugins_url( 'assets/images/brand/pult-site-logo.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_ico_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon.ico';
		$favicon_ico_url  = plugins_url( 'assets/images/brand/pult-site-favicon.ico', SONYRA_SITE_MANAGER_FILE );
		$favicon_32_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-32.png';
		$favicon_32_url  = plugins_url( 'assets/images/brand/pult-site-favicon-32.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_192_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-192.png';
		$favicon_192_url  = plugins_url( 'assets/images/brand/pult-site-favicon-192.png', SONYRA_SITE_MANAGER_FILE );
		$apple_touch_icon_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-apple-touch-icon-180.png';
		$apple_touch_icon_url  = plugins_url( 'assets/images/brand/pult-site-apple-touch-icon-180.png', SONYRA_SITE_MANAGER_FILE );
		$year = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );
		$logo_url_with_ver = self::versioned_asset_url( $logo_url, $logo_path );
		$favicon_ico_url_with_ver = self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' );
		$favicon_32_url_with_ver = self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' );
		$favicon_192_url_with_ver = self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' );
		$apple_touch_icon_url_with_ver = self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' );
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?></title>
	<?php if ( '' !== $favicon_ico_url_with_ver ) : ?>
	<link rel="icon" href="<?php echo esc_url( $favicon_ico_url_with_ver ); ?>" sizes="any">
	<link rel="shortcut icon" href="<?php echo esc_url( $favicon_ico_url_with_ver ); ?>" type="image/x-icon">
	<?php endif; ?>
	<?php if ( '' !== $favicon_32_url_with_ver ) : ?>
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( $favicon_32_url_with_ver ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $favicon_192_url_with_ver ) : ?>
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( $favicon_192_url_with_ver ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $apple_touch_icon_url_with_ver ) : ?>
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( $apple_touch_icon_url_with_ver ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( SONYRA_SITE_MANAGER_VERSION ); ?>">
</head>
<body class="sonyra-login-page sonyra-manager-placeholder-page">
	<div id="sonyra-login-root">
		<div class="sonyra-login-shell">
			<div class="sonyra-login-brand" aria-label="<?php echo esc_attr( self::text( 'login.product_name' ) ); ?>">
				<?php if ( '' !== $logo_url_with_ver ) : ?>
					<img src="<?php echo esc_url( $logo_url_with_ver ); ?>" alt="" class="sonyra-login-brand-icon" aria-hidden="true" decoding="async">
				<?php endif; ?>
				<div class="sonyra-login-brand-copy">
					<div class="sonyra-login-brand-title"><?php echo esc_html( self::text( 'login.product_name' ) ); ?></div>
					<div class="sonyra-login-brand-meta"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></div>
				</div>
			</div>

			<main class="sonyra-login-card">
				<section class="sonyra-manager-placeholder" aria-labelledby="sonyra-manager-placeholder-title">
					<div class="sonyra-login-card-header">
						<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
						<h1 id="sonyra-manager-placeholder-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'manager.placeholder_title' ) ); ?></h1>
						<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'manager.placeholder_lead' ) ); ?></p>
					</div>

					<div class="sonyra-login-status">
						<span><?php echo esc_html( self::text( 'manager.placeholder_status' ) ); ?></span>
						<span><?php echo esc_html( self::text( 'manager.placeholder_next' ) ); ?></span>
					</div>
				</section>
			</main>

			<footer class="sonyra-login-footer">
				<span class="sonyra-login-footer-item"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></span>
				<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
				<span class="sonyra-login-footer-item"><?php echo esc_html( '© ' . $year . ' ' . self::text( 'login.footer_rights_holder' ) ); ?></span>
				<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
				<span class="sonyra-login-footer-item sonyra-login-footer-version"><?php echo esc_html( self::text( 'login.version_label' ) . ' ' . SONYRA_SITE_MANAGER_VERSION ); ?></span>
			</footer>
		</div>
	</div>
</body>
</html>
		<?php
	}

	public static function render_login_shell(): void {
		$state    = self::get_preview_state();
		$title    = self::text( 'login.title_identifier' );
		$css_url  = plugins_url( 'assets/css/sonyra-login.css', SONYRA_SITE_MANAGER_FILE );
		$logo_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-logo.png';
		$logo_url  = plugins_url( 'assets/images/brand/pult-site-logo.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_ico_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon.ico';
		$favicon_ico_url  = plugins_url( 'assets/images/brand/pult-site-favicon.ico', SONYRA_SITE_MANAGER_FILE );
		$favicon_32_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-32.png';
		$favicon_32_url  = plugins_url( 'assets/images/brand/pult-site-favicon-32.png', SONYRA_SITE_MANAGER_FILE );
		$favicon_192_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-favicon-192.png';
		$favicon_192_url  = plugins_url( 'assets/images/brand/pult-site-favicon-192.png', SONYRA_SITE_MANAGER_FILE );
		$apple_touch_icon_path = plugin_dir_path( SONYRA_SITE_MANAGER_FILE ) . 'assets/images/brand/pult-site-apple-touch-icon-180.png';
		$apple_touch_icon_url  = plugins_url( 'assets/images/brand/pult-site-apple-touch-icon-180.png', SONYRA_SITE_MANAGER_FILE );
		$year     = function_exists( 'date_i18n' ) ? date_i18n( 'Y' ) : date( 'Y' );
		$logo_url_with_ver = self::versioned_asset_url( $logo_url, $logo_path );
		$favicon_ico_url_with_ver = self::versioned_asset_url( $favicon_ico_url, $favicon_ico_path, 'sonyra_favicon' );
		$favicon_32_url_with_ver = self::versioned_asset_url( $favicon_32_url, $favicon_32_path, 'sonyra_favicon' );
		$favicon_192_url_with_ver = self::versioned_asset_url( $favicon_192_url, $favicon_192_path, 'sonyra_favicon' );
		$apple_touch_icon_url_with_ver = self::versioned_asset_url( $apple_touch_icon_url, $apple_touch_icon_path, 'sonyra_favicon' );
		?>
<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?></title>
	<!-- SONYRA Site Manager favicon build: 0.1.28 -->
	<?php if ( '' !== $favicon_ico_url_with_ver ) : ?>
	<link rel="icon" href="<?php echo esc_url( $favicon_ico_url_with_ver ); ?>" sizes="any">
	<link rel="shortcut icon" href="<?php echo esc_url( $favicon_ico_url_with_ver ); ?>" type="image/x-icon">
	<?php endif; ?>
	<?php if ( '' !== $favicon_32_url_with_ver ) : ?>
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( $favicon_32_url_with_ver ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $favicon_192_url_with_ver ) : ?>
	<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( $favicon_192_url_with_ver ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $apple_touch_icon_url_with_ver ) : ?>
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( $apple_touch_icon_url_with_ver ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo esc_attr( SONYRA_SITE_MANAGER_VERSION ); ?>">
	<?php self::render_request_code_config(); ?>
</head>
<body class="sonyra-login-page">
	<div id="sonyra-login-root">
		<div class="sonyra-login-shell">
			<div class="sonyra-login-brand" aria-label="<?php echo esc_attr( self::text( 'login.product_name' ) ); ?>">
				<?php if ( '' !== $logo_url_with_ver ) : ?>
					<img src="<?php echo esc_url( $logo_url_with_ver ); ?>" alt="" class="sonyra-login-brand-icon" aria-hidden="true" decoding="async">
				<?php endif; ?>
				<div class="sonyra-login-brand-copy">
					<div class="sonyra-login-brand-title"><?php echo esc_html( self::text( 'login.product_name' ) ); ?></div>
					<div class="sonyra-login-brand-meta"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></div>
				</div>
			</div>

			<main class="sonyra-login-card">
				<?php if ( 'code' === $state ) : ?>
					<?php self::render_code_state(); ?>
				<?php elseif ( 'success' === $state ) : ?>
					<?php self::render_success_state(); ?>
				<?php elseif ( 'error' === $state ) : ?>
					<?php self::render_error_state(); ?>
				<?php else : ?>
					<?php self::render_identifier_state(); ?>
				<?php endif; ?>
			</main>

			<footer class="sonyra-login-footer">
				<span class="sonyra-login-footer-item"><?php echo esc_html( self::text( 'login.publisher' ) ); ?></span>
				<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
				<span class="sonyra-login-footer-item"><?php echo esc_html( '© ' . $year . ' ' . self::text( 'login.footer_rights_holder' ) ); ?></span>
				<span class="sonyra-login-footer-separator" aria-hidden="true">·</span>
				<span class="sonyra-login-footer-item sonyra-login-footer-version"><?php echo esc_html( self::text( 'login.version_label' ) . ' ' . SONYRA_SITE_MANAGER_VERSION ); ?></span>
			</footer>
		</div>
	</div>
	<?php self::render_request_code_script(); ?>
</body>
</html>
		<?php
	}

	private static function render_identifier_state(): void {
		?>
			<section class="sonyra-login-section sonyra-login-section-identifier" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-step" data-sonyra-login-step="quick-login" hidden>
				<div class="sonyra-login-card-header">
					<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
					<h1 class="sonyra-login-title"><?php echo esc_html( self::text( 'login.quick_login_title' ) ); ?></h1>
					<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.quick_login_hint' ) ); ?></p>
				</div>

				<form class="sonyra-login-form sonyra-login-device-code-form" data-sonyra-login-quick-form>
					<div class="sonyra-login-device-code-group">
						<div class="sonyra-login-label"><?php echo esc_html( self::text( 'login.quick_login_label' ) ); ?></div>
						<div class="sonyra-login-code-cells sonyra-login-code-cells-four" aria-label="<?php echo esc_attr( self::text( 'login.quick_login_label' ) ); ?>">
							<?php for ( $index = 0; $index < 4; $index++ ) : ?>
								<input class="sonyra-login-code-cell" type="text" name="sonyra_login_quick_code_<?php echo esc_attr( (string) $index ); ?>" inputmode="numeric" autocomplete="off" maxlength="1" aria-label="<?php echo esc_attr( self::text( 'login.quick_login_label' ) . ' ' . ( $index + 1 ) ); ?>" data-sonyra-login-quick-code-cell>
							<?php endfor; ?>
						</div>
					</div>

					<button class="sonyra-login-button sonyra-login-button-primary" type="submit" data-sonyra-login-quick-button><?php echo esc_html( self::text( 'login.quick_login_button' ) ); ?></button>
					<button class="sonyra-login-text-button" type="button" data-sonyra-login-quick-alternative><?php echo esc_html( self::text( 'login.quick_login_alternative' ) ); ?></button>
				</form>
			</div>

			<div class="sonyra-login-step" data-sonyra-login-step="identifier">
				<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_identifier' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_identifier' ) ); ?></p>
				</div>

				<form class="sonyra-login-form" aria-describedby="sonyra-login-status" data-sonyra-login-request-form>
					<div class="sonyra-login-field">
						<label class="sonyra-login-label" for="sonyra-login-identifier"><?php echo esc_html( self::text( 'login.identifier_label' ) ); ?></label>
						<input class="sonyra-login-input" id="sonyra-login-identifier" type="text" name="sonyra_login_identifier" autocomplete="username" inputmode="email" placeholder="<?php echo esc_attr( self::text( 'login.identifier_placeholder' ) ); ?>" data-sonyra-login-identifier>
					</div>

					<button class="sonyra-login-button sonyra-login-button-primary" type="submit" data-sonyra-login-request-button><?php echo esc_html( self::text( 'login.request_button' ) ); ?></button>
				</form>
			</div>

				<div class="sonyra-login-step" data-sonyra-login-step="verify" hidden>
					<div class="sonyra-login-card-header">
					<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
					<h2 class="sonyra-login-title"><?php echo esc_html( self::text( 'login.verify_panel_title' ) ); ?></h2>
					<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.verify_panel_lead' ) ); ?></p>
					<p class="sonyra-login-verify-hint"><?php echo esc_html( self::text( 'login.verify_panel_hint' ) ); ?></p>
				</div>

				<form class="sonyra-login-verify-form" data-sonyra-login-verify-form>
					<div class="sonyra-login-code-cells" aria-label="<?php echo esc_attr( self::text( 'login.code_label' ) ); ?>">
						<?php for ( $index = 0; $index < 6; $index++ ) : ?>
							<input class="sonyra-login-code-cell" type="text" name="sonyra_login_verify_code_<?php echo esc_attr( (string) $index ); ?>" inputmode="numeric" autocomplete="<?php echo 0 === $index ? 'one-time-code' : 'off'; ?>" maxlength="1" aria-label="<?php echo esc_attr( self::text( 'login.code_label' ) . ' ' . ( $index + 1 ) ); ?>" data-sonyra-login-code-cell data-sonyra-login-code-index="<?php echo esc_attr( (string) $index ); ?>">
						<?php endfor; ?>
					</div>

					<button class="sonyra-login-button sonyra-login-button-primary" type="submit" data-sonyra-login-verify-button><?php echo esc_html( self::text( 'login.verify_code_button' ) ); ?></button>
					<div class="sonyra-login-switch-panel" data-sonyra-login-remember-panel>
						<button class="sonyra-login-switch" type="button" role="switch" aria-checked="false" data-sonyra-login-remember-switch>
							<span class="sonyra-login-switch-control" aria-hidden="true">
								<span class="sonyra-login-switch-thumb"></span>
							</span>
							<span class="sonyra-login-switch-copy">
								<span class="sonyra-login-switch-title"><?php echo esc_html( self::text( 'login.remember_device_label' ) ); ?></span>
								<span class="sonyra-login-switch-hint"><?php echo esc_html( self::text( 'login.remember_device_hint' ) ); ?></span>
							</span>
						</button>
						<button class="sonyra-login-switch-info" type="button" aria-label="<?php echo esc_attr( self::text( 'login.remember_device_info_label' ) ); ?>" aria-expanded="false" aria-controls="sonyra-login-remember-tooltip" data-sonyra-login-remember-info>
							<span aria-hidden="true">?</span>
						</button>
						<div id="sonyra-login-remember-tooltip" class="sonyra-login-switch-tooltip" role="tooltip" data-sonyra-login-remember-tooltip hidden>
							<strong class="sonyra-login-switch-tooltip-title"><?php echo esc_html( self::text( 'login.remember_device_tooltip_title' ) ); ?></strong>
							<div class="sonyra-login-switch-tooltip-body">
								<p><?php echo esc_html( self::text( 'login.remember_device_tooltip_body_1' ) ); ?></p>
								<p><?php echo esc_html( self::text( 'login.remember_device_tooltip_body_2' ) ); ?></p>
								<p><?php echo esc_html( self::text( 'login.remember_device_tooltip_body_3' ) ); ?></p>
							</div>
						</div>
					</div>
					<button class="sonyra-login-text-button" type="button" data-sonyra-login-change-identifier><?php echo esc_html( self::text( 'login.verify_change' ) ); ?></button>
				</form>
			</div>

				<div class="sonyra-login-step" data-sonyra-login-step="setup-device-code" hidden>
					<div class="sonyra-login-card-header">
					<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
					<h2 class="sonyra-login-title"><?php echo esc_html( self::text( 'login.device_code_setup_title' ) ); ?></h2>
					<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.device_code_setup_hint' ) ); ?></p>
				</div>

				<form class="sonyra-login-form sonyra-login-device-code-form" data-sonyra-login-setup-code-form>
					<div class="sonyra-login-device-code-group">
						<div class="sonyra-login-label"><?php echo esc_html( self::text( 'login.device_code_setup_first_label' ) ); ?></div>
						<div class="sonyra-login-code-cells sonyra-login-code-cells-four" aria-label="<?php echo esc_attr( self::text( 'login.device_code_setup_first_label' ) ); ?>">
							<?php for ( $index = 0; $index < 4; $index++ ) : ?>
								<input class="sonyra-login-code-cell" type="text" name="sonyra_login_setup_code_<?php echo esc_attr( (string) $index ); ?>" inputmode="numeric" autocomplete="off" maxlength="1" aria-label="<?php echo esc_attr( self::text( 'login.device_code_setup_first_label' ) . ' ' . ( $index + 1 ) ); ?>" data-sonyra-login-setup-code-cell>
							<?php endfor; ?>
						</div>
					</div>

					<div class="sonyra-login-device-code-group">
						<div class="sonyra-login-label"><?php echo esc_html( self::text( 'login.device_code_setup_second_label' ) ); ?></div>
						<div class="sonyra-login-code-cells sonyra-login-code-cells-four" aria-label="<?php echo esc_attr( self::text( 'login.device_code_setup_second_label' ) ); ?>">
							<?php for ( $index = 0; $index < 4; $index++ ) : ?>
								<input class="sonyra-login-code-cell" type="text" name="sonyra_login_setup_confirm_<?php echo esc_attr( (string) $index ); ?>" inputmode="numeric" autocomplete="off" maxlength="1" aria-label="<?php echo esc_attr( self::text( 'login.device_code_setup_second_label' ) . ' ' . ( $index + 1 ) ); ?>" data-sonyra-login-setup-confirm-cell>
							<?php endfor; ?>
						</div>
					</div>

					<button class="sonyra-login-button sonyra-login-button-primary" type="submit" data-sonyra-login-setup-code-button><?php echo esc_html( self::text( 'login.device_code_setup_button' ) ); ?></button>
					<button class="sonyra-login-text-button" type="button" data-sonyra-login-setup-skip><?php echo esc_html( self::text( 'login.device_code_setup_skip' ) ); ?></button>
				</form>
			</div>

				<div class="sonyra-login-step" data-sonyra-login-step="success" hidden>
					<div class="sonyra-login-card-header">
					<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
					<h2 class="sonyra-login-title sonyra-login-title-word-gap" data-sonyra-login-success-title><?php self::render_word_spans( self::text( 'login.success_ready_title' ) ); ?></h2>
					<p class="sonyra-login-lead" data-sonyra-login-success-lead><?php echo esc_html( self::text( 'login.success_ready_lead' ) ); ?></p>
				</div>
			</div>

			<div id="sonyra-login-status" class="sonyra-login-status" aria-live="polite" data-sonyra-login-status>
				<span><?php echo esc_html( self::text( 'login.neutral_status_line_1' ) ); ?></span>
				<span><?php echo esc_html( self::text( 'login.neutral_status_line_2' ) ); ?></span>
			</div>
		</section>
		<?php
	}

	private static function render_code_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-code" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_code' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_code' ) ); ?></p>
			</div>

			<form class="sonyra-login-form">
				<div class="sonyra-login-code-cells" aria-label="<?php echo esc_attr( self::text( 'login.code_label' ) ); ?>">
					<?php for ( $index = 0; $index < 6; $index++ ) : ?>
						<input class="sonyra-login-code-cell" type="text" name="sonyra_login_code_<?php echo esc_attr( (string) $index ); ?>" inputmode="numeric" autocomplete="<?php echo 0 === $index ? 'one-time-code' : 'off'; ?>" maxlength="1" aria-label="<?php echo esc_attr( self::text( 'login.code_label' ) . ' ' . ( $index + 1 ) ); ?>">
					<?php endfor; ?>
				</div>

				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.verify_code_button' ) ); ?></button>

				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.resend' ) ); ?></button>
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.change_identifier' ) ); ?></button>
				</div>
			</form>
		</section>
		<?php
	}

	private static function render_success_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-success" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_success' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_success' ) ); ?></p>
			</div>
		</section>
		<?php
	}

	private static function render_error_state(): void {
		?>
		<section class="sonyra-login-section sonyra-login-section-error" aria-labelledby="sonyra-login-title">
			<div class="sonyra-login-card-header">
				<p class="sonyra-login-kicker"><?php echo esc_html( self::text( 'login.kicker' ) ); ?></p>
				<h1 id="sonyra-login-title" class="sonyra-login-title"><?php echo esc_html( self::text( 'login.title_error' ) ); ?></h1>
				<p class="sonyra-login-lead"><?php echo esc_html( self::text( 'login.description_error' ) ); ?></p>
			</div>

			<div class="sonyra-login-form">
				<button class="sonyra-login-button sonyra-login-button-primary" type="button"><?php echo esc_html( self::text( 'login.retry_button' ) ); ?></button>
				<div class="sonyra-login-actions">
					<button class="sonyra-login-text-button" type="button"><?php echo esc_html( self::text( 'login.change_identifier' ) ); ?></button>
				</div>
			</div>
		</section>
		<?php
	}
}
